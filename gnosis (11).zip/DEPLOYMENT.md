# GNOSIS Networking & Deployment Architecture

GNOSIS runs as a **100% static frontend deployment** (Vercel / static CDN) backed by your existing **Supabase** project (`VITE_SUPABASE_URL` + `VITE_SUPABASE_ANON_KEY`) — no standalone Node.js WebSocket server, Railway service, or Docker container is required.

## 1. Networking Separation by Subsystem

| Subsystem | Networking Infrastructure | How It Works |
|---|---|---|
| **GNOSIS Online Room** (`GameProtocol.tsx`) | Supabase Postgres (`game_rooms`) + Supabase Realtime (`src/supabaseClient.ts`) | Preserved intact for turn-based board/classic chambers, matchmaking, and persistence. |
| **GNOSIS Strike FPS** (`ws-shooter`) | Supabase Realtime (Broadcast + Presence) + `game_rooms` Lobby (`ShooterRoomHost`) | ~14Hz host-coordinated round/defusal/hit simulation with Presence host failover and ~16Hz client state broadcast. |
| **Titan Assault: ODM** (`ws-titan`) | Supabase Realtime + `game_rooms` Lobby (`TitanRoomHost`) + Solo Expedition | Host-coordinated Titan wave, grapple, and nape slash sync, plus full offline Solo Expedition mode. |
| **GNOSIS Racing** (`ws-racing`) | Supabase Realtime + `game_rooms` Lobby (`RacingRoomHost`) + Solo Time Trial | Host-coordinated 8-car spline slipstream & lap sync, plus full offline Solo Time Trial mode. |
| **GNOSIS Grand Strategy** (`ws-hoi4`) | Supabase Realtime + `game_rooms` Lobby (`Hoi4RoomHost`) + Solo World Campaign | Host-coordinated 176-nation theater ticks & command sync, plus full local Solo Campaign engine (`localEngine.ts`). |

## 2. Why `/ws/titan` Previously Failed & What Changed

Previously, frontend code attempted `new WebSocket(\`wss://\${host}/ws/titan\`)` (or required an external `VITE_GAME_SERVER_URL` server running `server.ts`), which returned HTTP 404 on static Vercel deployments.

Now `src/workshop/net/gameNetwork.ts` uses your existing Supabase project directly:
1. **Room Discovery (`createWorkshopLobbyClient`)**: Uses a one-shot query + Postgres Changes subscription on `public.game_rooms` (filtered by `game_id=eq.ws-<channel>`) with stale-room filtering instead of database polling.
2. **Real-Time Sync (`openWorkshopRoom`)**: Uses Supabase Realtime `Broadcast` (low-latency player state, inputs, and host snapshots) and `Presence` (live peer tracking, deterministic lowest-ID host election, and automatic host migration when the host disconnects).
3. **Host-Coordinated Authority Limitations**: Because Supabase Realtime runs without a custom dedicated server binary, one connected peer acts as the Room Host executing `ShooterRoomHost`, `RacingRoomHost`, `TitanRoomHost`, or `Hoi4RoomHost`. State validation is therefore host-coordinated rather than trustless anti-cheat server-authoritative.

## 3. Deploying on Vercel (or Any Static Host)

1. Configure two public environment variables in Vercel:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY` (public anon key only — never expose `service_role`)
2. Ensure `supabase/migrations/001_game_rooms.sql` has been applied to your Supabase project (`public.game_rooms` table + `supabase_realtime` publication).
3. Build command: `npm run build` (outputs static `dist/`).
