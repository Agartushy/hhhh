# GNOSIS Game Protocol — Supabase Realtime Multiplayer Setup

To enable real two-device internet multiplayer for **Chess**, **Aether Vault Co-op**, **Tic-Tac-Toe**, **Connect Four**, and **Rock Paper Scissors**:

## 1. Create a Supabase Project
1. Sign in at [supabase.com](https://supabase.com/) and create a new project.
2. In your project dashboard, open **Project Settings → API**.
3. Copy:
   - **Project URL** (`VITE_SUPABASE_URL`)
   - **anon / public key** (`VITE_SUPABASE_ANON_KEY`)
   > Never use or expose the `service_role` secret key in the frontend.

## 2. Run the Database Migration
1. Open **SQL Editor** in your Supabase dashboard.
2. Copy the contents of `supabase/migrations/001_game_rooms.sql` and run it.
3. Verify in **Database → Publications → supabase_realtime** that `public.game_rooms` is enabled.

## 3. Configure Environment Variables
Create a `.env` file in the project root (or set environment variables in your deployment host):

```env
VITE_SUPABASE_URL=https://your-project-ref.supabase.co
VITE_SUPABASE_ANON_KEY=your-public-anon-key
```

Restart the dev server (`npm run dev`). Once configured, the **Online Multiplayer** tab inside Game Protocol will automatically connect and allow creating and joining live room codes across devices.
