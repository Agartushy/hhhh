-- GNOSIS Academy · Game Protocol Multiplayer Schema
-- Run this migration in your Supabase SQL Editor to enable real two-device
-- online multiplayer across Chess, Tic-Tac-Toe, Connect Four, RPS, and Co-op Vault.

create table if not exists public.game_rooms (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  game_id text not null,
  status text not null default 'waiting' check (status in ('waiting', 'playing', 'finished', 'closed')),
  host_id text not null,
  host_name text not null default 'Host',
  guest_id text,
  guest_name text,
  turn text not null default 'host',
  state jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_game_rooms_code on public.game_rooms (code);
create index if not exists idx_game_rooms_updated_at on public.game_rooms (updated_at);

-- Automatically refresh updated_at on every row update
create or replace function public.touch_game_rooms_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_game_rooms_updated_at on public.game_rooms;
create trigger trg_game_rooms_updated_at
before update on public.game_rooms
for each row execute function public.touch_game_rooms_updated_at();

-- Enable Row Level Security
alter table public.game_rooms enable row level security;

-- Allow players using the public anon key to browse/join rooms by code,
-- create rooms, and synchronize game state updates.
-- Note: For production hardening with user accounts, restrict updates to authenticated
-- session IDs matching host_id or guest_id.
drop policy if exists "Allow public read game_rooms" on public.game_rooms;
create policy "Allow public read game_rooms"
  on public.game_rooms
  for select
  to anon, authenticated
  using (true);

drop policy if exists "Allow public insert game_rooms" on public.game_rooms;
create policy "Allow public insert game_rooms"
  on public.game_rooms
  for insert
  to anon, authenticated
  with check (char_length(code) between 4 and 12);

drop policy if exists "Allow public update game_rooms" on public.game_rooms;
create policy "Allow public update game_rooms"
  on public.game_rooms
  for update
  to anon, authenticated
  using (status <> 'closed')
  with check (true);

-- Enable Supabase Realtime Postgres Changes for this table
do $$
begin
  if not exists (
    select 1
    from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'game_rooms'
  ) then
    alter publication supabase_realtime add table public.game_rooms;
  end if;
end
$$;
