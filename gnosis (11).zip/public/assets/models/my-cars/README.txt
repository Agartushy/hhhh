GNOSIS RACING — CUSTOM 3D VEHICLE MODELS FOLDER
================================================

1. WHERE TO PLACE YOUR MODELS
   Place all of your downloaded 3D car files directly inside this folder:

       public/assets/models/my-cars/

2. HOW MANY FILES ARE REQUIRED
   GNOSIS Racing has exactly 8 predefined vehicle slots in the showroom.
   You need 8 separate .glb files (glTF 2.0 Binary format).

3. EXACT FILENAMES REQUIRED
   Rename your 8 downloaded .glb car models to these exact filenames:

       car-1.glb   -> Slot 1: Meridian GT (Sports Car)
       car-2.glb   -> Slot 2: Apex Sovereign V12 (Supercar)
       car-3.glb   -> Slot 3: Ironclad V8 Muscle (Muscle Car)
       car-4.glb   -> Slot 4: Kurogane S-Spec (Drift Car)
       car-5.glb   -> Slot 5: Alpine RS Rally (Rally Car)
       car-6.glb   -> Slot 6: Titan 4x4 Baja (Off-Road Vehicle)
       car-7.glb   -> Slot 7: Zephyr 240 Spyder (Lightweight Roadster)
       car-8.glb   -> Slot 8: Aether-X Formula (Racing Car)

4. DO NOT CHANGE THESE FILENAMES
   The racing configuration file (src/workshop/racing/myCars.ts) points
   directly to /assets/models/my-cars/car-1.glb through car-8.glb.
   Do not rename these filenames unless you also update modelPath inside
   src/workshop/racing/myCars.ts to match.

5. HOW AUTOMATIC LOADING WORKS
   There is no website upload button. As soon as you place any of car-1.glb
   through car-8.glb in this folder and select that slot in the GNOSIS Racing
   showroom (or reload the page), Three.js GLTFLoader loads the .glb file
   automatically with its original materials, textures, geometry, and
   proportions intact, grounds it on the floor, and frames the camera.

   If a file has not been placed in this folder yet, the showroom will display
   a clear missing-file notice showing which car-X.glb filename is expected.
