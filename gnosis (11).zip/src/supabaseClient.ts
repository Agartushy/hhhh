import { createClient, type RealtimeChannel, type SupabaseClient } from "@supabase/supabase-js";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

export const isSupabaseConfigured = Boolean(
  SUPABASE_URL &&
    SUPABASE_ANON_KEY &&
    SUPABASE_URL.startsWith("http") &&
    SUPABASE_ANON_KEY.length > 10,
);

let client: SupabaseClient | null = null;

export function getSupabaseClient(): SupabaseClient | null {
  if (!isSupabaseConfigured || !SUPABASE_URL || !SUPABASE_ANON_KEY) return null;
  if (!client) {
    client = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      realtime: {
        params: {
          eventsPerSecond: 20,
        },
      },
    });
  }
  return client;
}

export type MultiplayerGameId = "chess" | "coop-vault" | "tictactoe" | "connect4" | "rps";
export type RoomRole = "host" | "guest";

export interface GameRoomRecord {
  id: string;
  code: string;
  game_id: MultiplayerGameId;
  status: "waiting" | "playing" | "finished" | "closed";
  host_id: string;
  host_name: string;
  guest_id: string | null;
  guest_name: string | null;
  turn: string;
  state: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export interface RoomPeerPresence {
  playerId: string;
  playerName: string;
  role: RoomRole;
  onlineAt: string;
}

const PLAYER_ID_KEY = "gnosis-mp-player-id-v1";

export function getLocalPlayerId(): string {
  try {
    const existing = sessionStorage.getItem(PLAYER_ID_KEY);
    if (existing) return existing;
    const generated = `mech-${Math.random().toString(36).slice(2, 10)}-${Date.now().toString(36)}`;
    sessionStorage.setItem(PLAYER_ID_KEY, generated);
    return generated;
  } catch {
    return `mech-${Math.random().toString(36).slice(2, 10)}`;
  }
}

export function generateRoomCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 6; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}

export async function createMultiplayerRoom(params: {
  gameId: MultiplayerGameId;
  playerName: string;
  initialState: Record<string, unknown>;
  initialTurn?: string;
}): Promise<{ room?: GameRoomRecord; error?: string }> {
  const sb = getSupabaseClient();
  if (!sb) {
    return {
      error:
        "Supabase environment variables (VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY) are not configured.",
    };
  }

  const hostId = getLocalPlayerId();
  const code = generateRoomCode();
  const cleanName = params.playerName.trim() || "Host Mechanist";

  const { data, error } = await sb
    .from("game_rooms")
    .insert({
      code,
      game_id: params.gameId,
      status: "waiting",
      host_id: hostId,
      host_name: cleanName,
      turn: params.initialTurn ?? "host",
      state: params.initialState,
    })
    .select("*")
    .single();

  if (error) {
    return {
      error: `Failed to create room in Supabase: ${error.message}. Ensure migration 001_game_rooms.sql has been applied.`,
    };
  }

  return { room: data as GameRoomRecord };
}

export async function joinMultiplayerRoom(params: {
  code: string;
  playerName: string;
}): Promise<{ room?: GameRoomRecord; role?: RoomRole; error?: string }> {
  const sb = getSupabaseClient();
  if (!sb) {
    return {
      error:
        "Supabase environment variables (VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY) are not configured.",
    };
  }

  const normalized = params.code.trim().toUpperCase();
  if (!normalized) return { error: "Enter a valid room code." };

  const playerId = getLocalPlayerId();
  const cleanName = params.playerName.trim() || "Guest Mechanist";

  const { data: existing, error: fetchError } = await sb
    .from("game_rooms")
    .select("*")
    .eq("code", normalized)
    .maybeSingle();

  if (fetchError) {
    return { error: `Lookup failed: ${fetchError.message}` };
  }
  if (!existing) {
    return { error: `No room found with code "${normalized}".` };
  }

  const room = existing as GameRoomRecord;
  if (room.status === "closed") {
    return { error: `Room "${normalized}" has been closed.` };
  }
  if (room.host_id === playerId) {
    return { room, role: "host" };
  }
  if (room.guest_id && room.guest_id !== playerId) {
    return { error: `Room "${normalized}" already has two active players.` };
  }

  const { data: updated, error: updateError } = await sb
    .from("game_rooms")
    .update({
      guest_id: playerId,
      guest_name: cleanName,
      status: "playing",
    })
    .eq("code", normalized)
    .select("*")
    .single();

  if (updateError) {
    return { error: `Could not join room: ${updateError.message}` };
  }

  return { room: updated as GameRoomRecord, role: "guest" };
}

export async function pushRoomState(params: {
  code: string;
  state: Record<string, unknown>;
  turn: string;
  status?: GameRoomRecord["status"];
}): Promise<{ error?: string }> {
  const sb = getSupabaseClient();
  if (!sb) return { error: "Supabase not configured." };

  const patch: Record<string, unknown> = {
    state: params.state,
    turn: params.turn,
  };
  if (params.status) patch.status = params.status;

  const { error } = await sb.from("game_rooms").update(patch).eq("code", params.code);
  if (error) return { error: error.message };
  return {};
}

export async function leaveMultiplayerRoom(params: {
  code: string;
  role: RoomRole;
}): Promise<void> {
  const sb = getSupabaseClient();
  if (!sb) return;
  try {
    if (params.role === "host") {
      await sb.from("game_rooms").update({ status: "closed" }).eq("code", params.code);
    } else {
      await sb
        .from("game_rooms")
        .update({ guest_id: null, guest_name: null, status: "waiting" })
        .eq("code", params.code);
    }
  } catch {
    // Best-effort cleanup on leave
  }
}

export function subscribeToMultiplayerRoom(params: {
  code: string;
  playerId: string;
  playerName: string;
  role: RoomRole;
  onRoomUpdate: (room: GameRoomRecord) => void;
  onBroadcastState: (payload: {
    state: Record<string, unknown>;
    turn: string;
    status?: GameRoomRecord["status"];
    senderId: string;
  }) => void;
  onPresenceSync: (peers: RoomPeerPresence[]) => void;
  onStatusChange: (status: string) => void;
}): {
  sendBroadcast: (payload: {
    state: Record<string, unknown>;
    turn: string;
    status?: GameRoomRecord["status"];
  }) => Promise<void>;
  unsubscribe: () => Promise<void>;
} {
  const sb = getSupabaseClient();
  if (!sb) {
    return {
      sendBroadcast: async () => {},
      unsubscribe: async () => {},
    };
  }

  const channel: RealtimeChannel = sb.channel(`gnosis-room:${params.code}`, {
    config: {
      presence: {
        key: params.playerId,
      },
      broadcast: {
        self: false,
      },
    },
  });

  channel
    .on(
      "postgres_changes",
      {
        event: "UPDATE",
        schema: "public",
        table: "game_rooms",
        filter: `code=eq.${params.code}`,
      },
      (payload) => {
        if (payload.new) {
          params.onRoomUpdate(payload.new as GameRoomRecord);
        }
      },
    )
    .on("broadcast", { event: "state_sync" }, (msg) => {
      const p = msg.payload as {
        state: Record<string, unknown>;
        turn: string;
        status?: GameRoomRecord["status"];
        senderId: string;
      };
      if (p && p.senderId !== params.playerId) {
        params.onBroadcastState(p);
      }
    })
    .on("presence", { event: "sync" }, () => {
      const presenceState = channel.presenceState<RoomPeerPresence>();
      const peers: RoomPeerPresence[] = [];
      Object.values(presenceState).forEach((entries) => {
        entries.forEach((entry) => {
          peers.push(entry);
        });
      });
      params.onPresenceSync(peers);
    })
    .subscribe(async (status) => {
      params.onStatusChange(status);
      if (status === "SUBSCRIBED") {
        await channel.track({
          playerId: params.playerId,
          playerName: params.playerName,
          role: params.role,
          onlineAt: new Date().toISOString(),
        } satisfies RoomPeerPresence);
      }
    });

  return {
    sendBroadcast: async (payload) => {
      await channel.send({
        type: "broadcast",
        event: "state_sync",
        payload: {
          ...payload,
          senderId: params.playerId,
        },
      });
    },
    unsubscribe: async () => {
      try {
        await channel.untrack();
      } catch {
        // Ignore untrack error
      }
      await sb.removeChannel(channel);
    },
  };
}
