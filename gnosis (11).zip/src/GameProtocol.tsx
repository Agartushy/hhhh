import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  DEFAULT_UNTRUSTED_SANDBOX,
  isValidExternalGameUrl,
  loadImportedGames,
  removeImportedGame,
  restoreRegistryGames,
  saveUserImportedGame,
  type ImportedGame,
  type ImportedGameType,
  type ImportedLaunchMode,
} from "./game-imports";
import {
  createMultiplayerRoom,
  getLocalPlayerId,
  isSupabaseConfigured,
  joinMultiplayerRoom,
  leaveMultiplayerRoom,
  pushRoomState,
  subscribeToMultiplayerRoom,
  type GameRoomRecord,
  type MultiplayerGameId,
  type RoomPeerPresence,
  type RoomRole,
} from "./supabaseClient";
import cardChessImg from "./assets/images/card_chess_protocol_1795263403254.jpg";

type BuiltinGameId =
  | "chess"
  | "coop-vault"
  | "tictactoe"
  | "connect4"
  | "rps"
  | "snake"
  | "pong"
  | "2048"
  | "memory"
  | "reaction"
  | "platformer"
  | "puzzle"
  | "minesweeper";

type ProtocolSection = "arcade" | "multiplayer" | "imported";

interface GameMeta {
  id: BuiltinGameId;
  title: string;
  subtitle: string;
  category: string;
  players: string;
  multiplayerSupported?: boolean;
  sigil: string;
  description: string;
  controls: string;
}

const BUILTIN_GAMES: GameMeta[] = [
  {
    id: "chess",
    title: "Chess · Automaton Board",
    subtitle: "Grand Strategy",
    category: "Strategy & Online",
    players: "1P vs AI · 2P Local · 2P Online",
    multiplayerSupported: true,
    sigil: "♞",
    description:
      "Full rules chess with legal move validation, castling, en passant, pawn promotion, checkmate detection, AI opponent, and live two-device online play.",
    controls: "Click a piece to see legal moves, then click destination square.",
  },
  {
    id: "coop-vault",
    title: "Aether Vault Co-op",
    subtitle: "2-Player Cooperative Puzzle",
    category: "Co-op & Online",
    players: "2P Co-op (Local or Online)",
    multiplayerSupported: true,
    sigil: "⚿",
    description:
      "Guide Brass & Copper Sentinels together across 3 chambers. Hold pressure plates, push power cubes, gather Aether Cores, and unlock twin exit seals.",
    controls: "Local: WASD (P1) & Arrows (P2), or toggle active sentinel. Online: 1 sentinel each.",
  },
  {
    id: "tictactoe",
    title: "Tic-Tac-Toe",
    subtitle: "The Ternary Grid",
    category: "Classic & Online",
    players: "1P vs AI · 2P Local · 2P Online",
    multiplayerSupported: true,
    sigil: "✕",
    description:
      "Classic 3×3 tactical duel against an unbeatable minimax automaton, local challenger, or online opponent.",
    controls: "Click any open cell on your turn.",
  },
  {
    id: "connect4",
    title: "Connect Four",
    subtitle: "Chronometric Drop",
    category: "Strategy & Online",
    players: "1P vs AI · 2P Local · 2P Online",
    multiplayerSupported: true,
    sigil: "◉",
    description:
      "Drop brass and copper discs into the vertical frame to align four horizontally, vertically, or diagonally.",
    controls: "Click any column to drop a disc.",
  },
  {
    id: "rps",
    title: "Rock Paper Scissors",
    subtitle: "The Tri-Gear Duel",
    category: "Duel & Online",
    players: "1P vs AI · 2P Online",
    multiplayerSupported: true,
    sigil: "⚔",
    description:
      "Best-of-5 tactical duel. Online mode uses simultaneous secret commit so neither player sees the other's pick before reveal.",
    controls: "Choose Stone, Parchment, or Shears to lock your move.",
  },
  {
    id: "snake",
    title: "Snake",
    subtitle: "Serpent of Brass",
    category: "Arcade",
    players: "1P Arcade",
    sigil: "∿",
    description:
      "Navigate the clockwork serpent across the chamber, consume energy nodes, and survive as velocity climbs.",
    controls: "Arrow keys, WASD, or on-screen directional pad.",
  },
  {
    id: "pong",
    title: "Pong",
    subtitle: "Aether Pendulum",
    category: "Arcade",
    players: "1P vs AI · 2P Local",
    sigil: "▮",
    description:
      "Deflect the pressurized brass sphere with angular paddle physics. First mechanism to 7 points claims victory.",
    controls: "P1: W/S (or Arrows in AI mode). P2 Local: Up/Down arrows.",
  },
  {
    id: "2048",
    title: "2048",
    subtitle: "Alchemical Fusion",
    category: "Puzzle",
    players: "1P Puzzle",
    sigil: "◈",
    description:
      "Slide numbered brass plates across a 4×4 grid to fuse matching values until you forge the 2048 plate.",
    controls: "Arrow keys, WASD, or directional buttons.",
  },
  {
    id: "memory",
    title: "Memory",
    subtitle: "Cabinet of Echoes",
    category: "Puzzle",
    players: "1P Memory",
    sigil: "❖",
    description:
      "Uncover 8 pairs of engraved GNOSIS sigils in as few moves and seconds as possible.",
    controls: "Click cards to flip and match identical pairs.",
  },
  {
    id: "reaction",
    title: "Reaction Speed Test",
    subtitle: "The Ignition Reflex",
    category: "Calibration",
    players: "1P Reflex",
    sigil: "⚡",
    description:
      "Measure your millisecond response time across a 5-round calibration sequence without triggering a false start.",
    controls: "Click Start, wait for the gold signal, then click immediately.",
  },
  {
    id: "platformer",
    title: "Clockwork Ascent",
    subtitle: "Simple Platformer",
    category: "Action",
    players: "1P Platformer",
    sigil: "▲",
    description:
      "Leap across suspended brass girders across 3 stages, dodge spinning gear hazards, collect all cogs, and enter the exit portal.",
    controls: "A/D or Left/Right to move · W/Space/Up to jump (double jump enabled).",
  },
  {
    id: "puzzle",
    title: "15-Plate Brass Cipher",
    subtitle: "Sliding Puzzle",
    category: "Puzzle",
    players: "1P Puzzle",
    sigil: "⊞",
    description:
      "Arrange the 15 numbered plates in ascending order inside a guaranteed-solvable 4×4 mechanical frame.",
    controls: "Click tiles adjacent to the empty slot or use Arrow keys.",
  },
  {
    id: "minesweeper",
    title: "Clockwork Minesweeper",
    subtitle: "Aether Minefield",
    category: "Original Mini-Game",
    players: "1P Deduction",
    sigil: "✹",
    description:
      "Clear all safe chambers on a 9×9 grid containing 10 volatile mines. First click is always protected.",
    controls: "Left-click to reveal · Right-click or Flag Mode to mark mines.",
  },
];

/* ============================================================================
 * ONLINE MULTIPLAYER CONTEXT TYPES
 * ============================================================================ */

interface ActiveOnlineSession {
  room: GameRoomRecord;
  role: RoomRole;
  playerId: string;
  playerName: string;
  peers: RoomPeerPresence[];
  realtimeStatus: string;
  sendState: (state: Record<string, unknown>, turn: string, status?: GameRoomRecord["status"]) => Promise<void>;
}

/* ============================================================================
 * 1. CHESS ENGINE & COMPONENT
 * ============================================================================ */

type ChessColor = "w" | "b";
type ChessPieceType = "p" | "n" | "b" | "r" | "q" | "k";
interface ChessPiece {
  type: ChessPieceType;
  color: ChessColor;
}
type ChessBoard = (ChessPiece | null)[][];

interface ChessState {
  board: ChessBoard;
  turn: ChessColor;
  castling: { wk: boolean; wq: boolean; bk: boolean; bq: boolean };
  enPassant: [number, number] | null;
  history: string[];
  capturedW: ChessPiece[];
  capturedB: ChessPiece[];
  lastMove: { from: [number, number]; to: [number, number] } | null;
  status: "active" | "check" | "checkmate" | "stalemate";
  winner: ChessColor | "draw" | null;
}

const CHESS_GLYPHS: Record<ChessColor, Record<ChessPieceType, string>> = {
  w: { k: "♔", q: "♕", r: "♖", b: "♗", n: "♘", p: "♙" },
  b: { k: "♚", q: "♛", r: "♜", b: "♝", n: "♞", p: "♟" },
};

const PIECE_VALUES: Record<ChessPieceType, number> = {
  p: 100,
  n: 320,
  b: 330,
  r: 500,
  q: 900,
  k: 20000,
};

function createInitialChessState(): ChessState {
  const back: ChessPieceType[] = ["r", "n", "b", "q", "k", "b", "n", "r"];
  const board: ChessBoard = Array.from({ length: 8 }, (_, r) =>
    Array.from({ length: 8 }, (_, c) => {
      if (r === 0) return { type: back[c], color: "b" };
      if (r === 1) return { type: "p", color: "b" };
      if (r === 6) return { type: "p", color: "w" };
      if (r === 7) return { type: back[c], color: "w" };
      return null;
    }),
  );
  return {
    board,
    turn: "w",
    castling: { wk: true, wq: true, bk: true, bq: true },
    enPassant: null,
    history: [],
    capturedW: [],
    capturedB: [],
    lastMove: null,
    status: "active",
    winner: null,
  };
}

function cloneBoard(b: ChessBoard): ChessBoard {
  return b.map((row) => row.map((cell) => (cell ? { ...cell } : null)));
}

function inBounds(r: number, c: number) {
  return r >= 0 && r < 8 && c >= 0 && c < 8;
}

function isSquareAttacked(board: ChessBoard, r: number, c: number, byColor: ChessColor): boolean {
  // Pawn attacks
  const pawnDir = byColor === "w" ? 1 : -1;
  for (const dc of [-1, 1]) {
    const pr = r + pawnDir;
    const pc = c + dc;
    if (inBounds(pr, pc)) {
      const p = board[pr][pc];
      if (p && p.color === byColor && p.type === "p") return true;
    }
  }
  // Knight attacks
  const knightD = [
    [-2, -1],
    [-2, 1],
    [-1, -2],
    [-1, 2],
    [1, -2],
    [1, 2],
    [2, -1],
    [2, 1],
  ];
  for (const [dr, dc] of knightD) {
    const nr = r + dr;
    const nc = c + dc;
    if (inBounds(nr, nc)) {
      const p = board[nr][nc];
      if (p && p.color === byColor && p.type === "n") return true;
    }
  }
  // King attacks
  for (let dr = -1; dr <= 1; dr++) {
    for (let dc = -1; dc <= 1; dc++) {
      if (!dr && !dc) continue;
      const kr = r + dr;
      const kc = c + dc;
      if (inBounds(kr, kc)) {
        const p = board[kr][kc];
        if (p && p.color === byColor && p.type === "k") return true;
      }
    }
  }
  // Orthogonal (rook / queen)
  for (const [dr, dc] of [
    [-1, 0],
    [1, 0],
    [0, -1],
    [0, 1],
  ]) {
    let nr = r + dr;
    let nc = c + dc;
    while (inBounds(nr, nc)) {
      const p = board[nr][nc];
      if (p) {
        if (p.color === byColor && (p.type === "r" || p.type === "q")) return true;
        break;
      }
      nr += dr;
      nc += dc;
    }
  }
  // Diagonal (bishop / queen)
  for (const [dr, dc] of [
    [-1, -1],
    [-1, 1],
    [1, -1],
    [1, 1],
  ]) {
    let nr = r + dr;
    let nc = c + dc;
    while (inBounds(nr, nc)) {
      const p = board[nr][nc];
      if (p) {
        if (p.color === byColor && (p.type === "b" || p.type === "q")) return true;
        break;
      }
      nr += dr;
      nc += dc;
    }
  }
  return false;
}

function findKing(board: ChessBoard, color: ChessColor): [number, number] | null {
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const p = board[r][c];
      if (p && p.color === color && p.type === "k") return [r, c];
    }
  }
  return null;
}

function isInCheck(board: ChessBoard, color: ChessColor): boolean {
  const kp = findKing(board, color);
  if (!kp) return false;
  return isSquareAttacked(board, kp[0], kp[1], color === "w" ? "b" : "w");
}

function getPseudoMoves(state: ChessState, r: number, c: number): [number, number][] {
  const piece = state.board[r][c];
  if (!piece) return [];
  const moves: [number, number][] = [];
  const enemy: ChessColor = piece.color === "w" ? "b" : "w";

  if (piece.type === "p") {
    const dir = piece.color === "w" ? -1 : 1;
    const startRow = piece.color === "w" ? 6 : 1;
    if (inBounds(r + dir, c) && !state.board[r + dir][c]) {
      moves.push([r + dir, c]);
      if (r === startRow && !state.board[r + 2 * dir][c]) {
        moves.push([r + 2 * dir, c]);
      }
    }
    for (const dc of [-1, 1]) {
      const nr = r + dir;
      const nc = c + dc;
      if (inBounds(nr, nc)) {
        const target = state.board[nr][nc];
        if (target && target.color === enemy) {
          moves.push([nr, nc]);
        } else if (state.enPassant && state.enPassant[0] === nr && state.enPassant[1] === nc) {
          moves.push([nr, nc]);
        }
      }
    }
  } else if (piece.type === "n") {
    for (const [dr, dc] of [
      [-2, -1],
      [-2, 1],
      [-1, -2],
      [-1, 2],
      [1, -2],
      [1, 2],
      [2, -1],
      [2, 1],
    ]) {
      const nr = r + dr;
      const nc = c + dc;
      if (inBounds(nr, nc) && state.board[nr][nc]?.color !== piece.color) moves.push([nr, nc]);
    }
  } else if (piece.type === "b" || piece.type === "r" || piece.type === "q") {
    const dirs: [number, number][] = [];
    if (piece.type === "b" || piece.type === "q")
      dirs.push([-1, -1], [-1, 1], [1, -1], [1, 1]);
    if (piece.type === "r" || piece.type === "q")
      dirs.push([-1, 0], [1, 0], [0, -1], [0, 1]);
    for (const [dr, dc] of dirs) {
      let nr = r + dr;
      let nc = c + dc;
      while (inBounds(nr, nc)) {
        const target = state.board[nr][nc];
        if (!target) {
          moves.push([nr, nc]);
        } else {
          if (target.color === enemy) moves.push([nr, nc]);
          break;
        }
        nr += dr;
        nc += dc;
      }
    }
  } else if (piece.type === "k") {
    for (let dr = -1; dr <= 1; dr++) {
      for (let dc = -1; dc <= 1; dc++) {
        if (!dr && !dc) continue;
        const nr = r + dr;
        const nc = c + dc;
        if (inBounds(nr, nc) && state.board[nr][nc]?.color !== piece.color) moves.push([nr, nc]);
      }
    }
    // Castling
    const homeRow = piece.color === "w" ? 7 : 0;
    if (r === homeRow && c === 4 && !isSquareAttacked(state.board, homeRow, 4, enemy)) {
      const canK = piece.color === "w" ? state.castling.wk : state.castling.bk;
      const canQ = piece.color === "w" ? state.castling.wq : state.castling.bq;
      if (
        canK &&
        !state.board[homeRow][5] &&
        !state.board[homeRow][6] &&
        state.board[homeRow][7]?.type === "r" &&
        state.board[homeRow][7]?.color === piece.color &&
        !isSquareAttacked(state.board, homeRow, 5, enemy) &&
        !isSquareAttacked(state.board, homeRow, 6, enemy)
      ) {
        moves.push([homeRow, 6]);
      }
      if (
        canQ &&
        !state.board[homeRow][3] &&
        !state.board[homeRow][2] &&
        !state.board[homeRow][1] &&
        state.board[homeRow][0]?.type === "r" &&
        state.board[homeRow][0]?.color === piece.color &&
        !isSquareAttacked(state.board, homeRow, 3, enemy) &&
        !isSquareAttacked(state.board, homeRow, 2, enemy)
      ) {
        moves.push([homeRow, 2]);
      }
    }
  }
  return moves;
}

function applyRawMove(
  state: ChessState,
  from: [number, number],
  to: [number, number],
  promoType: ChessPieceType = "q",
): ChessState {
  const [fr, fc] = from;
  const [tr, tc] = to;
  const board = cloneBoard(state.board);
  const moving = board[fr][fc]!;
  let captured = board[tr][tc];
  const castling = { ...state.castling };
  let nextEnPassant: [number, number] | null = null;

  // En passant capture
  if (
    moving.type === "p" &&
    state.enPassant &&
    tr === state.enPassant[0] &&
    tc === state.enPassant[1] &&
    !captured
  ) {
    const capRow = moving.color === "w" ? tr + 1 : tr - 1;
    captured = board[capRow][tc];
    board[capRow][tc] = null;
  }

  // Double pawn advance -> set enPassant
  if (moving.type === "p" && Math.abs(tr - fr) === 2) {
    nextEnPassant = [(fr + tr) / 2, fc];
  }

  // Castling rook shift
  if (moving.type === "k" && Math.abs(tc - fc) === 2) {
    if (tc === 6) {
      board[fr][5] = board[fr][7];
      board[fr][7] = null;
    } else if (tc === 2) {
      board[fr][3] = board[fr][0];
      board[fr][0] = null;
    }
  }

  // Update castling flags
  if (moving.type === "k") {
    if (moving.color === "w") {
      castling.wk = false;
      castling.wq = false;
    } else {
      castling.bk = false;
      castling.bq = false;
    }
  }
  if (moving.type === "r") {
    if (fr === 7 && fc === 0) castling.wq = false;
    if (fr === 7 && fc === 7) castling.wk = false;
    if (fr === 0 && fc === 0) castling.bq = false;
    if (fr === 0 && fc === 7) castling.bk = false;
  }
  if (captured?.type === "r") {
    if (tr === 7 && tc === 0) castling.wq = false;
    if (tr === 7 && tc === 7) castling.wk = false;
    if (tr === 0 && tc === 0) castling.bq = false;
    if (tr === 0 && tc === 7) castling.bk = false;
  }

  // Move piece + promotion
  const isPromo = moving.type === "p" && (tr === 0 || tr === 7);
  board[tr][tc] = isPromo ? { type: promoType, color: moving.color } : moving;
  board[fr][fc] = null;

  const files = "abcdefgh";
  const notation = `${moving.type === "p" ? "" : moving.type.toUpperCase()}${files[fc]}${8 - fr}${captured ? "x" : "→"}${files[tc]}${8 - tr}${isPromo ? `=${promoType.toUpperCase()}` : ""}`;

  const nextTurn: ChessColor = state.turn === "w" ? "b" : "w";
  const capturedW = [...state.capturedW];
  const capturedB = [...state.capturedB];
  if (captured) {
    if (captured.color === "w") capturedW.push(captured);
    else capturedB.push(captured);
  }

  return {
    board,
    turn: nextTurn,
    castling,
    enPassant: nextEnPassant,
    history: [...state.history, notation],
    capturedW,
    capturedB,
    lastMove: { from, to },
    status: "active",
    winner: null,
  };
}

function getLegalMoves(state: ChessState, r: number, c: number): [number, number][] {
  const piece = state.board[r][c];
  if (!piece || piece.color !== state.turn) return [];
  const pseudo = getPseudoMoves(state, r, c);
  return pseudo.filter(([tr, tc]) => {
    const next = applyRawMove(state, [r, c], [tr, tc], "q");
    return !isInCheck(next.board, piece.color);
  });
}

function finalizeChessStatus(state: ChessState): ChessState {
  const inCheck = isInCheck(state.board, state.turn);
  let hasLegal = false;
  outer: for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      if (state.board[r][c]?.color === state.turn && getLegalMoves(state, r, c).length > 0) {
        hasLegal = true;
        break outer;
      }
    }
  }
  if (!hasLegal) {
    if (inCheck) {
      return {
        ...state,
        status: "checkmate",
        winner: state.turn === "w" ? "b" : "w",
      };
    }
    return { ...state, status: "stalemate", winner: "draw" };
  }
  return { ...state, status: inCheck ? "check" : "active", winner: null };
}

function pickChessAiMove(state: ChessState): { from: [number, number]; to: [number, number] } | null {
  const all: { from: [number, number]; to: [number, number]; score: number }[] = [];
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = state.board[r][c];
      if (!piece || piece.color !== state.turn) continue;
      const legal = getLegalMoves(state, r, c);
      for (const [tr, tc] of legal) {
        let score = Math.random() * 8;
        const cap = state.board[tr][tc];
        if (cap) score += PIECE_VALUES[cap.type] * 1.2 - PIECE_VALUES[piece.type] * 0.1;
        // Center control bonus
        const centerDist = Math.abs(3.5 - tr) + Math.abs(3.5 - tc);
        score += (7 - centerDist) * 4;
        const after = finalizeChessStatus(applyRawMove(state, [r, c], [tr, tc], "q"));
        if (after.status === "checkmate") score += 100000;
        else if (after.status === "check") score += 45;
        // Avoid hanging piece
        if (isSquareAttacked(after.board, tr, tc, state.turn)) {
          score -= PIECE_VALUES[piece.type] * 0.55;
        }
        all.push({ from: [r, c], to: [tr, tc], score });
      }
    }
  }
  if (!all.length) return null;
  all.sort((a, b) => b.score - a.score);
  return { from: all[0].from, to: all[0].to };
}

function ChessGame({ online }: { online: ActiveOnlineSession | null }) {
  const [mode, setMode] = useState<"ai" | "local">(online ? "local" : "ai");
  const [state, setState] = useState<ChessState>(() => createInitialChessState());
  const [selected, setSelected] = useState<[number, number] | null>(null);
  const [pendingPromo, setPendingPromo] = useState<{
    from: [number, number];
    to: [number, number];
  } | null>(null);

  // Sync from online room
  useEffect(() => {
    if (!online) return;
    const raw = online.room.state as Partial<ChessState> | undefined;
    if (raw && Array.isArray(raw.board)) {
      setState(raw as ChessState);
      setSelected(null);
      setPendingPromo(null);
    }
  }, [online?.room.state, online]);

  const myOnlineColor: ChessColor | null = online
    ? online.role === "host"
      ? "w"
      : "b"
    : null;

  const commitMove = useCallback(
    (from: [number, number], to: [number, number], promo: ChessPieceType = "q") => {
      const next = finalizeChessStatus(applyRawMove(state, from, to, promo));
      setState(next);
      setSelected(null);
      setPendingPromo(null);
      if (online) {
        const nextTurnRole = next.turn === "w" ? "host" : "guest";
        const nextStatus = next.winner ? "finished" : "playing";
        void online.sendState(next as unknown as Record<string, unknown>, nextTurnRole, nextStatus);
      }
    },
    [state, online],
  );

  // AI turn
  useEffect(() => {
    if (online || mode !== "ai" || state.turn !== "b" || state.winner) return;
    const timer = window.setTimeout(() => {
      const best = pickChessAiMove(state);
      if (best) {
        const next = finalizeChessStatus(applyRawMove(state, best.from, best.to, "q"));
        setState(next);
        setSelected(null);
      }
    }, 340);
    return () => window.clearTimeout(timer);
  }, [mode, online, state]);

  const legalMoves = useMemo(() => {
    if (!selected) return [];
    return getLegalMoves(state, selected[0], selected[1]);
  }, [selected, state]);

  const handleSquareClick = (r: number, c: number) => {
    if (state.winner || pendingPromo) return;
    if (online && myOnlineColor !== state.turn) return;
    if (!online && mode === "ai" && state.turn === "b") return;

    if (selected) {
      const isLegal = legalMoves.some(([lr, lc]) => lr === r && lc === c);
      if (isLegal) {
        const moving = state.board[selected[0]][selected[1]];
        if (moving?.type === "p" && (r === 0 || r === 7)) {
          setPendingPromo({ from: selected, to: [r, c] });
          return;
        }
        commitMove(selected, [r, c]);
        return;
      }
    }

    const clicked = state.board[r][c];
    if (clicked && clicked.color === state.turn) {
      setSelected([r, c]);
    } else {
      setSelected(null);
    }
  };

  const resetGame = () => {
    const fresh = createInitialChessState();
    setState(fresh);
    setSelected(null);
    setPendingPromo(null);
    if (online) {
      void online.sendState(fresh as unknown as Record<string, unknown>, "host", "playing");
    }
  };

  const displayRows = myOnlineColor === "b" ? [7, 6, 5, 4, 3, 2, 1, 0] : [0, 1, 2, 3, 4, 5, 6, 7];
  const displayCols = myOnlineColor === "b" ? [7, 6, 5, 4, 3, 2, 1, 0] : [0, 1, 2, 3, 4, 5, 6, 7];

  return (
    <div className="gp-game-shell">
      <div className="gp-game-toolbar">
        {!online && (
          <div className="gp-seg">
            <button className={mode === "ai" ? "active" : ""} onClick={() => setMode("ai")}>
              vs Automaton
            </button>
            <button className={mode === "local" ? "active" : ""} onClick={() => setMode("local")}>
              Local 2-Player
            </button>
          </div>
        )}
        <div className="gp-status-pill">
          {state.status === "checkmate"
            ? `Checkmate — ${state.winner === "w" ? "White (Brass)" : "Black (Obsidian)"} wins!`
            : state.status === "stalemate"
              ? "Stalemate — Draw"
              : `${state.turn === "w" ? "White" : "Black"}'s turn${state.status === "check" ? " · CHECK!" : ""}`}
        </div>
        {online && (
          <div className="gp-role-note">
            You play {myOnlineColor === "w" ? "White (Host)" : "Black (Guest)"}
          </div>
        )}
        <button className="gp-btn" onClick={resetGame}>
          Restart Match
        </button>
      </div>

      <div className="gp-chess-layout">
        <div className="gp-chess-board-wrap">
          {pendingPromo && (
            <div className="gp-promo-bar">
              <span>Promote pawn to:</span>
              {(["q", "r", "b", "n"] as ChessPieceType[]).map((t) => (
                <button
                  key={t}
                  className="gp-btn"
                  onClick={() => commitMove(pendingPromo.from, pendingPromo.to, t)}
                >
                  {CHESS_GLYPHS[state.turn][t]} {t.toUpperCase()}
                </button>
              ))}
            </div>
          )}
          <div className="gp-chess-board" role="grid" aria-label="Chess board">
            {displayRows.map((r) =>
              displayCols.map((c) => {
                const piece = state.board[r][c];
                const isLight = (r + c) % 2 === 0;
                const isSel = selected?.[0] === r && selected?.[1] === c;
                const isLegal = legalMoves.some(([lr, lc]) => lr === r && lc === c);
                const isLast =
                  (state.lastMove?.from[0] === r && state.lastMove?.from[1] === c) ||
                  (state.lastMove?.to[0] === r && state.lastMove?.to[1] === c);
                const isKingCheck =
                  (state.status === "check" || state.status === "checkmate") &&
                  piece?.type === "k" &&
                  piece.color === state.turn;
                return (
                  <button
                    key={`${r}-${c}`}
                    type="button"
                    onClick={() => handleSquareClick(r, c)}
                    className={`gp-chess-sq ${isLight ? "light" : "dark"} ${isSel ? "selected" : ""} ${isLast ? "last" : ""} ${isKingCheck ? "in-check" : ""}`}
                    aria-label={`Row ${8 - r} Col ${c + 1} ${piece ? `${piece.color} ${piece.type}` : "empty"}`}
                  >
                    {piece && (
                      <span className={`gp-piece ${piece.color}`}>
                        {CHESS_GLYPHS[piece.color][piece.type]}
                      </span>
                    )}
                    {isLegal && <span className={`gp-legal-dot ${piece ? "capture" : ""}`} />}
                  </button>
                );
              }),
            )}
          </div>
        </div>

        <aside className="gp-chess-side">
          <div className="gp-panel-box">
            <h4>Captured Pieces</h4>
            <div className="gp-captured-row">
              <span>White lost:</span>
              <div>
                {state.capturedW.length
                  ? state.capturedW.map((p, i) => <span key={i}>{CHESS_GLYPHS.w[p.type]}</span>)
                  : "—"}
              </div>
            </div>
            <div className="gp-captured-row">
              <span>Black lost:</span>
              <div>
                {state.capturedB.length
                  ? state.capturedB.map((p, i) => <span key={i}>{CHESS_GLYPHS.b[p.type]}</span>)
                  : "—"}
              </div>
            </div>
          </div>
          <div className="gp-panel-box gp-move-log">
            <h4>Chronicle of Moves ({state.history.length})</h4>
            <ol>
              {state.history.map((m, i) => (
                <li key={i}>
                  <span>{i % 2 === 0 ? `${Math.floor(i / 2) + 1}.` : "…"}</span> {m}
                </li>
              ))}
            </ol>
          </div>
        </aside>
      </div>
    </div>
  );
}

/* ============================================================================
 * 2. AETHER VAULT CO-OP (2-PLAYER CO-OP PUZZLE ADVENTURE)
 * ============================================================================ */

interface CoopVaultState {
  level: number;
  p1: [number, number];
  p2: [number, number];
  cubes: [number, number][];
  collectedCores: string[];
  moves: number;
  cleared: boolean;
}

const COOP_LEVELS: string[][] = [
  [
    "#########",
    "#1.C.b.X#",
    "#.B###.##",
    "#..M.C..#",
    "##.###K.#",
    "#2..k..Y#",
    "#########",
  ],
  [
    "#########",
    "#1.b.C.X#",
    "#.##K##.#",
    "#C.M.M.C#",
    "#.##B##.#",
    "#2.k...Y#",
    "#########",
  ],
  [
    "#########",
    "#1.b.k.X#",
    "#B#C#C#K#",
    "#..M.M..#",
    "#C.b.k.C#",
    "#2..B..Y#",
    "#########",
  ],
];

function initCoopLevel(levelIdx: number): CoopVaultState {
  const map = COOP_LEVELS[levelIdx % COOP_LEVELS.length];
  let p1: [number, number] = [1, 1];
  let p2: [number, number] = [5, 1];
  const cubes: [number, number][] = [];
  for (let r = 0; r < map.length; r++) {
    for (let c = 0; c < map[r].length; c++) {
      const ch = map[r][c];
      if (ch === "1") p1 = [r, c];
      if (ch === "2") p2 = [r, c];
      if (ch === "M") cubes.push([r, c]);
    }
  }
  return {
    level: levelIdx % COOP_LEVELS.length,
    p1,
    p2,
    cubes,
    collectedCores: [],
    moves: 0,
    cleared: false,
  };
}

function getCoopGatesStatus(state: CoopVaultState) {
  const map = COOP_LEVELS[state.level];
  const isPressed = (target: string) => {
    const checkPos = ([r, c]: [number, number]) => map[r]?.[c] === target;
    return checkPos(state.p1) || checkPos(state.p2) || state.cubes.some(checkPos);
  };
  let totalCores = 0;
  for (let r = 0; r < map.length; r++) {
    for (let c = 0; c < map[r].length; c++) {
      if (map[r][c] === "C") totalCores++;
    }
  }
  return {
    brassOpen: isPressed("B"),
    copperOpen: isPressed("K"),
    totalCores,
  };
}

function moveCoopSentinel(
  state: CoopVaultState,
  who: "p1" | "p2",
  dr: number,
  dc: number,
): CoopVaultState {
  if (state.cleared) return state;
  const map = COOP_LEVELS[state.level];
  const pos = who === "p1" ? state.p1 : state.p2;
  const other = who === "p1" ? state.p2 : state.p1;
  const nr = pos[0] + dr;
  const nc = pos[1] + dc;
  const tile = map[nr]?.[nc];
  if (!tile || tile === "#") return state;

  const { brassOpen, copperOpen, totalCores } = getCoopGatesStatus(state);
  if (tile === "b" && !brassOpen) return state;
  if (tile === "k" && !copperOpen) return state;
  if (other[0] === nr && other[1] === nc) return state;

  const cubes = state.cubes.map(([cr, cc]) => [cr, cc] as [number, number]);
  const cubeIdx = cubes.findIndex(([cr, cc]) => cr === nr && cc === nc);
  if (cubeIdx !== -1) {
    const br = nr + dr;
    const bc = nc + dc;
    const behind = map[br]?.[bc];
    if (!behind || behind === "#") return state;
    if (behind === "b" && !brassOpen) return state;
    if (behind === "k" && !copperOpen) return state;
    if (
      (other[0] === br && other[1] === bc) ||
      cubes.some(([cr, cc]) => cr === br && cc === bc)
    ) {
      return state;
    }
    cubes[cubeIdx] = [br, bc];
  }

  const nextP1: [number, number] = who === "p1" ? [nr, nc] : state.p1;
  const nextP2: [number, number] = who === "p2" ? [nr, nc] : state.p2;
  const collected = [...state.collectedCores];
  const coreKey = `${nr},${nc}`;
  if (tile === "C" && !collected.includes(coreKey)) {
    collected.push(coreKey);
  }

  const allCores = collected.length >= totalCores;
  const p1OnExit = map[nextP1[0]][nextP1[1]] === "X";
  const p2OnExit = map[nextP2[0]][nextP2[1]] === "Y";
  const cleared = allCores && p1OnExit && p2OnExit;

  return {
    ...state,
    p1: nextP1,
    p2: nextP2,
    cubes,
    collectedCores: collected,
    moves: state.moves + 1,
    cleared,
  };
}

function CoopVaultGame({ online }: { online: ActiveOnlineSession | null }) {
  const [state, setState] = useState<CoopVaultState>(() => initCoopLevel(0));
  const [activeLocal, setActiveLocal] = useState<"p1" | "p2">("p1");

  useEffect(() => {
    if (!online) return;
    const raw = online.room.state as Partial<CoopVaultState> | undefined;
    if (raw && typeof raw.level === "number" && Array.isArray(raw.p1) && Array.isArray(raw.p2)) {
      setState(raw as CoopVaultState);
    }
  }, [online?.room.state, online]);

  const myRoleSentinel: "p1" | "p2" | null = online
    ? online.role === "host"
      ? "p1"
      : "p2"
    : null;

  const step = useCallback(
    (who: "p1" | "p2", dr: number, dc: number) => {
      setState((prev) => {
        const next = moveCoopSentinel(prev, who, dr, dc);
        if (next !== prev && online) {
          void online.sendState(next as unknown as Record<string, unknown>, "both", "playing");
        }
        return next;
      });
    },
    [online],
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (["arrowup", "arrowdown", "arrowleft", "arrowright"].includes(k)) {
        e.preventDefault();
      }
      if (online && myRoleSentinel) {
        if (k === "w" || k === "arrowup") step(myRoleSentinel, -1, 0);
        else if (k === "s" || k === "arrowdown") step(myRoleSentinel, 1, 0);
        else if (k === "a" || k === "arrowleft") step(myRoleSentinel, 0, -1);
        else if (k === "d" || k === "arrowright") step(myRoleSentinel, 0, 1);
      } else {
        if (k === "w") step("p1", -1, 0);
        else if (k === "s") step("p1", 1, 0);
        else if (k === "a") step("p1", 0, -1);
        else if (k === "d") step("p1", 0, 1);
        else if (k === "arrowup") step("p2", -1, 0);
        else if (k === "arrowdown") step("p2", 1, 0);
        else if (k === "arrowleft") step("p2", 0, -1);
        else if (k === "arrowright") step("p2", 0, 1);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [online, myRoleSentinel, step]);

  const loadLevel = (lvl: number) => {
    const fresh = initCoopLevel(lvl);
    setState(fresh);
    if (online) {
      void online.sendState(fresh as unknown as Record<string, unknown>, "both", "playing");
    }
  };

  const map = COOP_LEVELS[state.level];
  const { brassOpen, copperOpen, totalCores } = getCoopGatesStatus(state);

  return (
    <div className="gp-game-shell">
      <div className="gp-game-toolbar">
        <div className="gp-status-pill">
          Chamber {state.level + 1}/{COOP_LEVELS.length} · Cores {state.collectedCores.length}/
          {totalCores} · Moves {state.moves}
        </div>
        <div className="gp-seg">
          <span className="gp-tag" style={{ opacity: brassOpen ? 1 : 0.45 }}>
            Brass Gate: {brassOpen ? "OPEN" : "SEALED"}
          </span>
          <span className="gp-tag" style={{ opacity: copperOpen ? 1 : 0.45 }}>
            Copper Gate: {copperOpen ? "OPEN" : "SEALED"}
          </span>
        </div>
        {!online && (
          <div className="gp-seg">
            <button
              className={activeLocal === "p1" ? "active" : ""}
              onClick={() => setActiveLocal("p1")}
            >
              Pad: P1 (Brass)
            </button>
            <button
              className={activeLocal === "p2" ? "active" : ""}
              onClick={() => setActiveLocal("p2")}
            >
              Pad: P2 (Copper)
            </button>
          </div>
        )}
        <button className="gp-btn" onClick={() => loadLevel(state.level)}>
          Restart Chamber
        </button>
      </div>

      {state.cleared && (
        <div className="gp-banner-win">
          Chamber {state.level + 1} Unlocked Together!{" "}
          <button className="gp-btn" onClick={() => loadLevel((state.level + 1) % COOP_LEVELS.length)}>
            {state.level + 1 < COOP_LEVELS.length ? "Next Chamber →" : "Replay From Chamber 1"}
          </button>
        </div>
      )}

      <div className="gp-coop-wrap">
        <div className="gp-coop-grid">
          {map.map((row, r) =>
            row.split("").map((ch, c) => {
              const isP1 = state.p1[0] === r && state.p1[1] === c;
              const isP2 = state.p2[0] === r && state.p2[1] === c;
              const isCube = state.cubes.some(([cr, cc]) => cr === r && cc === c);
              const hasCore = ch === "C" && !state.collectedCores.includes(`${r},${c}`);
              let cellClass = "floor";
              let label = "";
              if (ch === "#") cellClass = "wall";
              else if (ch === "B") {
                cellClass = "plate-b";
                label = "B";
              } else if (ch === "K") {
                cellClass = "plate-k";
                label = "K";
              } else if (ch === "b") {
                cellClass = brassOpen ? "gate-open" : "gate-b";
                label = brassOpen ? "·" : "╬";
              } else if (ch === "k") {
                cellClass = copperOpen ? "gate-open" : "gate-k";
                label = copperOpen ? "·" : "╬";
              } else if (ch === "X") {
                cellClass = "exit-1";
                label = "X1";
              } else if (ch === "Y") {
                cellClass = "exit-2";
                label = "Y2";
              }
              return (
                <div key={`${r}-${c}`} className={`gp-coop-cell ${cellClass}`}>
                  {label && <span className="gp-cell-mark">{label}</span>}
                  {hasCore && <span className="gp-core">◈</span>}
                  {isCube && <span className="gp-cube">▣</span>}
                  {isP1 && <span className="gp-sentinel p1">P1</span>}
                  {isP2 && <span className="gp-sentinel p2">P2</span>}
                </div>
              );
            }),
          )}
        </div>

        <div className="gp-dpad-panel">
          <p>
            {online
              ? `You control ${myRoleSentinel === "p1" ? "P1 (Brass Sentinel)" : "P2 (Copper Sentinel)"}`
              : `WASD moves P1 · Arrow keys move P2 · On-screen pad moves ${activeLocal.toUpperCase()}`}
          </p>
          <div className="gp-dpad">
            <span />
            <button onClick={() => step(online ? myRoleSentinel! : activeLocal, -1, 0)}>▲</button>
            <span />
            <button onClick={() => step(online ? myRoleSentinel! : activeLocal, 0, -1)}>◀</button>
            <button onClick={() => step(online ? myRoleSentinel! : activeLocal, 1, 0)}>▼</button>
            <button onClick={() => step(online ? myRoleSentinel! : activeLocal, 0, 1)}>▶</button>
          </div>
          <div className="gp-coop-legend">
            <span>
              <b>P1 / P2</b> Sentinels
            </span>
            <span>
              <b>◈</b> Collect all Aether Cores
            </span>
            <span>
              <b>B / K</b> Pressure Plates open <b>╬</b> Gates
            </span>
            <span>
              <b>▣</b> Pushable Cubes hold plates
            </span>
            <span>
              <b>X1 / Y2</b> Both Sentinels stand on exits to clear
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
 * 3. TIC-TAC-TOE (AI / LOCAL / ONLINE)
 * ============================================================================ */

function checkTttWinner(board: (string | null)[]) {
  const lines = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
  ];
  for (const [a, b, c] of lines) {
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return { winner: board[a], line: [a, b, c] };
    }
  }
  if (board.every(Boolean)) return { winner: "draw", line: [] };
  return null;
}

function tttMinimax(board: (string | null)[], isMax: boolean): number {
  const res = checkTttWinner(board);
  if (res?.winner === "O") return 10;
  if (res?.winner === "X") return -10;
  if (res?.winner === "draw") return 0;
  let best = isMax ? -100 : 100;
  for (let i = 0; i < 9; i++) {
    if (!board[i]) {
      board[i] = isMax ? "O" : "X";
      const val = tttMinimax(board, !isMax);
      board[i] = null;
      best = isMax ? Math.max(best, val) : Math.min(best, val);
    }
  }
  return best;
}

function TicTacToeGame({ online }: { online: ActiveOnlineSession | null }) {
  const [mode, setMode] = useState<"ai" | "local">(online ? "local" : "ai");
  const [board, setBoard] = useState<(string | null)[]>(Array(9).fill(null));
  const [turn, setTurn] = useState<"X" | "O">("X");
  const [scores, setScores] = useState({ X: 0, O: 0, D: 0 });

  useEffect(() => {
    if (!online) return;
    const st = online.room.state as { board?: (string | null)[]; turn?: "X" | "O" } | undefined;
    if (st && Array.isArray(st.board) && st.board.length === 9) {
      setBoard(st.board);
      if (st.turn) setTurn(st.turn);
    }
  }, [online?.room.state, online]);

  const result = useMemo(() => checkTttWinner(board), [board]);

  useEffect(() => {
    if (!result) return;
    setScores((s) => ({
      X: s.X + (result.winner === "X" ? 1 : 0),
      O: s.O + (result.winner === "O" ? 1 : 0),
      D: s.D + (result.winner === "draw" ? 1 : 0),
    }));
  }, [result?.winner]);

  const mySymbol: "X" | "O" | null = online ? (online.role === "host" ? "X" : "O") : null;

  const playCell = (idx: number) => {
    if (board[idx] || result) return;
    if (online && mySymbol !== turn) return;
    if (!online && mode === "ai" && turn === "O") return;
    const next = [...board];
    next[idx] = turn;
    const nextTurn = turn === "X" ? "O" : "X";
    setBoard(next);
    setTurn(nextTurn);
    if (online) {
      void online.sendState(
        { board: next, turn: nextTurn },
        nextTurn === "X" ? "host" : "guest",
        checkTttWinner(next) ? "finished" : "playing",
      );
    }
  };

  useEffect(() => {
    if (online || mode !== "ai" || turn !== "O" || result) return;
    const timer = window.setTimeout(() => {
      let bestScore = -100;
      let move = -1;
      const copy = [...board];
      for (let i = 0; i < 9; i++) {
        if (!copy[i]) {
          copy[i] = "O";
          const sc = tttMinimax(copy, false);
          copy[i] = null;
          if (sc > bestScore) {
            bestScore = sc;
            move = i;
          }
        }
      }
      if (move !== -1) {
        const next = [...board];
        next[move] = "O";
        setBoard(next);
        setTurn("X");
      }
    }, 260);
    return () => window.clearTimeout(timer);
  }, [board, mode, online, result, turn]);

  const restart = () => {
    const empty = Array(9).fill(null);
    setBoard(empty);
    setTurn("X");
    if (online) {
      void online.sendState({ board: empty, turn: "X" }, "host", "playing");
    }
  };

  return (
    <div className="gp-game-shell">
      <div className="gp-game-toolbar">
        {!online && (
          <div className="gp-seg">
            <button className={mode === "ai" ? "active" : ""} onClick={() => { setMode("ai"); restart(); }}>
              vs Automaton
            </button>
            <button className={mode === "local" ? "active" : ""} onClick={() => { setMode("local"); restart(); }}>
              Local 2-Player
            </button>
          </div>
        )}
        <div className="gp-status-pill">
          {result
            ? result.winner === "draw"
              ? "Draw Match"
              : `${result.winner} Wins!`
            : `Turn: ${turn}${online ? ` (You: ${mySymbol})` : ""}`}
        </div>
        <div className="gp-status-pill">
          X: {scores.X} · Draws: {scores.D} · O: {scores.O}
        </div>
        <button className="gp-btn" onClick={restart}>
          New Round
        </button>
      </div>
      <div className="gp-ttt-grid">
        {board.map((cell, i) => (
          <button
            key={i}
            onClick={() => playCell(i)}
            className={`gp-ttt-cell ${result?.line.includes(i) ? "win" : ""} ${cell === "X" ? "x" : cell === "O" ? "o" : ""}`}
          >
            {cell}
          </button>
        ))}
      </div>
    </div>
  );
}

/* ============================================================================
 * 4. CONNECT FOUR (AI / LOCAL / ONLINE)
 * ============================================================================ */

function checkC4Winner(grid: number[][]): { winner: number; cells: [number, number][] } | null {
  const rows = 6;
  const cols = 7;
  const dirs = [
    [0, 1],
    [1, 0],
    [1, 1],
    [1, -1],
  ];
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const p = grid[r][c];
      if (!p) continue;
      for (const [dr, dc] of dirs) {
        const line: [number, number][] = [[r, c]];
        for (let k = 1; k < 4; k++) {
          const nr = r + dr * k;
          const nc = c + dc * k;
          if (nr >= 0 && nr < rows && nc >= 0 && nc < cols && grid[nr][nc] === p) {
            line.push([nr, nc]);
          } else break;
        }
        if (line.length === 4) return { winner: p, cells: line };
      }
    }
  }
  if (grid[0].every((v) => v !== 0)) return { winner: -1, cells: [] };
  return null;
}

function ConnectFourGame({ online }: { online: ActiveOnlineSession | null }) {
  const emptyGrid = () => Array.from({ length: 6 }, () => Array(7).fill(0) as number[]);
  const [mode, setMode] = useState<"ai" | "local">(online ? "local" : "ai");
  const [grid, setGrid] = useState<number[][]>(emptyGrid);
  const [turn, setTurn] = useState<1 | 2>(1);

  useEffect(() => {
    if (!online) return;
    const st = online.room.state as { grid?: number[][]; turn?: 1 | 2 } | undefined;
    if (st && Array.isArray(st.grid) && st.grid.length === 6) {
      setGrid(st.grid);
      if (st.turn) setTurn(st.turn);
    }
  }, [online?.room.state, online]);

  const result = useMemo(() => checkC4Winner(grid), [grid]);
  const myPlayer: 1 | 2 | null = online ? (online.role === "host" ? 1 : 2) : null;

  const dropInCol = (col: number) => {
    if (result) return;
    if (online && myPlayer !== turn) return;
    if (!online && mode === "ai" && turn === 2) return;
    let targetRow = -1;
    for (let r = 5; r >= 0; r--) {
      if (grid[r][col] === 0) {
        targetRow = r;
        break;
      }
    }
    if (targetRow === -1) return;
    const next = grid.map((row) => [...row]);
    next[targetRow][col] = turn;
    const nextTurn: 1 | 2 = turn === 1 ? 2 : 1;
    setGrid(next);
    setTurn(nextTurn);
    if (online) {
      void online.sendState(
        { grid: next, turn: nextTurn },
        nextTurn === 1 ? "host" : "guest",
        checkC4Winner(next) ? "finished" : "playing",
      );
    }
  };

  useEffect(() => {
    if (online || mode !== "ai" || turn !== 2 || result) return;
    const timer = window.setTimeout(() => {
      const validCols = [3, 2, 4, 1, 5, 0, 6].filter((c) => grid[0][c] === 0);
      if (!validCols.length) return;
      const tryDrop = (c: number, player: number) => {
        const copy = grid.map((r) => [...r]);
        for (let r = 5; r >= 0; r--) {
          if (copy[r][c] === 0) {
            copy[r][c] = player;
            return copy;
          }
        }
        return null;
      };
      let chosen = validCols[0];
      // Immediate win
      for (const c of validCols) {
        const g = tryDrop(c, 2);
        if (g && checkC4Winner(g)?.winner === 2) {
          chosen = c;
          break;
        }
      }
      // Block player win
      if (checkC4Winner(tryDrop(chosen, 2)!)?.winner !== 2) {
        for (const c of validCols) {
          const g = tryDrop(c, 1);
          if (g && checkC4Winner(g)?.winner === 1) {
            chosen = c;
            break;
          }
        }
      }
      const next = tryDrop(chosen, 2);
      if (next) {
        setGrid(next);
        setTurn(1);
      }
    }, 300);
    return () => window.clearTimeout(timer);
  }, [grid, mode, online, result, turn]);

  const restart = () => {
    const fresh = emptyGrid();
    setGrid(fresh);
    setTurn(1);
    if (online) {
      void online.sendState({ grid: fresh, turn: 1 }, "host", "playing");
    }
  };

  return (
    <div className="gp-game-shell">
      <div className="gp-game-toolbar">
        {!online && (
          <div className="gp-seg">
            <button className={mode === "ai" ? "active" : ""} onClick={() => { setMode("ai"); restart(); }}>
              vs Automaton
            </button>
            <button className={mode === "local" ? "active" : ""} onClick={() => { setMode("local"); restart(); }}>
              Local 2-Player
            </button>
          </div>
        )}
        <div className="gp-status-pill">
          {result
            ? result.winner === -1
              ? "Grid Full — Draw"
              : `${result.winner === 1 ? "Brass (P1)" : "Copper (P2)"} Wins!`
            : `${turn === 1 ? "Brass (P1)" : "Copper (P2)"}'s Turn${online ? ` · You: P${myPlayer}` : ""}`}
        </div>
        <button className="gp-btn" onClick={restart}>
          Restart Board
        </button>
      </div>
      <div className="gp-c4-board">
        {grid.map((row, r) =>
          row.map((val, c) => {
            const isWin = result?.cells.some(([wr, wc]) => wr === r && wc === c);
            return (
              <button
                key={`${r}-${c}`}
                onClick={() => dropInCol(c)}
                className={`gp-c4-slot p${val} ${isWin ? "win" : ""}`}
                aria-label={`Column ${c + 1}`}
              />
            );
          }),
        )}
      </div>
    </div>
  );
}

/* ============================================================================
 * 5. ROCK PAPER SCISSORS (AI & ONLINE SEALED COMMIT)
 * ============================================================================ */

type RpsPick = "rock" | "paper" | "scissors";
const RPS_ITEMS: { id: RpsPick; label: string; glyph: string }[] = [
  { id: "rock", label: "Stone", glyph: "🪨" },
  { id: "paper", label: "Parchment", glyph: "📜" },
  { id: "scissors", label: "Shears", glyph: "✂" },
];

function judgeRps(a: RpsPick, b: RpsPick): "draw" | "a" | "b" {
  if (a === b) return "draw";
  if (
    (a === "rock" && b === "scissors") ||
    (a === "paper" && b === "rock") ||
    (a === "scissors" && b === "paper")
  ) {
    return "a";
  }
  return "b";
}

function RpsGame({ online }: { online: ActiveOnlineSession | null }) {
  const [aiHistory, setAiHistory] = useState<{ p: RpsPick; o: RpsPick; res: string }[]>([]);
  const [score, setScore] = useState({ p1: 0, p2: 0, draws: 0 });
  const [onlineState, setOnlineState] = useState<{
    hostPick: RpsPick | null;
    guestPick: RpsPick | null;
    round: number;
    hostScore: number;
    guestScore: number;
    draws: number;
  }>({ hostPick: null, guestPick: null, round: 1, hostScore: 0, guestScore: 0, draws: 0 });

  useEffect(() => {
    if (!online) return;
    const st = online.room.state as Partial<typeof onlineState> | undefined;
    if (st && typeof st.round === "number") {
      setOnlineState({
        hostPick: st.hostPick ?? null,
        guestPick: st.guestPick ?? null,
        round: st.round,
        hostScore: st.hostScore ?? 0,
        guestScore: st.guestScore ?? 0,
        draws: st.draws ?? 0,
      });
    }
  }, [online?.room.state, online]);

  const playAi = (pick: RpsPick) => {
    const opp = RPS_ITEMS[Math.floor(Math.random() * 3)].id;
    const w = judgeRps(pick, opp);
    const label = w === "a" ? "Victory" : w === "b" ? "Defeat" : "Draw";
    setScore((s) => ({
      p1: s.p1 + (w === "a" ? 1 : 0),
      p2: s.p2 + (w === "b" ? 1 : 0),
      draws: s.draws + (w === "draw" ? 1 : 0),
    }));
    setAiHistory((h) => [{ p: pick, o: opp, res: label }, ...h].slice(0, 6));
  };

  const pickOnline = (pick: RpsPick) => {
    if (!online) return;
    const isHost = online.role === "host";
    const next = {
      ...onlineState,
      hostPick: isHost ? pick : onlineState.hostPick,
      guestPick: !isHost ? pick : onlineState.guestPick,
    };
    if (next.hostPick && next.guestPick) {
      const w = judgeRps(next.hostPick, next.guestPick);
      if (w === "a") next.hostScore += 1;
      else if (w === "b") next.guestScore += 1;
      else next.draws += 1;
    }
    setOnlineState(next);
    void online.sendState(next as unknown as Record<string, unknown>, "both", "playing");
  };

  const nextOnlineRound = () => {
    if (!online) return;
    const next = {
      ...onlineState,
      hostPick: null,
      guestPick: null,
      round: onlineState.round + 1,
    };
    setOnlineState(next);
    void online.sendState(next as unknown as Record<string, unknown>, "both", "playing");
  };

  if (online) {
    const myPick = online.role === "host" ? onlineState.hostPick : onlineState.guestPick;
    const oppPick = online.role === "host" ? onlineState.guestPick : onlineState.hostPick;
    const bothPicked = Boolean(onlineState.hostPick && onlineState.guestPick);
    const outcome = bothPicked ? judgeRps(onlineState.hostPick!, onlineState.guestPick!) : null;
    return (
      <div className="gp-game-shell">
        <div className="gp-game-toolbar">
          <div className="gp-status-pill">
            Round {onlineState.round} · Host: {onlineState.hostScore} · Guest:{" "}
            {onlineState.guestScore} · Draws: {onlineState.draws}
          </div>
          {bothPicked && (
            <button className="gp-btn" onClick={nextOnlineRound}>
              Next Round →
            </button>
          )}
        </div>
        <div className="gp-rps-arena">
          <div className="gp-rps-choices">
            {RPS_ITEMS.map((item) => (
              <button
                key={item.id}
                disabled={Boolean(myPick)}
                className={`gp-rps-btn ${myPick === item.id ? "active" : ""}`}
                onClick={() => pickOnline(item.id)}
              >
                <span>{item.glyph}</span>
                <b>{item.label}</b>
              </button>
            ))}
          </div>
          <div className="gp-rps-reveal">
            <div>
              <small>Your Selection</small>
              <strong>{myPick ? RPS_ITEMS.find((i) => i.id === myPick)?.label : "Waiting…"}</strong>
            </div>
            <div>
              <small>Opponent</small>
              <strong>
                {bothPicked
                  ? RPS_ITEMS.find((i) => i.id === oppPick)?.label
                  : oppPick
                    ? "Locked (Hidden)"
                    : "Thinking…"}
              </strong>
            </div>
            {bothPicked && (
              <div className="gp-rps-outcome">
                {outcome === "draw"
                  ? "Round Tied"
                  : outcome === "a"
                    ? "Host Wins Round"
                    : "Guest Wins Round"}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="gp-game-shell">
      <div className="gp-game-toolbar">
        <div className="gp-status-pill">
          You: {score.p1} · Automaton: {score.p2} · Draws: {score.draws}
        </div>
        <button
          className="gp-btn"
          onClick={() => {
            setScore({ p1: 0, p2: 0, draws: 0 });
            setAiHistory([]);
          }}
        >
          Reset Tally
        </button>
      </div>
      <div className="gp-rps-arena">
        <div className="gp-rps-choices">
          {RPS_ITEMS.map((item) => (
            <button key={item.id} className="gp-rps-btn" onClick={() => playAi(item.id)}>
              <span>{item.glyph}</span>
              <b>{item.label}</b>
            </button>
          ))}
        </div>
        <div className="gp-rps-log">
          {aiHistory.length === 0 ? (
            <p className="gp-muted">Select Stone, Parchment, or Shears to begin the duel.</p>
          ) : (
            aiHistory.map((h, i) => (
              <div key={i} className="gp-rps-row">
                <span>You: {h.p}</span>
                <span>Automaton: {h.o}</span>
                <b>{h.res}</b>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
 * 6. SNAKE
 * ============================================================================ */

function SnakeGame() {
  const GRID = 20;
  const CELL = 20;
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [running, setRunning] = useState(false);
  const [over, setOver] = useState(false);
  const [score, setScore] = useState(0);
  const [best, setBest] = useState(() => Number(localStorage.getItem("gnosis-snake-best") || 0));

  const stateRef = useRef({
    snake: [
      [10, 10],
      [9, 10],
      [8, 10],
    ] as [number, number][],
    dir: [1, 0] as [number, number],
    nextDir: [1, 0] as [number, number],
    food: [15, 10] as [number, number],
  });

  const spawnFood = (snake: [number, number][]): [number, number] => {
    const free: [number, number][] = [];
    for (let x = 0; x < GRID; x++) {
      for (let y = 0; y < GRID; y++) {
        if (!snake.some(([sx, sy]) => sx === x && sy === y)) free.push([x, y]);
      }
    }
    return free.length ? free[Math.floor(Math.random() * free.length)] : [0, 0];
  };

  const reset = () => {
    const initSnake: [number, number][] = [
      [10, 10],
      [9, 10],
      [8, 10],
    ];
    stateRef.current = {
      snake: initSnake,
      dir: [1, 0],
      nextDir: [1, 0],
      food: spawnFood(initSnake),
    };
    setScore(0);
    setOver(false);
    setRunning(true);
  };

  const changeDir = useCallback((dx: number, dy: number) => {
    const cur = stateRef.current.dir;
    if (cur[0] + dx === 0 && cur[1] + dy === 0) return;
    stateRef.current.nextDir = [dx, dy];
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (["arrowup", "arrowdown", "arrowleft", "arrowright"].includes(k)) e.preventDefault();
      if (k === "arrowup" || k === "w") changeDir(0, -1);
      else if (k === "arrowdown" || k === "s") changeDir(0, 1);
      else if (k === "arrowleft" || k === "a") changeDir(-1, 0);
      else if (k === "arrowright" || k === "d") changeDir(1, 0);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [changeDir]);

  const draw = useCallback(() => {
    const ctx = canvasRef.current?.getContext("2d");
    if (!ctx) return;
    ctx.fillStyle = "#120e0a";
    ctx.fillRect(0, 0, GRID * CELL, GRID * CELL);
    ctx.strokeStyle = "rgba(176,141,87,0.1)";
    for (let i = 0; i <= GRID; i++) {
      ctx.beginPath();
      ctx.moveTo(i * CELL, 0);
      ctx.lineTo(i * CELL, GRID * CELL);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i * CELL);
      ctx.lineTo(GRID * CELL, i * CELL);
      ctx.stroke();
    }
    const { snake, food } = stateRef.current;
    ctx.fillStyle = "#d96b43";
    ctx.fillRect(food[0] * CELL + 3, food[1] * CELL + 3, CELL - 6, CELL - 6);
    snake.forEach(([sx, sy], idx) => {
      ctx.fillStyle = idx === 0 ? "#e6c984" : "#9c7a47";
      ctx.fillRect(sx * CELL + 1, sy * CELL + 1, CELL - 2, CELL - 2);
    });
  }, []);

  useEffect(() => {
    draw();
  }, [draw]);

  useEffect(() => {
    if (!running || over) return;
    const speed = Math.max(68, 135 - Math.floor(score / 3) * 6);
    const id = window.setInterval(() => {
      const st = stateRef.current;
      st.dir = st.nextDir;
      const head: [number, number] = [st.snake[0][0] + st.dir[0], st.snake[0][1] + st.dir[1]];
      if (
        head[0] < 0 ||
        head[0] >= GRID ||
        head[1] < 0 ||
        head[1] >= GRID ||
        st.snake.some(([sx, sy]) => sx === head[0] && sy === head[1])
      ) {
        setOver(true);
        setRunning(false);
        return;
      }
      const ate = head[0] === st.food[0] && head[1] === st.food[1];
      const nextSnake = [head, ...st.snake];
      if (!ate) nextSnake.pop();
      else {
        st.food = spawnFood(nextSnake);
        setScore((s) => {
          const ns = s + 1;
          setBest((b) => {
            const nb = Math.max(b, ns);
            localStorage.setItem("gnosis-snake-best", String(nb));
            return nb;
          });
          return ns;
        });
      }
      st.snake = nextSnake;
      draw();
    }, speed);
    return () => window.clearInterval(id);
  }, [draw, over, running, score]);

  return (
    <div className="gp-game-shell">
      <div className="gp-game-toolbar">
        <div className="gp-status-pill">
          Score: {score} · Best: {best} {over ? "· COLLISION" : ""}
        </div>
        <button className="gp-btn" onClick={() => (over || !running ? reset() : setRunning(false))}>
          {over ? "Restart" : running ? "Pause" : "Start"}
        </button>
        <button className="gp-btn" onClick={reset}>
          Reset
        </button>
      </div>
      <div className="gp-canvas-row">
        <canvas ref={canvasRef} width={GRID * CELL} height={GRID * CELL} className="gp-canvas" />
        <div className="gp-dpad">
          <span />
          <button onClick={() => changeDir(0, -1)}>▲</button>
          <span />
          <button onClick={() => changeDir(-1, 0)}>◀</button>
          <button onClick={() => changeDir(0, 1)}>▼</button>
          <button onClick={() => changeDir(1, 0)}>▶</button>
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
 * 7. PONG
 * ============================================================================ */

function PongGame() {
  const W = 600;
  const H = 360;
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [mode, setMode] = useState<"ai" | "local">("ai");
  const [running, setRunning] = useState(false);
  const [scores, setScores] = useState({ l: 0, r: 0 });
  const [winner, setWinner] = useState<string | null>(null);
  const keysRef = useRef<Record<string, boolean>>({});
  const stateRef = useRef({
    ly: H / 2 - 40,
    ry: H / 2 - 40,
    bx: W / 2,
    by: H / 2,
    vx: 4.2,
    vy: 2.6,
    l: 0,
    r: 0,
  });

  const reset = () => {
    stateRef.current = {
      ly: H / 2 - 40,
      ry: H / 2 - 40,
      bx: W / 2,
      by: H / 2,
      vx: Math.random() > 0.5 ? 4.2 : -4.2,
      vy: (Math.random() - 0.5) * 4,
      l: 0,
      r: 0,
    };
    setScores({ l: 0, r: 0 });
    setWinner(null);
    setRunning(true);
  };

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (["ArrowUp", "ArrowDown"].includes(e.key)) e.preventDefault();
      keysRef.current[e.key.toLowerCase()] = true;
    };
    const up = (e: KeyboardEvent) => {
      keysRef.current[e.key.toLowerCase()] = false;
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, []);

  useEffect(() => {
    let raf = 0;
    const render = () => {
      const ctx = canvasRef.current?.getContext("2d");
      const st = stateRef.current;
      if (running && !winner) {
        const keys = keysRef.current;
        const speed = 5.4;
        if (keys["w"] || (mode === "ai" && keys["arrowup"])) st.ly = Math.max(8, st.ly - speed);
        if (keys["s"] || (mode === "ai" && keys["arrowdown"])) st.ly = Math.min(H - 88, st.ly + speed);

        if (mode === "local") {
          if (keys["arrowup"]) st.ry = Math.max(8, st.ry - speed);
          if (keys["arrowdown"]) st.ry = Math.min(H - 88, st.ry + speed);
        } else {
          const target = st.by - 40;
          if (st.ry < target - 6) st.ry = Math.min(H - 88, st.ry + 4.1);
          else if (st.ry > target + 6) st.ry = Math.max(8, st.ry - 4.1);
        }

        st.bx += st.vx;
        st.by += st.vy;

        if (st.by <= 8 || st.by >= H - 8) st.vy *= -1;
        // Left paddle
        if (st.bx <= 24 && st.bx >= 12 && st.by >= st.ly && st.by <= st.ly + 80) {
          const offset = (st.by - (st.ly + 40)) / 40;
          st.vx = Math.min(9.5, Math.abs(st.vx) * 1.05);
          st.vy = offset * 5.2;
        }
        // Right paddle
        if (st.bx >= W - 24 && st.bx <= W - 12 && st.by >= st.ry && st.by <= st.ry + 80) {
          const offset = (st.by - (st.ry + 40)) / 40;
          st.vx = -Math.min(9.5, Math.abs(st.vx) * 1.05);
          st.vy = offset * 5.2;
        }

        if (st.bx < 0) {
          st.r += 1;
          setScores({ l: st.l, r: st.r });
          if (st.r >= 7) {
            setWinner(mode === "ai" ? "Automaton Wins!" : "Player 2 Wins!");
            setRunning(false);
          } else {
            st.bx = W / 2;
            st.by = H / 2;
            st.vx = 4.2;
            st.vy = (Math.random() - 0.5) * 4;
          }
        } else if (st.bx > W) {
          st.l += 1;
          setScores({ l: st.l, r: st.r });
          if (st.l >= 7) {
            setWinner("Player 1 Wins!");
            setRunning(false);
          } else {
            st.bx = W / 2;
            st.by = H / 2;
            st.vx = -4.2;
            st.vy = (Math.random() - 0.5) * 4;
          }
        }
      }

      if (ctx) {
        ctx.fillStyle = "#120e0a";
        ctx.fillRect(0, 0, W, H);
        ctx.setLineDash([8, 8]);
        ctx.strokeStyle = "rgba(198,169,108,0.28)";
        ctx.beginPath();
        ctx.moveTo(W / 2, 0);
        ctx.lineTo(W / 2, H);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.fillStyle = "#d9bc7c";
        ctx.fillRect(12, st.ly, 10, 80);
        ctx.fillStyle = "#b86b42";
        ctx.fillRect(W - 22, st.ry, 10, 80);
        ctx.fillStyle = "#f4ebdd";
        ctx.beginPath();
        ctx.arc(st.bx, st.by, 7, 0, Math.PI * 2);
        ctx.fill();
      }
      raf = window.requestAnimationFrame(render);
    };
    raf = window.requestAnimationFrame(render);
    return () => window.cancelAnimationFrame(raf);
  }, [mode, running, winner]);

  return (
    <div className="gp-game-shell">
      <div className="gp-game-toolbar">
        <div className="gp-seg">
          <button className={mode === "ai" ? "active" : ""} onClick={() => { setMode("ai"); reset(); }}>
            vs Automaton
          </button>
          <button className={mode === "local" ? "active" : ""} onClick={() => { setMode("local"); reset(); }}>
            Local 2P
          </button>
        </div>
        <div className="gp-status-pill">
          P1: {scores.l} — {scores.r} :{mode === "ai" ? "AI" : "P2"}{" "}
          {winner ? `· ${winner}` : ""}
        </div>
        <button className="gp-btn" onClick={() => (winner ? reset() : setRunning((r) => !r))}>
          {winner ? "Play Again" : running ? "Pause" : "Start"}
        </button>
        <button className="gp-btn" onClick={reset}>
          Restart
        </button>
      </div>
      <canvas ref={canvasRef} width={W} height={H} className="gp-canvas wide" />
    </div>
  );
}

/* ============================================================================
 * 8. 2048
 * ============================================================================ */

function spawn2048Tile(board: number[][]): number[][] {
  const empty: [number, number][] = [];
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 4; c++) {
      if (board[r][c] === 0) empty.push([r, c]);
    }
  }
  if (!empty.length) return board;
  const [r, c] = empty[Math.floor(Math.random() * empty.length)];
  const copy = board.map((row) => [...row]);
  copy[r][c] = Math.random() < 0.9 ? 2 : 4;
  return copy;
}

function slide2048Row(row: number[]): { next: number[]; gained: number } {
  const nonZero = row.filter((x) => x !== 0);
  const out: number[] = [];
  let gained = 0;
  for (let i = 0; i < nonZero.length; i++) {
    if (i + 1 < nonZero.length && nonZero[i] === nonZero[i + 1]) {
      const merged = nonZero[i] * 2;
      out.push(merged);
      gained += merged;
      i++;
    } else {
      out.push(nonZero[i]);
    }
  }
  while (out.length < 4) out.push(0);
  return { next: out, gained };
}

function canMove2048(board: number[][]): boolean {
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 4; c++) {
      if (board[r][c] === 0) return true;
      if (r < 3 && board[r][c] === board[r + 1][c]) return true;
      if (c < 3 && board[r][c] === board[r][c + 1]) return true;
    }
  }
  return false;
}

function Game2048() {
  const initBoard = () =>
    spawn2048Tile(spawn2048Tile(Array.from({ length: 4 }, () => [0, 0, 0, 0])));
  const [board, setBoard] = useState<number[][]>(initBoard);
  const [score, setScore] = useState(0);
  const [best, setBest] = useState(() => Number(localStorage.getItem("gnosis-2048-best") || 0));
  const [wonAck, setWonAck] = useState(false);

  const has2048 = board.some((r) => r.some((v) => v >= 2048));
  const gameOver = !canMove2048(board);

  const move = useCallback(
    (dir: "left" | "right" | "up" | "down") => {
      if (gameOver) return;
      let totalGain = 0;
      let changed = false;
      const next = Array.from({ length: 4 }, () => [0, 0, 0, 0]);

      for (let i = 0; i < 4; i++) {
        let line: number[];
        if (dir === "left") line = [...board[i]];
        else if (dir === "right") line = [...board[i]].reverse();
        else if (dir === "up") line = [board[0][i], board[1][i], board[2][i], board[3][i]];
        else line = [board[3][i], board[2][i], board[1][i], board[0][i]];

        const { next: slid, gained } = slide2048Row(line);
        totalGain += gained;
        const finalLine = dir === "right" || dir === "down" ? [...slid].reverse() : slid;

        for (let j = 0; j < 4; j++) {
          if (dir === "left" || dir === "right") {
            if (next[i][j] !== board[i][j]) {
              // checked below
            }
            next[i][j] = finalLine[j];
            if (finalLine[j] !== board[i][j]) changed = true;
          } else {
            next[j][i] = finalLine[j];
            if (finalLine[j] !== board[j][i]) changed = true;
          }
        }
      }

      if (!changed) return;
      setBoard(spawn2048Tile(next));
      setScore((s) => {
        const ns = s + totalGain;
        setBest((b) => {
          const nb = Math.max(b, ns);
          localStorage.setItem("gnosis-2048-best", String(nb));
          return nb;
        });
        return ns;
      });
    },
    [board, gameOver],
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (["arrowup", "arrowdown", "arrowleft", "arrowright"].includes(k)) e.preventDefault();
      if (k === "arrowleft" || k === "a") move("left");
      else if (k === "arrowright" || k === "d") move("right");
      else if (k === "arrowup" || k === "w") move("up");
      else if (k === "arrowdown" || k === "s") move("down");
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [move]);

  const restart = () => {
    setBoard(initBoard());
    setScore(0);
    setWonAck(false);
  };

  return (
    <div className="gp-game-shell">
      <div className="gp-game-toolbar">
        <div className="gp-status-pill">
          Score: {score} · Best: {best} {gameOver ? "· NO MOVES LEFT" : ""}
        </div>
        {has2048 && !wonAck && (
          <button className="gp-btn" onClick={() => setWonAck(true)}>
            2048 Forged! Continue →
          </button>
        )}
        <button className="gp-btn" onClick={restart}>
          New Forge
        </button>
      </div>
      <div className="gp-canvas-row">
        <div className="gp-2048-grid">
          {board.flat().map((val, i) => (
            <div key={i} className={`gp-2048-tile t-${val || 0}`}>
              {val || ""}
            </div>
          ))}
        </div>
        <div className="gp-dpad">
          <span />
          <button onClick={() => move("up")}>▲</button>
          <span />
          <button onClick={() => move("left")}>◀</button>
          <button onClick={() => move("down")}>▼</button>
          <button onClick={() => move("right")}>▶</button>
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
 * 9. MEMORY GAME
 * ============================================================================ */

function MemoryGame() {
  const symbols = ["⚙", "◈", "✦", "⌘", "♞", "⚛", "⚖", "❂"];
  const makeDeck = () =>
    [...symbols, ...symbols]
      .sort(() => Math.random() - 0.5)
      .map((s, idx) => ({ id: idx, sym: s, matched: false }));

  const [cards, setCards] = useState(makeDeck);
  const [flipped, setFlipped] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [seconds, setSeconds] = useState(0);
  const [locked, setLocked] = useState(false);

  const solved = cards.every((c) => c.matched);

  useEffect(() => {
    if (solved) return;
    const id = window.setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => window.clearInterval(id);
  }, [solved]);

  const flipCard = (idx: number) => {
    if (locked || flipped.includes(idx) || cards[idx].matched) return;
    const nextFlipped = [...flipped, idx];
    setFlipped(nextFlipped);
    if (nextFlipped.length === 2) {
      setMoves((m) => m + 1);
      const [a, b] = nextFlipped;
      if (cards[a].sym === cards[b].sym) {
        setCards((prev) => prev.map((c, i) => (i === a || i === b ? { ...c, matched: true } : c)));
        setFlipped([]);
      } else {
        setLocked(true);
        window.setTimeout(() => {
          setFlipped([]);
          setLocked(false);
        }, 620);
      }
    }
  };

  const restart = () => {
    setCards(makeDeck());
    setFlipped([]);
    setMoves(0);
    setSeconds(0);
    setLocked(false);
  };

  return (
    <div className="gp-game-shell">
      <div className="gp-game-toolbar">
        <div className="gp-status-pill">
          Moves: {moves} · Time: {seconds}s · Pairs: {cards.filter((c) => c.matched).length / 2}/8
          {solved ? " · ARCHIVE COMPLETE!" : ""}
        </div>
        <button className="gp-btn" onClick={restart}>
          Shuffle Cards
        </button>
      </div>
      <div className="gp-memory-grid">
        {cards.map((c, i) => {
          const open = c.matched || flipped.includes(i);
          return (
            <button
              key={c.id}
              onClick={() => flipCard(i)}
              className={`gp-memory-card ${open ? "open" : ""} ${c.matched ? "matched" : ""}`}
            >
              {open ? c.sym : "G"}
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ============================================================================
 * 10. REACTION SPEED TEST
 * ============================================================================ */

function ReactionGame() {
  const [phase, setPhase] = useState<"idle" | "waiting" | "ready" | "early" | "result">("idle");
  const [times, setTimes] = useState<number[]>([]);
  const [lastMs, setLastMs] = useState<number | null>(null);
  const startRef = useRef<number>(0);
  const timerRef = useRef<number | null>(null);

  const arm = () => {
    if (timerRef.current) window.clearTimeout(timerRef.current);
    setPhase("waiting");
    const delay = 1400 + Math.random() * 2600;
    timerRef.current = window.setTimeout(() => {
      startRef.current = performance.now();
      setPhase("ready");
    }, delay);
  };

  useEffect(
    () => () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
    },
    [],
  );

  const handlePadClick = () => {
    if (phase === "idle" || phase === "result" || phase === "early") {
      if (times.length >= 5) setTimes([]);
      arm();
    } else if (phase === "waiting") {
      if (timerRef.current) window.clearTimeout(timerRef.current);
      setPhase("early");
    } else if (phase === "ready") {
      const ms = Math.round(performance.now() - startRef.current);
      setLastMs(ms);
      setTimes((t) => [...t, ms]);
      setPhase("result");
    }
  };

  const avg = times.length ? Math.round(times.reduce((a, b) => a + b, 0) / times.length) : null;
  const best = times.length ? Math.min(...times) : null;

  return (
    <div className="gp-game-shell">
      <div className="gp-game-toolbar">
        <div className="gp-status-pill">
          Trial: {times.length}/5 {avg !== null ? `· Avg: ${avg}ms` : ""}{" "}
          {best !== null ? `· Best: ${best}ms` : ""}
        </div>
        <button
          className="gp-btn"
          onClick={() => {
            if (timerRef.current) window.clearTimeout(timerRef.current);
            setTimes([]);
            setLastMs(null);
            setPhase("idle");
          }}
        >
          Reset Calibration
        </button>
      </div>
      <button onClick={handlePadClick} className={`gp-reaction-pad ${phase}`}>
        {phase === "idle" && (
          <>
            <strong>Click to Arm Ignition</strong>
            <span>5-round reflex calibration</span>
          </>
        )}
        {phase === "waiting" && (
          <>
            <strong>HOLD STEADY…</strong>
            <span>Wait for the brass flare before clicking</span>
          </>
        )}
        {phase === "ready" && (
          <>
            <strong>IGNITE NOW!</strong>
            <span>Click immediately</span>
          </>
        )}
        {phase === "early" && (
          <>
            <strong>Too Early — Valve Misfired</strong>
            <span>Click to retry round</span>
          </>
        )}
        {phase === "result" && (
          <>
            <strong>{lastMs} ms</strong>
            <span>
              {times.length >= 5
                ? `Series complete · Average ${avg}ms · Click for new series`
                : "Click to start next trial"}
            </span>
          </>
        )}
      </button>
    </div>
  );
}

/* ============================================================================
 * 11. SIMPLE PLATFORMER (CLOCKWORK ASCENT)
 * ============================================================================ */

interface PlatformLevel {
  platforms: { x: number; y: number; w: number; h: number }[];
  cogs: [number, number][];
  hazards: { x: number; y: number; range: number; speed: number }[];
  spawn: [number, number];
  goal: [number, number];
}

const PLATFORM_LEVELS: PlatformLevel[] = [
  {
    spawn: [40, 280],
    goal: [580, 74],
    platforms: [
      { x: 0, y: 330, w: 640, h: 30 },
      { x: 110, y: 265, w: 120, h: 14 },
      { x: 280, y: 215, w: 130, h: 14 },
      { x: 450, y: 165, w: 110, h: 14 },
      { x: 280, y: 115, w: 120, h: 14 },
      { x: 520, y: 110, w: 100, h: 14 },
    ],
    cogs: [
      [165, 240],
      [340, 190],
      [335, 90],
    ],
    hazards: [{ x: 320, y: 315, range: 90, speed: 2.0 }],
  },
  {
    spawn: [30, 280],
    goal: [585, 64],
    platforms: [
      { x: 0, y: 330, w: 150, h: 30 },
      { x: 200, y: 295, w: 100, h: 14 },
      { x: 350, y: 250, w: 100, h: 14 },
      { x: 490, y: 200, w: 110, h: 14 },
      { x: 310, y: 145, w: 120, h: 14 },
      { x: 130, y: 110, w: 120, h: 14 },
      { x: 520, y: 98, w: 110, h: 14 },
    ],
    cogs: [
      [245, 270],
      [540, 175],
      [185, 85],
    ],
    hazards: [
      { x: 365, y: 132, range: 50, speed: 2.3 },
      { x: 540, y: 186, range: 45, speed: 2.1 },
    ],
  },
  {
    spawn: [35, 280],
    goal: [580, 62],
    platforms: [
      { x: 0, y: 330, w: 110, h: 30 },
      { x: 150, y: 270, w: 90, h: 14 },
      { x: 290, y: 220, w: 90, h: 14 },
      { x: 140, y: 165, w: 90, h: 14 },
      { x: 290, y: 115, w: 110, h: 14 },
      { x: 470, y: 145, w: 80, h: 14 },
      { x: 540, y: 96, w: 90, h: 14 },
    ],
    cogs: [
      [190, 245],
      [180, 140],
      [340, 90],
      [505, 120],
    ],
    hazards: [
      { x: 335, y: 206, range: 38, speed: 2.4 },
      { x: 345, y: 101, range: 46, speed: 2.7 },
    ],
  },
];

function PlatformerGame() {
  const W = 640;
  const H = 360;
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [stage, setStage] = useState(0);
  const [lives, setLives] = useState(3);
  const [running, setRunning] = useState(true);
  const [victory, setVictory] = useState(false);
  const [cogCount, setCogCount] = useState({ got: 0, total: PLATFORM_LEVELS[0].cogs.length });
  const keysRef = useRef<Record<string, boolean>>({});
  const stateRef = useRef({
    x: PLATFORM_LEVELS[0].spawn[0],
    y: PLATFORM_LEVELS[0].spawn[1],
    vx: 0,
    vy: 0,
    jumps: 2,
    onGround: false,
    collected: [] as number[],
    t: 0,
  });

  const loadStage = useCallback((idx: number, resetLives = false) => {
    const lv = PLATFORM_LEVELS[idx];
    stateRef.current = {
      x: lv.spawn[0],
      y: lv.spawn[1],
      vx: 0,
      vy: 0,
      jumps: 2,
      onGround: false,
      collected: [],
      t: 0,
    };
    setStage(idx);
    setCogCount({ got: 0, total: lv.cogs.length });
    if (resetLives) setLives(3);
    setVictory(false);
    setRunning(true);
  }, []);

  const triggerJump = useCallback(() => {
    const st = stateRef.current;
    if (st.jumps > 0) {
      st.vy = -8.6;
      st.jumps -= 1;
      st.onGround = false;
    }
  }, []);

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(k)) e.preventDefault();
      if ((k === "w" || k === "arrowup" || k === " ") && !keysRef.current[k]) {
        triggerJump();
      }
      keysRef.current[k] = true;
    };
    const up = (e: KeyboardEvent) => {
      keysRef.current[e.key.toLowerCase()] = false;
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, [triggerJump]);

  useEffect(() => {
    let raf = 0;
    const loop = () => {
      const lv = PLATFORM_LEVELS[stage];
      const st = stateRef.current;
      const ctx = canvasRef.current?.getContext("2d");

      if (running && !victory) {
        st.t += 0.03;
        const keys = keysRef.current;
        if (keys["a"] || keys["arrowleft"]) st.vx = -3.8;
        else if (keys["d"] || keys["arrowright"]) st.vx = 3.8;
        else st.vx *= 0.72;

        st.vy = Math.min(11, st.vy + 0.44);
        st.x = Math.max(0, Math.min(W - 22, st.x + st.vx));
        st.y += st.vy;
        st.onGround = false;

        for (const p of lv.platforms) {
          if (
            st.x + 22 > p.x &&
            st.x < p.x + p.w &&
            st.y + 26 >= p.y &&
            st.y + 26 <= p.y + p.h + 10 &&
            st.vy >= 0
          ) {
            st.y = p.y - 26;
            st.vy = 0;
            st.onGround = true;
            st.jumps = 2;
          }
        }

        // Collect cogs
        lv.cogs.forEach(([cx, cy], idx) => {
          if (!st.collected.includes(idx)) {
            const dist = Math.hypot(st.x + 11 - cx, st.y + 13 - cy);
            if (dist < 22) {
              st.collected.push(idx);
              setCogCount({ got: st.collected.length, total: lv.cogs.length });
            }
          }
        });

        // Hazards or fall
        let hit = st.y > H + 30;
        for (const hz of lv.hazards) {
          const hx = hz.x + Math.sin(st.t * hz.speed) * hz.range;
          if (Math.hypot(st.x + 11 - hx, st.y + 13 - hz.y) < 19) hit = true;
        }
        if (hit) {
          setLives((l) => {
            if (l <= 1) {
              loadStage(0, true);
              return 3;
            }
            st.x = lv.spawn[0];
            st.y = lv.spawn[1];
            st.vx = 0;
            st.vy = 0;
            return l - 1;
          });
        }

        // Goal check
        if (
          st.collected.length === lv.cogs.length &&
          Math.hypot(st.x + 11 - lv.goal[0], st.y + 13 - lv.goal[1]) < 26
        ) {
          if (stage + 1 < PLATFORM_LEVELS.length) {
            loadStage(stage + 1);
          } else {
            setVictory(true);
            setRunning(false);
          }
        }
      }

      if (ctx) {
        ctx.fillStyle = "#14100c";
        ctx.fillRect(0, 0, W, H);
        // Platforms
        for (const p of lv.platforms) {
          ctx.fillStyle = "#3c2e20";
          ctx.fillRect(p.x, p.y, p.w, p.h);
          ctx.fillStyle = "#b08d57";
          ctx.fillRect(p.x, p.y, p.w, 3);
        }
        // Cogs
        lv.cogs.forEach(([cx, cy], idx) => {
          if (st.collected.includes(idx)) return;
          ctx.fillStyle = "#e6c984";
          ctx.beginPath();
          ctx.arc(cx, cy, 8, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = "#14100c";
          ctx.beginPath();
          ctx.arc(cx, cy, 3, 0, Math.PI * 2);
          ctx.fill();
        });
        // Hazards
        for (const hz of lv.hazards) {
          const hx = hz.x + Math.sin(st.t * hz.speed) * hz.range;
          ctx.fillStyle = "#c95b3c";
          ctx.beginPath();
          ctx.arc(hx, hz.y, 10, 0, Math.PI * 2);
          ctx.fill();
        }
        // Goal
        const portalOpen = st.collected.length === lv.cogs.length;
        ctx.strokeStyle = portalOpen ? "#7cd690" : "#705b42";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(lv.goal[0], lv.goal[1], 16, 0, Math.PI * 2);
        ctx.stroke();
        // Player
        ctx.fillStyle = "#e9d9bd";
        ctx.fillRect(st.x, st.y, 22, 26);
        ctx.fillStyle = "#b08d57";
        ctx.fillRect(st.x + 3, st.y + 5, 16, 6);
      }

      raf = window.requestAnimationFrame(loop);
    };
    raf = window.requestAnimationFrame(loop);
    return () => window.cancelAnimationFrame(raf);
  }, [loadStage, running, stage, victory]);

  return (
    <div className="gp-game-shell">
      <div className="gp-game-toolbar">
        <div className="gp-status-pill">
          Stage {stage + 1}/{PLATFORM_LEVELS.length} · Lives: {lives} · Cogs: {cogCount.got}/
          {cogCount.total} {victory ? "· ALL STAGES ASCENDED!" : ""}
        </div>
        <button className="gp-btn" onClick={() => loadStage(0, true)}>
          Restart Ascent
        </button>
      </div>
      <canvas ref={canvasRef} width={W} height={H} className="gp-canvas wide" />
      <div className="gp-touch-bar">
        <button
          onPointerDown={() => (keysRef.current["arrowleft"] = true)}
          onPointerUp={() => (keysRef.current["arrowleft"] = false)}
          onPointerLeave={() => (keysRef.current["arrowleft"] = false)}
        >
          ◀ Left
        </button>
        <button onClick={triggerJump}>▲ Jump</button>
        <button
          onPointerDown={() => (keysRef.current["arrowright"] = true)}
          onPointerUp={() => (keysRef.current["arrowright"] = false)}
          onPointerLeave={() => (keysRef.current["arrowright"] = false)}
        >
          Right ▶
        </button>
      </div>
    </div>
  );
}

/* ============================================================================
 * 12. SLIDING PUZZLE (15-PLATE BRASS CIPHER)
 * ============================================================================ */

function makeSolvablePuzzle(): number[] {
  const tiles = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0];
  let blank = 15;
  let prev = -1;
  for (let i = 0; i < 140; i++) {
    const r = Math.floor(blank / 4);
    const c = blank % 4;
    const neighbors: number[] = [];
    if (r > 0) neighbors.push(blank - 4);
    if (r < 3) neighbors.push(blank + 4);
    if (c > 0) neighbors.push(blank - 1);
    if (c < 3) neighbors.push(blank + 1);
    const filtered = neighbors.filter((n) => n !== prev);
    const pick = filtered[Math.floor(Math.random() * filtered.length)];
    tiles[blank] = tiles[pick];
    tiles[pick] = 0;
    prev = blank;
    blank = pick;
  }
  return tiles;
}

function SlidingPuzzleGame() {
  const [tiles, setTiles] = useState<number[]>(makeSolvablePuzzle);
  const [moves, setMoves] = useState(0);
  const [seconds, setSeconds] = useState(0);
  const solved = tiles.every((v, i) => (i === 15 ? v === 0 : v === i + 1));

  useEffect(() => {
    if (solved) return;
    const id = window.setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => window.clearInterval(id);
  }, [solved]);

  const slideIndex = useCallback(
    (idx: number) => {
      if (solved) return;
      const blank = tiles.indexOf(0);
      const r1 = Math.floor(idx / 4);
      const c1 = idx % 4;
      const r2 = Math.floor(blank / 4);
      const c2 = blank % 4;
      if (Math.abs(r1 - r2) + Math.abs(c1 - c2) !== 1) return;
      const next = [...tiles];
      next[blank] = next[idx];
      next[idx] = 0;
      setTiles(next);
      setMoves((m) => m + 1);
    },
    [solved, tiles],
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const blank = tiles.indexOf(0);
      const r = Math.floor(blank / 4);
      const c = blank % 4;
      if (e.key === "ArrowUp" && r < 3) {
        e.preventDefault();
        slideIndex(blank + 4);
      } else if (e.key === "ArrowDown" && r > 0) {
        e.preventDefault();
        slideIndex(blank - 4);
      } else if (e.key === "ArrowLeft" && c < 3) {
        e.preventDefault();
        slideIndex(blank + 1);
      } else if (e.key === "ArrowRight" && c > 0) {
        e.preventDefault();
        slideIndex(blank - 1);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [slideIndex, tiles]);

  return (
    <div className="gp-game-shell">
      <div className="gp-game-toolbar">
        <div className="gp-status-pill">
          Moves: {moves} · Time: {seconds}s {solved ? "· CIPHER SOLVED!" : ""}
        </div>
        <button
          className="gp-btn"
          onClick={() => {
            setTiles(makeSolvablePuzzle());
            setMoves(0);
            setSeconds(0);
          }}
        >
          Reshuffle Cipher
        </button>
      </div>
      <div className="gp-puzzle-grid">
        {tiles.map((v, i) => (
          <button
            key={i}
            disabled={v === 0}
            onClick={() => slideIndex(i)}
            className={`gp-puzzle-tile ${v === 0 ? "blank" : v === i + 1 ? "home" : ""}`}
          >
            {v || ""}
          </button>
        ))}
      </div>
    </div>
  );
}

/* ============================================================================
 * 13. CLOCKWORK MINESWEEPER (ORIGINAL MINI-GAME)
 * ============================================================================ */

interface MineCell {
  mine: boolean;
  revealed: boolean;
  flagged: boolean;
  adj: number;
}

function createEmptyMinefield(): MineCell[][] {
  return Array.from({ length: 9 }, () =>
    Array.from({ length: 9 }, () => ({ mine: false, revealed: false, flagged: false, adj: 0 })),
  );
}

function MinesweeperGame() {
  const [grid, setGrid] = useState<MineCell[][]>(createEmptyMinefield);
  const [initialized, setInitialized] = useState(false);
  const [flagMode, setFlagMode] = useState(false);
  const [lost, setLost] = useState(false);

  const revealedSafe = grid.flat().filter((c) => c.revealed && !c.mine).length;
  const won = initialized && !lost && revealedSafe === 81 - 10;
  const flagsUsed = grid.flat().filter((c) => c.flagged).length;

  const populateMines = (safeR: number, safeC: number, base: MineCell[][]) => {
    const next = base.map((row) => row.map((c) => ({ ...c })));
    let placed = 0;
    while (placed < 10) {
      const r = Math.floor(Math.random() * 9);
      const c = Math.floor(Math.random() * 9);
      if (next[r][c].mine || (Math.abs(r - safeR) <= 1 && Math.abs(c - safeC) <= 1)) continue;
      next[r][c].mine = true;
      placed++;
    }
    for (let r = 0; r < 9; r++) {
      for (let c = 0; c < 9; c++) {
        if (next[r][c].mine) continue;
        let count = 0;
        for (let dr = -1; dr <= 1; dr++) {
          for (let dc = -1; dc <= 1; dc++) {
            if (next[r + dr]?.[c + dc]?.mine) count++;
          }
        }
        next[r][c].adj = count;
      }
    }
    return next;
  };

  const revealCell = (r: number, c: number) => {
    if (lost || won) return;
    if (flagMode) {
      toggleFlag(r, c);
      return;
    }
    let next = grid.map((row) => row.map((cell) => ({ ...cell })));
    if (!initialized) {
      next = populateMines(r, c, next);
      setInitialized(true);
    }
    const target = next[r][c];
    if (target.revealed || target.flagged) return;
    if (target.mine) {
      next.forEach((row) => row.forEach((cell) => cell.mine && (cell.revealed = true)));
      setGrid(next);
      setLost(true);
      return;
    }
    const stack: [number, number][] = [[r, c]];
    while (stack.length) {
      const [cr, cc] = stack.pop()!;
      const cell = next[cr]?.[cc];
      if (!cell || cell.revealed || cell.flagged) continue;
      cell.revealed = true;
      if (cell.adj === 0) {
        for (let dr = -1; dr <= 1; dr++) {
          for (let dc = -1; dc <= 1; dc++) {
            if (dr || dc) stack.push([cr + dr, cc + dc]);
          }
        }
      }
    }
    setGrid(next);
  };

  const toggleFlag = (r: number, c: number) => {
    if (lost || won || grid[r][c].revealed) return;
    setGrid((prev) =>
      prev.map((row, ri) =>
        row.map((cell, ci) =>
          ri === r && ci === c ? { ...cell, flagged: !cell.flagged } : cell,
        ),
      ),
    );
  };

  const reset = () => {
    setGrid(createEmptyMinefield());
    setInitialized(false);
    setLost(false);
  };

  return (
    <div className="gp-game-shell">
      <div className="gp-game-toolbar">
        <div className="gp-status-pill">
          Mines: {10 - flagsUsed} · Safe Cleared: {revealedSafe}/71{" "}
          {won ? "· FIELD CLEARED!" : lost ? "· MINE DETONATED!" : ""}
        </div>
        <button className={`gp-btn ${flagMode ? "active" : ""}`} onClick={() => setFlagMode((f) => !f)}>
          {flagMode ? "⚑ Flag Mode: ON" : "⚑ Flag Mode: OFF"}
        </button>
        <button className="gp-btn" onClick={reset}>
          New Field
        </button>
      </div>
      <div className="gp-mine-grid">
        {grid.map((row, r) =>
          row.map((cell, c) => (
            <button
              key={`${r}-${c}`}
              onClick={() => revealCell(r, c)}
              onContextMenu={(e) => {
                e.preventDefault();
                toggleFlag(r, c);
              }}
              className={`gp-mine-cell ${cell.revealed ? (cell.mine ? "mine" : "open") : ""}`}
            >
              {cell.revealed ? (cell.mine ? "✹" : cell.adj || "") : cell.flagged ? "⚑" : ""}
            </button>
          )),
        )}
      </div>
    </div>
  );
}

/* ============================================================================
 * GAME PROTOCOL SHELL (ARCADE + ONLINE MULTIPLAYER + IMPORTED GAMES)
 * ============================================================================ */

type ChamberFilter = "all" | "strategy" | "online" | "arcade";

export function GameProtocol({ onExit }: { onExit: () => void }) {
  const [section, setSection] = useState<ProtocolSection>("arcade");
  const [activeGame, setActiveGame] = useState<BuiltinGameId>("chess");
  const [chamberFilter, setChamberFilter] = useState<ChamberFilter>("all");

  // Imported games state
  const [importedGames, setImportedGames] = useState<ImportedGame[]>(() => loadImportedGames());
  const [activeImported, setActiveImported] = useState<ImportedGame | null>(null);
  const [showImportDocs, setShowImportDocs] = useState(false);
  const [formName, setFormName] = useState("");
  const [formUrl, setFormUrl] = useState("");
  const [formDesc, setFormDesc] = useState("");
  const [formCat, setFormCat] = useState("Arcade");
  const [formType, setFormType] = useState<ImportedGameType>("html5");
  const [formMode, setFormMode] = useState<ImportedLaunchMode>("iframe");
  const [formThumb, setFormThumb] = useState("");
  const [importError, setImportError] = useState("");

  // Online multiplayer state
  const [playerName, setPlayerName] = useState("Mechanist");
  const [mpGameId, setMpGameId] = useState<MultiplayerGameId>("chess");
  const [joinCodeInput, setJoinCodeInput] = useState("");
  const [mpError, setMpError] = useState("");
  const [mpBusy, setMpBusy] = useState(false);
  const [onlineSession, setOnlineSession] = useState<ActiveOnlineSession | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);
  const subRef = useRef<{
    sendBroadcast: (p: {
      state: Record<string, unknown>;
      turn: string;
      status?: GameRoomRecord["status"];
    }) => Promise<void>;
    unsubscribe: () => Promise<void>;
  } | null>(null);

  const buildInitialOnlineState = (gid: MultiplayerGameId): Record<string, unknown> => {
    if (gid === "chess") return createInitialChessState() as unknown as Record<string, unknown>;
    if (gid === "coop-vault") return initCoopLevel(0) as unknown as Record<string, unknown>;
    if (gid === "tictactoe") return { board: Array(9).fill(null), turn: "X" };
    if (gid === "connect4")
      return { grid: Array.from({ length: 6 }, () => Array(7).fill(0)), turn: 1 };
    return { hostPick: null, guestPick: null, round: 1, hostScore: 0, guestScore: 0, draws: 0 };
  };

  const attachRoomSubscription = useCallback(
    (room: GameRoomRecord, role: RoomRole, cleanName: string) => {
      if (subRef.current) {
        void subRef.current.unsubscribe();
      }
      const playerId = getLocalPlayerId();
      const sub = subscribeToMultiplayerRoom({
        code: room.code,
        playerId,
        playerName: cleanName,
        role,
        onRoomUpdate: (updated) => {
          setOnlineSession((prev) => (prev ? { ...prev, room: updated } : prev));
        },
        onBroadcastState: (payload) => {
          setOnlineSession((prev) =>
            prev
              ? {
                  ...prev,
                  room: {
                    ...prev.room,
                    state: payload.state,
                    turn: payload.turn,
                    status: payload.status ?? prev.room.status,
                  },
                }
              : prev,
          );
        },
        onPresenceSync: (peers) => {
          setOnlineSession((prev) => (prev ? { ...prev, peers } : prev));
        },
        onStatusChange: (status) => {
          setOnlineSession((prev) => (prev ? { ...prev, realtimeStatus: status } : prev));
        },
      });
      subRef.current = sub;

      setOnlineSession({
        room,
        role,
        playerId,
        playerName: cleanName,
        peers: [],
        realtimeStatus: "CONNECTING",
        sendState: async (state, turn, status) => {
          await sub.sendBroadcast({ state, turn, status });
          await pushRoomState({ code: room.code, state, turn, status });
        },
      });
      setActiveGame(room.game_id);
    },
    [],
  );

  useEffect(() => {
    return () => {
      if (subRef.current) void subRef.current.unsubscribe();
    };
  }, []);

  const handleCreateRoom = async () => {
    setMpError("");
    setMpBusy(true);
    const cleanName = playerName.trim() || "Host Mechanist";
    const initial = buildInitialOnlineState(mpGameId);
    const { room, error } = await createMultiplayerRoom({
      gameId: mpGameId,
      playerName: cleanName,
      initialState: initial,
      initialTurn: mpGameId === "coop-vault" || mpGameId === "rps" ? "both" : "host",
    });
    setMpBusy(false);
    if (error || !room) {
      setMpError(error || "Unable to create room.");
      return;
    }
    attachRoomSubscription(room, "host", cleanName);
  };

  const handleJoinRoom = async () => {
    setMpError("");
    setMpBusy(true);
    const cleanName = playerName.trim() || "Guest Mechanist";
    const { room, role, error } = await joinMultiplayerRoom({
      code: joinCodeInput,
      playerName: cleanName,
    });
    setMpBusy(false);
    if (error || !room || !role) {
      setMpError(error || "Unable to join room.");
      return;
    }
    attachRoomSubscription(room, role, cleanName);
  };

  const handleLeaveRoom = async () => {
    if (!onlineSession) return;
    const { room, role } = onlineSession;
    if (subRef.current) {
      await subRef.current.unsubscribe();
      subRef.current = null;
    }
    await leaveMultiplayerRoom({ code: room.code, role });
    setOnlineSession(null);
  };

  const handleAddImportedGame = (e: React.FormEvent) => {
    e.preventDefault();
    setImportError("");
    if (!formName.trim()) return setImportError("Enter a game name.");
    if (!isValidExternalGameUrl(formUrl))
      return setImportError("Enter a valid http:// or https:// URL.");
    if (formThumb.trim() && !isValidExternalGameUrl(formThumb))
      return setImportError("Thumbnail must be a valid http:// or https:// URL.");

    saveUserImportedGame({
      name: formName.trim(),
      url: formUrl.trim(),
      description: formDesc.trim() || "Externally imported web game.",
      category: formCat.trim() || "Arcade",
      type: formType,
      thumbnail: formThumb.trim() || undefined,
      launch: {
        mode: formMode,
        sandbox: DEFAULT_UNTRUSTED_SANDBOX,
        allowFullscreen: true,
        aspectRatio: "16 / 10",
      },
    });
    setImportedGames(loadImportedGames());
    setFormName("");
    setFormUrl("");
    setFormDesc("");
    setFormThumb("");
  };

  const currentMeta = BUILTIN_GAMES.find((g) => g.id === activeGame) || BUILTIN_GAMES[0];
  const hostOnline = onlineSession?.peers.some((p) => p.role === "host");
  const guestOnline = onlineSession?.peers.some((p) => p.role === "guest");

  const renderActiveGame = (onlineCtx: ActiveOnlineSession | null) => {
    switch (activeGame) {
      case "chess":
        return <ChessGame online={onlineCtx} />;
      case "coop-vault":
        return <CoopVaultGame online={onlineCtx} />;
      case "tictactoe":
        return <TicTacToeGame online={onlineCtx} />;
      case "connect4":
        return <ConnectFourGame online={onlineCtx} />;
      case "rps":
        return <RpsGame online={onlineCtx} />;
      case "snake":
        return <SnakeGame />;
      case "pong":
        return <PongGame />;
      case "2048":
        return <Game2048 />;
      case "memory":
        return <MemoryGame />;
      case "reaction":
        return <ReactionGame />;
      case "platformer":
        return <PlatformerGame />;
      case "puzzle":
        return <SlidingPuzzleGame />;
      case "minesweeper":
        return <MinesweeperGame />;
    }
  };

  return (
    <main className="gp-root">
      <header className="gp-header">
        <div className="gp-brand">
          <span className="gp-emblem">⚙</span>
          <div>
            <p className="eyebrow" style={{ marginBottom: 4 }}>
              Hidden Aperture · Protocol VII
            </p>
            <h1>GNOSIS GAME PROTOCOL</h1>
          </div>
        </div>
        <div className="gp-nav-tabs">
          <button
            className={section === "arcade" ? "active" : ""}
            onClick={() => setSection("arcade")}
          >
            Built-in Chambers ({BUILTIN_GAMES.length})
          </button>
          <button
            className={section === "multiplayer" ? "active" : ""}
            onClick={() => setSection("multiplayer")}
          >
            Online Multiplayer {onlineSession ? `(${onlineSession.room.code})` : ""}
          </button>
          <button
            className={section === "imported" ? "active" : ""}
            onClick={() => setSection("imported")}
          >
            Imported Games ({importedGames.length})
          </button>
        </div>
        <button className="gp-exit-btn" onClick={onExit}>
          ← Exit to Workshop
        </button>
      </header>

      {section === "arcade" && (
        <section className="gp-arcade-layout">
          <aside className="gp-game-list">
            <div className="gw-filter-bar" role="group" aria-label="Filter game chambers" style={{ padding: "8px 8px 4px" }}>
              {(
                [
                  ["all", "All"],
                  ["online", "Online & Co-op"],
                  ["strategy", "Strategy"],
                  ["arcade", "Arcade & Puzzle"],
                ] as [ChamberFilter, string][]
              ).map(([fid, flabel]) => (
                <button
                  key={fid}
                  type="button"
                  className={`gw-filter-btn ${chamberFilter === fid ? "active" : ""}`}
                  onClick={() => setChamberFilter(fid)}
                >
                  {flabel}
                </button>
              ))}
            </div>
            {BUILTIN_GAMES.filter((g) => {
              if (chamberFilter === "all") return true;
              if (chamberFilter === "online") return Boolean(g.multiplayerSupported);
              if (chamberFilter === "strategy") {
                return g.id === "chess" || g.id === "connect4" || g.id === "tictactoe" || g.id === "minesweeper";
              }
              return !g.multiplayerSupported && g.id !== "minesweeper";
            }).map((g) => (
              <button
                key={g.id}
                className={`gp-game-item ${activeGame === g.id ? "active" : ""}`}
                onClick={() => setActiveGame(g.id)}
              >
                <span className="gp-item-sigil">{g.sigil}</span>
                <div>
                  <b>{g.title}</b>
                  <small>
                    {g.category} · {g.players}
                  </small>
                </div>
              </button>
            ))}
          </aside>
          <div className="gp-stage">
            <div className="gw-hero-deck" style={{ marginBottom: 14, minHeight: 120 }}>
              <img className="gw-hero-deck-bg" src={cardChessImg} alt="" />
              <div className="gw-hero-deck-scrim" />
              <div className="gw-hero-deck-content">
                <span className="gw-hero-deck-kicker">
                  {currentMeta.subtitle} · {currentMeta.players}
                </span>
                <h3>{currentMeta.title}</h3>
                <p>{currentMeta.description}</p>
              </div>
              <div className="gw-hero-deck-actions">
                {currentMeta.multiplayerSupported && (
                  <button
                    className="brass-button"
                    onClick={() => {
                      setMpGameId(currentMeta.id as MultiplayerGameId);
                      setSection("multiplayer");
                    }}
                  >
                    Open Online Lobby →
                  </button>
                )}
              </div>
            </div>
            <div className="gp-stage-head">
              <div>
                <p className="gp-stage-ctrl" style={{ margin: 0 }}>
                  <b>Controls:</b> {currentMeta.controls}
                </p>
              </div>
            </div>
            {renderActiveGame(null)}
          </div>
        </section>
      )}

      {section === "multiplayer" && (
        <section className="gp-mp-section">
          {!isSupabaseConfigured ? (
            <div className="gp-mp-offline">
              <p className="eyebrow">Real-Time Backend Status · Not Configured</p>
              <h2>Online Multiplayer Offline — Supabase Required</h2>
              <p>
                Cross-device internet multiplayer uses <b>Supabase Realtime</b> (Postgres Changes +
                Presence + Broadcast). Because <code>VITE_SUPABASE_URL</code> and{" "}
                <code>VITE_SUPABASE_ANON_KEY</code> are not currently set in this environment, live
                online rooms are disabled rather than simulated.
              </p>
              <div className="gp-mp-steps">
                <div>
                  <b>1. Create Supabase Project</b>
                  <p>Copy Project URL and public anon key (never service_role).</p>
                </div>
                <div>
                  <b>2. Apply SQL Migration</b>
                  <p>
                    Run <code>supabase/migrations/001_game_rooms.sql</code> in Supabase SQL Editor.
                  </p>
                </div>
                <div>
                  <b>3. Set Env Vars</b>
                  <p>
                    Add <code>VITE_SUPABASE_URL</code> and <code>VITE_SUPABASE_ANON_KEY</code> to{" "}
                    <code>.env</code> (see <code>.env.example</code> and{" "}
                    <code>supabase/README.md</code>) and restart <code>npm run dev</code>.
                  </p>
                </div>
              </div>
              <p className="gp-muted" style={{ marginTop: 18 }}>
                Meanwhile, you can play Chess, Aether Vault Co-op, Tic-Tac-Toe, Connect Four, and
                Pong locally in the <b>Built-in Chambers</b> tab.
              </p>
            </div>
          ) : !onlineSession ? (
            <div className="gp-mp-lobby">
              <div className="gp-mp-card">
                <p className="eyebrow">Supabase Realtime · Connected</p>
                <h2>Create or Join an Online Room</h2>
                <label className="gp-field">
                  <span>Your Callsign</span>
                  <input
                    value={playerName}
                    onChange={(e) => setPlayerName(e.target.value)}
                    placeholder="Mechanist name…"
                    maxLength={24}
                  />
                </label>

                <div className="gp-mp-columns">
                  <div className="gp-mp-box">
                    <h3>Host a New Room</h3>
                    <label className="gp-field">
                      <span>Select Online Game</span>
                      <select
                        value={mpGameId}
                        onChange={(e) => setMpGameId(e.target.value as MultiplayerGameId)}
                      >
                        <option value="chess">Chess · Automaton Board</option>
                        <option value="coop-vault">Aether Vault Co-op (2P Puzzle)</option>
                        <option value="tictactoe">Tic-Tac-Toe</option>
                        <option value="connect4">Connect Four</option>
                        <option value="rps">Rock Paper Scissors (Sealed Commit)</option>
                      </select>
                    </label>
                    <button className="brass-button" disabled={mpBusy} onClick={handleCreateRoom}>
                      {mpBusy ? "Creating…" : "Create Room Code"}
                    </button>
                  </div>

                  <div className="gp-mp-box">
                    <h3>Join Existing Room</h3>
                    <label className="gp-field">
                      <span>6-Character Room Code</span>
                      <input
                        value={joinCodeInput}
                        onChange={(e) => setJoinCodeInput(e.target.value.toUpperCase())}
                        placeholder="e.g. A7K9P2"
                        maxLength={12}
                      />
                    </label>
                    <button className="brass-button" disabled={mpBusy} onClick={handleJoinRoom}>
                      {mpBusy ? "Joining…" : "Join Room"}
                    </button>
                  </div>
                </div>
                {mpError && <p className="gp-error">{mpError}</p>}
              </div>
            </div>
          ) : (
            <div className="gp-mp-active">
              <div className="gp-mp-roombar">
                <div>
                  <small>ROOM CODE</small>
                  <strong>{onlineSession.room.code}</strong>
                  <button
                    className="gp-btn"
                    onClick={() => {
                      navigator.clipboard?.writeText(onlineSession.room.code);
                      setCopiedCode(true);
                      window.setTimeout(() => setCopiedCode(false), 1400);
                    }}
                  >
                    {copiedCode ? "Copied ✓" : "Copy"}
                  </button>
                </div>
                <div className="gp-presence-list">
                  <span className={`gp-peer ${hostOnline ? "on" : "off"}`}>
                    ● Host ({onlineSession.room.host_name}): {hostOnline ? "Online" : "Disconnected"}
                  </span>
                  <span className={`gp-peer ${guestOnline ? "on" : "off"}`}>
                    ● Guest ({onlineSession.room.guest_name || "Waiting"}):{" "}
                    {guestOnline
                      ? "Online"
                      : onlineSession.room.guest_id
                        ? "Disconnected"
                        : "Waiting for player"}
                  </span>
                  <span className="gp-tag">Channel: {onlineSession.realtimeStatus}</span>
                </div>
                <button className="gp-exit-btn" onClick={handleLeaveRoom}>
                  Leave Room
                </button>
              </div>
              {onlineSession.room.status === "closed" && (
                <div className="gp-error">The host has closed this room.</div>
              )}
              {renderActiveGame(onlineSession)}
            </div>
          )}
        </section>
      )}

      {section === "imported" && (
        <section className="gp-imported-section">
          <div className="gp-imported-top">
            <div>
              <p className="eyebrow">External Registry · Untrusted Content Sandboxed</p>
              <h2>Imported Games Catalog</h2>
              <p className="gp-muted">
                Add external HTML5/web games with URL validation. Iframe embeds run inside an
                isolated sandbox without bypassing CSP or X-Frame-Options; blocked origins can open
                safely in a new tab.
              </p>
            </div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              <button className="gp-btn" onClick={() => setShowImportDocs((d) => !d)}>
                {showImportDocs ? "Hide Registry Docs" : "How to Add Manually"}
              </button>
              <button
                className="gp-btn"
                onClick={() => setImportedGames(restoreRegistryGames())}
              >
                Restore Defaults
              </button>
            </div>
          </div>

          {showImportDocs && (
            <div className="gp-docs-box">
              <h4>Manual Registry Guide (src/game-imports.ts)</h4>
              <p>
                Open <code>src/game-imports.ts</code> and append an entry to{" "}
                <code>MANUAL_IMPORTED_GAMES</code> with <code>id</code>, <code>name</code>,{" "}
                <code>description</code>, <code>url</code>, <code>category</code>,{" "}
                <code>type</code>, <code>source: &quot;manual-registry&quot;</code>, and{" "}
                <code>launch: &#123; mode: &quot;iframe&quot; | &quot;external&quot;, sandbox &#125;</code>.
              </p>
            </div>
          )}

          <div className="gp-imported-grid-wrap">
            <form className="gp-import-form" onSubmit={handleAddImportedGame}>
              <h3>Register External Game</h3>
              <label className="gp-field">
                <span>Game Name *</span>
                <input
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g. Polycraft Arena"
                />
              </label>
              <label className="gp-field">
                <span>Game URL (https:// or http://) *</span>
                <input
                  value={formUrl}
                  onChange={(e) => setFormUrl(e.target.value)}
                  placeholder="https://example.com/game"
                />
              </label>
              <label className="gp-field">
                <span>Description</span>
                <textarea
                  rows={2}
                  value={formDesc}
                  onChange={(e) => setFormDesc(e.target.value)}
                  placeholder="Short description…"
                />
              </label>
              <div className="gp-form-row">
                <label className="gp-field">
                  <span>Category</span>
                  <input value={formCat} onChange={(e) => setFormCat(e.target.value)} />
                </label>
                <label className="gp-field">
                  <span>Type</span>
                  <select
                    value={formType}
                    onChange={(e) => setFormType(e.target.value as ImportedGameType)}
                  >
                    <option value="html5">HTML5</option>
                    <option value="web">Web</option>
                    <option value="canvas">Canvas</option>
                    <option value="puzzle">Puzzle</option>
                    <option value="arcade">Arcade</option>
                    <option value="strategy">Strategy</option>
                    <option value="coop">Co-op</option>
                  </select>
                </label>
              </div>
              <div className="gp-form-row">
                <label className="gp-field">
                  <span>Launch Mode</span>
                  <select
                    value={formMode}
                    onChange={(e) => setFormMode(e.target.value as ImportedLaunchMode)}
                  >
                    <option value="iframe">Sandboxed Iframe</option>
                    <option value="external">External Tab</option>
                  </select>
                </label>
                <label className="gp-field">
                  <span>Thumbnail URL (optional)</span>
                  <input
                    value={formThumb}
                    onChange={(e) => setFormThumb(e.target.value)}
                    placeholder="https://…"
                  />
                </label>
              </div>
              {importError && <p className="gp-error">{importError}</p>}
              <button type="submit" className="brass-button">
                Add to Catalog
              </button>
            </form>

            <div className="gp-imported-catalog">
              {activeImported && (
                <div className="gp-import-player">
                  <div className="gp-import-player-bar">
                    <div>
                      <strong>{activeImported.name}</strong>
                      <small>
                        Sandboxed: <code>{activeImported.launch.sandbox || DEFAULT_UNTRUSTED_SANDBOX}</code>
                      </small>
                    </div>
                    <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                      <a
                        className="gp-btn"
                        href={activeImported.url}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        Blocked? Open Externally ↗
                      </a>
                      <button className="gp-btn" onClick={() => setActiveImported(null)}>
                        Close Player
                      </button>
                    </div>
                  </div>
                  <iframe
                    key={activeImported.id}
                    title={activeImported.name}
                    src={activeImported.url}
                    sandbox={activeImported.launch.sandbox || DEFAULT_UNTRUSTED_SANDBOX}
                    referrerPolicy="no-referrer"
                    allowFullScreen={activeImported.launch.allowFullscreen}
                  />
                </div>
              )}

              <div className="gp-import-cards">
                {importedGames.map((g) => (
                  <article key={g.id} className="gp-import-card">
                    {g.thumbnail && (
                      <img src={g.thumbnail} alt={g.name} className="gp-import-thumb" />
                    )}
                    <div className="gp-import-meta">
                      <small>
                        {g.category} · {g.type.toUpperCase()} ·{" "}
                        {g.source === "manual-registry" ? "Registry" : "Saved"}
                      </small>
                      <h4>{g.name}</h4>
                      <p>{g.description}</p>
                    </div>
                    <div className="gp-import-actions">
                      {g.launch.mode === "iframe" ? (
                        <button className="gp-btn" onClick={() => setActiveImported(g)}>
                          ▶ Launch Embedded
                        </button>
                      ) : (
                        <a
                          className="gp-btn"
                          href={g.url}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          Open Externally ↗
                        </a>
                      )}
                      <a
                        className="gp-btn"
                        href={g.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        title="Open direct external link"
                      >
                        ↗
                      </a>
                      <button
                        className="gp-btn danger"
                        onClick={() => {
                          if (activeImported?.id === g.id) setActiveImported(null);
                          setImportedGames(removeImportedGame(g.id));
                        }}
                      >
                        Remove
                      </button>
                    </div>
                  </article>
                ))}
              </div>
            </div>
          </div>
        </section>
      )}
    </main>
  );
}
