import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { WorkshopHub } from "./workshop/WorkshopHub";

type Page =
  | "academy"
  | "course"
  | "workshop"
  | "library"
  | "examination"
  | "gateway"
  | "chronicles"
  | "profile";
type Track = "HTML" | "CSS" | "JavaScript";

const IMG = {
  library:
    "https://images.unsplash.com/photo-1722182877533-7378b60bf1e8?auto=format&fit=crop&w=1600&q=85",
  gears:
    "https://images.unsplash.com/photo-1777891699620-98471a1042e2?auto=format&fit=crop&w=1600&q=85",
  ersicus:
    "https://images.unsplash.com/photo-1731705873247-d9e13f24e87d?auto=format&fit=crop&w=900&q=85",
};

const tracks: Record<
  Track,
  { subtitle: string; sigil: string; lessons: string[]; intro: string; color: string }
> = {
  HTML: {
    subtitle: "The Foundation of Creation",
    sigil: "< >",
    color: "#b86b42",
    intro: "Construct the semantic skeleton of every digital invention.",
    lessons: [
      "Document structure",
      "Tags & attributes",
      "Headings & paragraphs",
      "Links & hyperlinks",
      "Images",
      "Lists",
      "Tables",
      "Forms",
      "Semantic HTML",
      "HTML5",
    ],
  },
  CSS: {
    subtitle: "The Art of Engineering",
    sigil: "{ }",
    color: "#c6a96c",
    intro: "Master proportion, atmosphere, geometry, and responsive form.",
    lessons: [
      "Selectors",
      "Color systems",
      "Typography",
      "Margins & padding",
      "The box model",
      "Flexbox",
      "Grid",
      "Positioning",
      "Transitions",
      "Animations",
      "Responsive design",
      "Media queries",
    ],
  },
  JavaScript: {
    subtitle: "The Intelligence of Machines",
    sigil: "( )",
    color: "#d3ba74",
    intro: "Give mechanisms memory, decisions, motion, and intelligence.",
    lessons: [
      "Variables",
      "Data types",
      "Operators",
      "Conditions",
      "Loops",
      "Functions",
      "Arrays",
      "Objects",
      "DOM manipulation",
      "Events",
      "Promises",
      "Async / Await",
      "Fetch API",
    ],
  },
};

const resources = [
  [
    "Official Archives",
    "MDN Web Docs",
    "The comprehensive technical archive for web developers.",
    "https://developer.mozilla.org/",
  ],
  [
    "Official Archives",
    "W3Schools",
    "Accessible primers and practical examples for web technologies.",
    "https://www.w3schools.com/",
  ],
  [
    "Official Archives",
    "JavaScript.info",
    "A modern, deeply structured guide to JavaScript.",
    "https://javascript.info/",
  ],
  [
    "Official Archives",
    "HTML Living Standard",
    "The authoritative specification for the language of the web.",
    "https://html.spec.whatwg.org/",
  ],
  [
    "Official Archives",
    "CSS Reference",
    "MDN’s complete catalogue of CSS properties and concepts.",
    "https://developer.mozilla.org/en-US/docs/Web/CSS",
  ],
  [
    "Lecture Halls",
    "freeCodeCamp YouTube",
    "Long-form, free programming courses and guided projects.",
    "https://www.youtube.com/@freecodecamp",
  ],
  [
    "Lecture Halls",
    "Programming with Mosh",
    "Clear, polished courses for foundational programming skills.",
    "https://www.youtube.com/@programmingwithmosh",
  ],
  [
    "Lecture Halls",
    "Traversy Media",
    "Practical web development projects and crash courses.",
    "https://www.youtube.com/@TraversyMedia",
  ],
  [
    "Lecture Halls",
    "Fireship",
    "Rapid, visual explanations of modern development concepts.",
    "https://www.youtube.com/@Fireship",
  ],
  [
    "Inventors’ Workshops",
    "GitHub",
    "The repository of modern digital creations.",
    "https://github.com/",
  ],
  [
    "Inventors’ Workshops",
    "CodePen",
    "An experimental workshop for frontend development.",
    "https://codepen.io/",
  ],
  [
    "Inventors’ Workshops",
    "JSFiddle",
    "A quick laboratory for testing browser code.",
    "https://jsfiddle.net/",
  ],
  [
    "Inventors’ Workshops",
    "Stack Overflow",
    "A vast question-and-answer archive for working developers.",
    "https://stackoverflow.com/",
  ],
  [
    "Inventors’ Workshops",
    "Replit",
    "A collaborative, browser-based coding environment.",
    "https://replit.com/",
  ],
  [
    "Inventors’ Workshops",
    "Frontend Mentor",
    "Professional interface challenges for practical learning.",
    "https://www.frontendmentor.io/",
  ],
  [
    "Design Cabinet",
    "Figma",
    "A collaborative instrument for interface design.",
    "https://www.figma.com/",
  ],
  [
    "Design Cabinet",
    "Google Fonts",
    "A library of open typefaces for digital work.",
    "https://fonts.google.com/",
  ],
  [
    "Design Cabinet",
    "Unsplash",
    "A collection of high-quality, freely usable photography.",
    "https://unsplash.com/",
  ],
];

const icons: Record<string, string> = {
  academy: "M3 21h18M5 21V9l7-5 7 5v12M9 21v-7h6v7M8 10h.01M16 10h.01",
  workshop:
    "M14.7 6.3a4 4 0 0 0-5-5L12 3.6 3.6 12l-2.3 2.3a4 4 0 0 0 5 5L8.7 17l8.4-8.4 2.3 2.3a4 4 0 0 0-4.7-4.6Z",
  library: "M4 19.5A2.5 2.5 0 0 1 6.5 17H20V5H6.5A2.5 2.5 0 0 0 4 7.5v12Zm0 0V7.5M8 8h8",
  examination: "m9 11 3 3L22 4M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11",
  gateway: "M15 3h6v6M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",
  chronicles: "M12 6.3a9 9 0 1 0 5.7 2M12 3v9l4 2",
  profile: "M20 21a8 8 0 0 0-16 0M12 13a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z",
};
function Icon({ name, size = 19 }: { name: string; size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d={icons[name] || icons.academy} />
    </svg>
  );
}

function Emblem({ small = false }: { small?: boolean }) {
  return (
    <div className={`emblem ${small ? "emblem-small" : ""}`} aria-label="Gnosis emblem">
      <span className="gear-ring" />
      <span className="emblem-g">G</span>
    </div>
  );
}

type SoundKind = "click" | "gear" | "steam" | "success";

function makeNoise(context: AudioContext, seconds: number) {
  const buffer = context.createBuffer(1, context.sampleRate * seconds, context.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
  const source = context.createBufferSource();
  source.buffer = buffer;
  return source;
}

function playStandaloneEntranceSound() {
  const context = new AudioContext();
  const master = context.createGain();
  master.gain.setValueAtTime(0.0001, context.currentTime);
  master.gain.exponentialRampToValueAtTime(0.18, context.currentTime + 0.08);
  master.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + 2.7);
  master.connect(context.destination);

  const hiss = makeNoise(context, 2.6);
  const filter = context.createBiquadFilter();
  filter.type = "bandpass";
  filter.frequency.setValueAtTime(480, context.currentTime);
  filter.frequency.exponentialRampToValueAtTime(1800, context.currentTime + 1.5);
  filter.Q.value = 0.6;
  hiss.connect(filter).connect(master);
  hiss.start();

  [0, 0.24, 0.5, 0.82].forEach((delay, index) => {
    const gear = context.createOscillator();
    const gain = context.createGain();
    gear.type = "square";
    gear.frequency.value = 75 - index * 7;
    gain.gain.setValueAtTime(0.14, context.currentTime + delay);
    gain.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + delay + 0.11);
    gear.connect(gain).connect(master);
    gear.start(context.currentTime + delay);
    gear.stop(context.currentTime + delay + 0.12);
  });
  window.setTimeout(() => void context.close(), 3000);
}

function useSteampunkAudio() {
  const [enabled, setEnabledState] = useState(false);
  const [music, setMusic] = useState(true);
  const [effects, setEffects] = useState(true);
  const [volume, setVolume] = useState(30);
  const context = useRef<AudioContext | null>(null);
  const master = useRef<GainNode | null>(null);
  const musicBus = useRef<GainNode | null>(null);
  const effectsBus = useRef<GainNode | null>(null);
  const ambience = useRef<AudioScheduledSourceNode[]>([]);
  const tickTimer = useRef<number | null>(null);

  const ensureContext = useCallback(() => {
    if (!context.current) {
      const audio = new AudioContext();
      const main = audio.createGain();
      const musicGain = audio.createGain();
      const effectsGain = audio.createGain();
      main.gain.value = 0;
      musicGain.gain.value = 0.16;
      effectsGain.gain.value = 0.7;
      musicGain.connect(main);
      effectsGain.connect(main);
      main.connect(audio.destination);
      context.current = audio;
      master.current = main;
      musicBus.current = musicGain;
      effectsBus.current = effectsGain;
    }
    void context.current.resume();
    return context.current;
  }, []);

  const play = useCallback(
    (kind: SoundKind) => {
      if (!enabled || !effects) return;
      const audio = ensureContext();
      const bus = effectsBus.current;
      if (!bus) return;
      const now = audio.currentTime;

      if (kind === "steam") {
        const noise = makeNoise(audio, 1.35);
        const filter = audio.createBiquadFilter();
        const gain = audio.createGain();
        filter.type = "bandpass";
        filter.frequency.setValueAtTime(350, now);
        filter.frequency.exponentialRampToValueAtTime(1400, now + 0.75);
        filter.Q.value = 0.5;
        gain.gain.setValueAtTime(0.0001, now);
        gain.gain.exponentialRampToValueAtTime(0.32, now + 0.08);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 1.3);
        noise.connect(filter).connect(gain).connect(bus);
        noise.start(now);
        return;
      }

      const notes =
        kind === "success" ? [196, 247, 294, 392] : kind === "gear" ? [88, 73, 98] : [1180];
      notes.forEach((frequency, index) => {
        const oscillator = audio.createOscillator();
        const gain = audio.createGain();
        const delay = kind === "click" ? 0 : index * 0.09;
        oscillator.type = kind === "success" ? "triangle" : "square";
        oscillator.frequency.setValueAtTime(frequency, now + delay);
        if (kind !== "success")
          oscillator.frequency.exponentialRampToValueAtTime(
            Math.max(45, frequency * 0.7),
            now + delay + 0.09,
          );
        gain.gain.setValueAtTime(kind === "click" ? 0.035 : 0.09, now + delay);
        gain.gain.exponentialRampToValueAtTime(
          0.0001,
          now + delay + (kind === "success" ? 0.55 : 0.1),
        );
        oscillator.connect(gain).connect(bus);
        oscillator.start(now + delay);
        oscillator.stop(now + delay + (kind === "success" ? 0.6 : 0.11));
      });
    },
    [effects, enabled, ensureContext],
  );

  const stopAmbience = useCallback(() => {
    ambience.current.forEach((node) => {
      try {
        node.stop();
      } catch {
        // The source may already have naturally ended.
      }
    });
    ambience.current = [];
    if (tickTimer.current) window.clearInterval(tickTimer.current);
    tickTimer.current = null;
  }, []);

  const startAmbience = useCallback(() => {
    const audio = ensureContext();
    const bus = musicBus.current;
    if (!bus || ambience.current.length) return;
    [43.65, 65.41, 87.31].forEach((frequency, index) => {
      const oscillator = audio.createOscillator();
      const gain = audio.createGain();
      oscillator.type = index === 0 ? "sine" : "triangle";
      oscillator.frequency.value = frequency;
      oscillator.detune.value = index * 3;
      gain.gain.value = index === 0 ? 0.18 : 0.055;
      oscillator.connect(gain).connect(bus);
      oscillator.start();
      ambience.current.push(oscillator);
    });
    const air = makeNoise(audio, 4);
    const airFilter = audio.createBiquadFilter();
    const airGain = audio.createGain();
    air.loop = true;
    airFilter.type = "lowpass";
    airFilter.frequency.value = 180;
    airGain.gain.value = 0.035;
    air.connect(airFilter).connect(airGain).connect(bus);
    air.start();
    ambience.current.push(air);
  }, [ensureContext]);

  const setEnabled = (next: boolean) => {
    setEnabledState(next);
    const audio = ensureContext();
    master.current?.gain.setTargetAtTime(next ? volume / 100 : 0, audio.currentTime, 0.06);
  };

  useEffect(() => {
    if (!context.current || !master.current) return;
    master.current.gain.setTargetAtTime(
      enabled ? volume / 100 : 0,
      context.current.currentTime,
      0.06,
    );
  }, [enabled, volume]);
  useEffect(() => {
    if (enabled && music) startAmbience();
    else stopAmbience();
  }, [enabled, music, startAmbience, stopAmbience]);
  useEffect(() => {
    if (!enabled || !effects) {
      if (tickTimer.current) window.clearInterval(tickTimer.current);
      tickTimer.current = null;
      return;
    }
    tickTimer.current = window.setInterval(() => play("click"), 2600);
    return () => {
      if (tickTimer.current) window.clearInterval(tickTimer.current);
    };
  }, [effects, enabled, play]);
  useEffect(() => {
    const listener = (event: Event) => play((event as CustomEvent<SoundKind>).detail);
    window.addEventListener("gnosis:sound", listener);
    return () => window.removeEventListener("gnosis:sound", listener);
  }, [play]);
  useEffect(
    () => () => {
      stopAmbience();
      void context.current?.close();
    },
    [stopAmbience],
  );

  return { enabled, music, effects, volume, setEnabled, setMusic, setEffects, setVolume, play };
}

function Initiation({ onEnter }: { onEnter: () => void }) {
  const [answer, setAnswer] = useState("");
  const [error, setError] = useState(false);
  const [opening, setOpening] = useState(false);
  const unlock = () => {
    if (answer.trim().toLowerCase() !== "engine") return setError(true);
    setError(false);
    setOpening(true);
    playStandaloneEntranceSound();
    window.setTimeout(onEnter, 2200);
  };
  return (
    <main className={`initiation ${opening ? "opening" : ""}`}>
      <button className="skip" onClick={onEnter}>
        Skip initiation
      </button>
      <div className="door door-left">
        <div className="door-lines" />
      </div>
      <div className="door door-right">
        <div className="door-lines" />
      </div>
      <div className="steam steam-a" />
      <div className="steam steam-b" />
      <section className="init-panel">
        <Emblem />
        <p className="eyebrow">The sealed academy · Est. MDCCCLXIV</p>
        <h1>THE INITIATION</h1>
        <p className="lead">Prove that your mind can move the mechanism.</p>
        <div className="cipher">
          <small>ENCRYPTED INSCRIPTION · CAESAR III</small>
          <strong>HQJLQH</strong>
          <p>“I turn thought into motion. Move each letter three steps backward.”</p>
        </div>
        <label htmlFor="cipher-answer">Speak the mechanism’s name</label>
        <div className="unlock-row">
          <input
            id="cipher-answer"
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && unlock()}
            placeholder="Your answer…"
            autoComplete="off"
          />
          <button className="brass-button" onClick={unlock}>
            Unlock the academy
          </button>
        </div>
        {error && (
          <p className="error" role="alert">
            The mechanism refuses. Study the Caesar shift once more.
          </p>
        )}
        {opening && <p className="success">Cipher accepted. Stand clear of the aperture.</p>}
      </section>
    </main>
  );
}

function SoundPanel({
  open,
  onClose,
  audio,
}: {
  open: boolean;
  onClose: () => void;
  audio: ReturnType<typeof useSteampunkAudio>;
}) {
  const { enabled, music, effects, volume, setEnabled, setMusic, setEffects, setVolume, play } =
    audio;
  return (
    <aside className={`sound-panel ${open ? "visible" : ""}`} aria-hidden={!open}>
      <div className="panel-title">
        <span>Acoustic apparatus</span>
        <button onClick={onClose} aria-label="Close">
          ×
        </button>
      </div>
      <p>
        {enabled
          ? "The clockwork soundscape is engaged."
          : "Sound remains muted until you choose to engage it."}
      </p>
      <Toggle label="Master sound" value={enabled} setValue={setEnabled} />
      <Toggle label="Orchestral ambience" value={music} setValue={setMusic} disabled={!enabled} />
      <Toggle
        label="Mechanical effects"
        value={effects}
        setValue={setEffects}
        disabled={!enabled}
      />
      <label className="volume">
        Output pressure <b>{volume}%</b>
        <input
          type="range"
          min="0"
          max="100"
          value={volume}
          disabled={!enabled}
          onChange={(e) => setVolume(+e.target.value)}
        />
      </label>
      <div className="sound-tests">
        <button disabled={!enabled || !effects} onClick={() => play("gear")}>
          Test gears
        </button>
        <button disabled={!enabled || !effects} onClick={() => play("steam")}>
          Purge steam
        </button>
      </div>
    </aside>
  );
}
function Toggle({
  label,
  value,
  setValue,
  disabled,
}: {
  label: string;
  value: boolean;
  setValue: (x: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <button
      className="toggle-row"
      onClick={() => !disabled && setValue(!value)}
      disabled={disabled}
    >
      <span>{label}</span>
      <i className={value ? "on" : ""}>
        <span />
      </i>
    </button>
  );
}

function AppShell({
  children,
  page,
  setPage,
}: {
  children: React.ReactNode;
  page: Page;
  setPage: (p: Page) => void;
}) {
  const [menu, setMenu] = useState(false);
  const [sound, setSound] = useState(false);
  const audio = useSteampunkAudio();
  const nav: [Page, string][] = [
    ["academy", "Academy"],
    ["course", "Courses"],
    ["workshop", "Workshop"],
    ["library", "Library"],
    ["examination", "Challenges"],
    ["gateway", "Resources"],
    ["profile", "My Profile"],
  ];
  return (
    <div
      className="app-shell"
      onClickCapture={(event) => {
        const target = event.target as HTMLElement;
        if (target.closest("button, a")) audio.play("click");
      }}
    >
      <header>
        <button className="brand" onClick={() => setPage("academy")}>
          <Emblem small />
          <span>
            <b>GNOSIS</b>
            <small>Academia Mechanica</small>
          </span>
        </button>
        <nav className={menu ? "mobile-open" : ""} aria-label="Primary navigation">
          {nav.map(([id, label]) => (
            <button
              key={id}
              className={page === id ? "active" : ""}
              onClick={() => {
                audio.play("gear");
                setPage(id);
                setMenu(false);
              }}
            >
              {label}
            </button>
          ))}
        </nav>
        <div className="header-tools">
          <button
            className="round-button"
            onClick={() => setSound(!sound)}
            aria-label="Sound controls"
          >
            ◖
          </button>
          <button className="menu-button" onClick={() => setMenu(!menu)} aria-label="Menu">
            ☰
          </button>
        </div>
      </header>
      <SoundPanel open={sound} onClose={() => setSound(false)} audio={audio} />
      {children}
      <footer>
        <div>
          <Emblem small />
          <b>GNOSIS</b>
        </div>
        <p>Per scientiam ad futurum.</p>
        <button onClick={() => setPage("chronicles")}>Read the chronicles →</button>
      </footer>
    </div>
  );
}

function Ersicus({
  compact = false,
  quote = "Ah, another curious mind has entered the academy.",
}: {
  compact?: boolean;
  quote?: string;
}) {
  return (
    <div className={`ersicus ${compact ? "compact" : ""}`}>
      <div className="portrait">
        <img src={IMG.ersicus} alt="Ersicus Alpha, the academy's Victorian scientific mentor" />
        <span className="monocle" />
      </div>
      <div className="speech">
        <small>Ersicus Alpha · Chief Mechanist</small>
        <p>“{quote}”</p>
      </div>
    </div>
  );
}

function Academy({
  goCourse,
  setPage,
}: {
  goCourse: (t: Track) => void;
  setPage: (p: Page) => void;
}) {
  return (
    <main>
      <section className="hero">
        <div className="hero-copy">
          <p className="eyebrow">The Grand Mechanical Academy · Hall I</p>
          <h1>
            ENTER THE WORLD
            <br />
            <em>OF KNOWLEDGE.</em>
          </h1>
          <p className="hero-lead">
            Explore the architecture of the digital universe through science, creativity, and code.
          </p>
          <div className="hero-actions">
            <button className="brass-button" onClick={() => goCourse("HTML")}>
              Begin your studies
            </button>
            <button className="text-button" onClick={() => setPage("library")}>
              Consult the archives →
            </button>
          </div>
        </div>
        <div className="engine-visual" style={{ backgroundImage: `url(${IMG.gears})` }}>
          <div className="dial">
            <span>KNOWLEDGE</span>
            <b>∞</b>
            <small>ENGINE PRESSURE</small>
          </div>
          <div className="orbit orbit-a" />
          <div className="orbit orbit-b" />
        </div>
        <Ersicus compact />
      </section>
      <section className="manifesto">
        <span>THE AXIOM OF GNOSIS</span>
        <blockquote>
          “Knowledge is the engine
          <br />
          of human evolution.”
        </blockquote>
        <p>Per scientiam ad futurum</p>
      </section>
      <section className="section disciplines">
        <div className="section-heading">
          <div>
            <p className="eyebrow">Three great disciplines</p>
            <h2>Choose your instrument</h2>
          </div>
          <p>
            Each discipline is a chamber in the same magnificent machine. Begin with structure,
            continue through form, and finally awaken intelligence.
          </p>
        </div>
        <div className="discipline-grid">
          {(Object.keys(tracks) as Track[]).map((t, i) => (
            <article className="discipline-card" key={t}>
              <div className="card-number">0{i + 1}</div>
              <div className="sigil" style={{ borderColor: tracks[t].color }}>
                {tracks[t].sigil}
              </div>
              <p className="eyebrow">{t} discipline</p>
              <h3>{tracks[t].subtitle}</h3>
              <p>{tracks[t].intro}</p>
              <div className="difficulty">
                <span>Difficulty</span>
                <i />
                <i className={i > 0 ? "lit" : ""} />
                <i className={i > 1 ? "lit" : ""} />
              </div>
              <button onClick={() => goCourse(t)}>
                Enter the chamber <span>→</span>
              </button>
            </article>
          ))}
        </div>
      </section>
      <section
        className="library-teaser"
        style={{
          backgroundImage: `linear-gradient(90deg,rgba(23,17,13,.96),rgba(23,17,13,.45)),url(${IMG.library})`,
        }}
      >
        <p className="eyebrow">The infinite archive</p>
        <h2>
          Every answer leaves
          <br />
          behind a new question.
        </h2>
        <p>
          Explore references, field notes, terminology, and the preserved work of generations of
          digital inventors.
        </p>
        <button className="brass-button" onClick={() => setPage("library")}>
          Enter the library
        </button>
      </section>
    </main>
  );
}

function Course({
  track,
  setTrack,
  completed,
  complete,
}: {
  track: Track;
  setTrack: (t: Track) => void;
  completed: string[];
  complete: (x: string) => void;
}) {
  const [lesson, setLesson] = useState(0);
  const info = tracks[track];
  const title = info.lessons[lesson];
  const key = `${track}-${lesson}`;
  const examples: Record<Track, string> = {
    HTML: `<article>\n  <h1>The Brass Engine</h1>\n  <p>A semantic document has meaning.</p>\n</article>`,
    CSS: `.instrument {\n  display: grid;\n  gap: 1.5rem;\n  color: #E9D9BD;\n}`,
    JavaScript: `const engine = { pressure: 72 };\nif (engine.pressure > 60) {\n  console.log("Mechanism active");\n}`,
  };
  return (
    <main className="course-layout">
      <aside className="lesson-sidebar">
        <p className="eyebrow">Curriculum</p>
        <div className="track-switch">
          {(Object.keys(tracks) as Track[]).map((t) => (
            <button
              className={t === track ? "active" : ""}
              onClick={() => {
                setTrack(t);
                setLesson(0);
              }}
              key={t}
            >
              {t === "JavaScript" ? "JS" : t}
            </button>
          ))}
        </div>
        <h2>{track}</h2>
        <small>{info.subtitle}</small>
        <ol>
          {info.lessons.map((x, i) => (
            <li key={x}>
              <button className={i === lesson ? "active" : ""} onClick={() => setLesson(i)}>
                <span>{String(i + 1).padStart(2, "0")}</span>
                {x}
                {completed.includes(`${track}-${i}`) && <b>✓</b>}
              </button>
            </li>
          ))}
        </ol>
      </aside>
      <article className="lesson">
        <div className="breadcrumbs">
          Academy <span>/</span> {track} <span>/</span> Lesson {lesson + 1}
        </div>
        <p className="eyebrow">
          Lesson {String(lesson + 1).padStart(2, "0")} · {Math.max(8, title.length)} minutes
        </p>
        <h1>{title}</h1>
        <p className="lesson-lead">
          Every robust invention begins with a principle understood clearly. In this lesson, you
          will learn how <b>{title.toLowerCase()}</b> contributes to reliable, readable web
          experiences.
        </p>
        <div className="lesson-rule">
          <span>◈</span>
        </div>
        <h2>The operating principle</h2>
        <p>
          {track === "HTML"
            ? "HTML describes the meaning and structure of content. Browsers read its nested elements as a document tree, while people and assistive technologies use that structure to navigate."
            : track === "CSS"
              ? "CSS applies visual rules to selected elements. The cascade compares origin, importance, specificity, and source order so that every element receives a predictable final appearance."
              : "JavaScript is a programming language that lets a page react, calculate, remember, and communicate. Small instructions combine into functions and systems that respond to events."}
        </p>
        <div className="principle">
          <b>THE MECHANIST’S RULE</b>
          <p>
            {track === "HTML"
              ? "Choose an element for its meaning, not its default appearance."
              : track === "CSS"
                ? "Build from reusable rules; avoid correcting one accident with another."
                : "Name your data clearly, then transform it in small, observable steps."}
          </p>
        </div>
        <h2>Examine the mechanism</h2>
        <div className="codeblock">
          <div>
            <span>{track.toLowerCase()} · example</span>
            <button onClick={() => navigator.clipboard?.writeText(examples[track])}>Copy</button>
          </div>
          <pre>
            <code>{examples[track]}</code>
          </pre>
        </div>
        <section className="exercise">
          <p className="eyebrow">Practical calibration</p>
          <h3>Check your understanding</h3>
          <p>Which habit creates the strongest foundation?</p>
          <div className="answers">
            <button onClick={() => complete(key)}>
              Use the clearest semantic or logical choice
            </button>
            <button>Use the shortest possible name</button>
            <button>Add complexity before it is needed</button>
          </div>
          {completed.includes(key) && (
            <p className="correct">
              Correct. The mechanism is calibrated and your progress has been recorded.
            </p>
          )}
        </section>
        <Ersicus quote="Every line of code is a small invention. Make yours legible to the next inventor." />
        <div className="lesson-nav">
          <button disabled={lesson === 0} onClick={() => setLesson(lesson - 1)}>
            ← Previous lesson
          </button>
          <span>
            {lesson + 1} of {info.lessons.length}
          </span>
          <button
            disabled={lesson === info.lessons.length - 1}
            onClick={() => setLesson(lesson + 1)}
          >
            Next lesson →
          </button>
        </div>
      </article>
    </main>
  );
}

type WorkshopTab = "html" | "css" | "js";

interface ConsoleEntry {
  id: number;
  level: "log" | "warn" | "error" | "info";
  text: string;
}

const WORKSHOP_DEFAULTS: Record<WorkshopTab, string> = {
  html: `<main class="card">
  <p class="badge">GNOSIS WORKSHOP</p>
  <h1>The Aether Engine</h1>
  <p class="desc">Press the brass lever to test HTML, CSS, and JavaScript live.</p>
  <button id="lever" type="button">Engage mechanism</button>
  <div id="pressure" class="gauge">Pressure: 0 PSI</div>
</main>`,
  css: `body {
  display: grid;
  place-items: center;
  min-height: 100vh;
  margin: 0;
  background: #1a130e;
  color: #e9d9bd;
  font-family: Georgia, serif;
}
.card {
  padding: 2.5rem 3rem;
  border: 1px solid #b08d57;
  background: #231a13;
  text-align: center;
  box-shadow: 0 20px 50px rgba(0, 0, 0, 0.45);
}
.badge {
  font-size: 11px;
  letter-spacing: 0.22em;
  color: #c6a96c;
  margin: 0 0 10px;
}
h1 { margin: 0 0 12px; font-weight: 600; }
.desc { color: #bfb09c; font-size: 14px; margin: 0 0 22px; }
button {
  padding: 0.8rem 1.4rem;
  background: linear-gradient(135deg, #d1b273, #9b7545);
  color: #17110c;
  font-weight: 700;
  border: 1px solid #e4ca8d;
  cursor: pointer;
}
.gauge {
  margin-top: 16px;
  font-family: monospace;
  color: #c6a96c;
}`,
  js: `let psi = 0;
const lever = document.querySelector('#lever');
const gauge = document.querySelector('#pressure');

lever.addEventListener('click', () => {
  psi += 24;
  lever.textContent = 'Mechanism engaged (' + psi + ' PSI)';
  gauge.textContent = 'Pressure: ' + psi + ' PSI';
  console.log('Valve engaged at', psi, 'PSI');
});`,
};

function escapeHtml(text: string): string {
  return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function highlightSyntax(code: string, lang: WorkshopTab): string {
  const escaped = escapeHtml(code);
  if (lang === "html") {
    return escaped
      .replace(/(&lt;!--[\s\S]*?--&gt;)/g, '<span class="tok-comment">$1</span>')
      .replace(
        /(&lt;\/?)([a-zA-Z0-9-]+)([\s\S]*?)(\/?&gt;)/g,
        (_m, open, tag, attrs, close) =>
          `<span class="tok-punct">${open}</span><span class="tok-tag">${tag}</span>${attrs.replace(
            /([a-zA-Z-:]+)(=)(&quot;[^&]*&quot;|"[^"]*"|'[^']*')/g,
            '<span class="tok-attr">$1</span>$2<span class="tok-str">$3</span>',
          )}<span class="tok-punct">${close}</span>`,
      );
  }
  if (lang === "css") {
    return escaped
      .replace(/(\/\*[\s\S]*?\*\/)/g, '<span class="tok-comment">$1</span>')
      .replace(/(#[0-9a-fA-F]{3,8}\b)/g, '<span class="tok-num">$1</span>')
      .replace(/([a-z-]+)(?=\s*:)/g, '<span class="tok-attr">$1</span>')
      .replace(/('[^']*'|"[^"]*")/g, '<span class="tok-str">$1</span>')
      .replace(/\b(\d+(?:\.\d+)?(?:px|rem|em|vh|vw|%|s|ms)?)\b/g, '<span class="tok-num">$1</span>');
  }
  return escaped
    .replace(/(\/\/[^\n]*|\/\*[\s\S]*?\*\/)/g, '<span class="tok-comment">$1</span>')
    .replace(/('[^'\n]*'|"[^"\n]*"|`[^`]*`)/g, '<span class="tok-str">$1</span>')
    .replace(
      /\b(const|let|var|function|return|if|else|for|while|switch|case|break|new|try|catch|async|await|import|export|true|false|null|undefined)\b/g,
      '<span class="tok-kw">$1</span>',
    )
    .replace(/\b(\d+(?:\.\d+)?)\b/g, '<span class="tok-num">$1</span>');
}

function buildSandboxedSrcDoc(code: Record<WorkshopTab, string>, runId: number): string {
  const safeCss = code.css.replace(/<\/style/gi, "<\\/style");
  const safeJs = code.js.replace(/<\/script/gi, "<\\/script");
  const bridge = `
(function() {
  const RUN_ID = ${runId};
  const send = (level, args) => {
    try {
      const text = Array.from(args).map((item) => {
        if (item instanceof Error) return item.stack || item.message;
        if (typeof item === "object" && item !== null) {
          try { return JSON.stringify(item); } catch { return String(item); }
        }
        return String(item);
      }).join(" ");
      window.parent.postMessage({ source: "gnosis-workshop", runId: RUN_ID, level, text }, "*");
    } catch {}
  };
  ["log", "warn", "error", "info"].forEach((lvl) => {
    const orig = console[lvl];
    console[lvl] = function(...args) {
      send(lvl, args);
      if (orig) orig.apply(console, args);
    };
  });
  window.addEventListener("error", (ev) => {
    send("error", [ev.message + (ev.lineno ? " (line " + ev.lineno + ")" : "")]);
  });
  window.addEventListener("unhandledrejection", (ev) => {
    send("error", ["Unhandled rejection:", ev.reason]);
  });
})();`;

  return `<!doctype html>
<!-- gnosis-run:${runId} -->
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<style>${safeCss}</style>
<script>${bridge}<\/script>
</head>
<body>
${code.html}
<script>
try {
${safeJs}
} catch (err) {
  console.error(err);
}
<\/script>
</body>
</html>`;
}

function isExactGameActivationWord(value: string): boolean {
  return value.trim().toLowerCase() === "game";
}

function Workshop({ onActivateSecretWorkshop }: { onActivateSecretWorkshop: () => void }) {
  const [code, setCode] = useState<Record<WorkshopTab, string>>(WORKSHOP_DEFAULTS);
  const [tab, setTab] = useState<WorkshopTab>("html");
  const [projectName, setProjectName] = useState("aether-engine");
  const [runId, setRunId] = useState(1);
  const [output, setOutput] = useState(() => buildSandboxedSrcDoc(WORKSHOP_DEFAULTS, 1));
  const [layoutMode, setLayoutMode] = useState<"horizontal" | "vertical">("horizontal");
  const [splitPct, setSplitPct] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [consoleOpen, setConsoleOpen] = useState(false);
  const [logs, setLogs] = useState<ConsoleEntry[]>([]);
  const [transitioning, setTransitioning] = useState(false);

  const workbenchRef = useRef<HTMLDivElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const highlightRef = useRef<HTMLPreElement | null>(null);
  const gutterRef = useRef<HTMLDivElement | null>(null);

  const triggerHiddenWorkshop = useCallback(() => {
    if (transitioning) return;
    window.dispatchEvent(new CustomEvent<SoundKind>("gnosis:sound", { detail: "steam" }));
    setTransitioning(true);
    window.setTimeout(() => {
      setTransitioning(false);
      onActivateSecretWorkshop();
    }, 900);
  }, [onActivateSecretWorkshop, transitioning]);

  // Debounced exact-word detection: triggers if user types exact "game" (any case) and pauses,
  // preventing accidental triggers while typing longer words like "games" or "gameplay".
  useEffect(() => {
    if (!isExactGameActivationWord(projectName)) return;
    const timer = window.setTimeout(() => {
      triggerHiddenWorkshop();
    }, 550);
    return () => window.clearTimeout(timer);
  }, [projectName, triggerHiddenWorkshop]);

  const executeCode = useCallback(
    (source: Record<WorkshopTab, string>, allowSecretTrigger: boolean) => {
      if (allowSecretTrigger && isExactGameActivationWord(projectName)) {
        triggerHiddenWorkshop();
        return;
      }
      setLogs([]);
      setRunId((prev) => {
        const nextId = prev + 1;
        setOutput(buildSandboxedSrcDoc(source, nextId));
        return nextId;
      });
    },
    [projectName, triggerHiddenWorkshop],
  );

  useEffect(() => {
    const onMessage = (event: MessageEvent) => {
      const data = event.data as
        | { source?: string; runId?: number; level?: ConsoleEntry["level"]; text?: string }
        | undefined;
      if (!data || data.source !== "gnosis-workshop" || data.runId !== runId) return;
      setLogs((prev) => [
        ...prev.slice(-49),
        {
          id: Date.now() + Math.random(),
          level: data.level || "log",
          text: data.text || "",
        },
      ]);
      if (data.level === "error") setConsoleOpen(true);
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, [runId]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isFullscreen) setIsFullscreen(false);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [isFullscreen]);

  const syncScroll = () => {
    const ta = textareaRef.current;
    if (!ta) return;
    if (highlightRef.current) {
      highlightRef.current.scrollTop = ta.scrollTop;
      highlightRef.current.scrollLeft = ta.scrollLeft;
    }
    if (gutterRef.current) {
      gutterRef.current.scrollTop = ta.scrollTop;
    }
  };

  const handleEditorKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
      e.preventDefault();
      executeCode(code, true);
      return;
    }
    if (e.key === "Tab") {
      e.preventDefault();
      const ta = e.currentTarget;
      const start = ta.selectionStart;
      const end = ta.selectionEnd;
      const val = code[tab];
      const nextVal = val.slice(0, start) + "  " + val.slice(end);
      setCode({ ...code, [tab]: nextVal });
      window.requestAnimationFrame(() => {
        if (textareaRef.current) {
          textareaRef.current.selectionStart = textareaRef.current.selectionEnd = start + 2;
        }
      });
    }
  };

  const handleSplitterPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    const target = e.currentTarget;
    target.setPointerCapture(e.pointerId);
    setIsDragging(true);
  };

  const handleSplitterPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDragging || !workbenchRef.current) return;
    const rect = workbenchRef.current.getBoundingClientRect();
    const ratio =
      layoutMode === "horizontal"
        ? ((e.clientX - rect.left) / rect.width) * 100
        : ((e.clientY - rect.top) / rect.height) * 100;
    setSplitPct(Math.max(22, Math.min(78, Math.round(ratio * 10) / 10)));
  };

  const handleSplitterPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {
      // Ignore if not captured
    }
    setIsDragging(false);
  };

  const lineCount = useMemo(() => Math.max(1, code[tab].split("\n").length), [code, tab]);
  const highlightedHtml = useMemo(() => highlightSyntax(code[tab], tab) + "\n", [code, tab]);

  const workbenchStyle = useMemo(
    () =>
      ({
        "--ws-split": `${splitPct}%`,
      }) as React.CSSProperties,
    [splitPct],
  );

  return (
    <div className={`workshop-page ${isFullscreen ? "is-fullscreen" : ""}`}>
      {transitioning && (
        <div className="protocol-transition" role="status" aria-live="polite">
          <div className="protocol-aperture">
            <span className="gear-ring" />
            <strong>PROTOCOL VII</strong>
            <small>Opening hidden chamber…</small>
          </div>
        </div>
      )}

      <section
        className={`gnosis-workbench layout-${layoutMode} ${isDragging ? "is-resizing" : ""} ${isFullscreen ? "fullscreen" : ""}`}
        ref={workbenchRef}
        style={workbenchStyle}
      >
        <div className="ws-topbar">
          <div className="ws-project-wrap">
            <label htmlFor="workshop-project-name">Project</label>
            <input
              id="workshop-project-name"
              type="text"
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  executeCode(code, true);
                }
              }}
              placeholder="Project name…"
              spellCheck={false}
              autoComplete="off"
            />
          </div>

          <div className="ws-actions-bar">
            <button
              type="button"
              className={layoutMode === "horizontal" ? "active" : ""}
              onClick={() => setLayoutMode("horizontal")}
              title="Horizontal split (50/50)"
            >
              ◫ Horizontal
            </button>
            <button
              type="button"
              className={layoutMode === "vertical" ? "active" : ""}
              onClick={() => setLayoutMode("vertical")}
              title="Vertical split"
            >
              ⬓ Vertical
            </button>
            <button
              type="button"
              onClick={() => setSplitPct(50)}
              title="Reset 50/50 split"
            >
              50/50
            </button>
            <button
              type="button"
              className={isFullscreen ? "active" : ""}
              onClick={() => setIsFullscreen((f) => !f)}
              title="Toggle fullscreen"
            >
              {isFullscreen ? "⤡ Exit Fullscreen" : "⤢ Fullscreen"}
            </button>
          </div>
        </div>

        <div className="ws-panes">
          <section className="editor-panel">
            <div className="editor-tabs">
              {(["html", "css", "js"] as const).map((x) => (
                <button
                  type="button"
                  className={tab === x ? "active" : ""}
                  onClick={() => setTab(x)}
                  key={x}
                >
                  {x === "js" ? "JavaScript" : x.toUpperCase()}
                </button>
              ))}
              <span className="ws-shortcut-hint">Ctrl+Enter to Run</span>
            </div>

            <div className="ws-code-area">
              <div className="ws-gutter" ref={gutterRef} aria-hidden="true">
                {Array.from({ length: lineCount }, (_, i) => (
                  <div key={i}>{i + 1}</div>
                ))}
              </div>
              <div className="ws-editor-stack">
                <pre
                  ref={highlightRef}
                  className="ws-highlight"
                  aria-hidden="true"
                  dangerouslySetInnerHTML={{ __html: highlightedHtml }}
                />
                <textarea
                  ref={textareaRef}
                  aria-label={`${tab} editor`}
                  spellCheck={false}
                  autoCapitalize="off"
                  autoComplete="off"
                  autoCorrect="off"
                  value={code[tab]}
                  onChange={(e) => setCode({ ...code, [tab]: e.target.value })}
                  onScroll={syncScroll}
                  onKeyDown={handleEditorKeyDown}
                />
              </div>
            </div>

            <div className="editor-tools">
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard?.writeText(code[tab]);
                  setCopied(true);
                  window.setTimeout(() => setCopied(false), 1200);
                }}
              >
                {copied ? "Copied ✓" : "Copy"}
              </button>
              <button
                type="button"
                onClick={() => {
                  const cleared = { ...code, [tab]: "" };
                  setCode(cleared);
                  executeCode(cleared, false);
                }}
                title="Clear active tab"
              >
                Clear
              </button>
              <button
                type="button"
                onClick={() => {
                  setCode(WORKSHOP_DEFAULTS);
                  executeCode(WORKSHOP_DEFAULTS, false);
                }}
                title="Restore default mechanism"
              >
                Reset
              </button>
              <button
                type="button"
                onClick={() => executeCode(code, false)}
                title="Refresh preview"
              >
                ↻ Refresh
              </button>
              <button
                type="button"
                className="run"
                onClick={() => executeCode(code, true)}
              >
                ▶ Run
              </button>
            </div>
          </section>

          <div
            className="ws-splitter"
            role="separator"
            aria-orientation={layoutMode === "horizontal" ? "vertical" : "horizontal"}
            aria-label="Resize editor and preview"
            onPointerDown={handleSplitterPointerDown}
            onPointerMove={handleSplitterPointerMove}
            onPointerUp={handleSplitterPointerUp}
            onPointerCancel={handleSplitterPointerUp}
          >
            <span />
          </div>

          <section className="preview-panel">
            <div className="ws-preview-head">
              <span>LIVE OBSERVATION WINDOW · RUN #{runId}</span>
              <div className="ws-preview-meta">
                <button
                  type="button"
                  className="ws-console-toggle"
                  onClick={() => setConsoleOpen((o) => !o)}
                >
                  Console ({logs.length}) {consoleOpen ? "▾" : "▸"}
                </button>
                <i>● SANDBOXED</i>
              </div>
            </div>
            <iframe
              key={runId}
              title="Live code preview"
              sandbox="allow-scripts"
              srcDoc={output}
            />
            {consoleOpen && (
              <div className="ws-console">
                <div className="ws-console-bar">
                  <span>Mechanism Console</span>
                  <button type="button" onClick={() => setLogs([])}>
                    Clear Console
                  </button>
                </div>
                <div className="ws-console-list">
                  {logs.length === 0 ? (
                    <div className="ws-console-empty">No console output yet.</div>
                  ) : (
                    logs.map((entry) => (
                      <div key={entry.id} className={`ws-console-line ${entry.level}`}>
                        <span>[{entry.level}]</span> {entry.text}
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </section>
        </div>
      </section>
    </div>
  );
}

const archiveEntries = [
  [
    "HTML",
    "Semantic elements",
    "Elements such as header, nav, main, article, and footer describe a page’s regions.",
  ],
  [
    "HTML",
    "Forms & validation",
    "Collect structured input with labels, useful types, constraints, and accessible feedback.",
  ],
  [
    "CSS",
    "The box model",
    "Every rendered element consists of content, padding, border, and margin.",
  ],
  [
    "CSS",
    "Grid layout",
    "Two-dimensional layout designed for rows, columns, and precisely aligned regions.",
  ],
  [
    "JavaScript",
    "DOM events",
    "Listen for user and browser activity, then run a function in response.",
  ],
  ["JavaScript", "Promises", "Represent a value that may become available now, later, or never."],
  ["Glossary", "The cascade", "The decision process browsers use when multiple CSS rules match."],
  [
    "Shortcuts",
    "Workshop controls",
    "Use Tab to indent; Ctrl/Cmd+C to copy; Ctrl/Cmd+Enter to run in many editors.",
  ],
];
function Library() {
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<(typeof archiveEntries)[number] | null>(null);
  const found = archiveEntries.filter((x) =>
    x.join(" ").toLowerCase().includes(query.toLowerCase()),
  );
  return (
    <main className="library-page">
      <section
        className="library-hero"
        style={{
          backgroundImage: `linear-gradient(rgba(24,18,13,.62),rgba(24,18,13,.92)),url(${IMG.library})`,
        }}
      >
        <p className="eyebrow">Knowledge archives · Cabinet IV</p>
        <h1>The Library</h1>
        <p>Search the collected principles, definitions, and field notes of the academy.</p>
        <label className="search">
          <span>⌕</span>
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search the archives…"
          />
        </label>
      </section>
      <section className="archive-grid">
        {found.map((x, i) => (
          <button className="archive-card" key={i} onClick={() => setSelected(x)}>
            <small>{x[0]}</small>
            <h2>{x[1]}</h2>
            <p>{x[2]}</p>
            <span>Open folio →</span>
          </button>
        ))}
      </section>
      {selected && (
        <div className="modal-backdrop" onClick={() => setSelected(null)}>
          <article className="folio" onClick={(e) => e.stopPropagation()}>
            <button className="close" onClick={() => setSelected(null)}>
              ×
            </button>
            <p className="eyebrow">{selected[0]} reference folio</p>
            <h1>{selected[1]}</h1>
            <p>{selected[2]}</p>
            <h2>Field observation</h2>
            <p>
              This principle is most useful when treated as part of a system rather than an isolated
              trick. Test it in a small example, inspect the result, and then combine it with one
              new idea at a time.
            </p>
            <pre>
              <code>{`// Academy field note\nconst principle = "${selected[1]}";\nconsole.log(\`Studying: \${principle}\`);`}</code>
            </pre>
          </article>
        </div>
      )}
    </main>
  );
}

function Gateway() {
  const groups = [...new Set(resources.map((x) => x[0]))];
  return (
    <main className="gateway-page">
      <div className="page-mast">
        <p className="eyebrow">External knowledge network</p>
        <h1>The Gateway</h1>
        <p>No academy contains all knowledge. These trusted portals lead beyond our walls.</p>
      </div>
      {groups.map((g, gi) => (
        <section className="resource-section" key={g}>
          <div className="resource-label">
            <span>0{gi + 1}</span>
            <h2>{g}</h2>
          </div>
          <div className="resource-grid">
            {resources
              .filter((x) => x[0] === g)
              .map((x) => (
                <a href={x[3]} target="_blank" rel="noreferrer" key={x[1]}>
                  <small>Verified external archive ↗</small>
                  <h3>{x[1]}</h3>
                  <p>{x[2]}</p>
                  <b>
                    Open archive <span>↗</span>
                  </b>
                </a>
              ))}
          </div>
        </section>
      ))}
    </main>
  );
}

function Examination({
  completed,
  complete,
}: {
  completed: string[];
  complete: (x: string) => void;
}) {
  const qs = [
    ["Which HTML element contains primary page content?", ["<main>", "<div>", "<meta>"], 0],
    ["Which CSS system handles rows and columns?", ["Float", "Grid", "Opacity"], 1],
    ["Which keyword declares a reassignable JavaScript variable?", ["const", "style", "let"], 2],
  ] as const;
  const [answers, setAnswers] = useState<number[]>([]);
  const done = answers.length === qs.length;
  const score = answers.filter((x, i) => x === qs[i][2]).length;
  useEffect(() => {
    if (done && score === 3) complete("examination");
  }, [done, score]);
  return (
    <main className="examination-page">
      <div className="page-mast">
        <p className="eyebrow">The proving chamber</p>
        <h1>The Examination</h1>
        <p>Three disciplines. Three calibrations. One clear mind.</p>
      </div>
      <div className="exam-sheet">
        {qs.map((q, i) => (
          <section key={q[0]}>
            <span>0{i + 1}</span>
            <h2>{q[0]}</h2>
            <div>
              {q[1].map((a, j) => (
                <button
                  className={answers[i] === j ? "selected" : ""}
                  onClick={() =>
                    setAnswers((v) => {
                      const n = [...v];
                      n[i] = j;
                      return n;
                    })
                  }
                  key={a}
                >
                  {a}
                </button>
              ))}
            </div>
          </section>
        ))}
        {done && (
          <div className="result">
            <small>Final calibration</small>
            <strong>{score} / 3</strong>
            <p>
              {score === 3
                ? "Exceptional. The Academy records a flawless mechanism."
                : "Return to the lesson halls, refine the mechanism, and attempt the calibration again."}
            </p>
          </div>
        )}
      </div>
    </main>
  );
}

function Profile({ completed }: { completed: string[] }) {
  const count = (t: Track) => completed.filter((x) => x.startsWith(t)).length;
  const total = Object.values(tracks).reduce((a, x) => a + x.lessons.length, 0);
  const pct = Math.round((completed.filter((x) => x.includes("-")).length / total) * 100);
  return (
    <main className="profile-page">
      <div className="profile-head">
        <div className="seal">IV</div>
        <div>
          <p className="eyebrow">Student record · No. 1864</p>
          <h1>Apprentice Engineer</h1>
          <p>Rank II · The Academy has recognized your continued curiosity.</p>
        </div>
      </div>
      <section className="stat-grid">
        <div>
          <small>Lessons completed</small>
          <strong>{completed.filter((x) => x.includes("-")).length}</strong>
          <span>of {total} lectures</span>
        </div>
        <div>
          <small>Academy progress</small>
          <strong>{pct}%</strong>
          <span>curriculum calibrated</span>
        </div>
        <div>
          <small>Challenges</small>
          <strong>{completed.includes("examination") ? 1 : 0}</strong>
          <span>examinations passed</span>
        </div>
      </section>
      <section className="progress-ledger">
        <p className="eyebrow">Discipline ledger</p>
        <h2>Current studies</h2>
        {(Object.keys(tracks) as Track[]).map((t) => {
          const p = Math.round((count(t) / tracks[t].lessons.length) * 100);
          return (
            <div className="progress-row" key={t}>
              <div>
                <b>{t}</b>
                <span>{tracks[t].subtitle}</span>
              </div>
              <div className="bar">
                <i style={{ width: `${p}%` }} />
              </div>
              <strong>{p}%</strong>
            </div>
          );
        })}
      </section>
      <section className="achievements">
        <p className="eyebrow">Cabinet of distinctions</p>
        <h2>Achievements</h2>
        <div>
          <article className={completed.length ? "earned" : ""}>
            <span>✦</span>
            <b>First Spark</b>
            <small>Complete one calibration</small>
          </article>
          <article className={completed.includes("examination") ? "earned" : ""}>
            <span>⌘</span>
            <b>Perfect Mechanism</b>
            <small>Pass the examination</small>
          </article>
          <article>
            <span>♜</span>
            <b>Grand Architect</b>
            <small>Complete every lecture</small>
          </article>
        </div>
      </section>
    </main>
  );
}

function Chronicles() {
  return (
    <main className="chronicles-page">
      <div className="page-mast">
        <p className="eyebrow">A secret history · 1864—∞</p>
        <h1>The Chronicles</h1>
        <p>The Academy was built not to guard knowledge, but to keep it in motion.</p>
      </div>
      <div className="timeline">
        {[
          [
            "1864",
            "The First Ignition",
            "Seven engineers establish GNOSIS beneath the abandoned Meridian Tower.",
          ],
          [
            "1891",
            "The Aether Library",
            "A mechanical index connects every manuscript, diagram, and experiment.",
          ],
          [
            "1995",
            "The Digital Aperture",
            "The Academy opens a new chamber devoted to the architecture of the web.",
          ],
          ["Today", "Your Arrival", "A curious mind solves the cipher. The next chapter begins."],
        ].map((x) => (
          <article>
            <span>{x[0]}</span>
            <div>
              <h2>{x[1]}</h2>
              <p>{x[2]}</p>
            </div>
          </article>
        ))}
      </div>
    </main>
  );
}

export default function App() {
  const [entered, setEntered] = useState(() => localStorage.getItem("gnosis-entered") === "true");
  const [page, setPageState] = useState<Page>(() => (location.hash.slice(1) as Page) || "academy");
  const [track, setTrack] = useState<Track>("HTML");
  const [workshopUnlocked, setWorkshopUnlocked] = useState(
    () => sessionStorage.getItem("gnosis-workshop-unlocked") === "true",
  );
  const [completed, setCompleted] = useState<string[]>(() =>
    JSON.parse(localStorage.getItem("gnosis-progress") || "[]"),
  );
  const setPage = (p: Page) => {
    setPageState(p);
    location.hash = p;
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const activateSecretWorkshop = () => {
    sessionStorage.setItem("gnosis-workshop-unlocked", "true");
    setWorkshopUnlocked(true);
    setPageState("workshop");
    location.hash = "workshop";
  };
  const lockAndReturnToNormalGnosis = () => {
    sessionStorage.removeItem("gnosis-workshop-unlocked");
    setWorkshopUnlocked(false);
    setPageState("academy");
    location.hash = "academy";
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const complete = (x: string) =>
    setCompleted((v) => {
      if (v.includes(x)) return v;
      window.dispatchEvent(new CustomEvent<SoundKind>("gnosis:sound", { detail: "success" }));
      return [...v, x];
    });
  useEffect(() => localStorage.setItem("gnosis-progress", JSON.stringify(completed)), [completed]);
  useEffect(() => {
    const fn = () => setPageState((location.hash.slice(1) as Page) || "academy");
    addEventListener("hashchange", fn);
    return () => removeEventListener("hashchange", fn);
  }, []);
  if (!entered)
    return (
      <Initiation
        onEnter={() => {
          localStorage.setItem("gnosis-entered", "true");
          setEntered(true);
        }}
      />
    );
  let content: React.ReactNode;
  if (page === "academy")
    content = (
      <Academy
        setPage={setPage}
        goCourse={(t) => {
          setTrack(t);
          setPage("course");
        }}
      />
    );
  else if (page === "course")
    content = (
      <Course track={track} setTrack={setTrack} completed={completed} complete={complete} />
    );
  else if (page === "workshop")
    content = workshopUnlocked ? (
      <WorkshopHub onReturnToNormalGnosis={lockAndReturnToNormalGnosis} />
    ) : (
      <Workshop onActivateSecretWorkshop={activateSecretWorkshop} />
    );
  else if (page === "library") content = <Library />;
  else if (page === "gateway") content = <Gateway />;
  else if (page === "examination")
    content = <Examination completed={completed} complete={complete} />;
  else if (page === "profile") content = <Profile completed={completed} />;
  else content = <Chronicles />;
  return (
    <AppShell page={page} setPage={setPage}>
      {content}
    </AppShell>
  );
}
