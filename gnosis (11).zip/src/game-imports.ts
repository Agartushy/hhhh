/**
 * GNOSIS Game Protocol — Central Imported Games Registry
 * ======================================================
 *
 * HOW TO ADD GAMES MANUALLY THROUGH THIS REGISTRY:
 * 1. Add a new object to `MANUAL_IMPORTED_GAMES` below matching the `ImportedGame` interface.
 * 2. Provide a unique `id`, `name`, `description`, `url` (https:// or http://), `category`,
 *    `type`, `source: "manual-registry"`, and `launch` configuration.
 * 3. Configure `launch.mode`:
 *    - `"iframe"`: Renders inside an isolated sandboxed <iframe> inside Game Protocol.
 *      Note: Only works if the target site permits framing (does not send
 *      `X-Frame-Options: DENY/SAMEORIGIN` or `Content-Security-Policy: frame-ancestors`).
 *    - `"external"`: Opens safely in a new browser tab via <a target="_blank" rel="noopener noreferrer">.
 * 4. Optional `launch.sandbox` defaults to `"allow-scripts allow-forms allow-pointer-lock"`.
 *    Keep untrusted third-party sites isolated without `allow-same-origin` unless required
 *    and explicitly trusted. Never attempt to bypass CSP or X-Frame-Options headers.
 *
 * Example:
 * {
 *   id: "hexgl-racer",
 *   name: "HexGL",
 *   description: "Futuristic WebGL racing prototype.",
 *   url: "https://hexgl.bkcore.com/play/",
 *   category: "Arcade",
 *   thumbnail: "https://example.com/thumb.png",
 *   source: "manual-registry",
 *   type: "html5",
 *   launch: {
 *     mode: "iframe",
 *     sandbox: "allow-scripts allow-pointer-lock allow-forms",
 *     allowFullscreen: true,
 *   },
 * }
 */

export type ImportedGameType =
  | "web"
  | "html5"
  | "canvas"
  | "puzzle"
  | "arcade"
  | "strategy"
  | "coop";

export type ImportedLaunchMode = "iframe" | "external";

export interface ImportedGameLaunchConfig {
  mode: ImportedLaunchMode;
  sandbox?: string;
  allowFullscreen?: boolean;
  aspectRatio?: string;
}

export interface ImportedGame {
  id: string;
  name: string;
  description: string;
  url: string;
  category: string;
  thumbnail?: string;
  source: "manual-registry" | "user-added";
  type: ImportedGameType;
  launch: ImportedGameLaunchConfig;
  addedAt?: string;
}

export const DEFAULT_UNTRUSTED_SANDBOX = "allow-scripts allow-forms allow-pointer-lock";

export const MANUAL_IMPORTED_GAMES: ImportedGame[] = [
  {
    id: "registry-hextris",
    name: "Hextris",
    description:
      "Fast-paced hexagonal rotation puzzle inspired by classic falling-block mechanics.",
    url: "https://hextris.io/",
    category: "Puzzle",
    source: "manual-registry",
    type: "html5",
    launch: {
      mode: "iframe",
      sandbox: DEFAULT_UNTRUSTED_SANDBOX,
      allowFullscreen: true,
      aspectRatio: "16 / 10",
    },
  },
  {
    id: "registry-lichess-analysis",
    name: "Lichess Open Board",
    description:
      "Open-source chess arena and study portal. Launches externally due to strict frame-ancestors policy.",
    url: "https://lichess.org/",
    category: "Strategy",
    source: "manual-registry",
    type: "strategy",
    launch: {
      mode: "external",
      allowFullscreen: false,
    },
  },
  {
    id: "registry-2048-classic",
    name: "2048 Open Edition",
    description:
      "Original open-source web edition of the sliding number fusion puzzle.",
    url: "https://play2048.co/",
    category: "Puzzle",
    source: "manual-registry",
    type: "web",
    launch: {
      mode: "external",
      allowFullscreen: false,
    },
  },
];

const STORAGE_KEY = "gnosis-imported-games-v1";
const HIDDEN_REGISTRY_KEY = "gnosis-hidden-registry-games-v1";

export function isValidExternalGameUrl(raw: string): boolean {
  try {
    const parsed = new URL(raw.trim());
    return parsed.protocol === "https:" || parsed.protocol === "http:";
  } catch {
    return false;
  }
}

export function loadImportedGames(): ImportedGame[] {
  let userGames: ImportedGame[] = [];
  let hiddenIds: string[] = [];
  try {
    const rawUser = localStorage.getItem(STORAGE_KEY);
    if (rawUser) {
      const parsed = JSON.parse(rawUser);
      if (Array.isArray(parsed)) userGames = parsed;
    }
    const rawHidden = localStorage.getItem(HIDDEN_REGISTRY_KEY);
    if (rawHidden) {
      const parsedHidden = JSON.parse(rawHidden);
      if (Array.isArray(parsedHidden)) hiddenIds = parsedHidden;
    }
  } catch {
    // Ignore malformed local storage
  }
  const visibleManual = MANUAL_IMPORTED_GAMES.filter((g) => !hiddenIds.includes(g.id));
  return [...userGames, ...visibleManual];
}

export function saveUserImportedGame(
  input: Omit<ImportedGame, "id" | "source" | "addedAt">,
): ImportedGame {
  const created: ImportedGame = {
    ...input,
    id: `custom-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    source: "user-added",
    addedAt: new Date().toISOString(),
    launch: {
      mode: input.launch.mode,
      sandbox: input.launch.sandbox || DEFAULT_UNTRUSTED_SANDBOX,
      allowFullscreen: input.launch.allowFullscreen ?? true,
      aspectRatio: input.launch.aspectRatio || "16 / 10",
    },
  };
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const existing: ImportedGame[] = raw ? JSON.parse(raw) : [];
    const next = [created, ...(Array.isArray(existing) ? existing : [])];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  } catch {
    // Fallback ignored if storage quota exceeded
  }
  return created;
}

export function removeImportedGame(id: string): ImportedGame[] {
  try {
    if (MANUAL_IMPORTED_GAMES.some((g) => g.id === id)) {
      const rawHidden = localStorage.getItem(HIDDEN_REGISTRY_KEY);
      const hidden: string[] = rawHidden ? JSON.parse(rawHidden) : [];
      if (!hidden.includes(id)) {
        localStorage.setItem(HIDDEN_REGISTRY_KEY, JSON.stringify([...hidden, id]));
      }
    } else {
      const raw = localStorage.getItem(STORAGE_KEY);
      const existing: ImportedGame[] = raw ? JSON.parse(raw) : [];
      const next = (Array.isArray(existing) ? existing : []).filter((g) => g.id !== id);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    }
  } catch {
    // Ignore storage error
  }
  return loadImportedGames();
}

export function restoreRegistryGames(): ImportedGame[] {
  try {
    localStorage.removeItem(HIDDEN_REGISTRY_KEY);
  } catch {
    // Ignore
  }
  return loadImportedGames();
}
