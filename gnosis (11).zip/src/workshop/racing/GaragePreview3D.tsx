import { useCallback, useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import {
  computeProportionalCarScale,
  EXTERNAL_CAR_MODELS,
  loadVehicleGlbAsset,
  type VehicleSpec,
} from "./vehicles";

type CameraAnglePreset = "front34" | "side" | "rear" | "hero";

interface LoadedModelMeta {
  url: string;
  meshCount: number;
  dimsLabel: string;
  scale: number;
}

const thumbnailCache = new Map<string, string | "missing">();
let thumbnailQueue: Promise<void> = Promise.resolve();

function disposeObjectSubtree(root: THREE.Object3D) {
  root.traverse((obj) => {
    const mesh = obj as THREE.Mesh;
    if (mesh.isMesh) {
      mesh.geometry?.dispose();
      const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
      for (const m of mats) {
        if (!m) continue;
        const std = m as THREE.MeshStandardMaterial;
        std.map?.dispose();
        std.normalMap?.dispose();
        std.roughnessMap?.dispose();
        std.metalnessMap?.dispose();
        std.emissiveMap?.dispose();
        m.dispose();
      }
    }
  });
}

async function renderGlbThumbnail(url: string): Promise<string | "missing"> {
  const existing = thumbnailCache.get(url);
  if (existing) return existing;

  const task = thumbnailQueue.then(async (): Promise<string | "missing"> => {
    const cached = thumbnailCache.get(url);
    if (cached) return cached;

    const result = await loadVehicleGlbAsset(url);
    if (result.status !== "ok") {
      thumbnailCache.set(url, "missing");
      return "missing";
    }

    const w = 220;
    const h = 132;
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      preserveDrawingBuffer: true,
    });
    renderer.setSize(w, h);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.16;

    const scene = new THREE.Scene();
    const pmrem = new THREE.PMREMGenerator(renderer);
    const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;
    pmrem.dispose();

    const hemi = new THREE.HemisphereLight(0xfff4e2, 0x261e16, 1.05);
    const key = new THREE.DirectionalLight(0xffe9c8, 2.0);
    key.position.set(5, 7, 5);
    const rim = new THREE.DirectionalLight(0x90bcf0, 0.8);
    rim.position.set(-4, 3, -5);
    scene.add(hemi, key, rim);

    const camera = new THREE.PerspectiveCamera(36, w / h, 0.05, 100);
    const gltfScene = result.gltf.scene;

    try {
      gltfScene.updateMatrixWorld(true);
      const box = new THREE.Box3().setFromObject(gltfScene);
      const center = new THREE.Vector3();
      box.getCenter(center);

      const scale = computeProportionalCarScale(box);
      gltfScene.scale.setScalar(scale);
      gltfScene.position.set(
        -center.x * scale,
        -box.min.y * scale,
        -center.z * scale,
      );
      scene.add(gltfScene);

      gltfScene.updateMatrixWorld(true);
      const fittedBox = new THREE.Box3().setFromObject(gltfScene);
      const sphere = new THREE.Sphere();
      const target = new THREE.Vector3();
      fittedBox.getCenter(target);
      fittedBox.getBoundingSphere(sphere);

      const fovRad = THREE.MathUtils.degToRad(camera.fov * 0.5);
      const dist = (sphere.radius / Math.sin(fovRad)) * 1.18;
      camera.position.set(
        target.x + Math.sin(0.68) * Math.cos(0.24) * dist,
        target.y + Math.sin(0.24) * dist,
        target.z + Math.cos(0.68) * Math.cos(0.24) * dist,
      );
      camera.lookAt(target);

      renderer.render(scene, camera);
      const dataUrl = renderer.domElement.toDataURL("image/png");
      thumbnailCache.set(url, dataUrl);
      disposeObjectSubtree(gltfScene);
      return dataUrl;
    } catch {
      disposeObjectSubtree(gltfScene);
      thumbnailCache.set(url, "missing");
      return "missing";
    } finally {
      envTex.dispose();
      renderer.dispose();
    }
  });

  thumbnailQueue = task.then(
    () => undefined,
    () => undefined,
  );
  return task;
}

export function CarGlbThumbnail({
  vehicle,
  className,
}: {
  vehicle: VehicleSpec;
  className?: string;
}) {
  const entry = EXTERNAL_CAR_MODELS[vehicle.id];
  const assetUrl = entry?.url || "";
  const fileName = entry?.fileName || `${vehicle.id}.glb`;

  const [thumbState, setThumbState] = useState<string | "loading" | "missing">(() => {
    if (!assetUrl) return "missing";
    const c = thumbnailCache.get(assetUrl);
    return c || "loading";
  });

  useEffect(() => {
    if (!assetUrl) {
      setThumbState("missing");
      return;
    }
    let alive = true;
    renderGlbThumbnail(assetUrl).then((res) => {
      if (alive) setThumbState(res);
    });
    return () => {
      alive = false;
    };
  }, [assetUrl]);

  if (thumbState === "missing" || thumbState === "loading") {
    return (
      <div
        className={className}
        style={{
          height: 76,
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          gap: 3,
          padding: 6,
          background: "#120e0b",
          border: "1px dashed #4f3d2b",
          color: thumbState === "missing" ? "#d9b98b" : "#a89882",
          font: '500 10px "JetBrains Mono", monospace',
          textAlign: "center",
        }}
      >
        <span>{fileName}</span>
        <small style={{ color: "#8c7d68", fontSize: 9.5 }}>
          {thumbState === "missing" ? "Drop in my-cars/" : "Checking GLB…"}
        </small>
      </div>
    );
  }

  return (
    <div
      className={className}
      style={{
        height: 76,
        display: "grid",
        placeItems: "center",
        background: "radial-gradient(circle at 50% 60%, rgba(209,178,115,0.12), #110d0a 75%)",
        border: "1px solid #3c2e20",
        overflow: "hidden",
      }}
    >
      <img
        src={thumbState}
        alt={vehicle.name}
        style={{ width: "100%", height: "100%", objectFit: "contain", display: "block" }}
      />
    </div>
  );
}

function getCameraOffsetForPreset(preset: CameraAnglePreset, dist: number): THREE.Vector3 {
  let yaw = 0.68;
  let pitch = 0.24;
  if (preset === "side") {
    yaw = Math.PI / 2;
    pitch = 0.14;
  } else if (preset === "rear") {
    yaw = Math.PI + 0.56;
    pitch = 0.22;
  } else if (preset === "hero") {
    yaw = 0.42;
    pitch = 0.08;
    dist *= 0.86;
  }
  return new THREE.Vector3(
    Math.sin(yaw) * Math.cos(pitch) * dist,
    Math.sin(pitch) * dist,
    Math.cos(yaw) * Math.cos(pitch) * dist,
  );
}

export function GaragePreview3D({ vehicle }: { vehicle: VehicleSpec }) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [anglePreset, setAnglePreset] = useState<CameraAnglePreset>("front34");
  const [spinTurntable, setSpinTurntable] = useState(true);
  const [reloadNonce, setReloadNonce] = useState(0);
  const [loadStatus, setLoadStatus] = useState<"loading" | "ready" | "missing" | "error">("loading");
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [modelMeta, setModelMeta] = useState<LoadedModelMeta | null>(null);

  const controlsRef = useRef<OrbitControls | null>(null);
  const cameraObjRef = useRef<THREE.PerspectiveCamera | null>(null);
  const frameDistRef = useRef<number>(6.0);
  const targetCenterRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 0.55, 0));
  const spinRef = useRef<boolean>(spinTurntable);

  useEffect(() => {
    spinRef.current = spinTurntable;
    if (controlsRef.current) {
      controlsRef.current.autoRotate = spinTurntable;
    }
  }, [spinTurntable]);

  const applyAngle = useCallback((preset: CameraAnglePreset) => {
    setAnglePreset(preset);
    const cam = cameraObjRef.current;
    const ctrl = controlsRef.current;
    if (!cam || !ctrl) return;
    const target = targetCenterRef.current;
    const offset = getCameraOffsetForPreset(preset, frameDistRef.current);
    cam.position.copy(target).add(offset);
    ctrl.target.copy(target);
    ctrl.update();
  }, []);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const targetAsset = EXTERNAL_CAR_MODELS[vehicle.id];
    const activeUrl = targetAsset?.url;

    if (!activeUrl) {
      setLoadStatus("missing");
      setStatusMessage(`No modelPath mapped for slot "${vehicle.name}" (${vehicle.id}).`);
      setModelMeta(null);
      return;
    }

    setLoadStatus("loading");
    setStatusMessage(null);
    setModelMeta(null);

    const w = container.clientWidth || 520;
    const h = container.clientHeight || 340;
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x13100d);

    const camera = new THREE.PerspectiveCamera(40, w / h, 0.08, 160);
    camera.position.set(3.8, 1.85, 4.9);
    cameraObjRef.current = camera;

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: "high-performance",
    });
    renderer.setSize(w, h);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.16;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.domElement.style.display = "block";
    renderer.domElement.style.width = "100%";
    renderer.domElement.style.height = "100%";
    renderer.domElement.style.cursor = "grab";
    container.appendChild(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.enablePan = false;
    controls.minPolarAngle = 0.08;
    controls.maxPolarAngle = Math.PI * 0.49;
    controls.minDistance = 1.8;
    controls.maxDistance = 24;
    controls.autoRotate = spinRef.current;
    controls.autoRotateSpeed = 1.6;
    controls.target.set(0, 0.55, 0);
    controls.update();
    controlsRef.current = controls;

    const pmrem = new THREE.PMREMGenerator(renderer);
    const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;
    pmrem.dispose();

    const hemi = new THREE.HemisphereLight(0xfff3df, 0x261e16, 1.05);
    const keyLight = new THREE.DirectionalLight(0xffe9c9, 2.05);
    keyLight.position.set(6, 9, 6);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.camera.near = 1;
    keyLight.shadow.camera.far = 28;
    keyLight.shadow.camera.left = -5;
    keyLight.shadow.camera.right = 5;
    keyLight.shadow.camera.top = 5;
    keyLight.shadow.camera.bottom = -5;
    const fillLight = new THREE.DirectionalLight(0xd9e8ff, 0.72);
    fillLight.position.set(-5, 4, 4);
    const rimLight = new THREE.DirectionalLight(0x8bb6e6, 0.85);
    rimLight.position.set(-5, 5, -6);
    scene.add(hemi, keyLight, fillLight, rimLight);

    // Subtle showroom stage disc (ground plane only, never vehicle geometry)
    const stageFloorGeo = new THREE.CircleGeometry(3.6, 64);
    stageFloorGeo.rotateX(-Math.PI / 2);
    const stageFloorMat = new THREE.MeshStandardMaterial({
      color: 0x1b1611,
      metalness: 0.42,
      roughness: 0.52,
    });
    const stageFloor = new THREE.Mesh(stageFloorGeo, stageFloorMat);
    stageFloor.position.y = -0.005;
    stageFloor.receiveShadow = true;

    const stageRimGeo = new THREE.RingGeometry(3.52, 3.6, 64);
    stageRimGeo.rotateX(-Math.PI / 2);
    const stageRimMat = new THREE.MeshBasicMaterial({ color: 0xc9a867 });
    const stageRim = new THREE.Mesh(stageRimGeo, stageRimMat);
    stageRim.position.y = 0.002;
    scene.add(stageFloor, stageRim);

    let loadedModelRoot: THREE.Group | null = null;
    let cancelled = false;

    loadVehicleGlbAsset(activeUrl).then((result) => {
      if (cancelled) {
        if (result.status === "ok") disposeObjectSubtree(result.gltf.scene);
        return;
      }

      if (result.status !== "ok") {
        thumbnailCache.set(activeUrl, "missing");
        setLoadStatus(result.status);
        setStatusMessage(result.reason);
        setModelMeta(null);
        return;
      }

      const gltfScene = result.gltf.scene;
      gltfScene.traverse((child) => {
        if ((child as THREE.Mesh).isMesh) {
          child.castShadow = true;
          child.receiveShadow = true;
        }
      });

      // Automatically compute bounding box, preserve original proportions & materials, and ground at Y=0
      gltfScene.updateMatrixWorld(true);
      const rawBox = new THREE.Box3().setFromObject(gltfScene);
      const rawCenter = new THREE.Vector3();
      rawBox.getCenter(rawCenter);

      const scale = computeProportionalCarScale(rawBox);
      const wrapper = new THREE.Group();
      wrapper.name = `slot-${targetAsset.slot}:${vehicle.id}`;
      gltfScene.scale.setScalar(scale);
      gltfScene.position.set(
        -rawCenter.x * scale,
        -rawBox.min.y * scale,
        -rawCenter.z * scale,
      );
      wrapper.add(gltfScene);
      scene.add(wrapper);
      loadedModelRoot = wrapper;

      wrapper.updateMatrixWorld(true);
      const fittedBox = new THREE.Box3().setFromObject(wrapper);
      const fittedSize = new THREE.Vector3();
      const fittedCenter = new THREE.Vector3();
      const sphere = new THREE.Sphere();
      fittedBox.getSize(fittedSize);
      fittedBox.getCenter(fittedCenter);
      fittedBox.getBoundingSphere(sphere);

      const fovRad = THREE.MathUtils.degToRad(camera.fov * 0.5);
      const fitDist = Math.max(2.8, (sphere.radius / Math.sin(fovRad)) * 1.2);

      frameDistRef.current = fitDist;
      targetCenterRef.current.copy(fittedCenter);

      controls.minDistance = Math.max(1.4, sphere.radius * 1.1);
      controls.maxDistance = Math.max(10, sphere.radius * 4.8);
      controls.target.copy(fittedCenter);

      const initialOffset = getCameraOffsetForPreset(anglePreset, fitDist);
      camera.position.copy(fittedCenter).add(initialOffset);
      controls.update();

      // Clear missing cache mark if file was just placed on disk
      if (thumbnailCache.get(activeUrl) === "missing") {
        thumbnailCache.delete(activeUrl);
      }

      setModelMeta({
        url: activeUrl,
        meshCount: result.meshCount,
        scale,
        dimsLabel: `${fittedSize.x.toFixed(2)}m × ${fittedSize.y.toFixed(2)}m × ${fittedSize.z.toFixed(2)}m`,
      });
      setLoadStatus("ready");
      setStatusMessage(null);
    });

    const onResize = () => {
      if (!container) return;
      const nw = container.clientWidth;
      const nh = container.clientHeight;
      if (nw <= 0 || nh <= 0) return;
      camera.aspect = nw / nh;
      camera.updateProjectionMatrix();
      renderer.setSize(nw, nh);
    };
    const ro = new ResizeObserver(onResize);
    ro.observe(container);

    let rafId = 0;
    const animate = () => {
      if (cancelled) return;
      controls.update();
      renderer.render(scene, camera);
      rafId = requestAnimationFrame(animate);
    };
    rafId = requestAnimationFrame(animate);

    return () => {
      cancelled = true;
      cancelAnimationFrame(rafId);
      ro.disconnect();
      controls.dispose();
      controlsRef.current = null;
      cameraObjRef.current = null;
      if (loadedModelRoot) {
        scene.remove(loadedModelRoot);
        disposeObjectSubtree(loadedModelRoot);
        loadedModelRoot = null;
      }
      stageFloorGeo.dispose();
      stageFloorMat.dispose();
      stageRimGeo.dispose();
      stageRimMat.dispose();
      envTex.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [vehicle.id, vehicle.name, reloadNonce]);

  const slotMeta = EXTERNAL_CAR_MODELS[vehicle.id];

  return (
    <div className="gw-preview-wrap">
      <div
        className="gw-garage-3d"
        ref={mountRef}
        aria-label={`3D GLTF Showroom for ${vehicle.name}`}
        style={{ position: "relative" }}
      >
        {loadStatus === "loading" && (
          <div
            role="status"
            style={{
              position: "absolute",
              inset: 0,
              display: "grid",
              placeItems: "center",
              pointerEvents: "none",
              background: "rgba(19, 16, 13, 0.55)",
              color: "#e6d2a4",
              font: '600 12px "JetBrains Mono", monospace',
              letterSpacing: "0.06em",
            }}
          >
            LOADING {slotMeta?.url || vehicle.id}
          </div>
        )}
        {(loadStatus === "missing" || loadStatus === "error") && statusMessage && (
          <div
            role="alert"
            style={{
              position: "absolute",
              inset: 16,
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
              alignItems: "center",
              gap: 10,
              padding: 20,
              textAlign: "center",
              background:
                loadStatus === "missing" ? "rgba(22, 18, 13, 0.94)" : "rgba(28, 12, 11, 0.94)",
              border:
                loadStatus === "missing" ? "1px dashed #c9a867" : "1px solid #c24b3d",
              color: loadStatus === "missing" ? "#f1e3c4" : "#ffd0c7",
              fontSize: 13,
            }}
          >
            <strong>
              {loadStatus === "missing"
                ? `Missing Model File: ${slotMeta?.fileName || vehicle.id}`
                : `Invalid 3D Model File: ${slotMeta?.fileName || vehicle.id}`}
            </strong>
            <span style={{ maxWidth: 480, color: "#cbbba4", lineHeight: 1.5 }}>
              Place your downloaded <code>.glb</code> model as{" "}
              <code>public{slotMeta?.url}</code> and click Re-check Folder below. Original materials,
              textures, and proportions will load automatically with no placeholder car substituted.
            </span>
            <small style={{ color: "#9e8e78", fontFamily: '"JetBrains Mono", monospace' }}>
              {statusMessage}
            </small>
            <button
              type="button"
              className="gw-btn gw-btn-primary"
              onClick={() => {
                if (slotMeta?.url) thumbnailCache.delete(slotMeta.url);
                setReloadNonce((n) => n + 1);
              }}
            >
              Check Folder Again
            </button>
          </div>
        )}
        {loadStatus === "ready" && modelMeta && (
          <div
            style={{
              position: "absolute",
              left: 10,
              bottom: 10,
              padding: "4px 9px",
              background: "rgba(15, 12, 9, 0.82)",
              border: "1px solid rgba(209, 178, 115, 0.35)",
              color: "#d9caa8",
              font: '500 10.5px "JetBrains Mono", monospace',
              pointerEvents: "none",
            }}
          >
            {modelMeta.url.split("/").pop()} · {modelMeta.meshCount} meshes · {modelMeta.dimsLabel} · Drag to Orbit · Scroll to Zoom
          </div>
        )}
      </div>

      <div className="gw-preview-toolbar">
        <div className="gw-preview-btn-group">
          {(
            [
              ["front34", "3/4 Front"],
              ["side", "Side"],
              ["rear", "Rear Aero"],
              ["hero", "Low Hero"],
            ] as [CameraAnglePreset, string][]
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              className={`gw-btn ${anglePreset === id ? "gw-btn-primary" : ""}`}
              onClick={() => applyAngle(id)}
            >
              {label}
            </button>
          ))}
        </div>
        <div className="gw-preview-btn-group">
          <button
            type="button"
            className={`gw-btn ${spinTurntable ? "gw-btn-primary" : ""}`}
            onClick={() => setSpinTurntable((v) => !v)}
          >
            {spinTurntable ? "⟳ Orbit Spin On" : "⟳ Orbit Paused"}
          </button>
          <button
            type="button"
            className="gw-btn"
            onClick={() => {
              if (slotMeta?.url) thumbnailCache.delete(slotMeta.url);
              setReloadNonce((n) => n + 1);
            }}
          >
            Reload GLB
          </button>
        </div>
      </div>
    </div>
  );
}
