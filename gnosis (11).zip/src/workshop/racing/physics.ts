import * as CANNON from "cannon-es";
import * as THREE from "three";
import { MY_CARS, MY_CARS_BY_ID, type MyCarEntry } from "./myCars";
import {
  buildVehicleRig,
  computeProportionalCarScale,
  EXTERNAL_CAR_MODELS,
  loadVehicleGlbAsset,
  WORKSHOP_VEHICLES,
  type CarRig,
  type CarVisualOptions,
  type LoadedVehicleModelInfo,
  type VehicleSpec,
} from "./vehicles";
import type { CarTuningConfig } from "./customization";
import type { ClosestTrackResult } from "./trackAndWorld";

export interface CarControlsInput {
  /** Throttle input in [0, 1] */
  throttle: number;
  /** Brake / reverse input in [0, 1] */
  brake: number;
  /** Steering input in [-1, 1] where +1 turns left and -1 turns right */
  steer: number;
  /** Handbrake engaged for drift initiation */
  handbrake: boolean;
}

export interface LoadedCarPhysicsBounds {
  width: number;
  height: number;
  length: number;
  wheelRadius: number;
  wheelBaseHalf: number;
  trackHalfWidth: number;
  chassisCenterY: number;
}

export interface CarPhysicsStepContext {
  closestTrack: ClosestTrackResult;
  roadHalfWidth: number;
  barrierHalfWidth: number;
  tuning: CarTuningConfig;
  drafting: boolean;
}

export interface CarPhysicsSnapshot {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  vLong: number;
  vLat: number;
  speedMs: number;
  speedKmh: number;
  yaw: number;
  yawRate: number;
  steer: number;
  wheelSpin: number;
  pitch: number;
  roll: number;
  isBraking: boolean;
  isDrifting: boolean;
  onAsphalt: boolean;
  onShoulder: boolean;
  surface: "ASPHALT" | "SHOULDER" | "DRIFT" | "OFF-TRACK";
  numWheelsOnGround: number;
}

export interface LoadedCarPhysicsBundle {
  spec: MyCarEntry;
  rig: CarRig;
  physics: CannonVehiclePhysics;
  dispose: () => void;
}

const DEFAULT_CAR_SIZE = new THREE.Vector3(1.94, 1.18, 4.35);

/**
 * Derives realistic cannon-es chassis box dimensions and wheel mount geometry
 * directly from a loaded 3D GLB car model's bounding box (or falls back cleanly
 * to spec proportions before async load finishes).
 */
export function measureCarBoundsFromBox(
  box: THREE.Box3 | null,
  spec: VehicleSpec,
): LoadedCarPhysicsBounds {
  const size = new THREE.Vector3();
  if (box && !box.isEmpty()) {
    box.getSize(size);
  } else {
    size.copy(DEFAULT_CAR_SIZE);
  }

  const width = THREE.MathUtils.clamp(size.x || DEFAULT_CAR_SIZE.x, 1.4, 2.8);
  const height = THREE.MathUtils.clamp(size.y || DEFAULT_CAR_SIZE.y, 0.75, 2.2);
  const length = THREE.MathUtils.clamp(size.z || DEFAULT_CAR_SIZE.z, 3.0, 6.2);
  const wheelRadius = THREE.MathUtils.clamp(spec.wheelRadius || 0.37, 0.28, 0.56);

  return {
    width,
    height,
    length,
    wheelRadius,
    trackHalfWidth: width * 0.43,
    wheelBaseHalf: length * 0.34,
    chassisCenterY: Math.max(wheelRadius + 0.36, height * 0.48),
  };
}

/**
 * Resolves a car slot from MY_CARS / WORKSHOP_VEHICLES, loads its 3D GLB model,
 * and constructs a synced CannonVehiclePhysics simulation bound to the model.
 */
export function createLoadedCarWithPhysics(
  vehicleOrId: VehicleSpec | MyCarEntry | string,
  options?: {
    customVisual?: CarVisualOptions;
    spawn?: { x: number; y: number; z: number; yaw: number };
    onMissingAsset?: (url: string, reason: string) => void;
    onModelLoaded?: (info: LoadedVehicleModelInfo) => void;
  },
): LoadedCarPhysicsBundle {
  const resolvedId = typeof vehicleOrId === "string" ? vehicleOrId : vehicleOrId.id;
  const spec =
    MY_CARS_BY_ID[resolvedId] ||
    WORKSHOP_VEHICLES.find((c) => c.id === resolvedId) ||
    MY_CARS[0];

  const physics = new CannonVehiclePhysics(spec, options?.spawn);

  const rig = buildVehicleRig(spec, options?.customVisual, {
    onMissingAsset: options?.onMissingAsset,
    onModelLoaded: (info) => {
      physics.syncDimensionsFromModel(info.box);
      options?.onModelLoaded?.(info);
    },
  });

  // Also pre-probe the cached GLB metadata if already warm in browser cache
  const assetMeta = EXTERNAL_CAR_MODELS[spec.id];
  if (assetMeta) {
    void loadVehicleGlbAsset(assetMeta.url).then((res) => {
      if (res.status === "ok" && !physics.isDisposed()) {
        const scene = res.gltf.scene;
        scene.updateMatrixWorld(true);
        const rawBox = new THREE.Box3().setFromObject(scene);
        const scale = computeProportionalCarScale(rawBox);
        const scaledSize = new THREE.Vector3();
        rawBox.getSize(scaledSize).multiplyScalar(scale);
        const fittedBox = new THREE.Box3(
          new THREE.Vector3(-scaledSize.x * 0.5, 0, -scaledSize.z * 0.5),
          new THREE.Vector3(scaledSize.x * 0.5, scaledSize.y, scaledSize.z * 0.5),
        );
        physics.syncDimensionsFromModel(fittedBox);
      }
    });
  }

  return {
    spec,
    rig,
    physics,
    dispose: () => {
      physics.dispose();
    },
  };
}

/**
 * Real-time cannon-es rigid-body + RaycastVehicle physics simulation
 * for GNOSIS Racing cars.
 *
 * Coordinate convention:
 * - Three.js car models face +Z at yaw = 0 (`fx = sin(yaw)`, `fz = cos(yaw)`).
 * - cannon-es RaycastVehicle drives along local -Z with `indexRightAxis = 0`.
 * - We maintain a +Math.PI yaw offset on `chassisBody` so positive `applyEngineForce`
 *   accelerates forward along Three.js +Z and positive `setSteeringValue` turns left (+X).
 */
export class CannonVehiclePhysics {
  public readonly spec: VehicleSpec;
  public readonly world: CANNON.World;
  public readonly groundBody: CANNON.Body;
  public readonly chassisBody: CANNON.Body;
  public readonly vehicle: CANNON.RaycastVehicle;

  private readonly groundMaterial: CANNON.Material;
  private readonly wheelMaterial: CANNON.Material;
  private readonly chassisMaterial: CANNON.Material;

  private bounds: LoadedCarPhysicsBounds;
  private disposed = false;

  // Derived kinematics & visual suspension state
  private steerAngle = 0;
  private wheelSpin = 0;
  private bodyPitch = 0;
  private bodyRoll = 0;
  private lastForwardSpeed = 0;
  private lastSnapshot: CarPhysicsSnapshot;

  // Scratch vectors to avoid per-frame allocations at 120 Hz
  private readonly tmpRoadUp = new THREE.Vector3(0, 1, 0);
  private readonly tmpWorldUp = new THREE.Vector3(0, 1, 0);
  private readonly tmpQuat = new THREE.Quaternion();
  private readonly tmpFwd = new CANNON.Vec3();

  constructor(
    spec: VehicleSpec,
    initialSpawn: { x: number; y: number; z: number; yaw: number } = { x: 0, y: 0, z: 0, yaw: 0 },
  ) {
    this.spec = spec;
    this.bounds = measureCarBoundsFromBox(null, spec);

    this.world = new CANNON.World({
      gravity: new CANNON.Vec3(0, -9.81, 0),
    });
    // NaiveBroadphase avoids stale SAPBroadphase axis caches when groundBody follows the car
    this.world.broadphase = new CANNON.NaiveBroadphase();
    this.world.defaultContactMaterial.friction = 0.2;
    this.world.defaultContactMaterial.restitution = 0.04;

    this.groundMaterial = new CANNON.Material("trackGround");
    this.wheelMaterial = new CANNON.Material("carWheel");
    this.chassisMaterial = new CANNON.Material("carChassis");

    this.world.addContactMaterial(
      new CANNON.ContactMaterial(this.wheelMaterial, this.groundMaterial, {
        friction: 0.95,
        restitution: 0.0,
        contactEquationStiffness: 1e7,
        contactEquationRelaxation: 3,
      }),
    );
    this.world.addContactMaterial(
      new CANNON.ContactMaterial(this.chassisMaterial, this.groundMaterial, {
        friction: 0.05,
        restitution: 0.02,
      }),
    );

    // Dynamic road-patch static body positioned under the car to match curved/elevated tracks
    this.groundBody = new CANNON.Body({
      mass: 0,
      material: this.groundMaterial,
      shape: new CANNON.Box(new CANNON.Vec3(32, 0.5, 32)),
    });
    this.groundBody.position.set(initialSpawn.x, initialSpawn.y - 0.5, initialSpawn.z);
    this.groundBody.updateAABB();
    this.world.addBody(this.groundBody);

    // Car chassis rigid body (aero & rolling drag handled explicitly without artificial linearDamping)
    this.chassisBody = new CANNON.Body({
      mass: spec.massKg,
      material: this.chassisMaterial,
      linearDamping: 0.0,
      angularDamping: 0.25,
    });
    this.chassisBody.addShape(this.createChassisShape(this.bounds));
    // Allow full yaw rotation around Y while keeping chassis upright over high-speed crests
    this.chassisBody.angularFactor.set(0, 1.0, 0);

    const chassisStartY = initialSpawn.y + this.bounds.chassisCenterY;
    this.chassisBody.position.set(initialSpawn.x, chassisStartY, initialSpawn.z);
    this.chassisBody.quaternion.setFromAxisAngle(
      new CANNON.Vec3(0, 1, 0),
      initialSpawn.yaw + Math.PI,
    );
    this.chassisBody.updateAABB();

    this.vehicle = new CANNON.RaycastVehicle({
      chassisBody: this.chassisBody,
      indexRightAxis: 0,
      indexUpAxis: 1,
      indexForwardAxis: 2,
    });

    this.configureWheels(this.bounds);
    // Keep RaycastVehicle suspension rays & wheel transforms active while applying deterministic
    // tire friction, engine force, and braking forces directly onto chassisBody in step().
    this.vehicle.updateFriction = () => {
      let contactCount = 0;
      for (let i = 0; i < this.vehicle.wheelInfos.length; i++) {
        if (this.vehicle.wheelInfos[i].raycastResult.body) contactCount++;
      }
      this.vehicle.numWheelsOnGround = contactCount;
    };
    this.vehicle.addToWorld(this.world);

    this.lastSnapshot = {
      x: initialSpawn.x,
      y: initialSpawn.y,
      z: initialSpawn.z,
      vx: 0,
      vy: 0,
      vz: 0,
      vLong: 0,
      vLat: 0,
      speedMs: 0,
      speedKmh: 0,
      yaw: initialSpawn.yaw,
      yawRate: 0,
      steer: 0,
      wheelSpin: 0,
      pitch: 0,
      roll: 0,
      isBraking: false,
      isDrifting: false,
      onAsphalt: true,
      onShoulder: false,
      surface: "ASPHALT",
      numWheelsOnGround: 4,
    };
  }

  public isDisposed(): boolean {
    return this.disposed;
  }

  private createChassisShape(b: LoadedCarPhysicsBounds): CANNON.Box {
    return new CANNON.Box(new CANNON.Vec3(b.width * 0.46, b.height * 0.34, b.length * 0.46));
  }

  private configureWheels(b: LoadedCarPhysicsBounds) {
    const suspRest = Math.max(0.24, b.wheelRadius * 0.68);
    const connY = -b.chassisCenterY + b.wheelRadius + suspRest * 0.72;

    const baseWheelOpts = {
      radius: b.wheelRadius,
      directionLocal: new CANNON.Vec3(0, -1, 0),
      suspensionStiffness: 42,
      suspensionRestLength: suspRest,
      frictionSlip: 3.4 * this.spec.baseGrip,
      dampingRelaxation: 3.8,
      dampingCompression: 4.6,
      maxSuspensionForce: this.spec.massKg * 45,
      rollInfluence: 0.08,
      axleLocal: new CANNON.Vec3(1, 0, 0),
      maxSuspensionTravel: 0.32,
      customSlidingRotationalSpeed: -30,
      useCustomSlidingRotationalSpeed: true,
    };

    const points: Array<{ pt: CANNON.Vec3; isFront: boolean }> = [
      // Front-Left (local -X, -Z maps to Three.js +X, +Z when rotated +PI)
      { pt: new CANNON.Vec3(-b.trackHalfWidth, connY, -b.wheelBaseHalf), isFront: true },
      // Front-Right
      { pt: new CANNON.Vec3(b.trackHalfWidth, connY, -b.wheelBaseHalf), isFront: true },
      // Rear-Left
      { pt: new CANNON.Vec3(-b.trackHalfWidth, connY, b.wheelBaseHalf), isFront: false },
      // Rear-Right
      { pt: new CANNON.Vec3(b.trackHalfWidth, connY, b.wheelBaseHalf), isFront: false },
    ];

    for (const p of points) {
      this.vehicle.addWheel({
        ...baseWheelOpts,
        chassisConnectionPointLocal: p.pt,
        isFrontWheel: p.isFront,
      });
    }
  }

  /**
   * Resizes the cannon-es collision box and wheel axle offsets to match
   * the actual bounding box of the loaded GLB model.
   */
  public syncDimensionsFromModel(box: THREE.Box3) {
    if (this.disposed) return;
    const prevCenterY = this.bounds.chassisCenterY;
    const next = measureCarBoundsFromBox(box, this.spec);
    this.bounds = next;

    this.chassisBody.position.y += next.chassisCenterY - prevCenterY;
    this.chassisBody.shapes.length = 0;
    this.chassisBody.shapeOffsets.length = 0;
    this.chassisBody.shapeOrientations.length = 0;
    this.chassisBody.addShape(this.createChassisShape(next));
    this.chassisBody.updateMassProperties();
    this.chassisBody.updateAABB();

    const suspRest = Math.max(0.24, next.wheelRadius * 0.68);
    const connY = -next.chassisCenterY + next.wheelRadius + suspRest * 0.72;
    const offsets: Array<[number, number, number]> = [
      [-next.trackHalfWidth, connY, -next.wheelBaseHalf],
      [next.trackHalfWidth, connY, -next.wheelBaseHalf],
      [-next.trackHalfWidth, connY, next.wheelBaseHalf],
      [next.trackHalfWidth, connY, next.wheelBaseHalf],
    ];

    for (let i = 0; i < this.vehicle.wheelInfos.length; i++) {
      const w = this.vehicle.wheelInfos[i];
      w.radius = next.wheelRadius;
      w.suspensionRestLength = suspRest;
      const [wx, wy, wz] = offsets[i];
      w.chassisConnectionPointLocal.set(wx, wy, wz);
    }
  }

  public getYaw(): number {
    // Local -Z in Cannon body transforms to Three.js car forward (+Z when cannonYaw = PI)
    this.chassisBody.quaternion.vmult(new CANNON.Vec3(0, 0, -1), this.tmpFwd);
    return Math.atan2(this.tmpFwd.x, this.tmpFwd.z);
  }

  public reset(x: number, y: number, z: number, yaw: number) {
    this.chassisBody.position.set(x, y + this.bounds.chassisCenterY, z);
    this.chassisBody.velocity.set(0, 0, 0);
    this.chassisBody.angularVelocity.set(0, 0, 0);
    this.chassisBody.force.set(0, 0, 0);
    this.chassisBody.torque.set(0, 0, 0);
    this.chassisBody.quaternion.setFromAxisAngle(new CANNON.Vec3(0, 1, 0), yaw + Math.PI);
    this.chassisBody.updateAABB();

    this.groundBody.position.set(x, y - 0.5, z);
    this.groundBody.quaternion.set(0, 0, 0, 1);
    this.groundBody.updateAABB();

    this.steerAngle = 0;
    this.bodyPitch = 0;
    this.bodyRoll = 0;
    this.lastForwardSpeed = 0;

    for (let i = 0; i < 4; i++) {
      this.vehicle.applyEngineForce(0, i);
      this.vehicle.setBrake(0, i);
      if (i < 2) this.vehicle.setSteeringValue(0, i);
    }

    this.lastSnapshot = {
      ...this.lastSnapshot,
      x,
      y,
      z,
      vx: 0,
      vy: 0,
      vz: 0,
      vLong: 0,
      vLat: 0,
      speedMs: 0,
      speedKmh: 0,
      yaw,
      yawRate: 0,
      steer: 0,
      pitch: 0,
      roll: 0,
      isBraking: false,
      isDrifting: false,
    };
  }

  public step(
    dt: number,
    controls: CarControlsInput,
    ctx: CarPhysicsStepContext,
  ): CarPhysicsSnapshot {
    const { closestTrack, roadHalfWidth, barrierHalfWidth, tuning, drafting } = ctx;

    // 1. Align dynamic Cannon ground patch directly beneath car with track slope normal
    this.tmpRoadUp.crossVectors(closestTrack.sample.right, closestTrack.sample.tangent).normalize();
    if (this.tmpRoadUp.y < 0) this.tmpRoadUp.negate();
    this.tmpQuat.setFromUnitVectors(this.tmpWorldUp, this.tmpRoadUp);

    const cx = this.chassisBody.position.x;
    const cz = this.chassisBody.position.z;
    this.groundBody.position.set(
      cx - this.tmpRoadUp.x * 0.5,
      closestTrack.elevation - this.tmpRoadUp.y * 0.5,
      cz - this.tmpRoadUp.z * 0.5,
    );
    this.groundBody.quaternion.set(
      this.tmpQuat.x,
      this.tmpQuat.y,
      this.tmpQuat.z,
      this.tmpQuat.w,
    );
    // Critical: keep static ground patch AABB synced with its moved position for world.rayTest
    this.groundBody.aabbNeedsUpdate = true;
    this.groundBody.updateAABB();

    // 2. Measure current longitudinal / lateral velocity in car frame
    const yaw = this.getYaw();
    const fx = Math.sin(yaw);
    const fz = Math.cos(yaw);
    const rx = -fz;
    const rz = fx;

    const vx = this.chassisBody.velocity.x;
    const vz = this.chassisBody.velocity.z;
    const vLong = vx * fx + vz * fz;
    const vLat = vx * rx + vz * rz;

    const onAsphalt = closestTrack.absLateral <= roadHalfWidth + 0.6;
    const onShoulder = !onAsphalt && closestTrack.absLateral <= barrierHalfWidth - 0.8;

    // 3. Steering (front wheels 0 and 1)
    const speedSteerCap =
      (this.spec.maxSteerRad * tuning.steeringGain) /
      (1 + Math.abs(vLong) * this.spec.steerSpeedReduction);
    const targetSteer = THREE.MathUtils.clamp(controls.steer, -1, 1) * speedSteerCap;
    this.steerAngle = THREE.MathUtils.damp(this.steerAngle, targetSteer, this.spec.steerDamp, dt);
    this.vehicle.setSteeringValue(this.steerAngle, 0);
    this.vehicle.setSteeringValue(this.steerAngle, 1);

    // 4. Tire traction & slip update (asphalt vs shoulder vs off-track & handbrake)
    const surfaceGrip =
      (onAsphalt ? this.spec.baseGrip : this.spec.offTrackGrip) * tuning.tireGripMult;
    const rearDriftMult = controls.handbrake ? this.spec.handbrakeGripFactor : 1.0;

    for (let i = 0; i < this.vehicle.wheelInfos.length; i++) {
      const w = this.vehicle.wheelInfos[i];
      const isRear = i >= 2;
      w.frictionSlip = (isRear ? 4.8 * rearDriftMult : 4.2) * surfaceGrip;
    }

    // 5. Acceleration, Braking & Reverse (synced to RaycastVehicle & applied to chassisBody)
    const draftForceMult = drafting ? 1.14 : 1.0;
    const effectiveTopSpeed = this.spec.topSpeedMs * tuning.topSpeedTrim;
    const draftSpeedCap = drafting ? effectiveTopSpeed * 1.1 : effectiveTopSpeed;

    let longDriveForce = 0;
    let engineForcePerWheel = 0;
    let frontBrake = 0;
    let rearBrake = 0;
    let isBrakingVisual = false;

    const throttle = THREE.MathUtils.clamp(controls.throttle, 0, 1);
    const brake = THREE.MathUtils.clamp(controls.brake, 0, 1);

    if (throttle > 0) {
      const torqueCurve = Math.max(0.16, 1.0 - Math.max(0, vLong) / (draftSpeedCap * 1.08));
      const totalDriveForce =
        this.spec.engineForceN * tuning.accelBoostMult * draftForceMult * torqueCurve * throttle;
      longDriveForce += totalDriveForce;
      engineForcePerWheel = totalDriveForce * 0.25;
    }

    if (brake > 0) {
      isBrakingVisual = true;
      if (vLong > 0.8) {
        const totalBrake = this.spec.brakeForceN * tuning.brakePowerMult * brake;
        longDriveForce -= totalBrake;
        frontBrake = totalBrake * 0.025;
        rearBrake = totalBrake * 0.02;
      } else {
        const revCap = Math.max(0.15, 1.0 - Math.max(0, -vLong) / 22);
        const totalRevForce = -this.spec.reverseForceN * revCap * brake;
        longDriveForce += totalRevForce;
        engineForcePerWheel = totalRevForce * 0.25;
      }
    }

    if (controls.handbrake) {
      isBrakingVisual = true;
      longDriveForce -= Math.sign(vLong) * 6200;
      rearBrake = Math.max(rearBrake, 120);
      if (throttle === 0) engineForcePerWheel = 0;
    }

    for (let i = 0; i < 4; i++) {
      this.vehicle.applyEngineForce(engineForcePerWheel, i);
      this.vehicle.setBrake(i < 2 ? frontBrake : rearBrake, i);
    }

    // 6. Aerodynamic drag, rolling resistance, slope grade & lateral tire traction
    const surfaceRollMult = onAsphalt
      ? 1.0
      : onShoulder
        ? Math.min(2.4, this.spec.offTrackRollMult * 0.65)
        : this.spec.offTrackRollMult;
    const dragForce =
      -this.spec.aeroDrag * (drafting ? 0.82 : 1.0) * vLong * Math.abs(vLong) -
      18 * surfaceRollMult * vLong;
    const slopeForce = -this.spec.massKg * 9.81 * Math.sin(closestTrack.slopePitch) * 0.45;
    const totalLongForce = longDriveForce + dragForce + slopeForce;

    const lateralTraction = controls.handbrake ? this.spec.handbrakeGripFactor : 0.94;
    const maxLatForce = this.spec.massKg * 19.5 * surfaceGrip * lateralTraction;
    const latGripForce = THREE.MathUtils.clamp(
      -vLat * this.spec.massKg * 10.8 * surfaceGrip * lateralTraction,
      -maxLatForce,
      maxLatForce,
    );

    this.chassisBody.applyForce(
      new CANNON.Vec3(
        fx * totalLongForce + rx * latGripForce,
        0,
        fz * totalLongForce + rz * latGripForce,
      ),
      new CANNON.Vec3(0, 0, 0),
    );

    // 7. Speed-scaled yaw response from front steering angle
    const dirSign = vLong >= -0.05 ? 1 : -1;
    const speedFactor = THREE.MathUtils.clamp(Math.abs(vLong) / 4.0, 0, 1);
    const yawGain =
      this.spec.turnAuthority *
      tuning.diffLockYaw *
      (controls.handbrake ? this.spec.handbrakeYawBoost : 1.0);
    const targetYawRate = dirSign * this.steerAngle * speedFactor * yawGain;
    const blendedYawRate = THREE.MathUtils.damp(
      this.chassisBody.angularVelocity.y,
      targetYawRate,
      controls.handbrake ? 7.2 : 12.5,
      dt,
    );
    this.chassisBody.angularVelocity.set(0, blendedYawRate, 0);

    // Step cannon-es physics world at fixed timestep
    this.world.step(dt);

    // Keep chassis upright around Y while preserving vertical suspension travel
    const postYaw = this.getYaw();
    this.chassisBody.quaternion.setFromAxisAngle(new CANNON.Vec3(0, 1, 0), postYaw + Math.PI);
    this.chassisBody.angularVelocity.x = 0;
    this.chassisBody.angularVelocity.z = 0;
    this.chassisBody.updateAABB();

    // Smooth ground-plane follow if track elevation changes rapidly across crests
    const minWorldY = closestTrack.elevation + this.bounds.chassisCenterY - 0.12;
    const maxWorldY = closestTrack.elevation + this.bounds.chassisCenterY + 0.45;
    if (this.chassisBody.position.y < minWorldY) {
      this.chassisBody.position.y = THREE.MathUtils.damp(this.chassisBody.position.y, minWorldY, 26, dt);
      if (this.chassisBody.velocity.y < 0) this.chassisBody.velocity.y = 0;
    } else if (this.chassisBody.position.y > maxWorldY) {
      this.chassisBody.position.y = THREE.MathUtils.damp(this.chassisBody.position.y, maxWorldY, 14, dt);
    }

    // Idle creep stop
    const postVx = this.chassisBody.velocity.x;
    const postVz = this.chassisBody.velocity.z;
    const postFx = Math.sin(postYaw);
    const postFz = Math.cos(postYaw);
    const postRx = -postFz;
    const postRz = postFx;
    let postVLong = postVx * postFx + postVz * postFz;
    const postVLat = postVx * postRx + postVz * postRz;

    if (throttle === 0 && brake === 0 && Math.abs(postVLong) < 0.14 && Math.abs(postVLat) < 0.14) {
      this.chassisBody.velocity.set(0, this.chassisBody.velocity.y, 0);
      postVLong = 0;
    }

    const speedMs = Math.hypot(postVLong, postVLat);
    const longAccel = (postVLong - this.lastForwardSpeed) / Math.max(dt, 0.001);
    this.lastForwardSpeed = postVLong;

    const rollFactor =
      (this.spec.massKg > 1550 ? 0.0036 : 0.0026) / Math.max(0.5, tuning.suspensionStiffness);
    const targetPitch = THREE.MathUtils.clamp(
      (-longAccel * 0.0044) / Math.max(0.5, tuning.suspensionStiffness),
      -0.075,
      0.075,
    );
    const targetRoll = THREE.MathUtils.clamp(blendedYawRate * speedMs * rollFactor, -0.1, 0.1);
    this.bodyPitch = THREE.MathUtils.damp(this.bodyPitch, targetPitch, 8, dt);
    this.bodyRoll = THREE.MathUtils.damp(this.bodyRoll, targetRoll, 9, dt);
    this.wheelSpin += (postVLong / Math.max(0.25, this.spec.wheelRadius)) * dt;

    const slipMag = Math.abs(postVLat);
    const isDrifting = (slipMag > 3.6 || (controls.handbrake && speedMs > 6)) && onAsphalt;
    const surface: CarPhysicsSnapshot["surface"] = !onAsphalt
      ? "OFF-TRACK"
      : isDrifting
        ? "DRIFT"
        : onShoulder
          ? "SHOULDER"
          : "ASPHALT";

    this.lastSnapshot = {
      x: this.chassisBody.position.x,
      y: this.chassisBody.position.y - this.bounds.chassisCenterY,
      z: this.chassisBody.position.z,
      vx: this.chassisBody.velocity.x,
      vy: this.chassisBody.velocity.y,
      vz: this.chassisBody.velocity.z,
      vLong: postVLong,
      vLat: postVLat,
      speedMs,
      speedKmh: speedMs * 3.6,
      yaw: postYaw,
      yawRate: blendedYawRate,
      steer: this.steerAngle,
      wheelSpin: this.wheelSpin,
      pitch: this.bodyPitch,
      roll: this.bodyRoll,
      isBraking: isBrakingVisual,
      isDrifting,
      onAsphalt,
      onShoulder,
      surface,
      numWheelsOnGround: this.vehicle.numWheelsOnGround,
    };

    return this.lastSnapshot;
  }

  /**
   * Resolves trackside wall/barrier contact directly on the cannon-es chassisBody
   * and returns outward impact speed for audio & camera shake feedback.
   */
  public resolveBarrierCollision(closest: ClosestTrackResult, barrierHalfWidth: number): number {
    const wallLimit = barrierHalfWidth - 1.25;
    if (closest.absLateral <= wallLimit) return 0;

    const sign = Math.sign(closest.signedLateral);
    const pen = closest.absLateral - wallLimit;
    this.chassisBody.position.x -= closest.sample.right.x * sign * pen;
    this.chassisBody.position.z -= closest.sample.right.z * sign * pen;

    const vOut =
      this.chassisBody.velocity.x * closest.sample.right.x * sign +
      this.chassisBody.velocity.z * closest.sample.right.z * sign;

    if (vOut > 0) {
      this.chassisBody.velocity.x -= closest.sample.right.x * sign * vOut * 1.25;
      this.chassisBody.velocity.z -= closest.sample.right.z * sign * vOut * 1.25;
      this.chassisBody.velocity.x *= 0.85;
      this.chassisBody.velocity.z *= 0.85;
      return vOut;
    }
    return 0;
  }

  /**
   * Separates and bounces the cannon-es rigid body against dynamic obstacles (rivals, pylons, teammates).
   */
  public applyBodyImpulseCorrection(
    offsetX: number,
    offsetZ: number,
    impulseVelX: number,
    impulseVelZ: number,
    velocityDamp = 1.0,
  ) {
    this.chassisBody.position.x += offsetX;
    this.chassisBody.position.z += offsetZ;
    this.chassisBody.velocity.x = this.chassisBody.velocity.x * velocityDamp + impulseVelX;
    this.chassisBody.velocity.z = this.chassisBody.velocity.z * velocityDamp + impulseVelZ;
  }

  /**
   * Synchronizes the cannon-es physics simulation state onto the loaded Three.js CarRig.
   */
  public syncToRig(rig: CarRig, closest: ClosestTrackResult) {
    const s = this.lastSnapshot;
    rig.group.position.set(s.x, s.y, s.z);
    rig.group.rotation.order = "YXZ";
    rig.group.rotation.y = s.yaw;
    rig.group.rotation.x =
      -closest.slopePitch *
      Math.cos(s.yaw - Math.atan2(closest.sample.tangent.x, closest.sample.tangent.z));
    rig.bodyPivot.rotation.x = s.pitch;
    rig.bodyPivot.rotation.z = s.roll;

    rig.flSteer.rotation.y = s.steer;
    rig.frSteer.rotation.y = s.steer;
    for (const w of rig.wheels) w.rotation.x = s.wheelSpin;
    for (const bm of rig.brakeMaterials) {
      bm.emissiveIntensity = s.isBraking ? 3.2 : 0.65;
    }
  }

  public getSnapshot(): CarPhysicsSnapshot {
    return this.lastSnapshot;
  }

  public dispose() {
    if (this.disposed) return;
    this.disposed = true;
    this.vehicle.removeFromWorld(this.world);
    this.world.removeBody(this.groundBody);
  }
}
