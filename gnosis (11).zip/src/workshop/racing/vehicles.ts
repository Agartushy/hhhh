import * as THREE from "three";
import { GLTFLoader, type GLTF } from "three/addons/loaders/GLTFLoader.js";
import { disposeSafeHierarchy } from "../assets/modelLoader";
import { MY_CARS, type MyCarEntry } from "./myCars";
import type { CarLiveryId, PaintFinishId, RimStyleId } from "./customization";

export type VehicleBodyStyle =
  | "sports"
  | "supercar"
  | "muscle"
  | "drift"
  | "rally"
  | "offroad"
  | "roadster"
  | "formula";

export interface VehicleSpec {
  id: string;
  name: string;
  category: string;
  bodyStyle: VehicleBodyStyle;
  tagline: string;
  bodyColor: number;
  accentColor: number;
  rimColor: number;
  // Real 120Hz physics parameters
  massKg: number;
  engineForceN: number;
  topSpeedMs: number;
  brakeForceN: number;
  reverseForceN: number;
  aeroDrag: number;
  maxSteerRad: number;
  steerSpeedReduction: number;
  steerDamp: number;
  turnAuthority: number;
  baseGrip: number;
  offTrackGrip: number;
  offTrackRollMult: number;
  handbrakeGripFactor: number;
  handbrakeYawBoost: number;
  wheelRadius: number;
  wheelWidth: number;
  rideHeight: number;
  // Display ratings (0-100) for UI cards
  ratings: {
    speed: number;
    accel: number;
    handling: number;
    grip: number;
    drift: number;
    weightKgLabel: string;
  };
}

export interface CarVisualOptions {
  useCustomColors?: boolean;
  paintHex?: string;
  accentHex?: string;
  rimHex?: string;
  finish?: PaintFinishId;
  livery?: CarLiveryId;
  rimStyle?: RimStyleId;
  raceNumber?: string;
  rideHeightOffset?: number;
}

export interface CarRig {
  group: THREE.Group;
  bodyPivot: THREE.Group;
  flSteer: THREE.Group;
  frSteer: THREE.Group;
  wheels: THREE.Object3D[];
  brakeMaterials: THREE.MeshStandardMaterial[];
  headlightGlows: THREE.MeshBasicMaterial[];
}

export const WORKSHOP_VEHICLES: readonly MyCarEntry[] = MY_CARS;

export const EXTERNAL_CAR_MODELS: Record<
  string,
  { url: string; fileName: string; slot: number }
> = Object.fromEntries(
  MY_CARS.map((car) => [
    car.id,
    { url: car.modelPath, fileName: car.fileName, slot: car.slot },
  ]),
);

export type VehicleGlbLoadResult =
  | { status: "ok"; gltf: GLTF; meshCount: number }
  | { status: "missing"; reason: string }
  | { status: "error"; reason: string };

/**
 * Checks whether the target .glb exists inside public/assets/models/my-cars/
 * (rejecting 404s and Vite's text/html SPA fallback) and loads it cleanly via GLTFLoader.
 */
export async function loadVehicleGlbAsset(url: string): Promise<VehicleGlbLoadResult> {
  try {
    const res = await fetch(url, { cache: "no-store" });
    if (!res.ok) {
      return {
        status: "missing",
        reason: `HTTP ${res.status} — Place the .glb file at public${url}`,
      };
    }

    const contentType = (res.headers.get("content-type") || "").toLowerCase();
    if (contentType.includes("text/html")) {
      return {
        status: "missing",
        reason: `File not found at public${url} (server returned HTML fallback).`,
      };
    }

    const buffer = await res.arrayBuffer();
    if (buffer.byteLength < 12) {
      return {
        status: "error",
        reason: `File at public${url} is empty or truncated (${buffer.byteLength} bytes).`,
      };
    }

    // Check GLB magic ("glTF") or JSON glTF start ("{") so HTML/plain error pages never pass
    const header = new DataView(buffer, 0, 4).getUint32(0, true);
    const firstByte = new Uint8Array(buffer, 0, 1)[0];
    const isGlbMagic = header === 0x46546c67;
    const isGltfJson = firstByte === 0x7b || firstByte === 0x20 || firstByte === 0x0a;
    if (!isGlbMagic && !isGltfJson) {
      return {
        status: "missing",
        reason: `File at public${url} is not a valid binary .glb or .gltf asset.`,
      };
    }

    const loader = new GLTFLoader();
    const baseDir = url.slice(0, url.lastIndexOf("/") + 1) || "/";
    const gltf = await loader.parseAsync(buffer, baseDir);
    if (!gltf.scene) {
      return {
        status: "error",
        reason: `GLB at public${url} parsed without a root scene.`,
      };
    }

    let meshCount = 0;
    gltf.scene.traverse((child) => {
      if ((child as THREE.Mesh).isMesh) {
        meshCount += 1;
      }
    });
    if (meshCount === 0) {
      disposeSafeHierarchy(gltf.scene);
      return {
        status: "error",
        reason: `GLB at public${url} contains zero renderable meshes.`,
      };
    }

    return { status: "ok", gltf, meshCount };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    return {
      status: "error",
      reason: `Failed to parse GLB at public${url}: ${msg}`,
    };
  }
}

/**
 * Computes a proportional scale that preserves original geometry and relative size.
 * Models already in standard meter scale (1.2m..8.5m) keep 1.0x proportions;
 * models exported in cm/mm or tiny unit scales are uniformly fitted without stretching.
 */
export function computeProportionalCarScale(box: THREE.Box3): number {
  const size = new THREE.Vector3();
  box.getSize(size);
  const maxDim = Math.max(size.x, size.y, size.z, 0.001);
  if (maxDim < 1.2 || maxDim > 8.5) {
    return 4.4 / maxDim;
  }
  return 1.0;
}

export interface LoadedVehicleModelInfo {
  root: THREE.Group;
  box: THREE.Box3;
  size: THREE.Vector3;
  scale: number;
}

export function buildVehicleRig(
  spec: VehicleSpec,
  custom?: CarVisualOptions,
  callbacks?: {
    onMissingAsset?: (url: string, reason: string) => void;
    onModelLoaded?: (info: LoadedVehicleModelInfo) => void;
  },
): CarRig {
  const group = new THREE.Group();
  const bodyPivot = new THREE.Group();
  bodyPivot.position.y = custom?.rideHeightOffset ?? 0;
  group.add(bodyPivot);

  const flSteer = new THREE.Group();
  const frSteer = new THREE.Group();
  group.add(flSteer, frSteer);

  // Subtle floor contact shadow disc beneath the chassis
  const sCanvas = document.createElement("canvas");
  sCanvas.width = 128;
  sCanvas.height = 128;
  const sCtx = sCanvas.getContext("2d")!;
  const rad = sCtx.createRadialGradient(64, 64, 12, 64, 64, 62);
  rad.addColorStop(0, "rgba(0,0,0,0.62)");
  rad.addColorStop(0.65, "rgba(0,0,0,0.28)");
  rad.addColorStop(1, "rgba(0,0,0,0)");
  sCtx.fillStyle = rad;
  sCtx.fillRect(0, 0, 128, 128);
  const shadowTex = new THREE.CanvasTexture(sCanvas);
  const shadowGeo = new THREE.PlaneGeometry(2.8, 5.1);
  shadowGeo.rotateX(-Math.PI / 2);
  const shadowMat = new THREE.MeshBasicMaterial({
    map: shadowTex,
    transparent: true,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const shadowQuad = new THREE.Mesh(shadowGeo, shadowMat);
  shadowQuad.position.y = 0.025;
  group.add(shadowQuad);

  const wheelsList: THREE.Object3D[] = [];
  const extCar = EXTERNAL_CAR_MODELS[spec.id];

  if (extCar) {
    loadVehicleGlbAsset(extCar.url).then((result) => {
      if (result.status !== "ok") {
        console.error(`[GNOSIS Racing] ${result.reason}`);
        callbacks?.onMissingAsset?.(extCar.url, result.reason);
        return;
      }

      const root = result.gltf.scene;
      if (group.userData.disposed) {
        disposeSafeHierarchy(root);
        return;
      }

      root.traverse((child) => {
        if ((child as THREE.Mesh).isMesh) {
          child.castShadow = true;
          child.receiveShadow = true;
        }
      });

      root.updateMatrixWorld(true);
      const box = new THREE.Box3().setFromObject(root);
      const center = new THREE.Vector3();
      box.getCenter(center);

      const scale = computeProportionalCarScale(box);
      root.scale.setScalar(scale);
      root.position.set(
        -center.x * scale,
        -box.min.y * scale,
        -center.z * scale,
      );

      // Attach intact wheel nodes in-place if the GLB uses named wheel nodes
      const intactWheels: THREE.Object3D[] = [];
      root.traverse((obj) => {
        const n = obj.name.toLowerCase();
        if (
          n.includes("wheel") &&
          (n.includes("front") || n.includes("back") || n.includes("rear") || n.includes("fl") || n.includes("fr"))
        ) {
          intactWheels.push(obj);
        }
      });
      if (intactWheels.length > 0) {
        wheelsList.push(...intactWheels);
      }

      bodyPivot.add(root);
      root.updateMatrixWorld(true);
      const fittedBox = new THREE.Box3().setFromObject(root);
      const fittedSize = new THREE.Vector3();
      fittedBox.getSize(fittedSize);
      callbacks?.onModelLoaded?.({ root, box: fittedBox, size: fittedSize, scale });
    });
  } else {
    callbacks?.onMissingAsset?.(spec.id, `No GLB path configured for ${spec.id}`);
  }

  return {
    group,
    bodyPivot,
    flSteer,
    frSteer,
    wheels: wheelsList,
    brakeMaterials: [],
    headlightGlows: [],
  };
}
