import * as THREE from "three";
import { disposeSafeHierarchy, loadExternalModel } from "../assets/modelLoader";
import type { RacingTrackId } from "./customization";

export interface TrackSample {
  pos: THREE.Vector3;
  tangent: THREE.Vector3;
  right: THREE.Vector3;
  s: number;
  curvature: number;
}

export interface ClosestTrackResult {
  index: number;
  sample: TrackSample;
  signedLateral: number;
  absLateral: number;
  elevation: number;
  slopePitch: number;
}

export interface CollidablePylon {
  x: number;
  z: number;
  baseY: number;
  mesh: THREE.Object3D;
  radius: number;
  hitCooldown: number;
}

export interface TrackWorldBundle {
  trackId: RacingTrackId;
  curve: THREE.CatmullRomCurve3;
  samples: TrackSample[];
  totalLength: number;
  roadHalfWidth: number;
  barrierHalfWidth: number;
  pylons: CollidablePylon[];
  getTerrainHeight: (x: number, z: number) => number;
  dispose: () => void;
}

export interface RacingTrackDef {
  id: RacingTrackId;
  name: string;
  subtitle: string;
  lengthLabel: string;
  surfaceLabel: string;
  difficulty: "CLUB" | "PRO" | "ELITE" | "RAID";
  skyTopHex: string;
  skyMidHex: string;
  skyBottomHex: string;
  fogHex: number;
  fogDensity: number;
  sunHex: number;
  sunIntensity: number;
  hemiSkyHex: number;
  hemiGroundHex: number;
  groundColorHex: string;
  groundAccentHex: string;
  kerbColorA: string;
  kerbColorB: string;
  bannerText: string;
  roadHalfWidth: number;
  barrierHalfWidth: number;
  svgPath: string;
}

export const TRACK_CATALOG: RacingTrackDef[] = [
  {
    id: "alpine-grand",
    name: "Alpine Grand Circuit",
    subtitle: "High-speed mountain straight, ridge viaduct, S-bend canyon & lakeside hairpin.",
    lengthLabel: "2.48 KM",
    surfaceLabel: "Swiss Asphalt · 24m",
    difficulty: "CLUB",
    skyTopHex: "#1f354e",
    skyMidHex: "#61819c",
    skyBottomHex: "#dfd3b8",
    fogHex: 0xc8bfa8,
    fogDensity: 0.00135,
    sunHex: 0xfff1d6,
    sunIntensity: 1.9,
    hemiSkyHex: 0xd9e8f5,
    hemiGroundHex: 0x4d3f2c,
    groundColorHex: "#354a2c",
    groundAccentHex: "#4b6238",
    kerbColorA: "#c0372b",
    kerbColorB: "#ece3d3",
    bannerText: "GNOSIS ALPINE CIRCUIT",
    roadHalfWidth: 12.0,
    barrierHalfWidth: 17.5,
    svgPath: "M24 95 L24 38 Q30 14 68 18 L112 34 Q138 44 128 66 L104 72 L130 96 L88 108 L64 78 L42 104 Z",
  },
  {
    id: "coastal-highway",
    name: "Riviera Bay Highway",
    subtitle: "Oceanfront boulevard with twin bay viaduct bridges, wide drift carousels & marina chicanes.",
    lengthLabel: "2.76 KM",
    surfaceLabel: "Coastal Tarmac · 25m",
    difficulty: "PRO",
    skyTopHex: "#134770",
    skyMidHex: "#4a9ec7",
    skyBottomHex: "#f0dec0",
    fogHex: 0xd6d2c4,
    fogDensity: 0.0011,
    sunHex: 0xfff5dc,
    sunIntensity: 2.1,
    hemiSkyHex: 0xcfe8ff,
    hemiGroundHex: 0x73634a,
    groundColorHex: "#8d7c59",
    groundAccentHex: "#557a3c",
    kerbColorA: "#1b78b8",
    kerbColorB: "#f2ece1",
    bannerText: "RIVIERA BAY GRAND PRIX",
    roadHalfWidth: 12.5,
    barrierHalfWidth: 18.0,
    svgPath: "M22 86 L34 26 Q88 10 132 32 L120 56 L142 84 Q122 110 76 96 L52 72 L30 108 Z",
  },
  {
    id: "neon-metropolis",
    name: "Neo-Veritas Night GP",
    subtitle: "Floodlit street intersections, skyscraper canyon straights & 12m elevated expressway flyover.",
    lengthLabel: "2.62 KM",
    surfaceLabel: "Midnight Wet Asphalt · 22m",
    difficulty: "ELITE",
    skyTopHex: "#060812",
    skyMidHex: "#111833",
    skyBottomHex: "#2a2042",
    fogHex: 0x161a2e,
    fogDensity: 0.00165,
    sunHex: 0xaec8ff,
    sunIntensity: 1.35,
    hemiSkyHex: 0x4b6299,
    hemiGroundHex: 0x1d1c29,
    groundColorHex: "#1d2028",
    groundAccentHex: "#292d38",
    kerbColorA: "#24d8f2",
    kerbColorB: "#d9b252",
    bannerText: "NEO-VERITAS NIGHT GP",
    roadHalfWidth: 11.4,
    barrierHalfWidth: 16.5,
    svgPath: "M26 98 L26 24 L82 24 L82 48 L130 48 L130 88 L92 104 L62 80 L62 108 Z",
  },
  {
    id: "canyon-industrial",
    name: "Redstone Refinery Raid",
    subtitle: "Industrial pipeline bridges, desert mesa switchbacks, gravel shoulders & oil-tank chicanes.",
    lengthLabel: "2.55 KM",
    surfaceLabel: "Mixed Tarmac & Dirt · 26m",
    difficulty: "RAID",
    skyTopHex: "#3a251c",
    skyMidHex: "#a85d38",
    skyBottomHex: "#ebc18a",
    fogHex: 0xd4a477,
    fogDensity: 0.0014,
    sunHex: 0xffd59e,
    sunIntensity: 2.05,
    hemiSkyHex: 0xf7cfa0,
    hemiGroundHex: 0x5c3621,
    groundColorHex: "#8c5334",
    groundAccentHex: "#6e422b",
    kerbColorA: "#d97a26",
    kerbColorB: "#262320",
    bannerText: "REDSTONE REFINERY RAID",
    roadHalfWidth: 13.0,
    barrierHalfWidth: 18.8,
    svgPath: "M28 96 L20 34 Q52 12 94 28 L134 18 L140 62 L98 68 L128 98 L72 108 L48 86 Z",
  },
];

export function getTrackDef(trackId: RacingTrackId): RacingTrackDef {
  return TRACK_CATALOG.find((t) => t.id === trackId) || TRACK_CATALOG[0];
}

export function createTrackCircuitCurve(
  trackId: RacingTrackId = "alpine-grand",
): THREE.CatmullRomCurve3 {
  if (trackId === "coastal-highway") {
    const points = [
      new THREE.Vector3(-140, 0.5, 195),   // Marina Pit Straight Start
      new THREE.Vector3(-140, 0.5, -75),   // Long Oceanfront DRS Straight
      new THREE.Vector3(-75, 4.5, -210),   // Bay Bridge West Ramp
      new THREE.Vector3(70, 9.2, -260),    // High Bay Viaduct Deck
      new THREE.Vector3(235, 6.0, -230),   // Lighthouse Descent
      new THREE.Vector3(365, 2.2, -135),   // Palm Cove Sweeper
      new THREE.Vector3(345, 1.5, 25),     // Harbor S-Curve Right
      new THREE.Vector3(245, 2.5, 90),     // Harbor S-Curve Left
      new THREE.Vector3(315, 1.8, 225),    // Drift Peninsula Loop
      new THREE.Vector3(195, 1.0, 315),    // Yacht Club Hairpin
      new THREE.Vector3(65, 1.2, 235),     // Coastal Chicane Entry
      new THREE.Vector3(-35, 0.8, 275),    // Final Harbor Bend
    ];
    return new THREE.CatmullRomCurve3(points, true, "catmullrom", 0.5);
  }

  if (trackId === "neon-metropolis") {
    const points = [
      new THREE.Vector3(-155, 0.4, 210),   // Downtown Grid Start
      new THREE.Vector3(-155, 0.4, -145),  // Metro Expressway North Straight
      new THREE.Vector3(-125, 0.4, -225),  // Tower Plaza 90° Right
      new THREE.Vector3(35, 0.4, -225),    // Crosstown Boulevard
      new THREE.Vector3(75, 4.8, -145),    // Cloverleaf Flyover Climb
      new THREE.Vector3(155, 10.6, -125),  // Elevated Expressway Bridge
      new THREE.Vector3(285, 8.2, -125),   // Skybridge Crossing
      new THREE.Vector3(335, 2.4, -10),    // Neon District Spiral Descent
      new THREE.Vector3(315, 0.6, 170),    // Cyber Market Chicane
      new THREE.Vector3(195, 0.5, 255),    // Financial Loop
      new THREE.Vector3(75, 0.5, 155),     // Downtown Intersection Switchback
      new THREE.Vector3(-25, 0.5, 255),    // Final Grand Turn
    ];
    return new THREE.CatmullRomCurve3(points, true, "catmullrom", 0.42);
  }

  if (trackId === "canyon-industrial") {
    const points = [
      new THREE.Vector3(-135, 0.4, 220),   // Refinery Freight Straight Start
      new THREE.Vector3(-155, 0.6, -55),   // Pipeline Straight
      new THREE.Vector3(-115, 3.8, -210),  // Red Mesa Climb
      new THREE.Vector3(10, 8.6, -265),    // Pipeline Overpass Bridge
      new THREE.Vector3(165, 9.8, -215),   // Ridge Quarry Turn
      new THREE.Vector3(325, 6.2, -255),   // Canyon Hairpin Apex
      new THREE.Vector3(365, 3.0, -75),    // Fast Arroyo Sweeper
      new THREE.Vector3(215, 1.8, 35),     // Oil Silo Chicane Left
      new THREE.Vector3(310, 2.2, 165),    // Tank Farm Right
      new THREE.Vector3(225, 1.2, 290),    // Copper Gulch Bend
      new THREE.Vector3(65, 1.0, 295),     // Yard Exit Sweeper
      new THREE.Vector3(-40, 0.6, 250),    // Final Pit Approach
    ];
    return new THREE.CatmullRomCurve3(points, true, "catmullrom", 0.5);
  }

  // Default: alpine-grand
  const points = [
    new THREE.Vector3(-120, 0.3, 210),
    new THREE.Vector3(-120, 0.3, -45),
    new THREE.Vector3(-85, 2.2, -190),
    new THREE.Vector3(35, 5.8, -265),
    new THREE.Vector3(195, 10.5, -245),
    new THREE.Vector3(315, 12.2, -155),
    new THREE.Vector3(345, 7.6, -20),
    new THREE.Vector3(245, 4.8, 55),
    new THREE.Vector3(325, 2.2, 165),
    new THREE.Vector3(260, 0.9, 285),
    new THREE.Vector3(125, 0.5, 295),
    new THREE.Vector3(55, 0.8, 175),
    new THREE.Vector3(-25, 0.6, 265),
  ];
  return new THREE.CatmullRomCurve3(points, true, "catmullrom", 0.5);
}

export function sampleTrackCurve(
  curve: THREE.CatmullRomCurve3,
  count = 720,
): { samples: TrackSample[]; totalLength: number } {
  const up = new THREE.Vector3(0, 1, 0);
  const rawPts: THREE.Vector3[] = [];
  for (let i = 0; i < count; i++) {
    rawPts.push(curve.getPointAt(i / count));
  }

  const samples: TrackSample[] = [];
  let s = 0;
  for (let i = 0; i < count; i++) {
    const prev = rawPts[(i - 1 + count) % count];
    const curr = rawPts[i];
    const next = rawPts[(i + 1) % count];
    if (i > 0) s += curr.distanceTo(prev);

    const tangent = new THREE.Vector3().subVectors(next, prev).normalize();
    const right = new THREE.Vector3().crossVectors(tangent, up).normalize();

    const t1 = new THREE.Vector3().subVectors(curr, prev).normalize();
    const t2 = new THREE.Vector3().subVectors(next, curr).normalize();
    const curvature = t1.angleTo(t2);

    samples.push({ pos: curr, tangent, right, s, curvature });
  }
  const totalLength = s + rawPts[0].distanceTo(rawPts[count - 1]);
  return { samples, totalLength };
}

export function findClosestTrackPoint(
  samples: TrackSample[],
  x: number,
  z: number,
  hintIndex?: number,
): ClosestTrackResult {
  const n = samples.length;
  let bestIdx = 0;
  let bestDistSq = Infinity;

  if (hintIndex !== undefined && hintIndex >= 0 && hintIndex < n) {
    for (let offset = -48; offset <= 48; offset++) {
      const idx = (hintIndex + offset + n) % n;
      const p = samples[idx].pos;
      const dx = x - p.x;
      const dz = z - p.z;
      const dSq = dx * dx + dz * dz;
      if (dSq < bestDistSq) {
        bestDistSq = dSq;
        bestIdx = idx;
      }
    }
  }

  if (bestDistSq > 1600) {
    bestDistSq = Infinity;
    for (let idx = 0; idx < n; idx++) {
      const p = samples[idx].pos;
      const dx = x - p.x;
      const dz = z - p.z;
      const dSq = dx * dx + dz * dz;
      if (dSq < bestDistSq) {
        bestDistSq = dSq;
        bestIdx = idx;
      }
    }
  }

  const sample = samples[bestIdx];
  const dx = x - sample.pos.x;
  const dz = z - sample.pos.z;
  const signedLateral = dx * sample.right.x + dz * sample.right.z;
  const slopePitch = Math.asin(THREE.MathUtils.clamp(sample.tangent.y, -0.5, 0.5));

  return {
    index: bestIdx,
    sample,
    signedLateral,
    absLateral: Math.abs(signedLateral),
    elevation: sample.pos.y,
    slopePitch,
  };
}

function createAsphaltTexture(
  maxAnisotropy: number,
  isNight: boolean,
  isDesert: boolean,
): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext("2d")!;

  ctx.fillStyle = isNight ? "#1a1d24" : isDesert ? "#302b27" : "#26282c";
  ctx.fillRect(0, 0, 512, 512);

  for (let i = 0; i < 7500; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const v = (isNight ? 18 : 28) + Math.floor(Math.random() * 28);
    ctx.fillStyle = isDesert ? `rgb(${v + 8},${v + 2},${v - 2})` : `rgb(${v},${v + 1},${v + 3})`;
    ctx.fillRect(x, y, 2, 2);
  }

  const grad = ctx.createLinearGradient(0, 0, 512, 0);
  grad.addColorStop(0, "rgba(0,0,0,0)");
  grad.addColorStop(0.24, "rgba(12,12,14,0.22)");
  grad.addColorStop(0.5, "rgba(18,18,20,0.06)");
  grad.addColorStop(0.76, "rgba(12,12,14,0.22)");
  grad.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 512, 512);

  ctx.fillStyle = isNight ? "#48e2ff" : "#ede6d6";
  ctx.fillRect(14, 0, 12, 512);
  ctx.fillRect(486, 0, 12, 512);

  ctx.fillStyle = isNight ? "#f0b94a" : "#d9b36c";
  for (let y = 16; y < 512; y += 96) {
    ctx.fillRect(252, y, 8, 52);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createKerbTexture(
  maxAnisotropy: number,
  colA: string,
  colB: string,
): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 128;
  canvas.height = 256;
  const ctx = canvas.getContext("2d")!;
  ctx.fillStyle = colA;
  ctx.fillRect(0, 0, 128, 128);
  ctx.fillStyle = colB;
  ctx.fillRect(0, 128, 128, 128);
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createTerrainTexture(
  maxAnisotropy: number,
  baseHex: string,
  accentHex: string,
  isUrban: boolean,
): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext("2d")!;

  ctx.fillStyle = baseHex;
  ctx.fillRect(0, 0, 512, 512);

  if (isUrban) {
    ctx.strokeStyle = accentHex;
    ctx.lineWidth = 4;
    for (let i = 0; i <= 512; i += 64) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, 512);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(512, i);
      ctx.stroke();
    }
  } else {
    ctx.fillStyle = accentHex;
    for (let i = 0; i < 6200; i++) {
      const x = Math.random() * 512;
      const y = Math.random() * 512;
      ctx.fillRect(x, y, 3, 3);
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(58, 58);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createCheckeredBannerTexture(
  maxAnisotropy: number,
  bannerText: string,
): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 128;
  const ctx = canvas.getContext("2d")!;
  ctx.fillStyle = "#18130e";
  ctx.fillRect(0, 0, 512, 128);

  const cell = 16;
  for (let r = 0; r < 2; r++) {
    for (let c = 0; c < 32; c++) {
      ctx.fillStyle = (r + c) % 2 === 0 ? "#f4ebdd" : "#18130e";
      ctx.fillRect(c * cell, r * cell, cell, cell);
      ctx.fillRect(c * cell, 96 + r * cell, cell, cell);
    }
  }
  ctx.fillStyle = "#d1b273";
  ctx.font = "bold 31px Georgia, serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(bannerText, 256, 65);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function buildRibbonGeometry(
  samples: TrackSample[],
  innerOffset: number,
  outerOffset: number,
  yOffset: number,
  uvTileLength: number,
): THREE.BufferGeometry {
  const n = samples.length;
  const positions: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  for (let i = 0; i <= n; i++) {
    const sample = samples[i % n];
    const vCoord = (i === n ? samples[n - 1].s + 3.4 : sample.s) / uvTileLength;
    const pInner = sample.pos.clone().addScaledVector(sample.right, innerOffset);
    const pOuter = sample.pos.clone().addScaledVector(sample.right, outerOffset);

    positions.push(pInner.x, pInner.y + yOffset, pInner.z);
    positions.push(pOuter.x, pOuter.y + yOffset, pOuter.z);
    uvs.push(0, vCoord, 1, vCoord);
  }

  for (let i = 0; i < n; i++) {
    const a = i * 2;
    const b = i * 2 + 1;
    const c = (i + 1) * 2;
    const d = (i + 1) * 2 + 1;
    indices.push(a, b, c);
    indices.push(b, d, c);
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

export function buildTrackWorld(
  scene: THREE.Scene,
  maxAnisotropy: number,
  trackId: RacingTrackId = "alpine-grand",
): TrackWorldBundle {
  const def = getTrackDef(trackId);
  const curve = createTrackCircuitCurve(trackId);
  const { samples, totalLength } = sampleTrackCurve(curve, 720);

  const roadHalfWidth = def.roadHalfWidth;
  const kerbWidth = 1.45;
  const barrierHalfWidth = def.barrierHalfWidth;

  const disposableGeos: THREE.BufferGeometry[] = [];
  const disposableMats: THREE.Material[] = [];
  const disposableTexs: THREE.Texture[] = [];
  const asyncGroups: THREE.Object3D[] = [];
  let worldDisposed = false;

  const placeExternalTrackProp = (
    url: string,
    targetSize: number,
    x: number,
    y: number,
    z: number,
    rotY = 0,
    onLoaded?: (grp: THREE.Group) => void,
  ) => {
    loadExternalModel(url, { targetSize, groundAtZero: true })
      .then((grp) => {
        if (!grp) return;
        if (worldDisposed) {
          disposeSafeHierarchy(grp);
          return;
        }
        grp.position.set(x, y, z);
        grp.rotation.y = rotY;
        scene.add(grp);
        asyncGroups.push(grp);
        onLoaded?.(grp);
      })
      .catch(() => {
        // Procedural track geometry remains active as fallback
      });
  };

  const isNight = trackId === "neon-metropolis";
  const isDesert = trackId === "canyon-industrial";
  const isCoastal = trackId === "coastal-highway";

  const asphaltTex = createAsphaltTexture(maxAnisotropy, isNight, isDesert);
  const kerbTex = createKerbTexture(maxAnisotropy, def.kerbColorA, def.kerbColorB);
  const terrainTex = createTerrainTexture(
    maxAnisotropy,
    def.groundColorHex,
    def.groundAccentHex,
    isNight,
  );
  const gantryTex = createCheckeredBannerTexture(maxAnisotropy, def.bannerText);
  disposableTexs.push(asphaltTex, kerbTex, terrainTex, gantryTex);

  const getTerrainHeight = (x: number, z: number): number => {
    const closest = findClosestTrackPoint(samples, x, z);
    const roadBlend = THREE.MathUtils.smoothstep(closest.absLateral, 18, 48);
    const radialDist = Math.hypot(x - 105, z - 20);
    if (isNight) {
      return THREE.MathUtils.lerp(closest.elevation - 0.14, -0.25, roadBlend);
    }
    if (isCoastal) {
      const bayDip = Math.hypot(x - 135, z + 35) < 155 ? -1.9 : 0;
      const hillLift = THREE.MathUtils.smoothstep(radialDist, 360, 560) * 24;
      const coastalHeight =
        Math.sin(x * 0.012) * Math.cos(z * 0.012) * 5.2 + hillLift + bayDip - 0.8;
      return THREE.MathUtils.lerp(closest.elevation - 0.14, coastalHeight, roadBlend);
    }
    const rimLift = THREE.MathUtils.smoothstep(radialDist, 370, 580) * (isDesert ? 38 : 32);
    const outerHill =
      Math.sin(x * 0.015) * Math.cos(z * 0.014) * (isDesert ? 14 : 11.5) +
      Math.sin((x + z) * 0.008) * 6.5 -
      1.6 +
      rimLift;
    return THREE.MathUtils.lerp(closest.elevation - 0.14, Math.max(-1.8, outerHill), roadBlend);
  };

  // Terrain Mesh
  const terrainGeo = new THREE.PlaneGeometry(1400, 1400, 130, 130);
  terrainGeo.rotateX(-Math.PI / 2);
  const tPos = terrainGeo.attributes.position;
  for (let i = 0; i < tPos.count; i++) {
    const vx = tPos.getX(i) + 105;
    const vz = tPos.getZ(i) + 15;
    tPos.setX(i, vx);
    tPos.setZ(i, vz);
    tPos.setY(i, getTerrainHeight(vx, vz));
  }
  terrainGeo.computeVertexNormals();
  const terrainMat = new THREE.MeshStandardMaterial({
    map: terrainTex,
    roughness: isNight ? 0.65 : 0.94,
    metalness: isNight ? 0.18 : 0.02,
  });
  const terrainMesh = new THREE.Mesh(terrainGeo, terrainMat);
  terrainMesh.receiveShadow = true;
  scene.add(terrainMesh);
  disposableGeos.push(terrainGeo);
  disposableMats.push(terrainMat);

  // Water body (Alpine lake OR Coastal Bay)
  if (trackId === "alpine-grand" || isCoastal) {
    const lakeGeo = new THREE.CircleGeometry(isCoastal ? 195 : 132, 48);
    lakeGeo.rotateX(-Math.PI / 2);
    const lakeMat = new THREE.MeshStandardMaterial({
      color: isCoastal ? 0x166882 : 0x1b4254,
      roughness: 0.12,
      metalness: 0.78,
    });
    const lakeMesh = new THREE.Mesh(lakeGeo, lakeMat);
    lakeMesh.position.set(135, isCoastal ? -0.95 : -0.65, -25);
    scene.add(lakeMesh);
    disposableGeos.push(lakeGeo);
    disposableMats.push(lakeMat);
  }

  // Asphalt Road Ribbon
  const roadGeo = buildRibbonGeometry(samples, -roadHalfWidth, roadHalfWidth, 0.02, 20);
  const roadMat = new THREE.MeshStandardMaterial({
    map: asphaltTex,
    roughness: isNight ? 0.42 : 0.78,
    metalness: isNight ? 0.22 : 0.06,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const roadMesh = new THREE.Mesh(roadGeo, roadMat);
  roadMesh.receiveShadow = true;
  scene.add(roadMesh);
  disposableGeos.push(roadGeo);
  disposableMats.push(roadMat);

  // Bridge Underside Slab & Concrete Viaduct Piers along elevated sections
  const deckGeo = buildRibbonGeometry(samples, -barrierHalfWidth + 0.5, barrierHalfWidth - 0.5, -0.55, 24);
  const deckMat = new THREE.MeshStandardMaterial({
    color: 0x3b3835,
    roughness: 0.85,
    metalness: 0.15,
    side: THREE.DoubleSide,
  });
  scene.add(new THREE.Mesh(deckGeo, deckMat));
  disposableGeos.push(deckGeo);
  disposableMats.push(deckMat);

  const pierGeo = new THREE.BoxGeometry(2.6, 1.0, 2.6);
  const pierMat = new THREE.MeshStandardMaterial({ color: 0x484542, roughness: 0.88 });
  disposableGeos.push(pierGeo);
  disposableMats.push(pierMat);
  for (let i = 0; i < samples.length; i += 14) {
    const s = samples[i];
    if (s.pos.y > 2.4) {
      const pierH = s.pos.y + 3.0;
      for (const side of [-1, 1]) {
        const pier = new THREE.Mesh(pierGeo, pierMat);
        pier.scale.set(1, pierH, 1);
        pier.position.set(
          s.pos.x + s.right.x * side * (roadHalfWidth * 0.72),
          s.pos.y - pierH * 0.5 - 0.4,
          s.pos.z + s.right.z * side * (roadHalfWidth * 0.72),
        );
        pier.castShadow = true;
        scene.add(pier);
      }
    }
  }

  // Branching Pit Lane / Side Street Connector Aprons along Main Straight
  const pitApronGeo = new THREE.PlaneGeometry(14, 155);
  pitApronGeo.rotateX(-Math.PI / 2);
  const pitApronMat = new THREE.MeshStandardMaterial({
    color: 0x22252b,
    roughness: 0.8,
    metalness: 0.08,
  });
  const pitPos = samples[Math.floor(samples.length * 0.96)];
  const pitApron = new THREE.Mesh(pitApronGeo, pitApronMat);
  pitApron.position.set(
    pitPos.pos.x - pitPos.right.x * (roadHalfWidth + 6.5),
    pitPos.pos.y + 0.015,
    pitPos.pos.z - pitPos.right.z * (roadHalfWidth + 6.5),
  );
  pitApron.rotation.y = Math.atan2(pitPos.tangent.x, pitPos.tangent.z);
  scene.add(pitApron);
  disposableGeos.push(pitApronGeo);
  disposableMats.push(pitApronMat);

  // Rumble Kerbs
  const kerbMat = new THREE.MeshStandardMaterial({
    map: kerbTex,
    roughness: 0.65,
    metalness: 0.05,
    polygonOffset: true,
    polygonOffsetFactor: -2,
    polygonOffsetUnits: -2,
  });
  const leftKerbGeo = buildRibbonGeometry(
    samples,
    -roadHalfWidth - kerbWidth,
    -roadHalfWidth,
    0.045,
    7,
  );
  const rightKerbGeo = buildRibbonGeometry(
    samples,
    roadHalfWidth,
    roadHalfWidth + kerbWidth,
    0.045,
    7,
  );
  const leftKerb = new THREE.Mesh(leftKerbGeo, kerbMat);
  const rightKerb = new THREE.Mesh(rightKerbGeo, kerbMat);
  leftKerb.receiveShadow = true;
  rightKerb.receiveShadow = true;
  scene.add(leftKerb, rightKerb);
  disposableGeos.push(leftKerbGeo, rightKerbGeo);
  disposableMats.push(kerbMat);

  // Runoff Shoulders
  const shoulderMat = new THREE.MeshStandardMaterial({
    color: isDesert ? 0x6b472f : isNight ? 0x252834 : 0x3b3833,
    roughness: 0.92,
    metalness: 0.04,
  });
  const leftRunoffGeo = buildRibbonGeometry(
    samples,
    -barrierHalfWidth,
    -roadHalfWidth - kerbWidth,
    0.01,
    12,
  );
  const rightRunoffGeo = buildRibbonGeometry(
    samples,
    roadHalfWidth + kerbWidth,
    barrierHalfWidth,
    0.01,
    12,
  );
  scene.add(new THREE.Mesh(leftRunoffGeo, shoulderMat), new THREE.Mesh(rightRunoffGeo, shoulderMat));
  disposableGeos.push(leftRunoffGeo, rightRunoffGeo);
  disposableMats.push(shoulderMat);

  // Guardrails & Posts
  const railMat = new THREE.MeshStandardMaterial({
    color: isNight ? 0x6783a6 : 0xb6bec4,
    metalness: 0.72,
    roughness: 0.34,
  });
  const railPostMat = new THREE.MeshStandardMaterial({
    color: 0x45494e,
    metalness: 0.6,
    roughness: 0.5,
  });
  const buildRailWall = (offset: number) => {
    const n = samples.length;
    const pos: number[] = [];
    const idx: number[] = [];
    for (let i = 0; i <= n; i++) {
      const s = samples[i % n];
      const p = s.pos.clone().addScaledVector(s.right, offset);
      pos.push(p.x, p.y + 0.35, p.z);
      pos.push(p.x, p.y + 0.95, p.z);
    }
    for (let i = 0; i < n; i++) {
      const a = i * 2;
      const b = i * 2 + 1;
      const c = (i + 1) * 2;
      const d = (i + 1) * 2 + 1;
      idx.push(a, c, b, b, c, d, a, b, c, b, d, c);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    geo.setIndex(idx);
    geo.computeVertexNormals();
    const mesh = new THREE.Mesh(geo, railMat);
    mesh.castShadow = true;
    scene.add(mesh);
    disposableGeos.push(geo);
  };
  buildRailWall(-barrierHalfWidth);
  buildRailWall(barrierHalfWidth);

  const postGeo = new THREE.BoxGeometry(0.22, 1.0, 0.22);
  const postStep = 8;
  const postCount = Math.floor(samples.length / postStep) * 2;
  const postInstanced = new THREE.InstancedMesh(postGeo, railPostMat, postCount);
  const dummy = new THREE.Object3D();
  let pIdx = 0;
  for (let i = 0; i < samples.length && pIdx + 1 < postCount; i += postStep) {
    const s = samples[i];
    for (const side of [-1, 1]) {
      const px = s.pos.x + s.right.x * side * (barrierHalfWidth + 0.16);
      const pz = s.pos.z + s.right.z * side * (barrierHalfWidth + 0.16);
      dummy.position.set(px, s.pos.y + 0.48, pz);
      dummy.rotation.set(0, Math.atan2(s.tangent.x, s.tangent.z), 0);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      postInstanced.setMatrixAt(pIdx++, dummy.matrix);
    }
  }
  postInstanced.count = pIdx;
  postInstanced.instanceMatrix.needsUpdate = true;
  postInstanced.computeBoundingSphere();
  scene.add(postInstanced);
  disposableGeos.push(postGeo);
  disposableMats.push(railMat, railPostMat);

  // Start / Finish Overhead Gantry
  const startSample = samples[0];
  const gantryGroup = new THREE.Group();
  gantryGroup.position.copy(startSample.pos);
  gantryGroup.rotation.y = Math.atan2(startSample.tangent.x, startSample.tangent.z);

  const gantrySteelMat = new THREE.MeshStandardMaterial({
    color: 0x2c241d,
    metalness: 0.78,
    roughness: 0.3,
  });
  const gantryBannerMat = new THREE.MeshStandardMaterial({
    map: gantryTex,
    roughness: 0.45,
    metalness: 0.15,
    emissive: isNight ? new THREE.Color(0x28385a) : new THREE.Color(0x000000),
    emissiveIntensity: isNight ? 0.45 : 0,
  });
  const pillarGeo = new THREE.BoxGeometry(0.85, 7.6, 0.85);
  const pLeft = new THREE.Mesh(pillarGeo, gantrySteelMat);
  pLeft.position.set(-roadHalfWidth - 2.2, 3.8, 0);
  pLeft.castShadow = true;
  const pRight = new THREE.Mesh(pillarGeo, gantrySteelMat);
  pRight.position.set(roadHalfWidth + 2.2, 3.8, 0);
  pRight.castShadow = true;

  const crossGeo = new THREE.BoxGeometry(roadHalfWidth * 2 + 5.2, 2.1, 0.9);
  const crossBeam = new THREE.Mesh(crossGeo, gantryBannerMat);
  crossBeam.position.set(0, 6.6, 0);
  crossBeam.castShadow = true;

  const startStripGeo = new THREE.PlaneGeometry(roadHalfWidth * 2, 2.6);
  startStripGeo.rotateX(-Math.PI / 2);
  const startStrip = new THREE.Mesh(startStripGeo, gantryBannerMat);
  startStrip.position.set(0, 0.05, 0);
  gantryGroup.add(pLeft, pRight, crossBeam, startStrip);
  scene.add(gantryGroup);
  disposableGeos.push(pillarGeo, crossGeo, startStripGeo);
  disposableMats.push(gantrySteelMat, gantryBannerMat);

  // Grandstand Paddock Complex + Timing Tower along main straight
  const standGroup = new THREE.Group();
  const standBasePos = samples[Math.floor(samples.length * 0.94)].pos;
  standGroup.position.set(standBasePos.x - 28, standBasePos.y, standBasePos.z);
  const concreteMat = new THREE.MeshStandardMaterial({ color: 0x3b352f, roughness: 0.85 });
  const brassTrimMat = new THREE.MeshStandardMaterial({
    color: isNight ? 0x35d6f5 : 0xb08d57,
    metalness: 0.75,
    roughness: 0.3,
    emissive: isNight ? new THREE.Color(0x1b6680) : new THREE.Color(0x000000),
    emissiveIntensity: isNight ? 0.6 : 0,
  });
  const roofMat = new THREE.MeshStandardMaterial({ color: 0x201914, roughness: 0.6 });

  const baseDeckGeo = new THREE.BoxGeometry(11, 4.2, 56);
  const tier1 = new THREE.Mesh(baseDeckGeo, concreteMat);
  tier1.position.set(0, 2.1, 0);
  tier1.castShadow = true;
  tier1.receiveShadow = true;
  const roofGeo = new THREE.BoxGeometry(13, 0.55, 58);
  const roof = new THREE.Mesh(roofGeo, roofMat);
  roof.position.set(0.8, 7.6, 0);
  roof.castShadow = true;
  const fasciaGeo = new THREE.BoxGeometry(0.45, 0.9, 58.2);
  const fascia = new THREE.Mesh(fasciaGeo, brassTrimMat);
  fascia.position.set(7.2, 7.4, 0);

  const towerGeo = new THREE.BoxGeometry(7.5, 16, 7.5);
  const timingTower = new THREE.Mesh(towerGeo, concreteMat);
  timingTower.position.set(-1.5, 8, -36);
  timingTower.castShadow = true;
  const towerCap = new THREE.Mesh(new THREE.BoxGeometry(8.5, 1.2, 8.5), brassTrimMat);
  towerCap.position.set(-1.5, 15.8, -36);

  standGroup.add(tier1, roof, fascia, timingTower, towerCap);
  scene.add(standGroup);
  disposableGeos.push(baseDeckGeo, roofGeo, fasciaGeo, towerGeo);
  disposableMats.push(concreteMat, brassTrimMat, roofMat);

  // Overhead Arches spanning the circuit
  const archBeamGeo = new THREE.BoxGeometry(roadHalfWidth * 2 + 12, 2.2, 5.5);
  const archPillarGeo = new THREE.BoxGeometry(2.6, 9.2, 5.5);
  for (const archIdx of [210, 480]) {
    const s = samples[archIdx];
    const arch = new THREE.Group();
    arch.position.copy(s.pos);
    arch.rotation.y = Math.atan2(s.tangent.x, s.tangent.z);
    const aL = new THREE.Mesh(archPillarGeo, concreteMat);
    aL.position.set(-roadHalfWidth - 5.5, 4.6, 0);
    aL.castShadow = true;
    const aR = new THREE.Mesh(archPillarGeo, concreteMat);
    aR.position.set(roadHalfWidth + 5.5, 4.6, 0);
    aR.castShadow = true;
    const aTop = new THREE.Mesh(archBeamGeo, brassTrimMat);
    aTop.position.set(0, 8.8, 0);
    aTop.castShadow = true;
    arch.add(aL, aR, aTop);
    scene.add(arch);
  }
  disposableGeos.push(archBeamGeo, archPillarGeo);

  // Corner Chevron Warning Boards
  const chevronGeo = new THREE.BoxGeometry(2.4, 1.5, 0.25);
  const chevronMat = new THREE.MeshStandardMaterial({
    color: isNight ? 0x35e0ff : 0xe6a635,
    roughness: 0.4,
    emissive: isNight ? new THREE.Color(0x168ea6) : new THREE.Color(0x000000),
    emissiveIntensity: isNight ? 0.5 : 0,
  });
  for (let i = 15; i < samples.length; i += 22) {
    const s = samples[i];
    if (s.curvature > 0.036) {
      const sign = new THREE.Mesh(chevronGeo, chevronMat);
      sign.position.set(
        s.pos.x + s.right.x * (barrierHalfWidth + 1.2),
        s.pos.y + 1.6,
        s.pos.z + s.right.z * (barrierHalfWidth + 1.2),
      );
      sign.rotation.y = Math.atan2(s.tangent.x, s.tangent.z);
      scene.add(sign);
    }
  }
  disposableGeos.push(chevronGeo);
  disposableMats.push(chevronMat);

  // Street Lamps / Track Floodlights (especially crisp on Neon Metropolis & Pit Straight)
  const lampPoleGeo = new THREE.CylinderGeometry(0.14, 0.2, 8.5, 6);
  const lampHeadGeo = new THREE.BoxGeometry(1.4, 0.28, 0.55);
  const lampMat = new THREE.MeshStandardMaterial({ color: 0x363b42, metalness: 0.65, roughness: 0.4 });
  const lampGlowMat = new THREE.MeshBasicMaterial({
    color: isNight ? 0x9ef4ff : 0xfff3d4,
  });
  const lampStep = isNight ? 18 : 42;
  for (let i = 6; i < samples.length; i += lampStep) {
    const s = samples[i];
    const side = (i / lampStep) % 2 === 0 ? 1 : -1;
    const pole = new THREE.Mesh(lampPoleGeo, lampMat);
    pole.position.set(
      s.pos.x + s.right.x * side * (barrierHalfWidth + 1.5),
      s.pos.y + 4.25,
      s.pos.z + s.right.z * side * (barrierHalfWidth + 1.5),
    );
    const head = new THREE.Mesh(lampHeadGeo, lampGlowMat);
    head.position.set(
      s.pos.x + s.right.x * side * (barrierHalfWidth + 0.5),
      s.pos.y + 8.35,
      s.pos.z + s.right.z * side * (barrierHalfWidth + 0.5),
    );
    head.rotation.y = Math.atan2(s.tangent.x, s.tangent.z);
    scene.add(pole, head);
  }
  disposableGeos.push(lampPoleGeo, lampHeadGeo);
  disposableMats.push(lampMat, lampGlowMat);

  // Themed Trackside Scenery (Skyscrapers, Industrial Tanks, Coastal Lighthouse, or Evergreen Forest)
  if (isNight) {
    // Urban Skyline Towers
    const bldgGeo = new THREE.BoxGeometry(1, 1, 1);
    const bldgMat = new THREE.MeshStandardMaterial({ color: 0x161a26, roughness: 0.45, metalness: 0.5 });
    const winStripMat = new THREE.MeshBasicMaterial({ color: 0x45d8ff });
    const magentaMat = new THREE.MeshBasicMaterial({ color: 0xe649b0 });
    disposableGeos.push(bldgGeo);
    disposableMats.push(bldgMat, winStripMat, magentaMat);

    for (let i = 0; i < 68; i++) {
      const rx = THREE.MathUtils.randFloat(-290, 440);
      const rz = THREE.MathUtils.randFloat(-340, 360);
      const closest = findClosestTrackPoint(samples, rx, rz);
      if (closest.absLateral < barrierHalfWidth + 14) continue;
      const bw = THREE.MathUtils.randFloat(14, 30);
      const bd = THREE.MathUtils.randFloat(14, 30);
      const bh = THREE.MathUtils.randFloat(26, 92);
      const bldg = new THREE.Mesh(bldgGeo, bldgMat);
      bldg.scale.set(bw, bh, bd);
      bldg.position.set(rx, bh * 0.5 - 0.3, rz);
      scene.add(bldg);

      const band = new THREE.Mesh(bldgGeo, i % 3 === 0 ? magentaMat : winStripMat);
      band.scale.set(bw + 0.4, 1.2, bd + 0.4);
      band.position.set(rx, bh - 4, rz);
      scene.add(band);
    }
  } else if (isDesert) {
    // Industrial Silos, Fuel Tanks & Canyon Mesa Rocks
    const tankGeo = new THREE.CylinderGeometry(8.5, 8.5, 16, 16);
    const tankMat = new THREE.MeshStandardMaterial({ color: 0x9aa2a8, metalness: 0.55, roughness: 0.42 });
    const stripeMat = new THREE.MeshStandardMaterial({ color: 0xd97a26, roughness: 0.5 });
    disposableGeos.push(tankGeo);
    disposableMats.push(tankMat, stripeMat);

    const tankSpots = [
      [-185, 85],
      [-185, 42],
      [-185, -5],
      [115, 72],
      [148, 86],
      [255, -120],
    ];
    for (const [tx, tz] of tankSpots) {
      const ty = getTerrainHeight(tx, tz);
      const tank = new THREE.Mesh(tankGeo, tankMat);
      tank.position.set(tx, ty + 8, tz);
      tank.castShadow = true;
      const band = new THREE.Mesh(tankGeo, stripeMat);
      band.scale.set(1.02, 0.14, 1.02);
      band.position.set(tx, ty + 13.5, tz);
      scene.add(tank, band);
    }

    const cactiGeo = new THREE.CylinderGeometry(0.38, 0.48, 5.2, 7);
    cactiGeo.translate(0, 2.6, 0);
    const cactiMat = new THREE.MeshStandardMaterial({ color: 0x3b6331, roughness: 0.85 });
    const cactiInst = new THREE.InstancedMesh(cactiGeo, cactiMat, 140);
    let placed = 0;
    for (let a = 0; a < 900 && placed < 140; a++) {
      const rx = THREE.MathUtils.randFloat(-280, 440);
      const rz = THREE.MathUtils.randFloat(-340, 360);
      const closest = findClosestTrackPoint(samples, rx, rz);
      if (closest.absLateral < barrierHalfWidth + 10) continue;
      const ty = getTerrainHeight(rx, rz);
      dummy.position.set(rx, ty, rz);
      dummy.rotation.set(0, Math.random() * Math.PI * 2, 0);
      const s = THREE.MathUtils.randFloat(0.75, 1.45);
      dummy.scale.set(s, s, s);
      dummy.updateMatrix();
      cactiInst.setMatrixAt(placed++, dummy.matrix);
    }
    cactiInst.count = placed;
    cactiInst.instanceMatrix.needsUpdate = true;
    scene.add(cactiInst);
    disposableGeos.push(cactiGeo);
    disposableMats.push(cactiMat);
  } else {
    // Evergreen Alpine Forest or Coastal Palm Grove
    const treeCount = 290;
    const trunkGeo = new THREE.CylinderGeometry(0.32, 0.48, isCoastal ? 5.2 : 3.2, 7);
    trunkGeo.translate(0, isCoastal ? 2.6 : 1.6, 0);
    const foliageGeo = isCoastal
      ? new THREE.ConeGeometry(3.4, 2.4, 7)
      : new THREE.ConeGeometry(2.7, 7.6, 8);
    foliageGeo.translate(0, isCoastal ? 5.8 : 6.2, 0);

    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x4b3322, roughness: 0.92 });
    const foliageMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.85 });

    const trunkInst = new THREE.InstancedMesh(trunkGeo, trunkMat, treeCount);
    const foliageInst = new THREE.InstancedMesh(foliageGeo, foliageMat, treeCount);
    foliageInst.castShadow = true;

    const palette = isCoastal
      ? [new THREE.Color(0x3a6e32), new THREE.Color(0x4b7d39), new THREE.Color(0x2d5e2e)]
      : [new THREE.Color(0x2d4a29), new THREE.Color(0x365930), new THREE.Color(0x253e23)];
    let placedTrees = 0;
    let attempts = 0;
    while (placedTrees < treeCount && attempts < 2200) {
      attempts++;
      const rx = THREE.MathUtils.randFloat(-320, 490);
      const rz = THREE.MathUtils.randFloat(-380, 410);
      const closest = findClosestTrackPoint(samples, rx, rz);
      const lakeDist = Math.hypot(rx - 135, rz + 25);
      if (closest.absLateral < barrierHalfWidth + 9 || lakeDist < (isCoastal ? 198 : 136)) continue;

      const ty = getTerrainHeight(rx, rz);
      const sFactor = THREE.MathUtils.randFloat(0.85, 1.35);
      dummy.position.set(rx, ty, rz);
      dummy.rotation.set(0, Math.random() * Math.PI * 2, 0);
      dummy.scale.set(sFactor, sFactor, sFactor);
      dummy.updateMatrix();
      trunkInst.setMatrixAt(placedTrees, dummy.matrix);
      foliageInst.setMatrixAt(placedTrees, dummy.matrix);

      const tint = palette[placedTrees % palette.length].clone();
      tint.offsetHSL(THREE.MathUtils.randFloat(-0.02, 0.02), 0, THREE.MathUtils.randFloat(-0.04, 0.04));
      foliageInst.setColorAt(placedTrees, tint);
      placedTrees++;
    }
    trunkInst.count = placedTrees;
    foliageInst.count = placedTrees;
    trunkInst.instanceMatrix.needsUpdate = true;
    foliageInst.instanceMatrix.needsUpdate = true;
    if (foliageInst.instanceColor) foliageInst.instanceColor.needsUpdate = true;
    trunkInst.computeBoundingSphere();
    foliageInst.computeBoundingSphere();
    scene.add(trunkInst, foliageInst);
    disposableGeos.push(trunkGeo, foliageGeo);
    disposableMats.push(trunkMat, foliageMat);

    // Coastal Lighthouse Landmark
    if (isCoastal) {
      const lhBase = new THREE.Mesh(
        new THREE.CylinderGeometry(3.2, 4.4, 24, 12),
        new THREE.MeshStandardMaterial({ color: 0xf0e9dc, roughness: 0.7 }),
      );
      lhBase.position.set(220, 12, -165);
      const lhBeacon = new THREE.Mesh(
        new THREE.CylinderGeometry(2.6, 2.6, 3.2, 12),
        new THREE.MeshBasicMaterial({ color: 0xffe49c }),
      );
      lhBeacon.position.set(220, 25.5, -165);
      scene.add(lhBase, lhBeacon);
    }
  }

  // Instanced Boulders / Terrain Outcrops (skip Night Metropolis)
  if (!isNight) {
    const rockCount = 95;
    const rockGeo = new THREE.DodecahedronGeometry(1.7, 0);
    const rockMat = new THREE.MeshStandardMaterial({
      color: isDesert ? 0x7d4c32 : 0x666059,
      roughness: 0.92,
      metalness: 0.06,
    });
    const rockInst = new THREE.InstancedMesh(rockGeo, rockMat, rockCount);
    let placedRocks = 0;
    let rAttempts = 0;
    while (placedRocks < rockCount && rAttempts < 900) {
      rAttempts++;
      const rx = THREE.MathUtils.randFloat(-280, 460);
      const rz = THREE.MathUtils.randFloat(-340, 380);
      const closest = findClosestTrackPoint(samples, rx, rz);
      if (closest.absLateral < barrierHalfWidth + 6.5) continue;
      const ry = getTerrainHeight(rx, rz);
      dummy.position.set(rx, ry + 0.3, rz);
      dummy.rotation.set(Math.random(), Math.random(), Math.random());
      const rs = THREE.MathUtils.randFloat(0.8, 2.3);
      dummy.scale.set(rs * 1.25, rs * 0.78, rs);
      dummy.updateMatrix();
      rockInst.setMatrixAt(placedRocks++, dummy.matrix);
    }
    rockInst.count = placedRocks;
    rockInst.instanceMatrix.needsUpdate = true;
    rockInst.computeBoundingSphere();
    scene.add(rockInst);
    disposableGeos.push(rockGeo);
    disposableMats.push(rockMat);
  }

  // Collidable Trackside Safety Pylons (wrapped in Group so external pylon.glb swaps smoothly)
  const pylonGeo = new THREE.CylinderGeometry(0.15, 0.3, 1.0, 10);
  pylonGeo.translate(0, 0.5, 0);
  const pylonMat = new THREE.MeshStandardMaterial({
    color: isNight ? 0x35e0ff : 0xe26724,
    roughness: 0.45,
    metalness: 0.1,
    emissive: isNight ? new THREE.Color(0x168ea6) : new THREE.Color(0x000000),
    emissiveIntensity: isNight ? 0.55 : 0,
  });
  const pylons: CollidablePylon[] = [];
  const pylonIndices = [135, 195, 290, 360, 425, 515, 590, 645];
  const fallbackPylonMeshes: THREE.Mesh[] = [];
  for (const idx of pylonIndices) {
    const s = samples[idx % samples.length];
    const side = idx % 2 === 0 ? -1 : 1;
    const px = s.pos.x + s.right.x * side * (roadHalfWidth + 0.8);
    const pz = s.pos.z + s.right.z * side * (roadHalfWidth + 0.8);
    const holder = new THREE.Group();
    holder.position.set(px, s.pos.y, pz);
    const mesh = new THREE.Mesh(pylonGeo, pylonMat);
    mesh.castShadow = true;
    holder.add(mesh);
    scene.add(holder);
    fallbackPylonMeshes.push(mesh);
    pylons.push({
      x: px,
      z: pz,
      baseY: s.pos.y,
      mesh: holder,
      radius: 0.45,
      hitCooldown: 0,
    });
  }
  disposableGeos.push(pylonGeo);
  disposableMats.push(pylonMat);

  // Upgrade collidable pylons with downloaded 3D pylon.glb
  for (let i = 0; i < pylons.length; i++) {
    const holder = pylons[i].mesh;
    const fallbackMesh = fallbackPylonMeshes[i];
    loadExternalModel("/assets/models/racing/pylon.glb", { targetSize: 1.05, groundAtZero: true })
      .then((extPylon) => {
        if (!extPylon) return;
        if (worldDisposed) {
          disposeSafeHierarchy(extPylon);
          return;
        }
        fallbackMesh.visible = false;
        holder.add(extPylon);
        asyncGroups.push(extPylon);
      })
      .catch(() => {});
  }

  // Downloaded 3D Start/Finish Paddock Architecture (Grandstand, Pit Garages, Tents, Banner Tower, Gantry Lights, Checkered Flags, Road Network)
  const startYaw = Math.atan2(startSample.tangent.x, startSample.tangent.z);
  const pitYaw = Math.atan2(pitPos.tangent.x, pitPos.tangent.z);

  placeExternalTrackProp(
    "/assets/models/racing/overheadLights.glb",
    roadHalfWidth * 2 + 5.2,
    startSample.pos.x,
    startSample.pos.y + 7.25,
    startSample.pos.z,
    startYaw,
  );
  placeExternalTrackProp(
    "/assets/models/racing/flagCheckers.glb",
    8.5,
    startSample.pos.x + startSample.right.x * (roadHalfWidth + 3.2),
    startSample.pos.y,
    startSample.pos.z + startSample.right.z * (roadHalfWidth + 3.2),
    startYaw,
  );
  placeExternalTrackProp(
    "/assets/models/racing/flagCheckers.glb",
    8.5,
    startSample.pos.x - startSample.right.x * (roadHalfWidth + 3.2),
    startSample.pos.y,
    startSample.pos.z - startSample.right.z * (roadHalfWidth + 3.2),
    startYaw + Math.PI,
  );
  placeExternalTrackProp(
    "/assets/models/racing/bannerTowerRed.glb",
    13.5,
    startSample.pos.x + startSample.right.x * (barrierHalfWidth + 4.5),
    startSample.pos.y,
    startSample.pos.z + startSample.right.z * (barrierHalfWidth + 4.5),
    startYaw + Math.PI / 2,
  );
  placeExternalTrackProp(
    "/assets/models/racing/grandStandCovered.glb",
    22,
    standBasePos.x - 42,
    getTerrainHeight(standBasePos.x - 42, standBasePos.z),
    standBasePos.z + 18,
    startYaw + Math.PI / 2,
  );
  placeExternalTrackProp(
    "/assets/models/racing/pitsGarage.glb",
    19,
    pitPos.pos.x - pitPos.right.x * (roadHalfWidth + 16),
    pitPos.pos.y,
    pitPos.pos.z - pitPos.right.z * (roadHalfWidth + 16) - 22,
    pitYaw - Math.PI / 2,
  );
  placeExternalTrackProp(
    "/assets/models/racing/kit/decoration-tents.glb",
    14,
    pitPos.pos.x - pitPos.right.x * (barrierHalfWidth + 13),
    getTerrainHeight(pitPos.pos.x - pitPos.right.x * (barrierHalfWidth + 13), pitPos.pos.z + 26),
    pitPos.pos.z + 26,
    pitYaw,
  );

  // Paddock Service Roadway (real 3D road-straight, road-crossroad, road-bend tiles) + Paddock Safety & Pace Cars
  const paddockRoadOrigin = {
    x: pitPos.pos.x - pitPos.right.x * (barrierHalfWidth + 24),
    z: pitPos.pos.z - pitPos.right.z * (barrierHalfWidth + 24),
  };
  for (let step = -2; step <= 2; step++) {
    const rx = paddockRoadOrigin.x + pitPos.tangent.x * step * 14;
    const rz = paddockRoadOrigin.z + pitPos.tangent.z * step * 14;
    const tileUrl =
      step === 0
        ? "/assets/models/roads/road-crossroad.glb"
        : step === 2
          ? "/assets/models/roads/road-bend.glb"
          : "/assets/models/roads/road-straight.glb";
    placeExternalTrackProp(tileUrl, 14, rx, getTerrainHeight(rx, rz) + 0.04, rz, pitYaw);
  }
  placeExternalTrackProp(
    "/assets/models/racing/fenceStraight.glb",
    9.5,
    paddockRoadOrigin.x + pitPos.right.x * 7.5,
    getTerrainHeight(paddockRoadOrigin.x, paddockRoadOrigin.z),
    paddockRoadOrigin.z + pitPos.right.z * 7.5,
    pitYaw + Math.PI / 2,
  );
  placeExternalTrackProp(
    "/assets/models/cars/raceCarGreen.glb",
    4.5,
    pitPos.pos.x - pitPos.right.x * (roadHalfWidth + 9.5),
    pitPos.pos.y,
    pitPos.pos.z - pitPos.right.z * (roadHalfWidth + 9.5) - 6,
    pitYaw,
  );
  placeExternalTrackProp(
    "/assets/models/cars/raceCarWhite.glb",
    4.5,
    pitPos.pos.x - pitPos.right.x * (roadHalfWidth + 9.5),
    pitPos.pos.y,
    pitPos.pos.z - pitPos.right.z * (roadHalfWidth + 9.5) + 8,
    pitYaw,
  );

  // Trackside Billboards, Highway Signs & Elevated Bridge Approaches
  for (const sIdx of [85, 250, 420, 580]) {
    const ss = samples[sIdx % samples.length];
    const side = sIdx % 2 === 0 ? 1 : -1;
    const sx = ss.pos.x + ss.right.x * side * (barrierHalfWidth + 4.8);
    const sz = ss.pos.z + ss.right.z * side * (barrierHalfWidth + 4.8);
    placeExternalTrackProp(
      sIdx === 85 || sIdx === 420
        ? "/assets/models/racing/billboard.glb"
        : "/assets/models/roads/sign-highway-wide.glb",
      9.2,
      sx,
      ss.pos.y,
      sz,
      Math.atan2(ss.tangent.x, ss.tangent.z) + (side > 0 ? -Math.PI / 2 : Math.PI / 2),
    );
  }
  const bridgeAnchor = samples[Math.floor(samples.length * 0.28)];
  const bridgeYaw = Math.atan2(bridgeAnchor.tangent.x, bridgeAnchor.tangent.z);
  placeExternalTrackProp(
    "/assets/models/roads/road-bridge.glb",
    16,
    bridgeAnchor.pos.x + bridgeAnchor.right.x * (barrierHalfWidth + 14),
    getTerrainHeight(
      bridgeAnchor.pos.x + bridgeAnchor.right.x * (barrierHalfWidth + 14),
      bridgeAnchor.pos.z + bridgeAnchor.right.z * (barrierHalfWidth + 14),
    ),
    bridgeAnchor.pos.z + bridgeAnchor.right.z * (barrierHalfWidth + 14),
    bridgeYaw + Math.PI / 2,
  );
  placeExternalTrackProp(
    "/assets/models/roads/bridge-pillar-wide.glb",
    7.5,
    bridgeAnchor.pos.x + bridgeAnchor.right.x * (barrierHalfWidth + 14),
    getTerrainHeight(
      bridgeAnchor.pos.x + bridgeAnchor.right.x * (barrierHalfWidth + 14),
      bridgeAnchor.pos.z + bridgeAnchor.right.z * (barrierHalfWidth + 14),
    ) - 3.5,
    bridgeAnchor.pos.z + bridgeAnchor.right.z * (barrierHalfWidth + 14),
    bridgeYaw,
  );

  // Red Chicane/Apex Trackside Barriers & Modern Track Light Posts along main sections
  for (const bIdx of [24, 65, 675, 700]) {
    const bs = samples[bIdx % samples.length];
    const bSide = bIdx % 2 === 0 ? 1 : -1;
    const bx = bs.pos.x + bs.right.x * bSide * (barrierHalfWidth - 1.0);
    const bz = bs.pos.z + bs.right.z * bSide * (barrierHalfWidth - 1.0);
    placeExternalTrackProp(
      "/assets/models/racing/barrierRed.glb",
      4.5,
      bx,
      bs.pos.y,
      bz,
      Math.atan2(bs.tangent.x, bs.tangent.z),
    );
  }
  for (let i = 18; i < samples.length; i += 64) {
    const ls = samples[i];
    const lSide = (i / 64) % 2 === 0 ? 1 : -1;
    placeExternalTrackProp(
      "/assets/models/racing/lightPostModern.glb",
      9.2,
      ls.pos.x + ls.right.x * lSide * (barrierHalfWidth + 2.4),
      ls.pos.y,
      ls.pos.z + ls.right.z * lSide * (barrierHalfWidth + 2.4),
      Math.atan2(ls.tangent.x, ls.tangent.z) + (lSide > 0 ? Math.PI : 0),
    );
  }

  // Track-specific downloaded 3D Landmarks
  if (isNight) {
    const citySpots: [number, number, string, number][] = [
      [-230, 120, "/assets/models/racing/city/skyscraper-a.glb", 78],
      [-235, -35, "/assets/models/racing/city/skyscraper-b.glb", 92],
      [-210, -185, "/assets/models/racing/city/skyscraper-a.glb", 84],
      [15, -295, "/assets/models/racing/city/skyscraper-b.glb", 96],
      [165, -240, "/assets/models/racing/city/skyscraper-a.glb", 74],
      [395, -90, "/assets/models/racing/city/skyscraper-b.glb", 88],
      [395, 105, "/assets/models/racing/city/skyscraper-a.glb", 76],
      [255, 315, "/assets/models/racing/city/skyscraper-b.glb", 90],
      [15, 295, "/assets/models/racing/city/skyscraper-a.glb", 72],
    ];
    for (const [cx, cz, url, sz] of citySpots) {
      const closest = findClosestTrackPoint(samples, cx, cz);
      if (closest.absLateral < barrierHalfWidth + 16) continue;
      placeExternalTrackProp(url, sz, cx, -0.3, cz, (cx + cz) * 0.01);
    }
  } else if (isDesert) {
    const refinerySpots: [number, number][] = [
      [-192, 64],
      [-192, 18],
      [128, 92],
      [268, -112],
      [230, -155],
    ];
    for (const [tx, tz] of refinerySpots) {
      const closest = findClosestTrackPoint(samples, tx, tz);
      if (closest.absLateral < barrierHalfWidth + 10) continue;
      placeExternalTrackProp(
        "/assets/models/racing/industrial/detail-tank.glb",
        22,
        tx,
        getTerrainHeight(tx, tz),
        tz,
        tx * 0.02,
      );
    }
  } else {
    // Detailed 3D hero nature trees around scenic Alpine & Coastal curves
    const heroTreeModel = isCoastal
      ? "/assets/models/props/tree_palm.glb"
      : "/assets/models/props/tree_pine.glb";
    const altTreeModel = "/assets/models/props/tree_oak.glb";
    for (let i = 10; i < samples.length; i += 32) {
      const ts = samples[i];
      const side = (i / 32) % 2 === 0 ? 1 : -1;
      const distOut = barrierHalfWidth + 10.5;
      const tx = ts.pos.x + ts.right.x * side * distOut;
      const tz = ts.pos.z + ts.right.z * side * distOut;
      if (Math.hypot(tx - 135, tz + 25) < (isCoastal ? 198 : 136)) continue;
      const url = !isCoastal && i % 64 === 0 ? altTreeModel : heroTreeModel;
      placeExternalTrackProp(url, isCoastal ? 11.5 : 10.5, tx, getTerrainHeight(tx, tz), tz, i * 0.7);
    }
  }

  const dispose = () => {
    worldDisposed = true;
    for (const grp of asyncGroups) {
      scene.remove(grp);
      disposeSafeHierarchy(grp);
    }
    for (const g of disposableGeos) g.dispose();
    for (const m of disposableMats) m.dispose();
    for (const t of disposableTexs) t.dispose();
  };

  return {
    trackId,
    curve,
    samples,
    totalLength,
    roadHalfWidth,
    barrierHalfWidth,
    pylons,
    getTerrainHeight,
    dispose,
  };
}
