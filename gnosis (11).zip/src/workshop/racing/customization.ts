import { useSyncExternalStore } from "react";
import * as THREE from "three";

export type PaintFinishId = "gloss" | "metallic" | "matte" | "carbon" | "chrome" | "neon";
export type CarLiveryId =
  | "clean"
  | "twin-stripe"
  | "motorsport-num"
  | "checkered-flank"
  | "cyber-circuit"
  | "carbon-aero";
export type RimStyleId =
  | "5-spoke"
  | "mesh-gt"
  | "aero-disc"
  | "offroad-beadlock"
  | "star-split";
export type TuningPresetId = "balanced" | "drift" | "grip" | "sport" | "offroad";
export type RacingTrackId =
  | "alpine-grand"
  | "coastal-highway"
  | "neon-metropolis"
  | "canyon-industrial";

export interface PaintColorPreset {
  id: string;
  name: string;
  hex: string;
}

export const CAR_PAINT_PRESETS: PaintColorPreset[] = [
  { id: "bronze", name: "Solar Bronze", hex: "#9d5b28" },
  { id: "obsidian", name: "Obsidian Ink", hex: "#1d2027" },
  { id: "crimson", name: "Corsa Crimson", hex: "#9e1c24" },
  { id: "cobalt", name: "Bayside Cobalt", hex: "#1a4d94" },
  { id: "jade", name: "Midnight Jade", hex: "#195743" },
  { id: "titanium", name: "Titanium Pearl", hex: "#d6d9df" },
  { id: "sunburst", name: "Signal Amber", hex: "#d9821e" },
  { id: "sandstorm", name: "Dune Sand", hex: "#b89f74" },
  { id: "violet", name: "Ultraviolet", hex: "#4a2473" },
  { id: "cyan", name: "Volt Cyan", hex: "#1b8aa6" },
  { id: "olive", name: "Tactical Olive", hex: "#4d5932" },
  { id: "gold", name: "Champagne Gold", hex: "#c29b45" },
];

export const ACCENT_COLOR_PRESETS: PaintColorPreset[] = [
  { id: "brass", name: "GNOSIS Brass", hex: "#d4b26a" },
  { id: "red", name: "Track Red", hex: "#d93829" },
  { id: "cream", name: "Ivory Cream", hex: "#ece3d0" },
  { id: "orange", name: "Apex Orange", hex: "#f2a738" },
  { id: "cyan", name: "Neon Cyan", hex: "#38e8ff" },
  { id: "lime", name: "Acid Lime", hex: "#8df032" },
  { id: "black", name: "Stealth Carbon", hex: "#1c1f24" },
  { id: "silver", name: "Brushed Alloy", hex: "#d0d6df" },
];

export const PAINT_FINISHES: { id: PaintFinishId; label: string; desc: string }[] = [
  { id: "gloss", label: "Factory Gloss", desc: "Deep clearcoat lacquer" },
  { id: "metallic", label: "Metallic Flake", desc: "Rich alloy luster" },
  { id: "matte", label: "Satin Matte", desc: "Stealth low-sheen finish" },
  { id: "carbon", label: "Forged Carbon", desc: "Woven composite weave" },
  { id: "chrome", label: "Liquid Chrome", desc: "High-mirror show finish" },
  { id: "neon", label: "Emissive Neon", desc: "Subtle rim & body glow" },
];

export const CAR_LIVERIES: { id: CarLiveryId; label: string; desc: string }[] = [
  { id: "clean", label: "Factory Clean", desc: "Pure monochrome coachwork" },
  { id: "twin-stripe", label: "Twin Le Mans", desc: "Classic dual racing stripes" },
  { id: "motorsport-num", label: "Works Roundel", desc: "Team stripe + race numberplate" },
  { id: "checkered-flank", label: "Grand Flag", desc: "Checkered heritage flank" },
  { id: "cyber-circuit", label: "Circuit Trace", desc: "Geometric telemetry vector lines" },
  { id: "carbon-aero", label: "Two-Tone Aero", desc: "Darkened roof & hood split" },
];

export const RIM_STYLES: { id: RimStyleId; label: string }[] = [
  { id: "5-spoke", label: "5-Spoke Forged" },
  { id: "mesh-gt", label: "Mesh Endurance" },
  { id: "aero-disc", label: "Turbofan Aero" },
  { id: "offroad-beadlock", label: "Beadlock Heavy" },
  { id: "star-split", label: "Star Split-10" },
];

export interface CarTuningConfig {
  presetId: TuningPresetId;
  steeringGain: number; // 0.75 .. 1.35
  suspensionStiffness: number; // 0.70 .. 1.40
  rideHeightOffset: number; // -0.06 .. +0.12 m
  tireGripMult: number; // 0.75 .. 1.30
  brakePowerMult: number; // 0.80 .. 1.35
  accelBoostMult: number; // 0.85 .. 1.25
  topSpeedTrim: number; // 0.90 .. 1.12
  diffLockYaw: number; // 0.75 .. 1.40
}

export const TUNING_PRESETS: Record<
  TuningPresetId,
  { label: string; summary: string; config: CarTuningConfig }
> = {
  balanced: {
    label: "Balanced GP",
    summary: "Factory baseline geometry for predictable turn-in and clean braking.",
    config: {
      presetId: "balanced",
      steeringGain: 1.0,
      suspensionStiffness: 1.0,
      rideHeightOffset: 0,
      tireGripMult: 1.0,
      brakePowerMult: 1.0,
      accelBoostMult: 1.0,
      topSpeedTrim: 1.0,
      diffLockYaw: 1.0,
    },
  },
  drift: {
    label: "Touge Drift",
    summary: "Snappy yaw rotation, softened rear grip & extended countersteer angle.",
    config: {
      presetId: "drift",
      steeringGain: 1.24,
      suspensionStiffness: 0.88,
      rideHeightOffset: -0.02,
      tireGripMult: 0.82,
      brakePowerMult: 1.05,
      accelBoostMult: 1.12,
      topSpeedTrim: 0.98,
      diffLockYaw: 1.32,
    },
  },
  grip: {
    label: "Time Attack Grip",
    summary: "Stiffened anti-roll springs, lowered stance & maximum lateral bite.",
    config: {
      presetId: "grip",
      steeringGain: 1.08,
      suspensionStiffness: 1.34,
      rideHeightOffset: -0.04,
      tireGripMult: 1.25,
      brakePowerMult: 1.26,
      accelBoostMult: 1.04,
      topSpeedTrim: 0.99,
      diffLockYaw: 0.95,
    },
  },
  sport: {
    label: "Top Speed Veloce",
    summary: "Long gearing & low aero drag biased for sweeping highway straights.",
    config: {
      presetId: "sport",
      steeringGain: 0.94,
      suspensionStiffness: 1.16,
      rideHeightOffset: -0.03,
      tireGripMult: 1.06,
      brakePowerMult: 1.14,
      accelBoostMult: 1.14,
      topSpeedTrim: 1.1,
      diffLockYaw: 0.96,
    },
  },
  offroad: {
    label: "Raid Gravel",
    summary: "Raised long-travel damper clearance & planted off-track traction.",
    config: {
      presetId: "offroad",
      steeringGain: 1.04,
      suspensionStiffness: 0.76,
      rideHeightOffset: 0.08,
      tireGripMult: 1.14,
      brakePowerMult: 0.98,
      accelBoostMult: 1.08,
      topSpeedTrim: 0.94,
      diffLockYaw: 1.12,
    },
  },
};

export interface RacingCustomizationState {
  vehicleId: string;
  trackId: RacingTrackId;
  useCustomColors: boolean;
  paintHex: string;
  accentHex: string;
  rimHex: string;
  finish: PaintFinishId;
  livery: CarLiveryId;
  rimStyle: RimStyleId;
  raceNumber: string;
  tuning: CarTuningConfig;
}

export interface TrackBestRecord {
  bestLapSec: number;
  bestRaceSec: number;
  topSpeedKmh: number;
  vehicleName: string;
}

const STORAGE_KEY = "gnosis-racing-custom-v1";
const RECORDS_STORAGE_KEY = "gnosis-racing-records-v1";

export const DEFAULT_RACING_CUSTOMIZATION: RacingCustomizationState = {
  vehicleId: "meridian-gt",
  trackId: "alpine-grand",
  useCustomColors: false,
  paintHex: "#9d5b28",
  accentHex: "#d4b26a",
  rimHex: "#d9c293",
  finish: "gloss",
  livery: "twin-stripe",
  rimStyle: "5-spoke",
  raceNumber: "07",
  tuning: { ...TUNING_PRESETS.balanced.config },
};

function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}

const VALID_VEHICLE_IDS = new Set([
  "meridian-gt",
  "apex-v12",
  "ironclad-v8",
  "kurogane-drift",
  "alpine-rally",
  "titan-baja",
  "zephyr-spyder",
  "aether-formula",
]);

function loadCustomState(): RacingCustomizationState {
  if (typeof window === "undefined") return { ...DEFAULT_RACING_CUSTOMIZATION };
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return { ...DEFAULT_RACING_CUSTOMIZATION };
    const p = JSON.parse(raw) as Partial<RacingCustomizationState>;
    const t = (p.tuning || {}) as Partial<CarTuningConfig>;
    return {
      vehicleId:
        typeof p.vehicleId === "string" && VALID_VEHICLE_IDS.has(p.vehicleId)
          ? p.vehicleId
          : DEFAULT_RACING_CUSTOMIZATION.vehicleId,
      trackId:
        p.trackId === "alpine-grand" ||
        p.trackId === "coastal-highway" ||
        p.trackId === "neon-metropolis" ||
        p.trackId === "canyon-industrial"
          ? p.trackId
          : DEFAULT_RACING_CUSTOMIZATION.trackId,
      useCustomColors: Boolean(p.useCustomColors),
      paintHex: typeof p.paintHex === "string" ? p.paintHex : DEFAULT_RACING_CUSTOMIZATION.paintHex,
      accentHex: typeof p.accentHex === "string" ? p.accentHex : DEFAULT_RACING_CUSTOMIZATION.accentHex,
      rimHex: typeof p.rimHex === "string" ? p.rimHex : DEFAULT_RACING_CUSTOMIZATION.rimHex,
      finish:
        PAINT_FINISHES.some((f) => f.id === p.finish)
          ? (p.finish as PaintFinishId)
          : DEFAULT_RACING_CUSTOMIZATION.finish,
      livery:
        CAR_LIVERIES.some((l) => l.id === p.livery)
          ? (p.livery as CarLiveryId)
          : DEFAULT_RACING_CUSTOMIZATION.livery,
      rimStyle:
        RIM_STYLES.some((r) => r.id === p.rimStyle)
          ? (p.rimStyle as RimStyleId)
          : DEFAULT_RACING_CUSTOMIZATION.rimStyle,
      raceNumber:
        typeof p.raceNumber === "string" && p.raceNumber.trim().length > 0
          ? p.raceNumber.trim().slice(0, 2)
          : "07",
      tuning: {
        presetId:
          t.presetId && t.presetId in TUNING_PRESETS
            ? t.presetId
            : DEFAULT_RACING_CUSTOMIZATION.tuning.presetId,
        steeringGain: clamp(Number(t.steeringGain ?? 1), 0.75, 1.35),
        suspensionStiffness: clamp(Number(t.suspensionStiffness ?? 1), 0.7, 1.4),
        rideHeightOffset: clamp(Number(t.rideHeightOffset ?? 0), -0.06, 0.12),
        tireGripMult: clamp(Number(t.tireGripMult ?? 1), 0.75, 1.3),
        brakePowerMult: clamp(Number(t.brakePowerMult ?? 1), 0.8, 1.35),
        accelBoostMult: clamp(Number(t.accelBoostMult ?? 1), 0.85, 1.25),
        topSpeedTrim: clamp(Number(t.topSpeedTrim ?? 1), 0.9, 1.12),
        diffLockYaw: clamp(Number(t.diffLockYaw ?? 1), 0.75, 1.4),
      },
    };
  } catch {
    return { ...DEFAULT_RACING_CUSTOMIZATION };
  }
}

let currentCustom = loadCustomState();
const listeners = new Set<() => void>();

function saveAndEmit() {
  if (typeof window !== "undefined") {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(currentCustom));
    } catch {
      // Ignore quota errors
    }
  }
  for (const l of listeners) {
    try {
      l();
    } catch {
      // Ignore
    }
  }
}

export function getRacingCustomization(): RacingCustomizationState {
  return currentCustom;
}

export function updateRacingCustomization(patch: Partial<RacingCustomizationState>) {
  currentCustom = {
    ...currentCustom,
    ...patch,
    tuning: patch.tuning ? { ...currentCustom.tuning, ...patch.tuning } : currentCustom.tuning,
  };
  saveAndEmit();
}

export function updateRacingTuning(patch: Partial<CarTuningConfig>) {
  currentCustom = {
    ...currentCustom,
    tuning: {
      ...currentCustom.tuning,
      ...patch,
    },
  };
  saveAndEmit();
}

export function applyTuningPreset(presetId: TuningPresetId) {
  currentCustom = {
    ...currentCustom,
    tuning: { ...TUNING_PRESETS[presetId].config },
  };
  saveAndEmit();
}

export function resetRacingCustomization() {
  currentCustom = {
    ...DEFAULT_RACING_CUSTOMIZATION,
    tuning: { ...TUNING_PRESETS.balanced.config },
  };
  saveAndEmit();
}

function subscribe(listener: () => void): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function useRacingCustomization(): RacingCustomizationState {
  return useSyncExternalStore(subscribe, getRacingCustomization, getRacingCustomization);
}

export function loadTrackRecords(): Record<string, TrackBestRecord> {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(RECORDS_STORAGE_KEY);
    return raw ? (JSON.parse(raw) as Record<string, TrackBestRecord>) : {};
  } catch {
    return {};
  }
}

export function saveTrackRecord(
  trackId: RacingTrackId,
  bestLap: number | null,
  totalTime: number,
  topSpeedKmh: number,
  vehicleName: string,
): Record<string, TrackBestRecord> {
  const records = loadTrackRecords();
  const prev = records[trackId];
  const lapCandidate = bestLap ?? totalTime;
  records[trackId] = {
    bestLapSec: prev ? Math.min(prev.bestLapSec, lapCandidate) : lapCandidate,
    bestRaceSec: prev ? Math.min(prev.bestRaceSec, totalTime) : totalTime,
    topSpeedKmh: prev ? Math.max(prev.topSpeedKmh, topSpeedKmh) : topSpeedKmh,
    vehicleName:
      !prev || totalTime < prev.bestRaceSec ? vehicleName : prev.vehicleName,
  };
  if (typeof window !== "undefined") {
    try {
      window.localStorage.setItem(RECORDS_STORAGE_KEY, JSON.stringify(records));
    } catch {
      // Ignore quota errors
    }
  }
  return records;
}

export function createCarLiveryTexture(
  bodyHex: string,
  accentHex: string,
  liveryId: CarLiveryId,
  finishId: PaintFinishId,
  raceNumber: string,
): THREE.CanvasTexture | null {
  if (liveryId === "clean" && finishId !== "carbon") return null;

  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext("2d")!;

  ctx.fillStyle = bodyHex;
  ctx.fillRect(0, 0, 512, 512);

  if (finishId === "carbon") {
    ctx.fillStyle = "rgba(10, 12, 16, 0.42)";
    for (let y = 0; y < 512; y += 16) {
      for (let x = 0; x < 512; x += 16) {
        if (((x + y) / 16) % 2 === 0) {
          ctx.fillRect(x, y, 8, 8);
          ctx.fillRect(x + 8, y + 8, 8, 8);
        }
      }
    }
  }

  if (liveryId === "twin-stripe") {
    ctx.fillStyle = accentHex;
    ctx.fillRect(196, 0, 44, 512);
    ctx.fillRect(272, 0, 44, 512);
    ctx.fillStyle = "rgba(14, 14, 16, 0.36)";
    ctx.fillRect(188, 0, 8, 512);
    ctx.fillRect(316, 0, 8, 512);
  } else if (liveryId === "motorsport-num") {
    ctx.fillStyle = accentHex;
    ctx.fillRect(0, 210, 512, 92);
    ctx.fillStyle = "#f4efe4";
    ctx.beginPath();
    ctx.arc(256, 256, 78, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#141416";
    ctx.lineWidth = 6;
    ctx.stroke();
    ctx.fillStyle = "#141416";
    ctx.font = "bold 74px Georgia, serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(raceNumber.slice(0, 2) || "07", 256, 260);
  } else if (liveryId === "checkered-flank") {
    ctx.fillStyle = accentHex;
    ctx.fillRect(0, 0, 512, 54);
    ctx.fillRect(0, 458, 512, 54);
    for (let r = 0; r < 6; r++) {
      for (let c = 0; c < 12; c++) {
        ctx.fillStyle = (r + c) % 2 === 0 ? "#f2ece1" : "#15161a";
        ctx.fillRect(280 + c * 20, 140 + r * 38, 20, 38);
      }
    }
  } else if (liveryId === "cyber-circuit") {
    ctx.strokeStyle = accentHex;
    ctx.lineWidth = 8;
    for (let y = 48; y < 512; y += 96) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(160, y);
      ctx.lineTo(220, y - 34);
      ctx.lineTo(512, y - 34);
      ctx.stroke();
      ctx.fillStyle = accentHex;
      ctx.beginPath();
      ctx.arc(160, y, 10, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (liveryId === "carbon-aero") {
    ctx.fillStyle = "#16181c";
    ctx.fillRect(96, 0, 320, 512);
    ctx.fillStyle = accentHex;
    ctx.fillRect(88, 0, 10, 512);
    ctx.fillRect(414, 0, 10, 512);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(0.32, 0.32);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}
