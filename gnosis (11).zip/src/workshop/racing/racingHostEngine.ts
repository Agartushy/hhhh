import {
  createTrackCircuitCurve,
  sampleTrackCurve,
  type TrackSample,
} from "./trackAndWorld";
import type { RacingTrackId } from "./customization";

const PLAYER_COLORS = ["#e0a94f", "#5ec2f2", "#7ad979", "#ea7a66"];

const trackSplineCache = new Map<
  RacingTrackId,
  { samples: TrackSample[]; totalLength: number }
>();

function getTrackSpline(trackId: RacingTrackId) {
  let cached = trackSplineCache.get(trackId);
  if (!cached) {
    cached = sampleTrackCurve(createTrackCircuitCurve(trackId), 720);
    trackSplineCache.set(trackId, cached);
  }
  return cached;
}

export interface HostRacer {
  id: string;
  name: string;
  color: string;
  slot: number;
  vehicleId: string;
  x: number;
  y: number;
  z: number;
  yaw: number;
  steer: number;
  wheelSpin: number;
  speedKmh: number;
  topSpeedKmh: number;
  lap: number;
  progressNorm: number;
  drafting: boolean;
  finished: boolean;
  finishTime: number | null;
  bestLap: number | null;
  score: number;
}

export interface HostRival {
  id: string;
  name: string;
  vehicleId: string;
  s: number;
  speed: number;
  baseSpeed: number;
  laneOffset: number;
  lap: number;
  wheelSpin: number;
}

export interface HostRacingSnapshot {
  type: "racing:snapshot";
  code: string;
  title: string;
  trackId: RacingTrackId;
  status: "ACTIVE" | "FINISHED";
  elapsedTime: number;
  teamScore: number;
  totalLaps: number;
  squadLapsCompleted: number;
  squadTargetLaps: number;
  players: HostRacer[];
  rivals: Omit<HostRival, "baseSpeed">[];
}

export interface RacingOutgoingEvent {
  targetId?: string;
  payload: Record<string, unknown>;
}

export function getRacerGridSpawn(
  slot: number,
  trackId: RacingTrackId = "alpine-grand",
): { x: number; y: number; z: number; yaw: number } {
  const { samples, totalLength } = getTrackSpline(trackId);
  const row = Math.floor(slot / 2);
  const lateral = slot % 2 === 0 ? -4.2 : 4.2;
  const sOffset = (totalLength - row * 9.5) % totalLength;
  const idx = Math.floor((sOffset / totalLength) * samples.length) % samples.length;
  const samp = samples[idx];
  return {
    x: samp.pos.x + samp.right.x * lateral,
    y: samp.pos.y,
    z: samp.pos.z + samp.right.z * lateral,
    yaw: Math.atan2(samp.tangent.x, samp.tangent.z),
  };
}

export class RacingRoomHost {
  code: string;
  title: string;
  trackId: RacingTrackId;
  status: "ACTIVE" | "FINISHED" = "ACTIVE";
  elapsedTime = 0;
  teamScore = 0;
  totalLaps = 3;
  players = new Map<string, HostRacer>();
  rivals: HostRival[] = [
    {
      id: "rival-1",
      name: "Pacer Chronos",
      vehicleId: "apex-v12",
      s: 20,
      speed: 24,
      baseSpeed: 40,
      laneOffset: 5.2,
      lap: 1,
      wheelSpin: 0,
    },
    {
      id: "rival-2",
      name: "Pacer Vanguard",
      vehicleId: "alpine-rally",
      s: 44,
      speed: 22,
      baseSpeed: 36,
      laneOffset: -5.2,
      lap: 1,
      wheelSpin: 0,
    },
  ];

  constructor(code: string, title: string, trackId: RacingTrackId = "alpine-grand") {
    this.code = code;
    this.title = title.trim().slice(0, 36) || `GNOSIS Co-op GP ${code}`;
    this.trackId = trackId;
  }

  static fromSnapshot(snap: HostRacingSnapshot): RacingRoomHost {
    const host = new RacingRoomHost(snap.code, snap.title, snap.trackId || "alpine-grand");
    host.status = snap.status;
    host.elapsedTime = snap.elapsedTime;
    host.teamScore = snap.teamScore;
    host.totalLaps = snap.totalLaps;
    host.players.clear();
    for (const p of snap.players) {
      host.players.set(p.id, { ...p });
    }
    snap.rivals.forEach((rv, idx) => {
      if (host.rivals[idx]) {
        host.rivals[idx].s = rv.s;
        host.rivals[idx].speed = rv.speed;
        host.rivals[idx].lap = rv.lap;
        host.rivals[idx].wheelSpin = rv.wheelSpin;
      }
    });
    return host;
  }

  addRacer(
    playerId: string,
    rawName: string,
    vehicleId: string,
  ): {
    ok: boolean;
    error?: string;
    events: RacingOutgoingEvent[];
    spawn?: { x: number; y: number; z: number; yaw: number };
  } {
    const existing = this.players.get(playerId);
    if (existing) {
      const sp = { x: existing.x, y: existing.y, z: existing.z, yaw: existing.yaw };
      return { ok: true, spawn: sp, events: [] };
    }
    if (this.players.size >= 4) {
      return { ok: false, error: `Race Room ${this.code} is full (4/4 drivers).`, events: [] };
    }
    const usedSlots = new Set(Array.from(this.players.values()).map((p) => p.slot));
    let slot = 0;
    while (usedSlots.has(slot)) slot++;
    const spawn = getRacerGridSpawn(slot, this.trackId);
    const racer: HostRacer = {
      id: playerId,
      name: rawName.trim().slice(0, 18) || `Driver-${slot + 1}`,
      color: PLAYER_COLORS[slot % PLAYER_COLORS.length],
      slot,
      vehicleId: vehicleId.trim().slice(0, 32) || "meridian-gt",
      x: spawn.x,
      y: spawn.y,
      z: spawn.z,
      yaw: spawn.yaw,
      steer: 0,
      wheelSpin: 0,
      speedKmh: 0,
      topSpeedKmh: 0,
      lap: 1,
      progressNorm: 0,
      drafting: false,
      finished: false,
      finishTime: null,
      bestLap: null,
      score: 0,
    };
    this.players.set(playerId, racer);

    return {
      ok: true,
      spawn,
      events: [
        {
          targetId: playerId,
          payload: {
            type: "racing:joined",
            playerId,
            playerColor: racer.color,
            slot,
            spawn,
            snapshot: this.serializeSnapshot(),
          },
        },
        {
          payload: {
            type: "racer:joined",
            playerId,
            playerName: racer.name,
          },
        },
      ],
    };
  }

  removeRacer(playerId: string): RacingOutgoingEvent[] {
    const p = this.players.get(playerId);
    if (!p) return [];
    this.players.delete(playerId);
    return [{ payload: { type: "racer:left", playerId, playerName: p.name } }];
  }

  handleRacerState(playerId: string, msg: Record<string, unknown>) {
    const racer = this.players.get(playerId);
    if (!racer) return;

    if (typeof msg.x === "number" && Number.isFinite(msg.x)) racer.x = msg.x;
    if (typeof msg.y === "number" && Number.isFinite(msg.y)) racer.y = msg.y;
    if (typeof msg.z === "number" && Number.isFinite(msg.z)) racer.z = msg.z;
    if (typeof msg.yaw === "number" && Number.isFinite(msg.yaw)) racer.yaw = msg.yaw;
    if (typeof msg.steer === "number" && Number.isFinite(msg.steer)) racer.steer = msg.steer;
    if (typeof msg.wheelSpin === "number" && Number.isFinite(msg.wheelSpin)) {
      racer.wheelSpin = msg.wheelSpin;
    }
    if (typeof msg.speedKmh === "number" && Number.isFinite(msg.speedKmh)) {
      const clampedKmh = Math.max(0, Math.min(440, msg.speedKmh));
      racer.speedKmh = clampedKmh;
      if (clampedKmh > racer.topSpeedKmh) racer.topSpeedKmh = clampedKmh;
    }
    if (typeof msg.vehicleId === "string" && msg.vehicleId.length > 0) {
      racer.vehicleId = msg.vehicleId.slice(0, 32);
    }
    if (typeof msg.progressNorm === "number" && Number.isFinite(msg.progressNorm)) {
      racer.progressNorm = Math.max(0, Math.min(1, msg.progressNorm));
    }
    if (typeof msg.bestLap === "number" && Number.isFinite(msg.bestLap)) {
      racer.bestLap = msg.bestLap;
    }
    racer.drafting = Boolean(msg.drafting);

    if (typeof msg.lap === "number" && msg.lap > racer.lap && msg.lap <= this.totalLaps + 1) {
      const lapGain = Math.min(1, msg.lap - racer.lap);
      racer.lap += lapGain;
      const pts = lapGain * 300;
      racer.score += pts;
      this.teamScore += pts;
    }

    if (msg.finished === true && !racer.finished) {
      racer.finished = true;
      racer.finishTime =
        typeof msg.finishTime === "number" && Number.isFinite(msg.finishTime)
          ? msg.finishTime
          : this.elapsedTime;
      const finishBonus = 600;
      racer.score += finishBonus;
      this.teamScore += finishBonus;
    }
  }

  resetRace(): RacingOutgoingEvent[] {
    this.status = "ACTIVE";
    this.elapsedTime = 0;
    this.teamScore = 0;
    this.rivals[0].s = 20;
    this.rivals[0].speed = 24;
    this.rivals[0].lap = 1;
    this.rivals[1].s = 44;
    this.rivals[1].speed = 22;
    this.rivals[1].lap = 1;

    const events: RacingOutgoingEvent[] = [];
    for (const r of this.players.values()) {
      const sp = getRacerGridSpawn(r.slot, this.trackId);
      r.x = sp.x;
      r.y = sp.y;
      r.z = sp.z;
      r.yaw = sp.yaw;
      r.steer = 0;
      r.wheelSpin = 0;
      r.speedKmh = 0;
      r.topSpeedKmh = 0;
      r.lap = 1;
      r.progressNorm = 0;
      r.drafting = false;
      r.finished = false;
      r.finishTime = null;
      r.bestLap = null;
      r.score = 0;
      events.push({ targetId: r.id, payload: { type: "racing:restarted", spawn: sp } });
    }
    return events;
  }

  tick(dt: number) {
    if (this.status !== "ACTIVE") return;
    this.elapsedTime += dt;

    const { samples, totalLength } = getTrackSpline(this.trackId);
    for (const rv of this.rivals) {
      const norm = rv.s / totalLength;
      const sampleIdx = Math.floor(norm * samples.length) % samples.length;
      const curvature = samples[sampleIdx].curvature;
      const targetSpeed = curvature > 0.045 ? rv.baseSpeed * 0.65 : rv.baseSpeed;
      rv.speed += (targetSpeed - rv.speed) * Math.min(1, 2.2 * dt);
      const prevS = rv.s;
      rv.s = (rv.s + rv.speed * dt) % totalLength;
      if (rv.s < prevS) {
        rv.lap = Math.min(this.totalLaps + 1, rv.lap + 1);
      }
      rv.wheelSpin += (rv.speed / 0.37) * dt;
    }

    let allFinished = this.players.size > 0;
    for (const p of this.players.values()) {
      if (p.drafting && !p.finished) {
        p.score += 1;
        this.teamScore += 1;
      }
      if (!p.finished) allFinished = false;
    }
    if (allFinished) {
      this.status = "FINISHED";
    }
  }

  serializeSnapshot(): HostRacingSnapshot {
    const playersArr = Array.from(this.players.values());
    const squadLapsCompleted = playersArr.reduce(
      (sum, p) => sum + (p.finished ? this.totalLaps : Math.max(0, p.lap - 1)),
      0,
    );
    const squadTargetLaps = Math.max(1, playersArr.length) * this.totalLaps;

    return {
      type: "racing:snapshot",
      code: this.code,
      title: this.title,
      trackId: this.trackId,
      status: this.status,
      elapsedTime: Number(this.elapsedTime.toFixed(2)),
      teamScore: this.teamScore,
      totalLaps: this.totalLaps,
      squadLapsCompleted,
      squadTargetLaps,
      players: playersArr.map((p) => ({
        ...p,
        x: Number(p.x.toFixed(2)),
        y: Number(p.y.toFixed(2)),
        z: Number(p.z.toFixed(2)),
        yaw: Number(p.yaw.toFixed(4)),
        steer: Number(p.steer.toFixed(3)),
        wheelSpin: Number(p.wheelSpin.toFixed(2)),
        speedKmh: Math.round(p.speedKmh),
        topSpeedKmh: Math.round(p.topSpeedKmh),
        progressNorm: Number(p.progressNorm.toFixed(3)),
        finishTime: p.finishTime !== null ? Number(p.finishTime.toFixed(2)) : null,
        bestLap: p.bestLap !== null ? Number(p.bestLap.toFixed(2)) : null,
      })),
      rivals: this.rivals.map((rv) => ({
        id: rv.id,
        name: rv.name,
        vehicleId: rv.vehicleId,
        s: Number(rv.s.toFixed(2)),
        speed: Number(rv.speed.toFixed(2)),
        laneOffset: rv.laneOffset,
        lap: rv.lap,
        wheelSpin: Number(rv.wheelSpin.toFixed(2)),
      })),
    };
  }
}
