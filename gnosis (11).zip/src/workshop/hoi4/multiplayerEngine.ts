import { FEATURED_COUNTRY_IDS } from "./worldData";
import {
  applyCampaignCommand,
  createCampaignState,
  formatCampaignDate,
  pushCampaignEvent,
  serializeCampaignSnapshot,
  stepCampaignSimulation,
  switchPlayerNation,
  type CampaignState,
} from "./strategyEngine";
import type { StrategyScenario, StrategySnapshot } from "./types";

const PLAYER_COLORS = ["#e0a94f", "#5ec2f2", "#7ad979", "#ea7a66", "#c689f2", "#f5d76e"];

export interface Hoi4OutgoingEvent {
  targetId?: string;
  payload: Record<string, unknown>;
}

export class Hoi4RoomHost {
  state: CampaignState;

  constructor(code: string, title: string, scenario: StrategyScenario) {
    this.state = createCampaignState(title, scenario, code, "multiplayer");
  }

  static fromSnapshot(snap: StrategySnapshot): Hoi4RoomHost {
    const host = new Hoi4RoomHost(snap.code, snap.title, snap.scenario);
    host.state.dayCount = snap.dayCount;
    host.state.speed = snap.speed;
    host.state.paused = snap.paused;
    host.state.worldTension = snap.worldTension;
    host.state.winnerNationId = snap.winnerNationId;
    host.state.winnerReason = snap.winnerReason;
    host.state.players.clear();
    for (const p of snap.players) {
      host.state.players.set(p.id, { ...p });
    }
    for (const [iso, cDto] of Object.entries(snap.countries)) {
      const target = host.state.countries.get(iso);
      if (!target) continue;
      target.controllerIso = cDto.controllerIso;
      target.controllerPlayerId = cDto.controllerPlayerId;
      target.controllerName = cDto.controllerName;
      target.capitulated = cDto.capitulated;
      target.treasury = cDto.treasury;
      target.dailyBudgetDelta = cDto.dailyBudgetDelta;
      target.pp = cDto.pp;
      target.stability = cDto.stability;
      target.warSupport = cDto.warSupport;
      target.manpower = cDto.manpower;
      if (cDto.controllerIso === iso) {
        target.civFactories = cDto.civCount;
        target.milFactories = cDto.milCount;
      }
      target.infrastructure = cDto.infrastructure;
      target.fortLevel = cDto.fortLevel;
      target.hasSupplyHub = cDto.hasSupplyHub;
      target.supplied = cDto.supplied;
      target.victoryPoints = cDto.victoryPointsOwned;
      target.equipment = { ...cDto.equipment };
      target.productionAlloc = { ...cDto.productionAlloc };
      target.activeFocusId = cDto.activeFocusId;
      target.focusProgressDays = cDto.focusProgressDays;
      target.completedFocuses = [...cDto.completedFocuses];
      target.activeTechId = cDto.activeTechId;
      target.techProgressDays = cDto.techProgressDays;
      target.completedTechs = [...cDto.completedTechs];
      target.constructionQueue = cDto.constructionQueue.map((item) => ({ ...item }));
      target.trainingQueue = cDto.trainingQueue.map((item) => ({ ...item }));
      target.atWarWith = new Set(cDto.atWarWith);
      target.allies = new Set(cDto.allies);
      target.nonAggressionWith = new Set(cDto.nonAggressionWith);
      target.tradePactsWith = new Set(cDto.tradePactsWith);
      target.embargoed = new Set(cDto.embargoed);
      target.incomingAllyProposals = new Set(cDto.incomingAllyProposals);
      target.attackBonus = (cDto.attackBonusPct ?? 0) / 100;
      target.defenseBonus = (cDto.defenseBonusPct ?? 0) / 100;
      target.airSupremacyPct = cDto.airSupremacyPct;
    }
    host.state.divisions = snap.divisions.map((d) => ({
      ...d,
      pathQueue: d.targetProvinceId ? [d.targetProvinceId] : [],
    }));
    host.state.battles = new Map(snap.battles.map((b) => [b.id, { ...b }]));
    host.state.pendingEvents = snap.pendingEvents.map((e) => ({ ...e }));
    host.state.events = snap.events.map((e) => ({ ...e }));
    host.state.nextSeq = Math.max(
      host.state.nextSeq,
      snap.divisions.length + snap.events.length + 100,
    );
    return host;
  }

  addCommander(
    playerId: string,
    rawName: string,
    requestedNation?: string,
  ): { ok: boolean; error?: string; nationId: string | null; events: Hoi4OutgoingEvent[] } {
    const existing = this.state.players.get(playerId);
    if (existing) {
      return { ok: true, nationId: existing.nationId, events: [] };
    }
    if (this.state.players.size >= 12) {
      return {
        ok: false,
        error: `Theater ${this.state.code} is full (12/12 players).`,
        nationId: null,
        events: [],
      };
    }

    const cleanName = rawName.trim().slice(0, 18) || `Marshal-${this.state.players.size + 1}`;
    const color = PLAYER_COLORS[this.state.players.size % PLAYER_COLORS.length];
    this.state.players.set(playerId, {
      id: playerId,
      name: cleanName,
      nationId: null,
      color,
      ready: true,
    });

    let chosenIso: string | null = null;
    if (requestedNation && this.state.countries.has(requestedNation)) {
      const res = switchPlayerNation(this.state, playerId, requestedNation);
      if (res.ok) chosenIso = requestedNation;
    }
    if (!chosenIso) {
      const fallback = FEATURED_COUNTRY_IDS.find(
        (id) =>
          !this.state.countries.get(id)?.controllerPlayerId &&
          !this.state.countries.get(id)?.capitulated,
      );
      if (fallback) {
        switchPlayerNation(this.state, playerId, fallback);
        chosenIso = fallback;
      }
    }

    const snapshot = serializeCampaignSnapshot(this.state);
    return {
      ok: true,
      nationId: chosenIso,
      events: [
        {
          targetId: playerId,
          payload: {
            type: "hoi4:joined",
            playerId,
            nationId: chosenIso,
            snapshot,
          },
        },
      ],
    };
  }

  removeCommander(playerId: string) {
    const entry = this.state.players.get(playerId);
    if (!entry) return;
    if (entry.nationId) {
      const nat = this.state.countries.get(entry.nationId);
      if (nat && nat.controllerPlayerId === playerId) {
        nat.controllerPlayerId = null;
        nat.controllerName = null;
      }
    }
    this.state.players.delete(playerId);
    pushCampaignEvent(this.state, `${entry.name} left the theater.`, "info");
  }

  dispatchCommand(
    playerId: string,
    msg: Record<string, unknown>,
  ): { changed: boolean; error?: string } {
    return applyCampaignCommand(this.state, playerId, msg);
  }

  tick(): boolean {
    if (this.state.players.size === 0 || this.state.paused || this.state.winnerNationId) {
      return false;
    }
    stepCampaignSimulation(this.state, 1);
    return true;
  }

  getRoomSummaryMeta() {
    return {
      title: this.state.title,
      scenario: this.state.scenario,
      players: this.state.players.size,
      maxPlayers: 12,
      dateStr: formatCampaignDate(this.state.dayCount, this.state.hourAccum),
      speed: this.state.speed,
      paused: this.state.paused,
      worldTension: Math.round(this.state.worldTension),
    };
  }

  serializeSnapshot(): StrategySnapshot {
    return serializeCampaignSnapshot(this.state);
  }
}
