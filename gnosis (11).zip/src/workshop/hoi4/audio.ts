export class Hoi4AudioEngine {
  private ctx: AudioContext | null = null;
  private muted = false;
  private volume = 0.82;

  initOnGesture() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") this.ctx.resume().catch(() => {});
      return;
    }
    try {
      const AC =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AC) this.ctx = new AC();
    } catch {
      // Blocked
    }
  }

  setMuted(m: boolean) {
    this.muted = m;
  }

  setVolume(v: number) {
    this.volume = Math.max(0, Math.min(1, v));
  }

  playClick() {
    if (!this.ctx || this.muted || this.volume <= 0.001) return;
    try {
      const t = this.ctx.currentTime;
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      o.type = "triangle";
      o.frequency.setValueAtTime(520, t);
      o.frequency.exponentialRampToValueAtTime(220, t + 0.045);
      g.gain.setValueAtTime(0.055 * this.volume, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.05);
      o.connect(g).connect(this.ctx.destination);
      o.start(t);
      o.stop(t + 0.055);
    } catch {
      // Ignore
    }
  }

  playOrderMarch() {
    if (!this.ctx || this.muted || this.volume <= 0.001) return;
    try {
      const t = this.ctx.currentTime;
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      o.type = "sawtooth";
      o.frequency.setValueAtTime(140, t);
      o.frequency.exponentialRampToValueAtTime(95, t + 0.09);
      g.gain.setValueAtTime(0.06 * this.volume, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
      o.connect(g).connect(this.ctx.destination);
      o.start(t);
      o.stop(t + 0.11);
    } catch {
      // Ignore
    }
  }

  playWarHorn() {
    if (!this.ctx || this.muted || this.volume <= 0.001) return;
    try {
      const t = this.ctx.currentTime;
      for (const freq of [130.8, 196.0]) {
        const o = this.ctx.createOscillator();
        const g = this.ctx.createGain();
        o.type = "sawtooth";
        o.frequency.setValueAtTime(freq, t);
        o.frequency.linearRampToValueAtTime(freq * 0.96, t + 0.65);
        g.gain.setValueAtTime(0.001, t);
        g.gain.linearRampToValueAtTime(0.065 * this.volume, t + 0.08);
        g.gain.exponentialRampToValueAtTime(0.001, t + 0.68);
        o.connect(g).connect(this.ctx.destination);
        o.start(t);
        o.stop(t + 0.7);
      }
    } catch {
      // Ignore
    }
  }

  playChime() {
    if (!this.ctx || this.muted || this.volume <= 0.001) return;
    try {
      const t = this.ctx.currentTime;
      [440, 554.37, 659.25].forEach((freq, i) => {
        if (!this.ctx) return;
        const o = this.ctx.createOscillator();
        const g = this.ctx.createGain();
        o.type = "sine";
        o.frequency.setValueAtTime(freq, t + i * 0.06);
        g.gain.setValueAtTime(0.05 * this.volume, t + i * 0.06);
        g.gain.exponentialRampToValueAtTime(0.001, t + i * 0.06 + 0.25);
        o.connect(g).connect(this.ctx.destination);
        o.start(t + i * 0.06);
        o.stop(t + i * 0.06 + 0.27);
      });
    } catch {
      // Ignore
    }
  }

  dispose() {
    try {
      if (this.ctx && this.ctx.state !== "closed") {
        this.ctx.close().catch(() => {});
      }
    } catch {
      // Ignore
    }
    this.ctx = null;
  }
}
