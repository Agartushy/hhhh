import { WORLD_COUNTRIES, type WorldCountryGeo } from "./worldGeo.ts";

export type RegionId =
  | "europe"
  | "north-america"
  | "south-america"
  | "middle-east"
  | "africa"
  | "asia"
  | "oceania";

export type IdeologyId = "democratic" | "authoritarian" | "socialist" | "non-aligned";
export type TerrainType = "plains" | "forest" | "hills" | "mountain" | "desert" | "urban";
export type EquipmentType = "infantry" | "tanks" | "artillery" | "fighters";
export type UnitTemplateId = "infantry" | "armor" | "motorized" | "mountaineer";

export interface ResourceSet {
  steel: number;
  oil: number;
  rare: number;
  grain: number;
}

export interface CountrySpec {
  isoId: string;
  name: string;
  shortName: string;
  region: RegionId;
  capitalName: string;
  // Grounded approximate real-world reference figure (millions) for historical/geographic context
  refPopulationM: number;
  // Game simulation parameters (clearly separated from reference data in UI)
  color: string;
  borderColor: string;
  ideology: IdeologyId;
  featured: boolean;
  doctrine: string;
  terrain: TerrainType;
  vp: number;
  startCiv: number;
  startMil: number;
  startInfra: number; // 1..5
  startTreasury: number;
  startManpower: number;
  startStability: number;
  startWarSupport: number;
  resources: ResourceSet;
  attackMod: number;
  defenseMod: number;
  civOutputMod: number;
}

export const REGION_INFO: Record<
  RegionId,
  { label: string; color: string; focusX: number; focusY: number; focusZoom: number }
> = {
  europe: { label: "Europe", color: "#4e739e", focusX: 845, focusY: 185, focusZoom: 2.9 },
  "north-america": { label: "North America", color: "#50856d", focusX: 390, focusY: 225, focusZoom: 2.1 },
  "south-america": { label: "South America", color: "#768548", focusX: 540, focusY: 575, focusZoom: 2.2 },
  "middle-east": { label: "Middle East", color: "#9c7546", focusX: 985, focusY: 295, focusZoom: 3.1 },
  africa: { label: "Africa", color: "#8c6148", focusX: 880, focusY: 465, focusZoom: 2.0 },
  asia: { label: "Asia", color: "#914d55", focusX: 1215, focusY: 265, focusZoom: 2.1 },
  oceania: { label: "Oceania", color: "#4d8287", focusX: 1410, focusY: 590, focusZoom: 2.6 },
};

export const TERRAIN_INFO: Record<
  TerrainType,
  { label: string; color: string; defBonus: number; atkMult: number; speedMult: number }
> = {
  plains: { label: "Plains", color: "#5e7448", defBonus: 0, atkMult: 1.0, speedMult: 1.05 },
  forest: { label: "Forest & Taiga", color: "#3d5939", defBonus: 0.16, atkMult: 0.9, speedMult: 0.88 },
  hills: { label: "Highlands", color: "#6c6444", defBonus: 0.22, atkMult: 0.85, speedMult: 0.84 },
  mountain: { label: "Mountain Range", color: "#685c54", defBonus: 0.36, atkMult: 0.72, speedMult: 0.68 },
  desert: { label: "Arid & Steppe", color: "#8c744c", defBonus: 0.1, atkMult: 0.92, speedMult: 0.85 },
  urban: { label: "Metropolis Core", color: "#686266", defBonus: 0.28, atkMult: 0.84, speedMult: 0.92 },
};

export interface UnitTemplateSpec {
  id: UnitTemplateId;
  name: string;
  shortTag: string;
  iconType: "inf" | "tank" | "mot" | "mtn";
  maxHp: number;
  maxOrg: number;
  softAttack: number;
  hardAttack: number;
  defense: number;
  breakthrough: number;
  speed: number;
  manpowerCost: number;
  infEqCost: number;
  tankCost: number;
  artilleryCost: number;
  treasuryCost: number;
  trainDays: number;
  mountainBonus: number;
}

export const UNIT_TEMPLATES: Record<UnitTemplateId, UnitTemplateSpec> = {
  infantry: {
    id: "infantry",
    name: "Regular Infantry Corps",
    shortTag: "INF",
    iconType: "inf",
    maxHp: 100,
    maxOrg: 65,
    softAttack: 18,
    hardAttack: 7,
    defense: 27,
    breakthrough: 12,
    speed: 1.0,
    manpowerCost: 4000,
    infEqCost: 100,
    tankCost: 0,
    artilleryCost: 12,
    treasuryCost: 25,
    trainDays: 6,
    mountainBonus: 0,
  },
  armor: {
    id: "armor",
    name: "Heavy Armored Division",
    shortTag: "ARM",
    iconType: "tank",
    maxHp: 118,
    maxOrg: 56,
    softAttack: 29,
    hardAttack: 26,
    defense: 19,
    breakthrough: 36,
    speed: 1.65,
    manpowerCost: 3000,
    infEqCost: 60,
    tankCost: 40,
    artilleryCost: 15,
    treasuryCost: 55,
    trainDays: 10,
    mountainBonus: -0.08,
  },
  motorized: {
    id: "motorized",
    name: "Mechanized Rapid Brigade",
    shortTag: "MOT",
    iconType: "mot",
    maxHp: 100,
    maxOrg: 62,
    softAttack: 22,
    hardAttack: 13,
    defense: 23,
    breakthrough: 22,
    speed: 1.5,
    manpowerCost: 3500,
    infEqCost: 90,
    tankCost: 14,
    artilleryCost: 14,
    treasuryCost: 38,
    trainDays: 8,
    mountainBonus: 0,
  },
  mountaineer: {
    id: "mountaineer",
    name: "Alpine Expeditionary Unit",
    shortTag: "MTN",
    iconType: "mtn",
    maxHp: 104,
    maxOrg: 72,
    softAttack: 21,
    hardAttack: 8,
    defense: 30,
    breakthrough: 15,
    speed: 1.08,
    manpowerCost: 4200,
    infEqCost: 115,
    tankCost: 0,
    artilleryCost: 16,
    treasuryCost: 32,
    trainDays: 8,
    mountainBonus: 0.35,
  },
};

export interface FocusSpec {
  id: string;
  branch: "industry" | "military" | "diplomacy";
  name: string;
  summary: string;
  days: number;
  requires?: string[];
  effects: {
    pp?: number;
    treasury?: number;
    civ?: number;
    mil?: number;
    infra?: number;
    manpower?: number;
    stability?: number;
    warSupport?: number;
    infEq?: number;
    tanks?: number;
    fighters?: number;
    attackMod?: number;
    defenseMod?: number;
    researchSpeed?: number;
  };
}

export const NATIONAL_FOCUSES: FocusSpec[] = [
  {
    id: "ind_grid",
    branch: "industry",
    name: "National Industrial Grid",
    summary: "+2 Civilian Factories, +120 Treasury, +60 Political Power",
    days: 9,
    effects: { civ: 2, treasury: 120, pp: 60 },
  },
  {
    id: "ind_corridors",
    branch: "industry",
    name: "Trans-Continental Logistics",
    summary: "+1 Infrastructure Tier, +14% Research Speed, +7% Stability",
    days: 10,
    requires: ["ind_grid"],
    effects: { infra: 1, researchSpeed: 0.14, stability: 7 },
  },
  {
    id: "ind_mobilize",
    branch: "industry",
    name: "Strategic Reserve Mobilization",
    summary: "+3 Military Factories, +120,000 Manpower, +10% War Support",
    days: 11,
    requires: ["ind_corridors"],
    effects: { mil: 3, manpower: 120000, warSupport: 10 },
  },
  {
    id: "mil_doctrine",
    branch: "military",
    name: "Combined Arms Modernization",
    summary: "+2 Military Factories, +450 Infantry Gear, +100 Treasury",
    days: 9,
    effects: { mil: 2, infEq: 450, treasury: 100 },
  },
  {
    id: "mil_armor",
    branch: "military",
    name: "Armored Spearhead Doctrine",
    summary: "+100 Tanks, +12% Division Attack",
    days: 10,
    requires: ["mil_doctrine"],
    effects: { tanks: 100, attackMod: 0.12 },
  },
  {
    id: "mil_air",
    branch: "military",
    name: "Aerospace Defense Network",
    summary: "+80 Fighters, +10% Defense",
    days: 10,
    requires: ["mil_doctrine"],
    effects: { fighters: 80, defenseMod: 0.1 },
  },
  {
    id: "dip_summit",
    branch: "diplomacy",
    name: "Global Diplomatic Summit",
    summary: "+110 Political Power, +10% Stability, +150 Treasury",
    days: 8,
    effects: { pp: 110, stability: 10, treasury: 150 },
  },
  {
    id: "dip_bastion",
    branch: "diplomacy",
    name: "Sovereign Defense Charter",
    summary: "+12% Core Defense, +90k Manpower, +8% War Support",
    days: 10,
    requires: ["dip_summit"],
    effects: { defenseMod: 0.12, manpower: 90000, warSupport: 8 },
  },
];

export interface TechSpec {
  id: string;
  name: string;
  category: "infantry" | "armor" | "doctrine" | "industry";
  days: number;
  summary: string;
  attackBonus?: number;
  defenseBonus?: number;
  armorBonus?: number;
  supplyBonus?: number;
  civSpeedBonus?: number;
  maxOrgBonus?: number;
}

export const TECH_ITEMS: TechSpec[] = [
  {
    id: "tech_infantry_2",
    name: "Modular Small Arms",
    category: "infantry",
    days: 10,
    summary: "+10% Division Attack & +8% Defense",
    attackBonus: 0.1,
    defenseBonus: 0.08,
  },
  {
    id: "tech_armor_composite",
    name: "Composite Armor Plating",
    category: "armor",
    days: 12,
    summary: "+16% Armored Breakthrough",
    armorBonus: 0.16,
  },
  {
    id: "tech_c4i_comms",
    name: "Encrypted Field C4I",
    category: "doctrine",
    days: 9,
    summary: "+10 Max Division Organization",
    maxOrgBonus: 10,
  },
  {
    id: "tech_logistics_rail",
    name: "Automated Freight Corridors",
    category: "industry",
    days: 10,
    summary: "+20% Supply Reach & +14% Construction Speed",
    supplyBonus: 0.2,
    civSpeedBonus: 0.14,
  },
  {
    id: "tech_precision_arty",
    name: "Precision Fire Control",
    category: "infantry",
    days: 11,
    summary: "+14% Division Attack",
    attackBonus: 0.14,
  },
  {
    id: "tech_advanced_tooling",
    name: "Distributed Manufacturing",
    category: "industry",
    days: 11,
    summary: "+22% Factory & Resource Output",
    civSpeedBonus: 0.22,
  },
];

export interface StrategicEventTemplate {
  id: string;
  title: string;
  description: string;
  choices: {
    id: string;
    label: string;
    summary: string;
    ppDelta?: number;
    treasuryDelta?: number;
    stabilityDelta?: number;
    warSupportDelta?: number;
    manpowerDelta?: number;
    civDelta?: number;
    milDelta?: number;
    infEqDelta?: number;
  }[];
}

export const STRATEGIC_EVENTS: StrategicEventTemplate[] = [
  {
    id: "ev_energy_compact",
    title: "Global Energy Corridor Summit",
    description:
      "International energy consortia propose joint pipeline and maritime refinery investments across your borders.",
    choices: [
      {
        id: "sign_compact",
        label: "Ratify Energy Compact",
        summary: "+180 Treasury · +1 Civilian Factory · -5 Political Power",
        treasuryDelta: 180,
        civDelta: 1,
        ppDelta: -5,
      },
      {
        id: "strategic_reserves",
        label: "Stockpile Domestic Reserves",
        summary: "+5% Stability · +400 Infantry Gear · +25 Political Power",
        stabilityDelta: 5,
        infEqDelta: 400,
        ppDelta: 25,
      },
    ],
  },
  {
    id: "ev_industrial_boom",
    title: "Domestic Manufacturing Initiative",
    description:
      "Heavy engineering syndicates request state subsidies to expand either consumer industry or defense assembly lines.",
    choices: [
      {
        id: "expand_civilian",
        label: "Subsidize Civil Grid",
        summary: "+1 Civilian Factory · +120 Treasury · +4% Stability",
        civDelta: 1,
        treasuryDelta: 120,
        stabilityDelta: 4,
      },
      {
        id: "expand_defense",
        label: "Commission Defense Plants",
        summary: "+1 Military Factory · +6% War Support · -60 Treasury",
        milDelta: 1,
        warSupportDelta: 6,
        treasuryDelta: -60,
      },
    ],
  },
  {
    id: "ev_diplomatic_dispatch",
    title: "Border Security Crisis",
    description:
      "Heightened strategic tensions along key trade chokepoints force your cabinet to set an immediate posture.",
    choices: [
      {
        id: "deescalate",
        label: "Lead Diplomatic Mediation",
        summary: "+60 Political Power · +6% Stability",
        ppDelta: 60,
        stabilityDelta: 6,
      },
      {
        id: "mobilize_guard",
        label: "Activate Reserve Corps",
        summary: "+90,000 Manpower · +8% War Support",
        manpowerDelta: 90000,
        warSupportDelta: 8,
      },
    ],
  },
  {
    id: "ev_maritime_trade",
    title: "Maritime Trade Charter",
    description:
      "Merchant fleets await naval escort guarantees along international shipping lanes.",
    choices: [
      {
        id: "open_ports",
        label: "Establish Free Port Zones",
        summary: "+220 Treasury · +30 Political Power",
        treasuryDelta: 220,
        ppDelta: 30,
      },
      {
        id: "convoy_escorts",
        label: "Nationalize Logistics Fleets",
        summary: "+350 Infantry Gear · +5% War Support · +100 Treasury",
        infEqDelta: 350,
        warSupportDelta: 5,
        treasuryDelta: 100,
      },
    ],
  },
];

interface CuratedProfile {
  short: string;
  region: RegionId;
  capital: string;
  refPopM: number;
  color: string;
  ideology: IdeologyId;
  featured: boolean;
  doctrine: string;
  terrain: TerrainType;
  vp: number;
  civ: number;
  mil: number;
  infra: number;
  resources: ResourceSet;
  atkMod?: number;
  defMod?: number;
}

const CURATED_PROFILES: Record<string, CuratedProfile> = {
  "840": { short: "USA", region: "north-america", capital: "Washington, D.C.", refPopM: 335, color: "#3464a3", ideology: "democratic", featured: true, doctrine: "Global Expeditionary", terrain: "urban", vp: 36, civ: 10, mil: 8, infra: 5, resources: { steel: 42, oil: 46, rare: 26, grain: 52 }, atkMod: 1.08, defMod: 1.06 },
  "124": { short: "CAN", region: "north-america", capital: "Ottawa", refPopM: 40, color: "#9e4b45", ideology: "democratic", featured: true, doctrine: "Northern Bastion", terrain: "forest", vp: 18, civ: 5, mil: 3, infra: 4, resources: { steel: 18, oil: 28, rare: 22, grain: 26 } },
  "484": { short: "MEX", region: "north-america", capital: "Mexico City", refPopM: 129, color: "#3e7d58", ideology: "democratic", featured: true, doctrine: "Cordillera Guard", terrain: "hills", vp: 18, civ: 4, mil: 3, infra: 3, resources: { steel: 12, oil: 18, rare: 12, grain: 16 } },
  "076": { short: "BRA", region: "south-america", capital: "Brasilia", refPopM: 216, color: "#3c8549", ideology: "democratic", featured: true, doctrine: "Continental Shield", terrain: "forest", vp: 24, civ: 6, mil: 4, infra: 3, resources: { steel: 24, oil: 18, rare: 24, grain: 38 } },
  "032": { short: "ARG", region: "south-america", capital: "Buenos Aires", refPopM: 46, color: "#5c92b8", ideology: "democratic", featured: true, doctrine: "Southern Cross", terrain: "plains", vp: 16, civ: 4, mil: 2, infra: 3, resources: { steel: 8, oil: 12, rare: 14, grain: 30 } },
  "170": { short: "COL", region: "south-america", capital: "Bogota", refPopM: 52, color: "#b38e3d", ideology: "democratic", featured: false, doctrine: "Andean Watch", terrain: "mountain", vp: 12, civ: 3, mil: 2, infra: 2, resources: { steel: 6, oil: 14, rare: 10, grain: 14 } },
  "152": { short: "CHL", region: "south-america", capital: "Santiago", refPopM: 20, color: "#4e6d9c", ideology: "democratic", featured: false, doctrine: "Pacific Ridge", terrain: "mountain", vp: 12, civ: 3, mil: 2, infra: 3, resources: { steel: 10, oil: 3, rare: 24, grain: 10 } },
  "826": { short: "GBR", region: "europe", capital: "London", refPopM: 68, color: "#b54848", ideology: "democratic", featured: true, doctrine: "Maritime Supremacy", terrain: "urban", vp: 30, civ: 8, mil: 6, infra: 5, resources: { steel: 22, oil: 14, rare: 14, grain: 14 }, defMod: 1.1 },
  "250": { short: "FRA", region: "europe", capital: "Paris", refPopM: 68, color: "#3d6cb8", ideology: "democratic", featured: true, doctrine: "Combined Doctrine", terrain: "urban", vp: 28, civ: 7, mil: 6, infra: 5, resources: { steel: 20, oil: 6, rare: 14, grain: 26 }, defMod: 1.08 },
  "276": { short: "DEU", region: "europe", capital: "Berlin", refPopM: 84, color: "#5f6c7a", ideology: "democratic", featured: true, doctrine: "Precision Mechanized", terrain: "urban", vp: 32, civ: 9, mil: 6, infra: 5, resources: { steel: 30, oil: 5, rare: 16, grain: 20 }, atkMod: 1.1 },
  "380": { short: "ITA", region: "europe", capital: "Rome", refPopM: 59, color: "#4a784c", ideology: "democratic", featured: true, doctrine: "Mediterranean Bastion", terrain: "hills", vp: 24, civ: 6, mil: 4, infra: 4, resources: { steel: 14, oil: 5, rare: 10, grain: 18 } },
  "724": { short: "ESP", region: "europe", capital: "Madrid", refPopM: 48, color: "#c29238", ideology: "democratic", featured: true, doctrine: "Iberian Watch", terrain: "hills", vp: 20, civ: 5, mil: 3, infra: 4, resources: { steel: 12, oil: 3, rare: 10, grain: 16 } },
  "620": { short: "PRT", region: "europe", capital: "Lisbon", refPopM: 10, color: "#437558", ideology: "democratic", featured: false, doctrine: "Atlantic Port", terrain: "hills", vp: 10, civ: 3, mil: 2, infra: 3, resources: { steel: 4, oil: 2, rare: 6, grain: 8 } },
  "616": { short: "POL", region: "europe", capital: "Warsaw", refPopM: 38, color: "#a64c69", ideology: "democratic", featured: true, doctrine: "Eastern Frontier", terrain: "plains", vp: 22, civ: 5, mil: 4, infra: 4, resources: { steel: 14, oil: 4, rare: 10, grain: 20 }, defMod: 1.12 },
  "804": { short: "UKR", region: "europe", capital: "Kyiv", refPopM: 37, color: "#4b85ad", ideology: "democratic", featured: true, doctrine: "Steppe Resilience", terrain: "plains", vp: 22, civ: 4, mil: 5, infra: 3, resources: { steel: 18, oil: 6, rare: 12, grain: 32 }, defMod: 1.12 },
  "752": { short: "SWE", region: "europe", capital: "Stockholm", refPopM: 10.5, color: "#467f99", ideology: "democratic", featured: false, doctrine: "Nordic Defense", terrain: "forest", vp: 14, civ: 4, mil: 3, infra: 4, resources: { steel: 22, oil: 2, rare: 14, grain: 10 } },
  "578": { short: "NOR", region: "europe", capital: "Oslo", refPopM: 5.5, color: "#58739e", ideology: "democratic", featured: false, doctrine: "Fjord Guard", terrain: "mountain", vp: 12, civ: 3, mil: 2, infra: 4, resources: { steel: 6, oil: 24, rare: 8, grain: 6 } },
  "246": { short: "FIN", region: "europe", capital: "Helsinki", refPopM: 5.6, color: "#68899c", ideology: "democratic", featured: false, doctrine: "Winter Fortification", terrain: "forest", vp: 12, civ: 3, mil: 3, infra: 4, resources: { steel: 8, oil: 1, rare: 10, grain: 8 }, defMod: 1.14 },
  "300": { short: "GRC", region: "europe", capital: "Athens", refPopM: 10.4, color: "#527da8", ideology: "democratic", featured: false, doctrine: "Aegean Watch", terrain: "mountain", vp: 12, civ: 3, mil: 2, infra: 3, resources: { steel: 6, oil: 2, rare: 8, grain: 8 } },
  "642": { short: "ROU", region: "europe", capital: "Bucharest", refPopM: 19, color: "#8c723e", ideology: "democratic", featured: false, doctrine: "Carpathian Line", terrain: "hills", vp: 14, civ: 3, mil: 3, infra: 3, resources: { steel: 8, oil: 10, rare: 6, grain: 16 } },
  "643": { short: "RUS", region: "europe", capital: "Moscow", refPopM: 144, color: "#8c3535", ideology: "authoritarian", featured: true, doctrine: "Deep Echelon", terrain: "forest", vp: 36, civ: 8, mil: 8, infra: 4, resources: { steel: 38, oil: 44, rare: 30, grain: 36 }, defMod: 1.08 },
  "792": { short: "TUR", region: "middle-east", capital: "Ankara", refPopM: 85, color: "#a15843", ideology: "non-aligned", featured: true, doctrine: "Straits Sentinel", terrain: "mountain", vp: 24, civ: 6, mil: 5, infra: 4, resources: { steel: 16, oil: 8, rare: 14, grain: 22 } },
  "818": { short: "EGY", region: "middle-east", capital: "Cairo", refPopM: 112, color: "#9e7e46", ideology: "non-aligned", featured: true, doctrine: "Suez Command", terrain: "desert", vp: 20, civ: 4, mil: 4, infra: 3, resources: { steel: 8, oil: 14, rare: 8, grain: 18 } },
  "682": { short: "SAU", region: "middle-east", capital: "Riyadh", refPopM: 37, color: "#3d7a55", ideology: "authoritarian", featured: true, doctrine: "Gulf Shield", terrain: "desert", vp: 20, civ: 5, mil: 4, infra: 4, resources: { steel: 6, oil: 48, rare: 8, grain: 6 } },
  "364": { short: "IRN", region: "middle-east", capital: "Tehran", refPopM: 89, color: "#688255", ideology: "authoritarian", featured: true, doctrine: "Zagros Bastion", terrain: "mountain", vp: 20, civ: 4, mil: 4, infra: 3, resources: { steel: 12, oil: 32, rare: 12, grain: 14 } },
  "376": { short: "ISR", region: "middle-east", capital: "Jerusalem", refPopM: 9.8, color: "#4d78ab", ideology: "democratic", featured: false, doctrine: "Precision Strike", terrain: "hills", vp: 14, civ: 4, mil: 4, infra: 4, resources: { steel: 6, oil: 3, rare: 10, grain: 6 }, atkMod: 1.1 },
  "566": { short: "NGA", region: "africa", capital: "Abuja", refPopM: 224, color: "#3d855b", ideology: "democratic", featured: true, doctrine: "West African Pivot", terrain: "plains", vp: 18, civ: 4, mil: 3, infra: 2, resources: { steel: 8, oil: 24, rare: 12, grain: 24 } },
  "231": { short: "ETH", region: "africa", capital: "Addis Ababa", refPopM: 126, color: "#6e8744", ideology: "non-aligned", featured: false, doctrine: "Highland Guard", terrain: "mountain", vp: 14, civ: 3, mil: 3, infra: 2, resources: { steel: 4, oil: 2, rare: 8, grain: 18 } },
  "710": { short: "ZAF", region: "africa", capital: "Pretoria", refPopM: 60, color: "#558258", ideology: "democratic", featured: true, doctrine: "Cape Horizon", terrain: "hills", vp: 18, civ: 4, mil: 3, infra: 3, resources: { steel: 16, oil: 4, rare: 26, grain: 16 } },
  "012": { short: "DZA", region: "africa", capital: "Algiers", refPopM: 46, color: "#477859", ideology: "non-aligned", featured: false, doctrine: "Maghreb Sentinel", terrain: "desert", vp: 14, civ: 3, mil: 3, infra: 3, resources: { steel: 6, oil: 20, rare: 8, grain: 10 } },
  "504": { short: "MAR", region: "africa", capital: "Rabat", refPopM: 38, color: "#9c4743", ideology: "non-aligned", featured: false, doctrine: "Atlas Watch", terrain: "hills", vp: 12, civ: 3, mil: 2, infra: 3, resources: { steel: 6, oil: 2, rare: 14, grain: 12 } },
  "356": { short: "IND", region: "asia", capital: "New Delhi", refPopM: 1428, color: "#b5723c", ideology: "democratic", featured: true, doctrine: "Subcontinent Mass", terrain: "plains", vp: 32, civ: 8, mil: 7, infra: 4, resources: { steel: 32, oil: 12, rare: 22, grain: 48 } },
  "586": { short: "PAK", region: "asia", capital: "Islamabad", refPopM: 240, color: "#3d704c", ideology: "non-aligned", featured: false, doctrine: "Indus Guard", terrain: "hills", vp: 16, civ: 3, mil: 4, infra: 3, resources: { steel: 8, oil: 4, rare: 8, grain: 22 } },
  "156": { short: "CHN", region: "asia", capital: "Beijing", refPopM: 1410, color: "#ab423a", ideology: "socialist", featured: true, doctrine: "Industrial Scale", terrain: "hills", vp: 36, civ: 10, mil: 8, infra: 5, resources: { steel: 44, oil: 20, rare: 46, grain: 48 }, civMod: 1.12 } as CuratedProfile & { civMod?: number },
  "392": { short: "JPN", region: "asia", capital: "Tokyo", refPopM: 124, color: "#b55d6e", ideology: "democratic", featured: true, doctrine: "Archipelago Fleet", terrain: "urban", vp: 28, civ: 8, mil: 5, infra: 5, resources: { steel: 22, oil: 3, rare: 18, grain: 14 }, defMod: 1.08 },
  "410": { short: "KOR", region: "asia", capital: "Seoul", refPopM: 52, color: "#4b7ab3", ideology: "democratic", featured: true, doctrine: "Peninsula Shield", terrain: "hills", vp: 24, civ: 6, mil: 5, infra: 5, resources: { steel: 18, oil: 2, rare: 14, grain: 10 }, defMod: 1.1 },
  "158": { short: "TWN", region: "asia", capital: "Taipei", refPopM: 23.9, color: "#3d7999", ideology: "democratic", featured: false, doctrine: "Strait Bastion", terrain: "mountain", vp: 18, civ: 5, mil: 4, infra: 5, resources: { steel: 8, oil: 1, rare: 20, grain: 6 }, defMod: 1.16 },
  "704": { short: "VNM", region: "asia", capital: "Hanoi", refPopM: 99, color: "#8c4242", ideology: "socialist", featured: false, doctrine: "Asymmetric Defense", terrain: "forest", vp: 16, civ: 4, mil: 3, infra: 3, resources: { steel: 8, oil: 8, rare: 14, grain: 20 }, defMod: 1.12 },
  "764": { short: "THA", region: "asia", capital: "Bangkok", refPopM: 72, color: "#5b6a94", ideology: "non-aligned", featured: false, doctrine: "Chao Phraya Watch", terrain: "plains", vp: 14, civ: 4, mil: 3, infra: 3, resources: { steel: 6, oil: 6, rare: 10, grain: 22 } },
  "360": { short: "IDN", region: "asia", capital: "Jakarta", refPopM: 277, color: "#9e5148", ideology: "democratic", featured: true, doctrine: "Archipelago Network", terrain: "forest", vp: 20, civ: 5, mil: 4, infra: 3, resources: { steel: 14, oil: 16, rare: 24, grain: 26 } },
  "608": { short: "PHL", region: "asia", capital: "Manila", refPopM: 117, color: "#4e6d9e", ideology: "democratic", featured: false, doctrine: "Island Watch", terrain: "hills", vp: 14, civ: 3, mil: 2, infra: 3, resources: { steel: 6, oil: 2, rare: 14, grain: 16 } },
  "398": { short: "KAZ", region: "asia", capital: "Astana", refPopM: 20, color: "#4f8d9c", ideology: "non-aligned", featured: false, doctrine: "Steppe Corridor", terrain: "desert", vp: 14, civ: 3, mil: 2, infra: 3, resources: { steel: 16, oil: 22, rare: 20, grain: 16 } },
  "036": { short: "AUS", region: "oceania", capital: "Canberra", refPopM: 26.5, color: "#4b8a6f", ideology: "democratic", featured: true, doctrine: "Southern Alliance", terrain: "desert", vp: 22, civ: 6, mil: 4, infra: 4, resources: { steel: 28, oil: 12, rare: 30, grain: 22 } },
  "554": { short: "NZL", region: "oceania", capital: "Wellington", refPopM: 5.2, color: "#447378", ideology: "democratic", featured: false, doctrine: "Tasman Sentinel", terrain: "hills", vp: 10, civ: 3, mil: 2, infra: 4, resources: { steel: 4, oil: 2, rare: 6, grain: 12 } },
};

const PALETTE_SWATCHES = [
  "#4c6d8a",
  "#5a7d56",
  "#856d49",
  "#7b5575",
  "#4b7d7c",
  "#8f534b",
  "#6d7548",
  "#5a6385",
  "#7d6654",
];

function inferRegion(geo: WorldCountryGeo): RegionId {
  const { lon, lat } = geo;
  if (lon < -30) {
    return lat >= 12 ? "north-america" : "south-america";
  }
  if (lon >= 110 && lat < -10) return "oceania";
  if (lon >= 34 && lon <= 62 && lat >= 12 && lat <= 42) return "middle-east";
  if (lon >= -20 && lon <= 52 && lat < 37) return "africa";
  if (lon >= -25 && lon <= 65 && lat >= 35) return "europe";
  return "asia";
}

function hashString(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

function makeShortName(name: string): string {
  const clean = name.replace(/[^a-zA-Z ]/g, "").trim();
  const words = clean.split(/\s+/).filter(Boolean);
  if (words.length >= 3) {
    return (words[0][0] + words[1][0] + words[2][0]).toUpperCase();
  }
  return clean.replace(/\s+/g, "").slice(0, 3).toUpperCase().padEnd(3, "X");
}

function buildCountryCatalog(): {
  countries: CountrySpec[];
  byId: Record<string, CountrySpec>;
  featuredIds: string[];
} {
  const countries: CountrySpec[] = [];
  const byId: Record<string, CountrySpec> = {};
  const featuredIds: string[] = [];

  for (const geo of WORLD_COUNTRIES) {
    const cur = CURATED_PROFILES[geo.isoId];
    const h = hashString(geo.isoId);
    const region = cur ? cur.region : inferRegion(geo);

    let areaApprox = 0;
    for (const p of geo.polygons) {
      areaApprox += (p.bbox[2] - p.bbox[0]) * (p.bbox[3] - p.bbox[1]);
    }
    const sizeTier = Math.max(1, Math.min(4, Math.round(Math.sqrt(areaApprox) / 18) + 1));

    const refPopM = cur
      ? cur.refPopM
      : Number(Math.max(1.2, Math.min(85, sizeTier * 7 + (h % 14))).toFixed(1));

    const civ = cur ? cur.civ : Math.max(1, Math.min(4, sizeTier));
    const mil = cur ? cur.mil : Math.max(1, Math.min(3, Math.ceil(sizeTier * 0.7)));
    const infra = cur ? cur.infra : region === "europe" || region === "north-america" ? 3 : 2;
    const terrain: TerrainType = cur
      ? cur.terrain
      : region === "middle-east"
        ? "desert"
        : region === "africa"
          ? h % 2 === 0
            ? "plains"
            : "hills"
          : region === "south-america"
            ? "forest"
            : h % 3 === 0
              ? "hills"
              : "plains";

    const spec: CountrySpec = {
      isoId: geo.isoId,
      name: geo.name,
      shortName: cur ? cur.short : makeShortName(geo.name),
      region,
      capitalName: cur ? cur.capital : `${geo.name.split(" ")[0]} Capital`,
      refPopulationM: refPopM,
      color: cur ? cur.color : PALETTE_SWATCHES[h % PALETTE_SWATCHES.length],
      borderColor: "#d6c39c",
      ideology: cur ? cur.ideology : "non-aligned",
      featured: Boolean(cur?.featured),
      doctrine: cur ? cur.doctrine : "Regional Defense",
      terrain,
      vp: cur ? cur.vp : 6 + sizeTier * 2,
      startCiv: civ,
      startMil: mil,
      startInfra: infra,
      startTreasury: 80 + civ * 32,
      startManpower: Math.round(Math.max(120_000, refPopM * 11_000)),
      startStability: cur?.featured ? 74 : 68 + (h % 14),
      startWarSupport: cur?.featured ? 62 : 44 + (h % 18),
      resources: cur
        ? cur.resources
        : {
            steel: 3 + (h % 8),
            oil: region === "middle-east" ? 10 + (h % 12) : 1 + (h % 5),
            rare: 2 + ((h >> 3) % 7),
            grain: 5 + ((h >> 5) % 10),
          },
      attackMod: cur?.atkMod ?? 1.0,
      defenseMod: cur?.defMod ?? 1.0,
      civOutputMod: 1.0,
    };

    countries.push(spec);
    byId[spec.isoId] = spec;
    if (spec.featured) featuredIds.push(spec.isoId);
  }

  return { countries, byId, featuredIds };
}

const CATALOG = buildCountryCatalog();
export const WORLD_COUNTRY_SPECS = CATALOG.countries;
export const COUNTRIES_BY_ID = CATALOG.byId;
export const FEATURED_COUNTRY_IDS = CATALOG.featuredIds;
