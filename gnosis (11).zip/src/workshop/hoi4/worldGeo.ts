import countriesTopology from "world-atlas/countries-110m.json" with { type: "json" };
import { feature, neighbors } from "topojson-client";

export const WORLD_MAP_W = 1600;
export const WORLD_MAP_H = 820;

export interface GeoCountryPolygon {
  rings: [number, number][][]; // Projected [x, y] in 1600x820 world space
  bbox: [number, number, number, number]; // [minX, minY, maxX, maxY]
}

export interface WorldCountryGeo {
  isoId: string; // ISO 3166-1 numeric code string e.g. "840"
  name: string;
  lon: number;
  lat: number;
  x: number;
  y: number;
  polygons: GeoCountryPolygon[];
  landNeighbors: string[]; // ISO IDs of land-bordering countries
  seaNeighbors: string[]; // ISO IDs of strategic sea-lane links
  allNeighbors: string[];
  isCoastal: boolean;
}

export function projectLonLat(lon: number, lat: number): [number, number] {
  const x = ((lon + 180) / 360) * WORLD_MAP_W;
  // Slightly trim extreme poles (-60..84) for balanced grand-strategy framing
  const clampedLat = Math.max(-58, Math.min(83, lat));
  const y = ((83 - clampedLat) / 141) * WORLD_MAP_H;
  return [x, y];
}

function splitRingAtAntimeridian(ring: number[][]): [number, number][][] {
  const segments: [number, number][][] = [];
  let current: [number, number][] = [];

  for (let i = 0; i < ring.length; i++) {
    const [lon, lat] = ring[i];
    if (i > 0) {
      const prevLon = ring[i - 1][0];
      if (Math.abs(lon - prevLon) > 170) {
        if (current.length >= 3) segments.push(current);
        current = [];
      }
    }
    current.push(projectLonLat(lon, lat));
  }
  if (current.length >= 3) segments.push(current);
  return segments;
}

function ringAreaAndCentroid(ring: [number, number][]): {
  area: number;
  cx: number;
  cy: number;
} {
  let area = 0;
  let cx = 0;
  let cy = 0;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const [x0, y0] = ring[j];
    const [x1, y1] = ring[i];
    const f = x0 * y1 - x1 * y0;
    area += f;
    cx += (x0 + x1) * f;
    cy += (y0 + y1) * f;
  }
  area *= 0.5;
  if (Math.abs(area) < 1e-4) {
    let sx = 0;
    let sy = 0;
    for (const p of ring) {
      sx += p[0];
      sy += p[1];
    }
    const n = Math.max(1, ring.length);
    return { area: 0.01, cx: sx / n, cy: sy / n };
  }
  return {
    area: Math.abs(area),
    cx: cx / (6 * area),
    cy: cy / (6 * area),
  };
}

// Curated capital coordinates [lon, lat] for accurate label & capital placement
const CURATED_CAPITAL_COORDS: Record<string, [number, number]> = {
  "840": [-77.03, 38.9], // USA - Washington DC
  "124": [-75.69, 45.42], // Canada - Ottawa
  "484": [-99.13, 19.43], // Mexico - Mexico City
  "076": [-47.93, -15.79], // Brazil - Brasilia
  "032": [-58.38, -34.6], // Argentina - Buenos Aires
  "152": [-70.66, -33.45], // Chile - Santiago
  "170": [-74.07, 4.71], // Colombia - Bogota
  "826": [-0.12, 51.5], // UK - London
  "250": [2.35, 48.85], // France - Paris
  "276": [13.4, 52.52], // Germany - Berlin
  "380": [12.49, 41.9], // Italy - Rome
  "724": [-3.7, 40.41], // Spain - Madrid
  "620": [-9.14, 38.72], // Portugal - Lisbon
  "528": [4.9, 52.37], // Netherlands - Amsterdam
  "056": [4.35, 50.85], // Belgium - Brussels
  "756": [7.45, 46.95], // Switzerland - Bern
  "040": [16.37, 48.21], // Austria - Vienna
  "616": [21.01, 52.23], // Poland - Warsaw
  "203": [14.43, 50.07], // Czechia - Prague
  "752": [18.06, 59.33], // Sweden - Stockholm
  "578": [10.75, 59.91], // Norway - Oslo
  "246": [24.94, 60.17], // Finland - Helsinki
  "208": [12.56, 55.67], // Denmark - Copenhagen
  "804": [30.52, 50.45], // Ukraine - Kyiv
  "642": [26.1, 44.43], // Romania - Bucharest
  "300": [23.72, 37.98], // Greece - Athens
  "643": [37.62, 55.75], // Russia - Moscow
  "792": [32.85, 39.93], // Turkey - Ankara
  "818": [31.23, 30.04], // Egypt - Cairo
  "682": [46.67, 24.71], // Saudi Arabia - Riyadh
  "364": [51.39, 35.69], // Iran - Tehran
  "368": [44.36, 33.31], // Iraq - Baghdad
  "376": [35.21, 31.77], // Israel - Jerusalem
  "566": [7.49, 9.07], // Nigeria - Abuja
  "231": [38.75, 9.03], // Ethiopia - Addis Ababa
  "404": [36.82, -1.29], // Kenya - Nairobi
  "710": [28.19, -25.75], // South Africa - Pretoria
  "504": [-6.84, 34.02], // Morocco - Rabat
  "012": [3.05, 36.75], // Algeria - Algiers
  "356": [77.21, 28.61], // India - New Delhi
  "586": [73.04, 33.68], // Pakistan - Islamabad
  "050": [90.41, 23.81], // Bangladesh - Dhaka
  "156": [116.4, 39.9], // China - Beijing
  "392": [139.69, 35.69], // Japan - Tokyo
  "410": [126.97, 37.56], // South Korea - Seoul
  "408": [125.76, 39.03], // North Korea - Pyongyang
  "158": [121.56, 25.03], // Taiwan - Taipei
  "704": [105.85, 21.02], // Vietnam - Hanoi
  "764": [100.5, 13.75], // Thailand - Bangkok
  "360": [106.84, -6.2], // Indonesia - Jakarta
  "608": [120.98, 14.6], // Philippines - Manila
  "458": [101.68, 3.14], // Malaysia - Kuala Lumpur
  "036": [149.13, -35.28], // Australia - Canberra
  "554": [174.77, -41.29], // New Zealand - Wellington
  "398": [71.45, 51.16], // Kazakhstan - Astana
};

// Strategic maritime corridors connecting islands & overseas theaters
const SEA_LANE_PAIRS: [string, string][] = [
  ["826", "250"], // UK - France
  ["826", "372"], // UK - Ireland
  ["826", "578"], // UK - Norway
  ["826", "840"], // UK - USA
  ["826", "124"], // UK - Canada
  ["208", "752"], // Denmark - Sweden
  ["208", "578"], // Denmark - Norway
  ["380", "788"], // Italy - Tunisia
  ["380", "300"], // Italy - Greece
  ["724", "504"], // Spain - Morocco
  ["300", "818"], // Greece - Egypt
  ["300", "792"], // Greece - Turkey
  ["792", "804"], // Turkey - Ukraine
  ["840", "192"], // USA - Cuba
  ["840", "392"], // USA - Japan
  ["392", "410"], // Japan - South Korea
  ["392", "156"], // Japan - China
  ["392", "158"], // Japan - Taiwan
  ["392", "608"], // Japan - Philippines
  ["156", "158"], // China - Taiwan
  ["158", "608"], // Taiwan - Philippines
  ["608", "360"], // Philippines - Indonesia
  ["360", "458"], // Indonesia - Malaysia
  ["360", "036"], // Indonesia - Australia
  ["036", "554"], // Australia - New Zealand
  ["356", "144"], // India - Sri Lanka
  ["356", "682"], // India - Saudi Arabia
  ["682", "818"], // Saudi Arabia - Egypt
  ["076", "620"], // Brazil - Portugal
  ["076", "566"], // Brazil - Nigeria
  ["710", "450"], // South Africa - Madagascar
];

function buildWorldCountries(): {
  countries: WorldCountryGeo[];
  byId: Record<string, WorldCountryGeo>;
} {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const topo = countriesTopology as any;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const fc = feature(topo, topo.objects.countries) as any;
  const rawGeoms = topo.objects.countries.geometries as Parameters<typeof neighbors>[0];
  const neighborIndexes = neighbors(rawGeoms);

  const indexToIso = new Map<number, string>();
  for (let i = 0; i < fc.features.length; i++) {
    const f = fc.features[i];
    const isoId = String(f.id ?? rawGeoms[i]?.id ?? i).padStart(3, "0");
    indexToIso.set(i, isoId);
  }

  const countries: WorldCountryGeo[] = [];
  const byId: Record<string, WorldCountryGeo> = {};

  for (let i = 0; i < fc.features.length; i++) {
    const f = fc.features[i];
    const isoId = indexToIso.get(i)!;
    // Skip Antarctica (010) to keep the grand strategy map focused on inhabited nations
    if (isoId === "010") continue;
    const name = String(f.properties?.name || `Territory ${isoId}`);
    const geom = f.geometry;
    if (!geom) continue;

    const polygonCoords: number[][][][] =
      geom.type === "Polygon" ? [geom.coordinates] : geom.type === "MultiPolygon" ? geom.coordinates : [];

    const polygons: GeoCountryPolygon[] = [];
    let bestArea = -1;
    let bestCx = WORLD_MAP_W / 2;
    let bestCy = WORLD_MAP_H / 2;

    for (const poly of polygonCoords) {
      const rings: [number, number][][] = [];
      for (const rawRing of poly) {
        const split = splitRingAtAntimeridian(rawRing);
        for (const seg of split) {
          rings.push(seg);
        }
      }
      if (rings.length === 0) continue;

      let minX = Infinity;
      let minY = Infinity;
      let maxX = -Infinity;
      let maxY = -Infinity;
      for (const r of rings) {
        for (const [px, py] of r) {
          if (px < minX) minX = px;
          if (py < minY) minY = py;
          if (px > maxX) maxX = px;
          if (py > maxY) maxY = py;
        }
      }
      const { area, cx, cy } = ringAreaAndCentroid(rings[0]);
      if (area > bestArea) {
        bestArea = area;
        bestCx = cx;
        bestCy = cy;
      }
      polygons.push({ rings, bbox: [minX, minY, maxX, maxY] });
    }

    if (polygons.length === 0) continue;

    const curated = CURATED_CAPITAL_COORDS[isoId];
    let x = bestCx;
    let y = bestCy;
    let lon = (x / WORLD_MAP_W) * 360 - 180;
    let lat = 83 - (y / WORLD_MAP_H) * 141;
    if (curated) {
      lon = curated[0];
      lat = curated[1];
      [x, y] = projectLonLat(lon, lat);
    }

    const landNeighbors = Array.from(
      new Set(
        (neighborIndexes[i] || [])
          .map((idx) => indexToIso.get(idx))
          .filter((id): id is string => Boolean(id && id !== "010" && id !== isoId)),
      ),
    );

    const entry: WorldCountryGeo = {
      isoId,
      name,
      lon,
      lat,
      x,
      y,
      polygons,
      landNeighbors,
      seaNeighbors: [],
      allNeighbors: [...landNeighbors],
      isCoastal: landNeighbors.length <= 4,
    };

    // Handle occasional duplicate ISO rows in 110m (if any, keep the larger landmass)
    if (!byId[isoId]) {
      countries.push(entry);
      byId[isoId] = entry;
    }
  }

  for (const [a, b] of SEA_LANE_PAIRS) {
    const ca = byId[a];
    const cb = byId[b];
    if (!ca || !cb) continue;
    ca.isCoastal = true;
    cb.isCoastal = true;
    if (!ca.seaNeighbors.includes(b)) ca.seaNeighbors.push(b);
    if (!cb.seaNeighbors.includes(a)) cb.seaNeighbors.push(a);
    if (!ca.allNeighbors.includes(b)) ca.allNeighbors.push(b);
    if (!cb.allNeighbors.includes(a)) cb.allNeighbors.push(a);
  }

  return { countries, byId };
}

const BUILT = buildWorldCountries();
export const WORLD_COUNTRIES: WorldCountryGeo[] = BUILT.countries;
export const WORLD_COUNTRIES_BY_ID: Record<string, WorldCountryGeo> = BUILT.byId;

export function pointInRing(px: number, py: number, ring: [number, number][]): boolean {
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const xi = ring[i][0];
    const yi = ring[i][1];
    const xj = ring[j][0];
    const yj = ring[j][1];
    const intersect = yi > py !== yj > py && px < ((xj - xi) * (py - yi)) / (yj - yi + 1e-9) + xi;
    if (intersect) inside = !inside;
  }
  return inside;
}

export function findCountryAtWorldPoint(wx: number, wy: number): WorldCountryGeo | null {
  for (const c of WORLD_COUNTRIES) {
    for (const poly of c.polygons) {
      if (wx < poly.bbox[0] || wx > poly.bbox[2] || wy < poly.bbox[1] || wy > poly.bbox[3]) {
        continue;
      }
      if (pointInRing(wx, wy, poly.rings[0])) {
        return c;
      }
    }
  }
  return null;
}
