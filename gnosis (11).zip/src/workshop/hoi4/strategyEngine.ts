import { WORLD_COUNTRIES_BY_ID } from "./worldGeo.ts";
import {
  COUNTRIES_BY_ID,
  NATIONAL_FOCUSES,
  STRATEGIC_EVENTS,
  TECH_ITEMS,
  TERRAIN_INFO,
  UNIT_TEMPLATES,
  WORLD_COUNTRY_SPECS,
  type EquipmentType,
  type UnitTemplateId,
} from "./worldData.ts";
import type {
  StrategyActiveEvent,
  StrategyBattleDto,
  StrategyConstructionItem,
  StrategyCountryDto,
  StrategyDivisionDto,
  StrategyPlayerDto,
  StrategyScenario,
  StrategySnapshot,
  StrategyTrainingItem,
} from "./types.ts";

export interface CampaignCountryState {
  isoId: string;
  controllerIso: string;
  controllerPlayerId: string | null;
  controllerName: string | null;
  capitulated: boolean;
  treasury: number;
  dailyBudgetDelta: number;
  pp: number;
  stability: number;
  warSupport: number;
  manpower: number;
  civFactories: number;
  milFactories: number;
  infrastructure: number;
  fortLevel: number;
  hasSupplyHub: boolean;
  supplied: boolean;
  victoryPoints: number;
  equipment: Record<EquipmentType, number>;
  productionAlloc: Record<EquipmentType, number>;
  activeFocusId: string | null;
  focusProgressDays: number;
  completedFocuses: string[];
  activeTechId: string | null;
  techProgressDays: number;
  completedTechs: string[];
  constructionQueue: StrategyConstructionItem[];
  trainingQueue: StrategyTrainingItem[];
  atWarWith: Set<string>;
  allies: Set<string>;
  nonAggressionWith: Set<string>;
  tradePactsWith: Set<string>;
  embargoed: Set<string>;
  incomingAllyProposals: Set<string>;
  attackBonus: number;
  defenseBonus: number;
  armorAttackBonus: number;
  researchSpeedBonus: number;
  supplyBonus: number;
  civSpeedBonus: number;
  maxOrgBonus: number;
  airSupremacyPct: number;
}

export interface CampaignDivisionState extends StrategyDivisionDto {
  pathQueue: string[];
}

export interface CampaignPlayerEntry {
  id: string;
  name: string;
  nationId: string | null;
  color: string;
  ready: boolean;
}

export interface CampaignState {
  mode: "multiplayer" | "solo";
  code: string;
  title: string;
  scenario: StrategyScenario;
  createdAt: number;
  emptySince: number | null;
  dayCount: number;
  hourAccum: number;
  speed: number;
  paused: boolean;
  worldTension: number;
  winnerNationId: string | null;
  winnerReason: string | null;
  players: Map<string, CampaignPlayerEntry>;
  countries: Map<string, CampaignCountryState>;
  divisions: CampaignDivisionState[];
  battles: Map<string, StrategyBattleDto>;
  pendingEvents: StrategyActiveEvent[];
  events: { id: string; dateStr: string; text: string; tone: "war" | "ally" | "info" | "victory" }[];
  nextSeq: number;
}

export function formatCampaignDate(dayCount: number, hour: number): string {
  const base = new Date(Date.UTC(2026, 0, 1));
  base.setUTCDate(base.getUTCDate() + dayCount);
  const y = base.getUTCFullYear();
  const m = String(base.getUTCMonth() + 1).padStart(2, "0");
  const d = String(base.getUTCDate()).padStart(2, "0");
  const h = String(Math.floor(hour) % 24).padStart(2, "0");
  return `${y}.${m}.${d} · ${h}:00`;
}

export function pushCampaignEvent(
  state: CampaignState,
  text: string,
  tone: "war" | "ally" | "info" | "victory" = "info",
) {
  state.events.unshift({
    id: `EV-${++state.nextSeq}`,
    dateStr: formatCampaignDate(state.dayCount, state.hourAccum).slice(0, 10),
    text,
    tone,
  });
  if (state.events.length > 36) state.events.length = 36;
}

export function createCampaignDivision(
  state: CampaignState,
  ownerIso: string,
  templateId: UnitTemplateId,
  provinceIso: string,
  customName?: string,
): CampaignDivisionState {
  const tpl = UNIT_TEMPLATES[templateId];
  const nat = state.countries.get(ownerIso);
  const maxOrg = tpl.maxOrg + (nat?.maxOrgBonus || 0);
  const seq = ++state.nextSeq;
  const tag = COUNTRIES_BY_ID[ownerIso]?.shortName || ownerIso;
  return {
    id: `DIV-${tag}-${seq}`,
    name: customName || `${seq}. ${tag} ${tpl.shortTag}`,
    owner: ownerIso,
    templateId,
    provinceId: provinceIso,
    targetProvinceId: null,
    pathQueue: [],
    moveProgress: 0,
    hp: tpl.maxHp,
    maxHp: tpl.maxHp,
    org: maxOrg,
    maxOrg,
    supplied: true,
    inBattle: false,
  };
}

export function getNationIndustrialTotals(
  state: CampaignState,
  sovereignIso: string,
): { civ: number; mil: number; vp: number; territoryCount: number; steel: number; oil: number; rare: number; grain: number } {
  let civ = 0;
  let mil = 0;
  let vp = 0;
  let territoryCount = 0;
  let steel = 0;
  let oil = 0;
  let rare = 0;
  let grain = 0;

  for (const c of state.countries.values()) {
    if (c.controllerIso === sovereignIso) {
      civ += c.civFactories;
      mil += c.milFactories;
      vp += c.victoryPoints;
      territoryCount += 1;
      const spec = COUNTRIES_BY_ID[c.isoId];
      if (spec) {
        const infraMult = 0.8 + c.infrastructure * 0.12;
        steel += Math.round(spec.resources.steel * infraMult);
        oil += Math.round(spec.resources.oil * infraMult);
        rare += Math.round(spec.resources.rare * infraMult);
        grain += Math.round(spec.resources.grain * infraMult);
      }
    }
  }
  return { civ, mil, vp, territoryCount, steel, oil, rare, grain };
}

export function isFriendlyControl(state: CampaignState, nationA: string, nationB: string): boolean {
  if (nationA === nationB) return true;
  const n = state.countries.get(nationA);
  return Boolean(n?.allies.has(nationB));
}

export function recomputeSupplyAndProduction(state: CampaignState) {
  for (const c of state.countries.values()) {
    c.supplied = false;
  }

  for (const c of state.countries.values()) {
    if (c.capitulated || c.controllerIso !== c.isoId) continue;
    const sovereignIso = c.isoId;
    const visited = new Set<string>([sovereignIso]);
    const queue: string[] = [sovereignIso];
    const maxDepth = 4 + Math.floor(c.infrastructure * 0.6 + c.supplyBonus * 5);

    const depth = new Map<string, number>([[sovereignIso, 0]]);
    while (queue.length > 0) {
      const curId = queue.shift()!;
      const curState = state.countries.get(curId);
      const curD = depth.get(curId) ?? 0;
      if (curState && curState.controllerIso === sovereignIso) {
        curState.supplied = true;
      }
      if (curD >= maxDepth && !(curState && curState.hasSupplyHub)) continue;
      const geo = WORLD_COUNTRIES_BY_ID[curId];
      if (!geo) continue;
      for (const nbId of geo.allNeighbors) {
        if (visited.has(nbId)) continue;
        const nbState = state.countries.get(nbId);
        if (!nbState || !isFriendlyControl(state, sovereignIso, nbState.controllerIso)) continue;
        visited.add(nbId);
        depth.set(nbId, curD + 1);
        queue.push(nbId);
      }
    }
  }

  for (const div of state.divisions) {
    const prov = state.countries.get(div.provinceId);
    div.supplied = Boolean(prov && prov.supplied && isFriendlyControl(state, div.owner, prov.controllerIso));
  }
}

export function declareWarBetween(
  state: CampaignState,
  a: string,
  b: string,
  silent = false,
) {
  if (a === b) return;
  const na = state.countries.get(a);
  const nb = state.countries.get(b);
  if (!na || !nb || na.capitulated || nb.capitulated) return;
  if (na.atWarWith.has(b)) return;
  na.allies.delete(b);
  nb.allies.delete(a);
  na.nonAggressionWith.delete(b);
  nb.nonAggressionWith.delete(a);
  na.tradePactsWith.delete(b);
  nb.tradePactsWith.delete(a);
  na.atWarWith.add(b);
  nb.atWarWith.add(a);
  state.worldTension = Math.min(100, state.worldTension + 12);
  if (!silent) {
    const an = COUNTRIES_BY_ID[a]?.name || a;
    const bn = COUNTRIES_BY_ID[b]?.name || b;
    pushCampaignEvent(state, `${an} declared WAR on ${bn}!`, "war");
  }
}

export function formAllianceBetween(
  state: CampaignState,
  a: string,
  b: string,
  silent = false,
) {
  if (a === b) return;
  const na = state.countries.get(a);
  const nb = state.countries.get(b);
  if (!na || !nb) return;
  if (na.atWarWith.has(b)) return;
  na.allies.add(b);
  nb.allies.add(a);
  na.incomingAllyProposals.delete(b);
  nb.incomingAllyProposals.delete(a);
  if (!silent) {
    const an = COUNTRIES_BY_ID[a]?.name || a;
    const bn = COUNTRIES_BY_ID[b]?.name || b;
    pushCampaignEvent(state, `${an} & ${bn} signed a Mutual Defense Alliance.`, "ally");
  }
}

export function findCountryPath(
  state: CampaignState,
  nationIso: string,
  startIso: string,
  goalIso: string,
): string[] | null {
  if (startIso === goalIso) return [];
  const nat = state.countries.get(nationIso);
  if (!nat) return null;

  const parent = new Map<string, string | null>();
  parent.set(startIso, null);
  const queue: string[] = [startIso];

  while (queue.length > 0) {
    const cur = queue.shift()!;
    if (cur === goalIso) {
      const path: string[] = [];
      let trace: string | null = goalIso;
      while (trace && trace !== startIso) {
        path.unshift(trace);
        trace = parent.get(trace) ?? null;
      }
      return path;
    }

    const geo = WORLD_COUNTRIES_BY_ID[cur];
    if (!geo) continue;
    for (const nb of geo.allNeighbors) {
      if (parent.has(nb)) continue;
      const nbState = state.countries.get(nb);
      if (!nbState) continue;
      const isFriend = isFriendlyControl(state, nationIso, nbState.controllerIso);
      const isWarEnemy = nat.atWarWith.has(nbState.controllerIso);
      if (isFriend || isWarEnemy) {
        parent.set(nb, cur);
        queue.push(nb);
      }
    }
  }
  return null;
}

export function createCampaignState(
  title: string,
  scenario: StrategyScenario,
  code: string,
  mode: "multiplayer" | "solo",
): CampaignState {
  const state: CampaignState = {
    mode,
    code,
    title: title.trim().slice(0, 36) || "GNOSIS Global Theater",
    scenario,
    createdAt: Date.now(),
    emptySince: null,
    dayCount: 0,
    hourAccum: 8,
    speed: 2,
    paused: false,
    worldTension: scenario === "flashpoint" ? 68 : 18,
    winnerNationId: null,
    winnerReason: null,
    players: new Map(),
    countries: new Map(),
    divisions: [],
    battles: new Map(),
    pendingEvents: [],
    events: [],
    nextSeq: 1,
  };

  for (const spec of WORLD_COUNTRY_SPECS) {
    const startInf = Math.max(1, Math.round(spec.startMil * 0.45));
    const startTank = spec.featured ? Math.max(1, Math.round(spec.startMil * 0.22)) : 0;
    const startArty = Math.max(0, Math.round(spec.startMil * 0.15));
    const startAir = Math.max(0, spec.startMil - startInf - startTank - startArty);

    state.countries.set(spec.isoId, {
      isoId: spec.isoId,
      controllerIso: spec.isoId,
      controllerPlayerId: null,
      controllerName: null,
      capitulated: false,
      treasury: spec.startTreasury,
      dailyBudgetDelta: Math.round(spec.startCiv * 4.5 + spec.startInfra * 2 - spec.startMil * 1.4),
      pp: scenario === "flashpoint" ? 130 : 75,
      stability: spec.startStability,
      warSupport: scenario === "flashpoint" ? Math.min(95, spec.startWarSupport + 14) : spec.startWarSupport,
      manpower: spec.startManpower,
      civFactories: spec.startCiv,
      milFactories: spec.startMil,
      infrastructure: spec.startInfra,
      fortLevel: spec.featured ? 1 : 0,
      hasSupplyHub: true,
      supplied: true,
      victoryPoints: spec.vp,
      equipment: {
        infantry: spec.featured ? 950 : 340,
        tanks: spec.featured ? 110 : 14,
        artillery: spec.featured ? 170 : 35,
        fighters: spec.featured ? 80 : 10,
      },
      productionAlloc: {
        infantry: startInf,
        tanks: startTank,
        artillery: startArty,
        fighters: startAir,
      },
      activeFocusId: null,
      focusProgressDays: 0,
      completedFocuses: [],
      activeTechId: null,
      techProgressDays: 0,
      completedTechs: [],
      constructionQueue: [],
      trainingQueue: [],
      atWarWith: new Set(),
      allies: new Set(),
      nonAggressionWith: new Set(),
      tradePactsWith: new Set(),
      embargoed: new Set(),
      incomingAllyProposals: new Set(),
      attackBonus: 0,
      defenseBonus: 0,
      armorAttackBonus: 0,
      researchSpeedBonus: 0,
      supplyBonus: 0,
      civSpeedBonus: 0,
      maxOrgBonus: 0,
      airSupremacyPct: 50,
    });

    // Seed garrison divisions cleanly per country size
    const infCount = spec.featured ? Math.min(5, Math.max(2, Math.round(spec.startMil * 0.7))) : 1;
    for (let i = 0; i < infCount; i++) {
      state.divisions.push(createCampaignDivision(state, spec.isoId, "infantry", spec.isoId));
    }
    if (spec.featured && spec.startMil >= 4) {
      state.divisions.push(createCampaignDivision(state, spec.isoId, "armor", spec.isoId));
      state.divisions.push(createCampaignDivision(state, spec.isoId, "motorized", spec.isoId));
    }
  }

  // Regional alliances in both scenarios; active flashpoints in Flashpoint Crisis
  formAllianceBetween(state, "840", "826", true);
  formAllianceBetween(state, "250", "276", true);
  formAllianceBetween(state, "392", "410", true);

  if (scenario === "flashpoint") {
    declareWarBetween(state, "643", "804", true);
    formAllianceBetween(state, "840", "124", true);
    formAllianceBetween(state, "826", "250", true);
    pushCampaignEvent(
      state,
      "FLASHPOINT CRISIS: Global readiness escalated. Select any nation on the world map to command.",
      "war",
    );
  } else {
    pushCampaignEvent(
      state,
      "MULTIPOLAR ERA BEGINS: Natural Earth 176-nation theater active. Click any country to inspect or command.",
      "info",
    );
  }

  recomputeSupplyAndProduction(state);
  return state;
}

export function switchPlayerNation(
  state: CampaignState,
  playerId: string,
  targetIso: string,
): { ok: boolean; error?: string } {
  const player = state.players.get(playerId);
  if (!player) return { ok: false, error: "Player session not found." };
  const target = state.countries.get(targetIso);
  if (!target) return { ok: false, error: "Country not found." };
  if (target.capitulated) return { ok: false, error: "Cannot command a capitulated nation." };
  if (target.controllerPlayerId && target.controllerPlayerId !== playerId) {
    return { ok: false, error: `${COUNTRIES_BY_ID[targetIso]?.name || targetIso} is already commanded by ${target.controllerName}.` };
  }

  if (player.nationId) {
    const oldNat = state.countries.get(player.nationId);
    if (oldNat && oldNat.controllerPlayerId === playerId) {
      oldNat.controllerPlayerId = null;
      oldNat.controllerName = null;
    }
  }

  player.nationId = targetIso;
  target.controllerPlayerId = player.id;
  target.controllerName = player.name;
  pushCampaignEvent(
    state,
    `${player.name} assumed command of ${COUNTRIES_BY_ID[targetIso]?.name || targetIso}.`,
    "info",
  );
  return { ok: true };
}

function checkCapitulation(state: CampaignState, defenderIso: string, attackerIso: string) {
  const defHome = state.countries.get(defenderIso);
  if (!defHome || defHome.capitulated) return;

  let currentVp = 0;
  let initialVp = 0;
  for (const c of state.countries.values()) {
    if (c.isoId === defenderIso) initialVp += c.victoryPoints;
    if (c.controllerIso === defenderIso) currentVp += c.victoryPoints;
  }

  const capitalLost = defHome.controllerIso !== defenderIso;
  if (capitalLost && currentVp <= initialVp * 0.45) {
    defHome.capitulated = true;
    for (const c of state.countries.values()) {
      if (c.controllerIso === defenderIso) {
        c.controllerIso = attackerIso;
      }
    }
    state.divisions = state.divisions.filter((d) => d.owner !== defenderIso);
    const defName = COUNTRIES_BY_ID[defenderIso]?.name || defenderIso;
    const atkName = COUNTRIES_BY_ID[attackerIso]?.name || attackerIso;
    pushCampaignEvent(state, `${defName} CAPITULATED to ${atkName}!`, "victory");
    recomputeSupplyAndProduction(state);

    // Check if an active player coalition dominates >= 55% of total featured VPs
    let totalVp = 0;
    const vpByNat = new Map<string, number>();
    for (const c of state.countries.values()) {
      totalVp += c.victoryPoints;
      vpByNat.set(c.controllerIso, (vpByNat.get(c.controllerIso) || 0) + c.victoryPoints);
    }
    for (const [nid, vp] of vpByNat.entries()) {
      const nat = state.countries.get(nid);
      if (!nat) continue;
      let blocVp = vp;
      for (const allyId of nat.allies) blocVp += vpByNat.get(allyId) || 0;
      if (blocVp >= totalVp * 0.48) {
        state.winnerNationId = nid;
        state.winnerReason = `${COUNTRIES_BY_ID[nid]?.name || nid} & Coalition achieved Global Hegemony (${Math.round((blocVp / totalVp) * 100)}% Strategic VP)!`;
        state.paused = true;
        pushCampaignEvent(state, state.winnerReason, "victory");
        break;
      }
    }
  }
}

function stepDailyEconomyAndAI(state: CampaignState) {
  for (const nat of state.countries.values()) {
    if (nat.capitulated || nat.controllerIso !== nat.isoId) continue;

    const spec = COUNTRIES_BY_ID[nat.isoId];
    const totals = getNationIndustrialTotals(state, nat.isoId);

    // Daily Treasury / Budget & Political Power & Manpower
    const tradeBonus = nat.tradePactsWith.size * 6;
    const divUpkeep = state.divisions.filter((d) => d.owner === nat.isoId).length * 0.9;
    const delta =
      totals.civ * 3.8 +
      nat.infrastructure * 2.2 +
      tradeBonus -
      totals.mil * 1.15 -
      divUpkeep;
    nat.dailyBudgetDelta = Math.round(delta);
    nat.treasury = Math.max(-250, Math.min(9999, Math.round(nat.treasury + delta)));
    nat.pp = Math.min(999, nat.pp + 1.9 + (nat.stability / 100) * 0.8);
    nat.manpower += Math.round(
      Math.max(1200, (spec?.refPopulationM || 8) * 160 + (nat.warSupport > 55 ? 650 : 250)),
    );

    // Rebalance military factory assignments
    const allocSum =
      nat.productionAlloc.infantry +
      nat.productionAlloc.tanks +
      nat.productionAlloc.artillery +
      nat.productionAlloc.fighters;
    if (allocSum !== totals.mil) {
      if (allocSum < totals.mil) {
        nat.productionAlloc.infantry += totals.mil - allocSum;
      } else {
        let excess = allocSum - totals.mil;
        for (const k of ["fighters", "artillery", "tanks", "infantry"] as EquipmentType[]) {
          const take = Math.min(excess, nat.productionAlloc[k]);
          nat.productionAlloc[k] -= take;
          excess -= take;
        }
      }
    }

    // Resource sufficiency factor
    const hasSteel = totals.steel >= totals.mil * 1.5 ? 1 : 0.78;
    const hasOil = totals.oil >= totals.mil * 1.0 ? 1 : 0.8;
    const prodMult = (1 + nat.civSpeedBonus) * hasSteel * hasOil;

    nat.equipment.infantry += Math.round(nat.productionAlloc.infantry * 22 * prodMult);
    nat.equipment.tanks += Math.round(nat.productionAlloc.tanks * 4.5 * prodMult);
    nat.equipment.artillery += Math.round(nat.productionAlloc.artillery * 6 * prodMult);
    nat.equipment.fighters += Math.round(nat.productionAlloc.fighters * 3.2 * prodMult);
    nat.airSupremacyPct = Math.min(98, Math.round(34 + nat.equipment.fighters * 0.25));

    // Construction Queue
    if (nat.constructionQueue.length > 0 && totals.civ > 0) {
      const top = nat.constructionQueue[0];
      const civOutput = Math.max(1.2, totals.civ * 0.72) * (1 + nat.civSpeedBonus);
      top.progress += civOutput;
      if (top.progress >= top.cost) {
        nat.constructionQueue.shift();
        const targetProv = state.countries.get(top.provinceId);
        if (targetProv && targetProv.controllerIso === nat.isoId) {
          if (top.kind === "civ") targetProv.civFactories += 1;
          else if (top.kind === "mil") targetProv.milFactories += 1;
          else if (top.kind === "infra") targetProv.infrastructure = Math.min(5, targetProv.infrastructure + 1);
          else if (top.kind === "fort") targetProv.fortLevel = Math.min(6, targetProv.fortLevel + 1);
          else if (top.kind === "hub") targetProv.hasSupplyHub = true;
          recomputeSupplyAndProduction(state);
          if (nat.controllerPlayerId) {
            pushCampaignEvent(
              state,
              `${spec?.shortName || nat.isoId}: Completed ${top.kind.toUpperCase()} project in ${COUNTRIES_BY_ID[top.provinceId]?.name || top.provinceId}.`,
              "info",
            );
          }
        }
      }
    }

    // Focus Progression
    if (nat.activeFocusId) {
      const fSpec = NATIONAL_FOCUSES.find((f) => f.id === nat.activeFocusId);
      if (fSpec) {
        nat.focusProgressDays += 1;
        if (nat.focusProgressDays >= fSpec.days) {
          nat.completedFocuses.push(fSpec.id);
          nat.activeFocusId = null;
          nat.focusProgressDays = 0;
          const eff = fSpec.effects;
          if (eff.pp) nat.pp += eff.pp;
          if (eff.treasury) nat.treasury += eff.treasury;
          if (eff.manpower) nat.manpower += eff.manpower;
          if (eff.stability) nat.stability = Math.min(100, nat.stability + eff.stability);
          if (eff.warSupport) nat.warSupport = Math.min(100, nat.warSupport + eff.warSupport);
          if (eff.infEq) nat.equipment.infantry += eff.infEq;
          if (eff.tanks) nat.equipment.tanks += eff.tanks;
          if (eff.fighters) nat.equipment.fighters += eff.fighters;
          if (eff.attackMod) nat.attackBonus += eff.attackMod;
          if (eff.defenseMod) nat.defenseBonus += eff.defenseMod;
          if (eff.researchSpeed) nat.researchSpeedBonus += eff.researchSpeed;
          if (eff.civ) nat.civFactories += eff.civ;
          if (eff.mil) nat.milFactories += eff.mil;
          if (eff.infra) nat.infrastructure = Math.min(5, nat.infrastructure + eff.infra);
          pushCampaignEvent(state, `${spec?.name || nat.isoId} completed Focus: ${fSpec.name}.`, "info");
        }
      }
    }

    // Tech Progression
    if (nat.activeTechId) {
      const tSpec = TECH_ITEMS.find((t) => t.id === nat.activeTechId);
      if (tSpec) {
        nat.techProgressDays += 1 + nat.researchSpeedBonus;
        if (nat.techProgressDays >= tSpec.days) {
          nat.completedTechs.push(tSpec.id);
          nat.activeTechId = null;
          nat.techProgressDays = 0;
          if (tSpec.attackBonus) nat.attackBonus += tSpec.attackBonus;
          if (tSpec.defenseBonus) nat.defenseBonus += tSpec.defenseBonus;
          if (tSpec.armorBonus) nat.armorAttackBonus += tSpec.armorBonus;
          if (tSpec.supplyBonus) nat.supplyBonus += tSpec.supplyBonus;
          if (tSpec.civSpeedBonus) nat.civSpeedBonus += tSpec.civSpeedBonus;
          if (tSpec.maxOrgBonus) {
            nat.maxOrgBonus += tSpec.maxOrgBonus;
            for (const div of state.divisions) {
              if (div.owner === nat.isoId) div.maxOrg += tSpec.maxOrgBonus;
            }
          }
          if (nat.controllerPlayerId) {
            pushCampaignEvent(state, `${spec?.shortName}: Researched ${tSpec.name}!`, "info");
          }
        }
      }
    }

    // Division Recruitment Queue
    if (nat.trainingQueue.length > 0) {
      const head = nat.trainingQueue[0];
      head.progressDays += 1;
      if (head.progressDays >= head.totalDays) {
        nat.trainingQueue.shift();
        const deployTarget = state.countries.get(head.deployProvinceId);
        const deployIso =
          deployTarget && deployTarget.controllerIso === nat.isoId ? head.deployProvinceId : nat.isoId;
        state.divisions.push(createCampaignDivision(state, nat.isoId, head.templateId, deployIso));
        if (nat.controllerPlayerId) {
          pushCampaignEvent(
            state,
            `${spec?.shortName}: Deployed ${UNIT_TEMPLATES[head.templateId].shortTag} in ${COUNTRIES_BY_ID[deployIso]?.name || deployIso}.`,
            "info",
          );
        }
      }
    }

    // Periodic Strategic Event trigger for active player nations
    if (
      nat.controllerPlayerId !== null &&
      state.dayCount > 0 &&
      state.dayCount % 16 === 0 &&
      state.pendingEvents.filter((e) => e.targetIsoId === nat.isoId).length === 0
    ) {
      const evTpl = STRATEGIC_EVENTS[(state.dayCount / 16 + Math.floor(nat.pp)) % STRATEGIC_EVENTS.length];
      if (evTpl) {
        state.pendingEvents.push({
          uid: `SE-${++state.nextSeq}`,
          templateId: evTpl.id,
          targetIsoId: nat.isoId,
          title: evTpl.title,
          description: evTpl.description,
          choices: evTpl.choices.map((ch) => ({
            id: ch.id,
            label: ch.label,
            summary: ch.summary,
          })),
        });
        if (state.mode === "solo") {
          state.paused = true;
        }
      }
    }

    // Lightweight AI governance for unclaimed countries (only featured or at-war nations stay active)
    if (nat.controllerPlayerId === null && (spec?.featured || nat.atWarWith.size > 0)) {
      if (!nat.activeTechId && state.dayCount % 4 === 0) {
        const nextTech = TECH_ITEMS.find((t) => !nat.completedTechs.includes(t.id));
        if (nextTech) {
          nat.activeTechId = nextTech.id;
          nat.techProgressDays = 0;
        }
      }

      if (nat.atWarWith.size > 0) {
        if (nat.trainingQueue.length === 0) {
          const myCount = state.divisions.filter((d) => d.owner === nat.isoId).length;
          if (myCount < (spec?.featured ? 10 : 4)) {
            const tpl = UNIT_TEMPLATES.infantry;
            if (nat.manpower >= tpl.manpowerCost && nat.equipment.infantry >= tpl.infEqCost) {
              nat.manpower -= tpl.manpowerCost;
              nat.equipment.infantry -= tpl.infEqCost;
              nat.trainingQueue.push({
                id: `TRN-${++state.nextSeq}`,
                templateId: "infantry",
                deployProvinceId: nat.isoId,
                progressDays: 0,
                totalDays: tpl.trainDays,
              });
            }
          }
        }

        const idleDivs = state.divisions.filter(
          (d) => d.owner === nat.isoId && !d.targetProvinceId && d.org > d.maxOrg * 0.48,
        );
        for (const div of idleDivs) {
          const geo = WORLD_COUNTRIES_BY_ID[div.provinceId];
          if (!geo) continue;
          const enemyNbrs = geo.allNeighbors.filter((nbIso) => {
            const nbS = state.countries.get(nbIso);
            return nbS && nat.atWarWith.has(nbS.controllerIso);
          });
          if (enemyNbrs.length > 0) {
            const target = enemyNbrs[0];
            const localFriends = state.divisions.filter(
              (d) => d.provinceId === div.provinceId && isFriendlyControl(state, nat.isoId, d.owner),
            ).length;
            const enemyDefs = state.divisions.filter((d) => d.provinceId === target).length;
            if (localFriends >= Math.max(1, enemyDefs)) {
              div.targetProvinceId = target;
              div.pathQueue = [target];
            }
          }
        }
      }
    }
  }
}

function stepHourlyMovementAndCombat(state: CampaignState, hoursElapsed: number) {
  for (const div of state.divisions) div.inBattle = false;
  state.battles.clear();

  for (const div of state.divisions) {
    const nat = state.countries.get(div.owner);
    const prov = state.countries.get(div.provinceId);
    if (!nat || !prov) continue;
    if (!div.targetProvinceId && isFriendlyControl(state, div.owner, prov.controllerIso)) {
      const orgGain = (div.supplied ? 0.55 : -0.15) * hoursElapsed;
      div.org = Math.max(2, Math.min(div.maxOrg, div.org + orgGain));
      if (div.supplied && nat.equipment.infantry > 5 && div.hp < div.maxHp) {
        div.hp = Math.min(div.maxHp, div.hp + 0.3 * hoursElapsed);
      }
    }
  }

  const attackersByTarget = new Map<string, CampaignDivisionState[]>();

  for (const div of state.divisions) {
    if (!div.targetProvinceId) continue;
    const targetProv = state.countries.get(div.targetProvinceId);
    const nat = state.countries.get(div.owner);
    if (!targetProv || !nat) {
      div.targetProvinceId = null;
      div.pathQueue = [];
      div.moveProgress = 0;
      continue;
    }

    const curGeo = WORLD_COUNTRIES_BY_ID[div.provinceId];
    if (!curGeo || !curGeo.allNeighbors.includes(div.targetProvinceId)) {
      div.targetProvinceId = null;
      div.pathQueue = [];
      div.moveProgress = 0;
      continue;
    }

    const isFriendDest = isFriendlyControl(state, div.owner, targetProv.controllerIso);
    const isEnemyDest = nat.atWarWith.has(targetProv.controllerIso);
    if (!isFriendDest && !isEnemyDest) {
      div.targetProvinceId = null;
      div.pathQueue = [];
      div.moveProgress = 0;
      continue;
    }

    const defenders = isEnemyDest
      ? state.divisions.filter(
          (d) =>
            d.provinceId === targetProv.isoId &&
            !isFriendlyControl(state, div.owner, d.owner),
        )
      : [];

    if (isEnemyDest && defenders.length > 0) {
      div.inBattle = true;
      const list = attackersByTarget.get(targetProv.isoId) || [];
      list.push(div);
      attackersByTarget.set(targetProv.isoId, list);
    } else {
      const tpl = UNIT_TEMPLATES[div.templateId];
      const spec = COUNTRIES_BY_ID[div.targetProvinceId];
      const terr = TERRAIN_INFO[spec?.terrain || "plains"];
      const infraSpeed = 0.85 + targetProv.infrastructure * 0.08;
      const supMult = div.supplied ? 1.0 : 0.62;
      const marchRate = 3.1 * tpl.speed * terr.speedMult * infraSpeed * supMult * hoursElapsed;
      div.moveProgress += marchRate;

      if (div.moveProgress >= 100) {
        const arrivedIso = div.targetProvinceId;
        div.provinceId = arrivedIso;
        div.moveProgress = 0;

        if (isEnemyDest) {
          const prevCtrl = targetProv.controllerIso;
          targetProv.controllerIso = div.owner;
          pushCampaignEvent(
            state,
            `${COUNTRIES_BY_ID[div.owner]?.shortName} occupied ${COUNTRIES_BY_ID[arrivedIso]?.name}!`,
            "info",
          );
          recomputeSupplyAndProduction(state);
          checkCapitulation(state, prevCtrl, div.owner);
        }

        if (div.pathQueue.length > 0 && div.pathQueue[0] === arrivedIso) {
          div.pathQueue.shift();
        }
        div.targetProvinceId = div.pathQueue.length > 0 ? div.pathQueue[0] : null;
      }
    }
  }

  for (const [targetIso, attackers] of attackersByTarget.entries()) {
    const targetProv = state.countries.get(targetIso);
    const targetSpec = COUNTRIES_BY_ID[targetIso];
    if (!targetProv || !targetSpec || attackers.length === 0) continue;

    const mainAttacker = attackers[0].owner;
    const defenders = state.divisions.filter(
      (d) => d.provinceId === targetIso && !isFriendlyControl(state, mainAttacker, d.owner),
    );
    if (defenders.length === 0) continue;
    for (const d of defenders) d.inBattle = true;

    const atkNat = state.countries.get(mainAttacker)!;
    const defNat = state.countries.get(targetProv.controllerIso)!;
    const terr = TERRAIN_INFO[targetSpec.terrain];
    const flankCount = Math.max(0, new Set(attackers.map((a) => a.provinceId)).size - 1);
    const flankMult = 1 + flankCount * 0.16;
    const airDiff = atkNat.airSupremacyPct - defNat.airSupremacyPct;
    const atkAirMult = 1 + Math.max(-0.12, Math.min(0.24, airDiff * 0.004));
    const fortMult = Math.max(0.45, 1 - targetProv.fortLevel * 0.12);

    let totalAtk = 0;
    for (const a of attackers) {
      const tpl = UNIT_TEMPLATES[a.templateId];
      const cSpec = COUNTRIES_BY_ID[a.owner];
      const aNat = state.countries.get(a.owner)!;
      const mtnMod = targetSpec.terrain === "mountain" ? 1 + tpl.mountainBonus : 1;
      const supMod = a.supplied ? 1 : 0.65;
      totalAtk +=
        (tpl.softAttack * 0.72 + tpl.hardAttack * 0.28 + tpl.breakthrough * 0.32) *
        (cSpec?.attackMod || 1) *
        (1 + aNat.attackBonus + (tpl.id === "armor" ? aNat.armorAttackBonus : 0)) *
        terr.atkMult *
        mtnMod *
        supMod *
        Math.max(0.2, a.hp / a.maxHp);
    }
    totalAtk *= flankMult * atkAirMult * fortMult;

    let totalDef = 0;
    for (const d of defenders) {
      const tpl = UNIT_TEMPLATES[d.templateId];
      const cSpec = COUNTRIES_BY_ID[d.owner];
      const dNat = state.countries.get(d.owner)!;
      const mtnMod = targetSpec.terrain === "mountain" ? 1 + tpl.mountainBonus : 1;
      const supMod = d.supplied ? 1 : 0.62;
      totalDef +=
        (tpl.defense * 0.82 + tpl.softAttack * 0.45 + tpl.hardAttack * 0.2) *
        (cSpec?.defenseMod || 1) *
        (1 + dNat.defenseBonus) *
        (1 + terr.defBonus) *
        mtnMod *
        supMod *
        Math.max(0.2, d.hp / d.maxHp);
    }

    const atkDmg = (totalAtk / Math.max(1, defenders.length)) * 0.044 * hoursElapsed;
    const defDmg = (totalDef / Math.max(1, attackers.length)) * 0.036 * hoursElapsed;

    for (const d of defenders) {
      d.org = Math.max(0, d.org - atkDmg * (d.supplied ? 1 : 1.45));
      d.hp = Math.max(0, d.hp - atkDmg * 0.34);
    }
    for (const a of attackers) {
      a.org = Math.max(0, a.org - defDmg * (a.supplied ? 1 : 1.35));
      a.hp = Math.max(0, a.hp - defDmg * 0.28);
    }

    const shatteredDefs = defenders.filter((d) => d.org <= 1 || d.hp <= 2);
    for (const sd of shatteredDefs) {
      const geo = WORLD_COUNTRIES_BY_ID[targetIso];
      const retreatOptions = (geo?.allNeighbors || []).filter((nbIso) => {
        const nbP = state.countries.get(nbIso);
        return nbP && isFriendlyControl(state, sd.owner, nbP.controllerIso);
      });
      if (retreatOptions.length > 0 && sd.hp > 5) {
        sd.provinceId = retreatOptions[0];
        sd.targetProvinceId = null;
        sd.pathQueue = [];
        sd.moveProgress = 0;
        sd.org = 14;
      } else {
        state.divisions = state.divisions.filter((x) => x.id !== sd.id);
        pushCampaignEvent(
          state,
          `ENCIRCLEMENT: ${sd.name} shattered in ${targetSpec.name}!`,
          "war",
        );
      }
    }

    for (const a of attackers) {
      if (a.org <= 2 || a.hp <= 4) {
        a.targetProvinceId = null;
        a.pathQueue = [];
        a.moveProgress = 0;
        a.org = Math.max(4, a.org);
      }
    }

    const remDefs = state.divisions.filter(
      (d) => d.provinceId === targetIso && !isFriendlyControl(state, mainAttacker, d.owner),
    );
    if (remDefs.length === 0) {
      const prevCtrl = targetProv.controllerIso;
      targetProv.controllerIso = mainAttacker;
      const lead = attackers[0];
      lead.provinceId = targetIso;
      lead.moveProgress = 0;
      if (lead.pathQueue[0] === targetIso) lead.pathQueue.shift();
      lead.targetProvinceId = lead.pathQueue[0] || null;
      pushCampaignEvent(
        state,
        `BREAKTHROUGH AT ${targetSpec.name.toUpperCase()}: ${COUNTRIES_BY_ID[mainAttacker]?.shortName} captured the country!`,
        "info",
      );
      recomputeSupplyAndProduction(state);
      checkCapitulation(state, prevCtrl, mainAttacker);
    } else {
      const atkOrg = attackers.reduce((s, x) => s + x.org, 0) / Math.max(1, attackers.length);
      const defOrg = remDefs.reduce((s, x) => s + x.org, 0) / Math.max(1, remDefs.length);
      const ratio = totalAtk / Math.max(1, totalAtk + totalDef);
      const orgBalance = atkOrg / Math.max(1, atkOrg + defOrg);
      const prog = Math.round(Math.max(4, Math.min(96, (ratio * 0.55 + orgBalance * 0.45) * 100)));
      state.battles.set(targetIso, {
        id: `BAT-${targetIso}`,
        provinceId: targetIso,
        fromProvinceId: attackers[0].provinceId,
        attackerNation: mainAttacker,
        defenderNation: targetProv.controllerIso,
        progress: prog,
        attackerCount: attackers.length,
        defenderCount: remDefs.length,
        flankBonus: flankCount * 16,
        airBonus: Math.round(Math.max(-12, Math.min(24, airDiff * 0.4))),
        terrainPenaltyPct: Math.round((1 - terr.atkMult) * 100),
      });
    }
  }
}

export function stepCampaignSimulation(state: CampaignState, tickFactor = 1) {
  if (state.paused || state.winnerNationId) return;
  const hoursStep =
    (state.speed === 1 ? 2 : state.speed === 2 ? 4 : state.speed === 3 ? 8 : state.speed === 4 ? 14 : 24) *
    tickFactor;
  state.hourAccum += hoursStep;
  stepHourlyMovementAndCombat(state, hoursStep);

  while (state.hourAccum >= 24) {
    state.hourAccum -= 24;
    state.dayCount += 1;
    stepDailyEconomyAndAI(state);
  }
}

export function applyCampaignCommand(
  state: CampaignState,
  playerId: string,
  msg: Record<string, unknown>,
): { ok: boolean; error?: string; changed: boolean } {
  const player = state.players.get(playerId);
  if (!player) return { ok: false, error: "Session not found.", changed: false };

  if (msg.type === "set_speed" && typeof msg.speed === "number") {
    state.speed = Math.max(1, Math.min(5, Math.round(msg.speed)));
    state.paused = false;
    return { ok: true, changed: true };
  }

  if (msg.type === "toggle_pause") {
    state.paused = !state.paused;
    return { ok: true, changed: true };
  }

  if (msg.type === "select_nation" && typeof msg.nationId === "string") {
    const res = switchPlayerNation(state, playerId, msg.nationId);
    return { ok: res.ok, error: res.error, changed: res.ok };
  }

  if (msg.type === "chat_message" && typeof msg.text === "string") {
    const clean = msg.text.trim().slice(0, 140);
    if (clean) {
      const tag = player.nationId ? COUNTRIES_BY_ID[player.nationId]?.shortName || "CMD" : "OBS";
      pushCampaignEvent(state, `[${tag}] ${player.name}: ${clean}`, "info");
      return { ok: true, changed: true };
    }
    return { ok: true, changed: false };
  }

  const myIso = player.nationId;
  if (!myIso) return { ok: false, error: "Select a nation first.", changed: false };
  const myNat = state.countries.get(myIso);
  if (!myNat || myNat.capitulated || state.winnerNationId) {
    return { ok: false, error: "Nation is unable to act.", changed: false };
  }

  if (msg.type === "move_divisions" && Array.isArray(msg.divisionIds) && typeof msg.targetProvinceId === "string") {
    const targetIso = msg.targetProvinceId;
    if (!WORLD_COUNTRIES_BY_ID[targetIso]) return { ok: false, changed: false };
    const idSet = new Set(msg.divisionIds.map(String));
    for (const div of state.divisions) {
      if (div.owner !== myIso || !idSet.has(div.id)) continue;
      const path = findCountryPath(state, myIso, div.provinceId, targetIso);
      if (path && path.length > 0) {
        div.pathQueue = path;
        div.targetProvinceId = path[0];
      }
    }
    return { ok: true, changed: true };
  }

  if (msg.type === "halt_divisions" && Array.isArray(msg.divisionIds)) {
    const idSet = new Set(msg.divisionIds.map(String));
    for (const div of state.divisions) {
      if (div.owner === myIso && idSet.has(div.id)) {
        div.targetProvinceId = null;
        div.pathQueue = [];
        div.moveProgress = 0;
      }
    }
    return { ok: true, changed: true };
  }

  if (msg.type === "start_focus" && typeof msg.focusId === "string") {
    const fSpec = NATIONAL_FOCUSES.find((f) => f.id === msg.focusId);
    if (!fSpec || myNat.completedFocuses.includes(fSpec.id)) return { ok: false, changed: false };
    if (fSpec.requires && !fSpec.requires.every((r) => myNat.completedFocuses.includes(r))) {
      return { ok: false, error: "Prerequisite focus required.", changed: false };
    }
    myNat.activeFocusId = fSpec.id;
    myNat.focusProgressDays = 0;
    return { ok: true, changed: true };
  }

  if (msg.type === "start_tech" && typeof msg.techId === "string") {
    const tSpec = TECH_ITEMS.find((t) => t.id === msg.techId);
    if (!tSpec || myNat.completedTechs.includes(tSpec.id)) return { ok: false, changed: false };
    myNat.activeTechId = tSpec.id;
    myNat.techProgressDays = 0;
    return { ok: true, changed: true };
  }

  if (msg.type === "queue_construction" && typeof msg.provinceId === "string" && typeof msg.kind === "string") {
    const prov = state.countries.get(msg.provinceId);
    if (!prov || prov.controllerIso !== myIso) {
      return { ok: false, error: "Select one of your controlled countries.", changed: false };
    }
    const kind = msg.kind as StrategyConstructionItem["kind"];
    if (!["civ", "mil", "infra", "fort", "hub"].includes(kind)) return { ok: false, changed: false };
    if (myNat.constructionQueue.length >= 6) return { ok: false, error: "Construction queue full (max 6).", changed: false };
    const treasuryCost = kind === "civ" ? 70 : kind === "mil" ? 65 : kind === "infra" ? 55 : kind === "hub" ? 60 : 40;
    if (myNat.treasury < treasuryCost) {
      return { ok: false, error: `Need $${treasuryCost}B Treasury to queue ${kind.toUpperCase()}.`, changed: false };
    }
    myNat.treasury -= treasuryCost;
    const cost = kind === "civ" ? 26 : kind === "mil" ? 22 : kind === "infra" ? 20 : kind === "hub" ? 24 : 15;
    myNat.constructionQueue.push({
      id: `CON-${++state.nextSeq}`,
      provinceId: prov.isoId,
      kind,
      progress: 0,
      cost,
    });
    return { ok: true, changed: true };
  }

  if (msg.type === "set_production" && msg.alloc && typeof msg.alloc === "object") {
    const raw = msg.alloc as Record<string, unknown>;
    const { mil } = getNationIndustrialTotals(state, myIso);
    const keys: EquipmentType[] = ["infantry", "tanks", "artillery", "fighters"];
    const next: Record<EquipmentType, number> = { infantry: 0, tanks: 0, artillery: 0, fighters: 0 };
    let used = 0;
    for (const k of keys) {
      const val = Math.max(0, Math.round(Number(raw[k] || 0)));
      const assign = Math.min(mil - used, val);
      next[k] = assign;
      used += assign;
    }
    if (used < mil) next.infantry += mil - used;
    myNat.productionAlloc = next;
    return { ok: true, changed: true };
  }

  if (msg.type === "recruit_division" && typeof msg.templateId === "string") {
    const tplId = msg.templateId as UnitTemplateId;
    const tpl = UNIT_TEMPLATES[tplId];
    if (!tpl || myNat.trainingQueue.length >= 6) {
      return { ok: false, error: "Training queue full (max 6).", changed: false };
    }
    if (
      myNat.manpower < tpl.manpowerCost ||
      myNat.equipment.infantry < tpl.infEqCost ||
      myNat.equipment.tanks < tpl.tankCost ||
      myNat.equipment.artillery < tpl.artilleryCost ||
      myNat.treasury < tpl.treasuryCost
    ) {
      return {
        ok: false,
        error: `Insufficient Treasury ($${tpl.treasuryCost}B), manpower, or equipment for ${tpl.name}.`,
        changed: false,
      };
    }
    const deployIso =
      typeof msg.deployProvinceId === "string" && state.countries.get(msg.deployProvinceId)?.controllerIso === myIso
        ? msg.deployProvinceId
        : myIso;
    myNat.treasury -= tpl.treasuryCost;
    myNat.manpower -= tpl.manpowerCost;
    myNat.equipment.infantry -= tpl.infEqCost;
    myNat.equipment.tanks -= tpl.tankCost;
    myNat.equipment.artillery -= tpl.artilleryCost;
    myNat.trainingQueue.push({
      id: `TRN-${++state.nextSeq}`,
      templateId: tplId,
      deployProvinceId: deployIso,
      progressDays: 0,
      totalDays: tpl.trainDays,
    });
    return { ok: true, changed: true };
  }

  if (msg.type === "event_choice" && typeof msg.uid === "string" && typeof msg.choiceId === "string") {
    const idx = state.pendingEvents.findIndex((e) => e.uid === msg.uid && e.targetIsoId === myIso);
    if (idx === -1) return { ok: false, changed: false };
    const ev = state.pendingEvents[idx];
    const tpl = STRATEGIC_EVENTS.find((s) => s.id === ev.templateId);
    const ch = tpl?.choices.find((c) => c.id === msg.choiceId);
    state.pendingEvents.splice(idx, 1);
    if (ch) {
      if (ch.ppDelta) myNat.pp = Math.max(0, myNat.pp + ch.ppDelta);
      if (ch.treasuryDelta) myNat.treasury += ch.treasuryDelta;
      if (ch.stabilityDelta) myNat.stability = Math.max(0, Math.min(100, myNat.stability + ch.stabilityDelta));
      if (ch.warSupportDelta) myNat.warSupport = Math.max(0, Math.min(100, myNat.warSupport + ch.warSupportDelta));
      if (ch.manpowerDelta) myNat.manpower += ch.manpowerDelta;
      if (ch.civDelta) myNat.civFactories += ch.civDelta;
      if (ch.milDelta) myNat.milFactories += ch.milDelta;
      if (ch.infEqDelta) myNat.equipment.infantry += ch.infEqDelta;
      pushCampaignEvent(state, `${COUNTRIES_BY_ID[myIso]?.shortName}: ${ev.title} — ${ch.label}`, "info");
    }
    return { ok: true, changed: true };
  }

  if (msg.type === "diplomacy_action" && typeof msg.targetNationId === "string" && typeof msg.action === "string") {
    const targetIso = msg.targetNationId;
    const targetNat = state.countries.get(targetIso);
    if (!targetNat || targetIso === myIso || targetNat.capitulated) {
      return { ok: false, error: "Invalid diplomatic target.", changed: false };
    }
    const targetName = COUNTRIES_BY_ID[targetIso]?.name || targetIso;
    const myShort = COUNTRIES_BY_ID[myIso]?.shortName || myIso;

    if (msg.action === "declare_war") {
      if (myNat.pp < 15) return { ok: false, error: "Need 15 Political Power to declare war.", changed: false };
      myNat.pp -= 15;
      declareWarBetween(state, myIso, targetIso);
      recomputeSupplyAndProduction(state);
      return { ok: true, changed: true };
    }
    if (msg.action === "offer_peace") {
      if (!myNat.atWarWith.has(targetIso)) return { ok: false, changed: false };
      if (myNat.pp < 35) return { ok: false, error: "Need 35 Political Power to negotiate ceasefire.", changed: false };
      myNat.pp -= 35;
      myNat.atWarWith.delete(targetIso);
      targetNat.atWarWith.delete(myIso);
      myNat.nonAggressionWith.add(targetIso);
      targetNat.nonAggressionWith.add(myIso);
      pushCampaignEvent(state, `${COUNTRIES_BY_ID[myIso]?.name} & ${targetName} signed an Armistice Ceasefire.`, "ally");
      return { ok: true, changed: true };
    }
    if (msg.action === "trade_pact") {
      if (myNat.atWarWith.has(targetIso)) return { ok: false, error: "Cannot trade with hostile state.", changed: false };
      if (myNat.tradePactsWith.has(targetIso)) return { ok: true, changed: false };
      if (myNat.pp < 10) return { ok: false, error: "Need 10 Political Power to establish Trade Pact.", changed: false };
      myNat.pp -= 10;
      myNat.tradePactsWith.add(targetIso);
      targetNat.tradePactsWith.add(myIso);
      pushCampaignEvent(state, `${myShort} & ${targetName} established a Bilateral Trade Corridor.`, "ally");
      return { ok: true, changed: true };
    }
    if (msg.action === "non_aggression") {
      if (myNat.atWarWith.has(targetIso)) return { ok: false, changed: false };
      if (myNat.pp < 10) return { ok: false, error: "Need 10 Political Power for Non-Aggression Pact.", changed: false };
      myNat.pp -= 10;
      myNat.nonAggressionWith.add(targetIso);
      targetNat.nonAggressionWith.add(myIso);
      pushCampaignEvent(state, `${myShort} & ${targetName} signed Non-Aggression Treaty.`, "info");
      return { ok: true, changed: true };
    }
    if (msg.action === "embargo") {
      myNat.tradePactsWith.delete(targetIso);
      targetNat.tradePactsWith.delete(myIso);
      myNat.embargoed.add(targetIso);
      pushCampaignEvent(state, `${myShort} imposed Trade Sanctions on ${targetName}.`, "war");
      return { ok: true, changed: true };
    }
    if (msg.action === "propose_ally") {
      if (myNat.atWarWith.has(targetIso) || myNat.allies.has(targetIso)) return { ok: false, changed: false };
      if (targetNat.controllerPlayerId === null) {
        if (state.worldTension >= 20 || myNat.pp >= 25) {
          formAllianceBetween(state, myIso, targetIso);
          recomputeSupplyAndProduction(state);
        } else {
          pushCampaignEvent(state, `${targetName} declined an alliance at low tension.`, "info");
        }
      } else {
        targetNat.incomingAllyProposals.add(myIso);
        pushCampaignEvent(state, `${myShort} sent an Alliance Pact to ${targetName}.`, "ally");
      }
      return { ok: true, changed: true };
    }
    if (msg.action === "accept_ally") {
      if (myNat.incomingAllyProposals.has(targetIso)) {
        formAllianceBetween(state, myIso, targetIso);
        recomputeSupplyAndProduction(state);
        return { ok: true, changed: true };
      }
    }
    if (msg.action === "lend_lease") {
      if (myNat.atWarWith.has(targetIso) || myNat.equipment.infantry < 150) {
        return { ok: false, error: "Need 150 Infantry Gear to send Aid.", changed: false };
      }
      myNat.equipment.infantry -= 150;
      targetNat.equipment.infantry += 150;
      pushCampaignEvent(state, `${myShort} shipped Defense Aid to ${targetName}.`, "ally");
      return { ok: true, changed: true };
    }
  }

  return { ok: false, changed: false };
}

export function serializeCampaignSnapshot(state: CampaignState): StrategySnapshot {
  const countriesDto: Record<string, StrategyCountryDto> = {};
  for (const [isoId, c] of state.countries.entries()) {
    const spec = COUNTRIES_BY_ID[isoId];
    const totals = getNationIndustrialTotals(state, isoId);
    countriesDto[isoId] = {
      isoId,
      controllerIso: c.controllerIso,
      controllerPlayerId: c.controllerPlayerId,
      controllerName: c.controllerName,
      capitulated: c.capitulated,
      ideology: spec?.ideology || "non-aligned",
      treasury: Math.round(c.treasury),
      dailyBudgetDelta: c.dailyBudgetDelta,
      pp: Math.round(c.pp),
      stability: Math.round(c.stability),
      warSupport: Math.round(c.warSupport),
      manpower: Math.round(c.manpower),
      civCount: c.controllerIso === isoId ? totals.civ : c.civFactories,
      milCount: c.controllerIso === isoId ? totals.mil : c.milFactories,
      infrastructure: c.infrastructure,
      fortLevel: c.fortLevel,
      hasSupplyHub: c.hasSupplyHub,
      supplied: c.supplied,
      resources: {
        steel: totals.steel || spec?.resources.steel || 4,
        oil: totals.oil || spec?.resources.oil || 2,
        rare: totals.rare || spec?.resources.rare || 3,
        grain: totals.grain || spec?.resources.grain || 6,
      },
      equipment: { ...c.equipment },
      productionAlloc: { ...c.productionAlloc },
      activeFocusId: c.activeFocusId,
      focusProgressDays: Math.floor(c.focusProgressDays),
      completedFocuses: [...c.completedFocuses],
      activeTechId: c.activeTechId,
      techProgressDays: Math.floor(c.techProgressDays),
      completedTechs: [...c.completedTechs],
      constructionQueue: c.constructionQueue.map((item) => ({ ...item })),
      trainingQueue: c.trainingQueue.map((item) => ({ ...item })),
      atWarWith: Array.from(c.atWarWith),
      allies: Array.from(c.allies),
      nonAggressionWith: Array.from(c.nonAggressionWith),
      tradePactsWith: Array.from(c.tradePactsWith),
      embargoed: Array.from(c.embargoed),
      incomingAllyProposals: Array.from(c.incomingAllyProposals),
      victoryPointsOwned: totals.vp,
      attackBonusPct: Math.round(c.attackBonus * 100),
      defenseBonusPct: Math.round(c.defenseBonus * 100),
      airSupremacyPct: c.airSupremacyPct,
    };
  }

  const players: StrategyPlayerDto[] = Array.from(state.players.values()).map((p) => ({
    id: p.id,
    name: p.name,
    nationId: p.nationId,
    color: p.color,
    ready: p.ready,
  }));

  return {
    type: "hoi4:snapshot",
    mode: state.mode,
    code: state.code,
    title: state.title,
    scenario: state.scenario,
    dateStr: formatCampaignDate(state.dayCount, state.hourAccum),
    dayCount: state.dayCount,
    speed: state.speed,
    paused: state.paused,
    worldTension: Math.round(state.worldTension),
    winnerNationId: state.winnerNationId,
    winnerReason: state.winnerReason,
    players,
    countries: countriesDto,
    divisions: state.divisions.map((d) => ({
      id: d.id,
      name: d.name,
      owner: d.owner,
      templateId: d.templateId,
      provinceId: d.provinceId,
      targetProvinceId: d.targetProvinceId,
      moveProgress: Math.round(d.moveProgress),
      hp: Math.round(d.hp),
      maxHp: d.maxHp,
      org: Math.round(d.org),
      maxOrg: Math.round(d.maxOrg),
      supplied: d.supplied,
      inBattle: d.inBattle,
    })),
    battles: Array.from(state.battles.values()),
    pendingEvents: [...state.pendingEvents],
    events: state.events,
  };
}
