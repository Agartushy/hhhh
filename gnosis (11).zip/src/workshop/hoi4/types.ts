import type {
  EquipmentType,
  IdeologyId,
  ResourceSet,
  UnitTemplateId,
} from "./worldData.ts";

export type StrategyScenario = "multipolar" | "flashpoint";
export type Hoi4Scenario = StrategyScenario;

export interface StrategyPublicRoom {
  code: string;
  title: string;
  scenario: StrategyScenario;
  players: number;
  maxPlayers: number;
  dateStr: string;
  speed: number;
  paused: boolean;
  worldTension: number;
}

export type Hoi4PublicRoom = StrategyPublicRoom;

export interface StrategyDivisionDto {
  id: string;
  name: string;
  owner: string; // ISO ID of owning nation
  templateId: UnitTemplateId;
  provinceId: string; // ISO ID of current country location
  targetProvinceId: string | null;
  moveProgress: number;
  hp: number;
  maxHp: number;
  org: number;
  maxOrg: number;
  supplied: boolean;
  inBattle: boolean;
}

export type Hoi4DivisionDto = StrategyDivisionDto;

export interface StrategyConstructionItem {
  id: string;
  provinceId: string; // ISO ID
  kind: "civ" | "mil" | "infra" | "fort" | "hub";
  progress: number;
  cost: number;
}

export type Hoi4ConstructionItem = StrategyConstructionItem;

export interface StrategyTrainingItem {
  id: string;
  templateId: UnitTemplateId;
  deployProvinceId: string; // ISO ID
  progressDays: number;
  totalDays: number;
}

export type Hoi4TrainingItem = StrategyTrainingItem;

export interface StrategyCountryDto {
  isoId: string;
  controllerIso: string; // Currently occupied/controlled by which sovereign ISO
  controllerPlayerId: string | null;
  controllerName: string | null;
  capitulated: boolean;
  ideology: IdeologyId;
  treasury: number;
  dailyBudgetDelta: number;
  pp: number;
  stability: number;
  warSupport: number;
  manpower: number;
  civCount: number;
  milCount: number;
  infrastructure: number;
  fortLevel: number;
  hasSupplyHub: boolean;
  supplied: boolean;
  resources: ResourceSet;
  equipment: Record<EquipmentType, number>;
  productionAlloc: Record<EquipmentType, number>;
  activeFocusId: string | null;
  focusProgressDays: number;
  completedFocuses: string[];
  activeTechId: string | null;
  techProgressDays: number;
  completedTechs: string[];
  constructionQueue: StrategyConstructionItem[];
  trainingQueue: StrategyTrainingItem[];
  atWarWith: string[];
  allies: string[];
  nonAggressionWith: string[];
  tradePactsWith: string[];
  embargoed: string[];
  incomingAllyProposals: string[];
  victoryPointsOwned: number;
  attackBonusPct: number;
  defenseBonusPct: number;
  airSupremacyPct: number;
}

export interface StrategyBattleDto {
  id: string;
  provinceId: string; // Target country ISO
  fromProvinceId: string;
  attackerNation: string;
  defenderNation: string;
  progress: number;
  attackerCount: number;
  defenderCount: number;
  flankBonus: number;
  airBonus: number;
  terrainPenaltyPct: number;
}

export interface StrategyEventChoice {
  id: string;
  label: string;
  summary: string;
}

export interface StrategyActiveEvent {
  uid: string;
  templateId: string;
  targetIsoId: string;
  title: string;
  description: string;
  choices: StrategyEventChoice[];
}

export interface StrategyPlayerDto {
  id: string;
  name: string;
  nationId: string | null;
  color: string;
  ready: boolean;
}

export interface StrategySnapshot {
  type: "hoi4:snapshot";
  mode: "multiplayer" | "solo";
  code: string;
  title: string;
  scenario: StrategyScenario;
  dateStr: string;
  dayCount: number;
  speed: number;
  paused: boolean;
  worldTension: number;
  winnerNationId: string | null;
  winnerReason: string | null;
  players: StrategyPlayerDto[];
  countries: Record<string, StrategyCountryDto>;
  divisions: StrategyDivisionDto[];
  battles: StrategyBattleDto[];
  pendingEvents: StrategyActiveEvent[];
  events: { id: string; dateStr: string; text: string; tone: "war" | "ally" | "info" | "victory" }[];
}

export type Hoi4Snapshot = StrategySnapshot;
