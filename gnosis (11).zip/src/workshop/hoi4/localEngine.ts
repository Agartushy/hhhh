import {
  applyCampaignCommand,
  createCampaignState,
  serializeCampaignSnapshot,
  stepCampaignSimulation,
  switchPlayerNation,
  type CampaignState,
} from "./strategyEngine";
import type { StrategyScenario, StrategySnapshot } from "./types";

export class LocalStrategyCampaign {
  private state: CampaignState;
  private playerId = "LOCAL-CMDR";

  constructor(commanderName: string, nationIso: string, scenario: StrategyScenario) {
    this.state = createCampaignState(
      `Solo Campaign · ${scenario === "flashpoint" ? "Flashpoint" : "Multipolar"}`,
      scenario,
      "SOLO",
      "solo",
    );
    this.state.players.set(this.playerId, {
      id: this.playerId,
      name: commanderName.trim().slice(0, 18) || "Commander",
      nationId: null,
      color: "#e0a94f",
      ready: true,
    });
    switchPlayerNation(this.state, this.playerId, nationIso);
  }

  getPlayerId(): string {
    return this.playerId;
  }

  tick(ticks = 1): StrategySnapshot {
    for (let i = 0; i < ticks; i++) {
      stepCampaignSimulation(this.state, 1);
    }
    return serializeCampaignSnapshot(this.state);
  }

  dispatch(msg: Record<string, unknown>): {
    snapshot: StrategySnapshot;
    error?: string;
  } {
    const res = applyCampaignCommand(this.state, this.playerId, msg);
    return {
      snapshot: serializeCampaignSnapshot(this.state),
      error: res.error,
    };
  }

  getSnapshot(): StrategySnapshot {
    return serializeCampaignSnapshot(this.state);
  }
}
