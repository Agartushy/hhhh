import { useCallback, useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import {
  GameSoundtrackPlayer,
  getSharedPlaylist,
  registerSessionTrackFile,
  selectActiveSoundtrackByUrl,
  subscribeSoundtrackMeta,
} from "./soundtrack";
import {
  resetWorkshopSettings,
  updateWorkshopSettings,
  useWorkshopSettings,
} from "./sharedSettings";
import {
  createWorkshopLobbyClient,
  openWorkshopRoom,
  type NetworkConnectionState,
  type WorkshopLobbyClient,
  type WorkshopRoomSummary,
  type WorkshopRoomTransport,
} from "./net/gameNetwork";
import {
  TitanRoomHost,
  type HostTitanSnapshot,
  type TitanOutgoingEvent,
} from "./titan/titanHostEngine";
import { OdmAudioEngine } from "./titan/audio";
import {
  raycastCityObstacles,
  resolvePlayerCityCollision,
  resolveTitanCityPush,
  SCOUT_SPAWNS,
  SUPPLY_STATIONS,
  TITAN_SPAWN_POINTS,
} from "./titan/cityData";
import {
  buildLocalScoutAvatar,
  buildLocalShifterRig,
  buildOdmBladeViewmodels,
  buildScoutTeammateRig,
  buildTitanFirstPersonArms,
  buildTitanRig,
  buildWalledDistrictScene,
  DEFAULT_TITAN_COSMETICS,
  disposeTitanHierarchy,
  TITAN_BLADE_PRESETS,
  TITAN_CABLE_PRESETS,
  TITAN_CLOAK_PRESETS,
  TITAN_SCARF_PRESETS,
  type LocalScoutAvatarRig,
  type LocalShifterAvatarRig,
  type ScoutTeammateRig,
  type TitanCosmeticOptions,
  type TitanModelRig,
  type TitanVariant,
} from "./titan/models";
import { TITAN_POWERS, TITAN_POWERS_BY_ID, type TitanPowerId } from "./titan/powers";
import cardTitanImg from "../assets/images/card_titan_assault_1795263403128.jpg";

const TITAN_COSMETICS_KEY = "gnosis-titan-cosmetics-v1";

function loadTitanCosmetics(): TitanCosmeticOptions {
  if (typeof window === "undefined") return { ...DEFAULT_TITAN_COSMETICS };
  try {
    const raw = window.localStorage.getItem(TITAN_COSMETICS_KEY);
    if (!raw) return { ...DEFAULT_TITAN_COSMETICS };
    const parsed = JSON.parse(raw) as Partial<TitanCosmeticOptions>;
    return {
      cloakColorHex: typeof parsed.cloakColorHex === "string" ? parsed.cloakColorHex : DEFAULT_TITAN_COSMETICS.cloakColorHex,
      scarfColorHex: typeof parsed.scarfColorHex === "string" ? parsed.scarfColorHex : DEFAULT_TITAN_COSMETICS.scarfColorHex,
      bladeFinish:
        parsed.bladeFinish === "steel" ||
        parsed.bladeFinish === "obsidian" ||
        parsed.bladeFinish === "gold" ||
        parsed.bladeFinish === "crimson"
          ? parsed.bladeFinish
          : DEFAULT_TITAN_COSMETICS.bladeFinish,
      cableColorHex: typeof parsed.cableColorHex === "string" ? parsed.cableColorHex : DEFAULT_TITAN_COSMETICS.cableColorHex,
    };
  } catch {
    return { ...DEFAULT_TITAN_COSMETICS };
  }
}

interface TitanAssaultGameProps {
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  onExit: () => void;
}

interface PublicTitanRoom {
  code: string;
  title: string;
  players: number;
  maxPlayers: number;
  wave: number;
  status: string;
}

interface HookAnchor {
  active: boolean;
  x: number;
  y: number;
  z: number;
  attachedTitanId?: string;
}

interface TitanEntity {
  id: string;
  variant: TitanVariant;
  x: number;
  z: number;
  yaw: number;
  hp: number;
  maxHp: number;
  height: number;
  speed: number;
  bodyRadius: number;
  attackCooldown: number;
  telegraphTimer: number;
  staggerTimer: number;
  stepPhase: number;
}

interface ScoutSnapshotPlayer {
  id: string;
  name: string;
  color: string;
  x: number;
  y: number;
  z: number;
  yaw: number;
  hp: number;
  maxHp: number;
  alive: boolean;
  respawnTimer: number;
  kills: number;
  score: number;
  shifterForm: TitanPowerId | null;
  hookLeft: { active: boolean; x: number; y: number; z: number } | null;
  hookRight: { active: boolean; x: number; y: number; z: number } | null;
}

interface TitanSnapshot {
  code: string;
  title: string;
  wave: number;
  maxWaves: number;
  status: "ACTIVE" | "VICTORY" | "DEFEAT";
  teamScore: number;
  players: ScoutSnapshotPlayer[];
  titans: {
    id: string;
    variant: TitanVariant;
    x: number;
    z: number;
    yaw: number;
    hp: number;
    maxHp: number;
    height: number;
    telegraphTimer: number;
    staggerTimer: number;
  }[];
}

function makeSoloWave(wave: number, seqStart: number): { titans: TitanEntity[]; nextSeq: number } {
  const count = wave === 1 ? 5 : wave === 2 ? 6 : wave === 3 ? 7 : 6;
  const titans: TitanEntity[] = [];
  let seq = seqStart;
  for (let i = 0; i < count; i++) {
    const sp = TITAN_SPAWN_POINTS[i % TITAN_SPAWN_POINTS.length];
    let variant: TitanVariant = "pure";
    if (wave === 2 && i % 2 === 0) variant = "abnormal";
    else if (wave === 3) variant = i < 2 ? "armored" : i % 2 === 0 ? "abnormal" : "pure";
    else if (wave >= 4) variant = i === 0 ? "colossal" : i < 3 ? "armored" : "abnormal";

    const maxHp =
      variant === "colossal" ? 560 : variant === "armored" ? 260 : variant === "abnormal" ? 150 : 100;
    const height =
      variant === "colossal" ? 23 : variant === "armored" ? 15.5 : variant === "abnormal" ? 11.5 : 8.5;
    const speed =
      variant === "colossal" ? 2.6 : variant === "armored" ? 4.2 : variant === "abnormal" ? 6.8 : 4.5;

    titans.push({
      id: `SOLO-T-${++seq}`,
      variant,
      x: sp.x + (Math.random() - 0.5) * 6,
      z: sp.z + (Math.random() - 0.5) * 6,
      yaw: 0,
      hp: maxHp,
      maxHp,
      height,
      speed,
      bodyRadius: (height / 10) * 1.9,
      attackCooldown: 1.4 + Math.random(),
      telegraphTimer: 0,
      staggerTimer: 0,
      stepPhase: Math.random() * Math.PI * 2,
    });
  }
  return { titans, nextSeq: seq };
}

export function TitanAssaultGame({
  isFullscreen,
  onToggleFullscreen,
  onExit,
}: TitanAssaultGameProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const settings = useWorkshopSettings();
  const [audioEngine] = useState(() => new OdmAudioEngine());
  const [musicPlayer] = useState(() => new GameSoundtrackPlayer(settings.musicVolume, "titan"));
  const audioRef = useRef<OdmAudioEngine>(audioEngine);
  const musicRef = useRef<GameSoundtrackPlayer>(musicPlayer);
  const lobbyClientRef = useRef<WorkshopLobbyClient | null>(null);
  const roomTransportRef = useRef<WorkshopRoomTransport | null>(null);
  const hostEngineRef = useRef<TitanRoomHost | null>(null);
  const hostTickTimerRef = useRef<number | null>(null);
  const joinTimeoutRef = useRef<number | null>(null);
  const lastMetaSyncAtRef = useRef(0);
  const applyTitanMessageRef = useRef<(msg: Record<string, unknown>) => void>(() => {});

  const [mode, setMode] = useState<"LOBBY" | "SOLO" | "COOP">("LOBBY");
  const [lobbyTab, setLobbyTab] = useState<"deploy" | "gear" | "settings">("deploy");
  const [cosmetics, setCosmetics] = useState<TitanCosmeticOptions>(loadTitanCosmetics);
  const [playlistItems, setPlaylistItems] = useState(() => getSharedPlaylist());
  const [selectedPower, setSelectedPower] = useState<TitanPowerId>("attack");
  const [scoutName, setScoutName] = useState("Levi-Scout");
  const [roomTitle, setRoomTitle] = useState("Wall Rose Sector");
  const [joinCode, setJoinCode] = useState("");
  const [publicRooms, setPublicRooms] = useState<PublicTitanRoom[]>([]);
  const [wsStatus, setWsStatus] = useState<NetworkConnectionState>("probing");
  const [wsDetail, setWsDetail] = useState<string | null>(null);
  const [wsError, setWsError] = useState<string | null>(null);
  const [wsLatency, setWsLatency] = useState<number | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);

  const muted = settings.muted;
  const musicOn = settings.musicEnabled;
  const [pointerLocked, setPointerLocked] = useState(false);
  const [cameraView, setCameraView] = useState<"3RD" | "3RD WIDE" | "1ST">("3RD");
  const [titanPickerOpen, setTitanPickerOpen] = useState(false);

  // Live Combat & Titan Power HUD state
  const [hp, setHp] = useState(100);
  const [maxHpHud, setMaxHpHud] = useState(100);
  const [gas, setGas] = useState(100);
  const [bladeDurability, setBladeDurability] = useState(100);
  const [bladePairs, setBladePairs] = useState(4);
  const [thunderSpears, setThunderSpears] = useState(3);
  const [speedKmh, setSpeedKmh] = useState(0);
  const [airCombo, setAirCombo] = useState(0);
  const [shifterCharge, setShifterCharge] = useState(100);
  const [activeShifterForm, setActiveShifterForm] = useState<TitanPowerId | null>(null);
  const [shifterTimer, setShifterTimer] = useState(0);
  const [specialCooldownHud, setSpecialCooldownHud] = useState(0);

  const [wave, setWave] = useState(1);
  const [titansRemaining, setTitansRemaining] = useState(5);
  const [kills, setKills] = useState(0);
  const [score, setScore] = useState(0);
  const [statusBanner, setStatusBanner] = useState<"ACTIVE" | "VICTORY" | "DEFEAT">("ACTIVE");
  const [hookState, setHookState] = useState({ left: false, right: false, rangeOk: false });
  const [slashFeedback, setSlashFeedback] = useState<{
    text: string;
    crit: boolean;
    id: number;
  } | null>(null);
  const [damageFlash, setDamageFlash] = useState(false);
  const [shiftFlash, setShiftFlash] = useState(false);
  const [feed, setFeed] = useState<string[]>([]);
  const [coopSnapshot, setCoopSnapshot] = useState<TitanSnapshot | null>(null);
  const [localScoutId, setLocalScoutId] = useState<string | null>(null);
  const [sessionKey, setSessionKey] = useState(1);

  const selectedPowerRef = useRef<TitanPowerId>("attack");
  selectedPowerRef.current = selectedPower;
  const cameraViewRef = useRef<"3RD" | "3RD WIDE" | "1ST">("3RD");
  cameraViewRef.current = cameraView;
  const titanPickerOpenRef = useRef(false);
  titanPickerOpenRef.current = titanPickerOpen;
  const cosmeticsRef = useRef<TitanCosmeticOptions>(cosmetics);
  cosmeticsRef.current = cosmetics;
  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  const externalTransformFnRef = useRef<((powerId?: TitanPowerId) => void) | null>(null);

  const coopSnapshotRef = useRef<TitanSnapshot | null>(null);
  const pendingSpawnRef = useRef<{ x: number; y: number; z: number; yaw: number } | null>(null);
  const modeRef = useRef<"LOBBY" | "SOLO" | "COOP">("LOBBY");
  modeRef.current = mode;

  const gasRef = useRef(100);
  const bladeDurabilityRef = useRef(100);
  const bladePairsRef = useRef(4);
  const spearsRef = useRef(3);
  const hpRef = useRef(100);
  const shifterChargeRef = useRef(100);
  const shifterFormRef = useRef<TitanPowerId | null>(null);
  const shifterTimerRef = useRef(0);
  const airComboRef = useRef(0);

  const updateCosmetics = useCallback((patch: Partial<TitanCosmeticOptions>) => {
    setCosmetics((prev) => {
      const next = { ...prev, ...patch };
      try {
        window.localStorage.setItem(TITAN_COSMETICS_KEY, JSON.stringify(next));
      } catch {
        // Ignore quota errors
      }
      return next;
    });
  }, []);

  useEffect(() => {
    audioRef.current.setMuted(muted);
    audioRef.current.setVolume(settings.sfxVolume);
    musicRef.current.setVolume(settings.musicVolume);
    musicRef.current.setMuted(muted);
    musicRef.current.setMusicEnabled(musicOn);
  }, [muted, musicOn, settings.musicVolume, settings.sfxVolume]);

  useEffect(() => {
    return subscribeSoundtrackMeta(() => setPlaylistItems(getSharedPlaylist()));
  }, []);

  useEffect(() => {
    const audio = audioRef.current;
    const music = musicRef.current;
    music.attach();
    return () => {
      audio.dispose();
      music.dispose();
    };
  }, []);

  const pushFeed = useCallback((msg: string) => {
    setFeed((prev) => [msg, ...prev].slice(0, 4));
  }, []);

  const resetLocalStats = useCallback(() => {
    gasRef.current = 100;
    bladeDurabilityRef.current = 100;
    bladePairsRef.current = 4;
    spearsRef.current = 3;
    hpRef.current = 100;
    shifterChargeRef.current = 100;
    shifterFormRef.current = null;
    shifterTimerRef.current = 0;
    airComboRef.current = 0;

    setHp(100);
    setMaxHpHud(100);
    setGas(100);
    setBladeDurability(100);
    setBladePairs(4);
    setThunderSpears(3);
    setShifterCharge(100);
    setActiveShifterForm(null);
    setShifterTimer(0);
    setSpecialCooldownHud(0);
    setAirCombo(0);
    setTitanPickerOpen(false);
  }, []);

  const stopHostSimulation = useCallback(() => {
    if (hostTickTimerRef.current !== null) {
      window.clearInterval(hostTickTimerRef.current);
      hostTickTimerRef.current = null;
    }
    hostEngineRef.current = null;
  }, []);

  const clearJoinTimeout = useCallback(() => {
    if (joinTimeoutRef.current !== null) {
      window.clearTimeout(joinTimeoutRef.current);
      joinTimeoutRef.current = null;
    }
  }, []);

  applyTitanMessageRef.current = (msg: Record<string, unknown>) => {
    if (msg.type === "error" && typeof msg.message === "string") {
      clearJoinTimeout();
      setWsError(msg.message);
    } else if (msg.type === "titan:joined") {
      clearJoinTimeout();
      const snap = msg.snapshot as TitanSnapshot;
      const spawn = msg.spawn as { x: number; y: number; z: number; yaw: number };
      setLocalScoutId(String(msg.playerId));
      coopSnapshotRef.current = snap;
      setCoopSnapshot(snap);
      pendingSpawnRef.current = spawn;
      resetLocalStats();
      setWave(snap.wave);
      setStatusBanner(snap.status);
      setMode("COOP");
      setSessionKey((k) => k + 1);
      pushFeed(`Joined Scout Squad [${snap.code}]`);
    } else if (msg.type === "titan:snapshot") {
      const snap = msg as unknown as TitanSnapshot;
      coopSnapshotRef.current = snap;
      setCoopSnapshot(snap);
      setWave(snap.wave);
      setTitansRemaining(snap.titans.length);
      setStatusBanner(snap.status);
    } else if (msg.type === "titan:wave_advanced") {
      pushFeed(`WAVE ${String(msg.wave)} TITAN BREACH!`);
    } else if (msg.type === "titan:killed") {
      pushFeed(
        `${String(msg.killerName)} severed ${String(msg.variant).toUpperCase()} TITAN nape!`,
      );
    } else if (msg.type === "titan:slash_confirm") {
      const dmg = Number(msg.damage || 0);
      const crit = Boolean(msg.isNapeCrit);
      const killed = Boolean(msg.killed);
      const staggered = Boolean(msg.staggered);
      audioRef.current.playNapeHit(killed || crit);
      if (!shifterFormRef.current) {
        shifterChargeRef.current = Math.min(100, shifterChargeRef.current + (killed ? 24 : 8));
        setShifterCharge(Math.round(shifterChargeRef.current));
      }
      setSlashFeedback({
        text: killed
          ? `NAPE SEVERED! ${dmg}`
          : crit
            ? `NAPE CRIT ${dmg}`
            : staggered
              ? `STAGGER CUT ${dmg}`
              : `STRIKE ${dmg}`,
        crit: crit || killed,
        id: Date.now() + Math.random(),
      });
    } else if (msg.type === "scout:damaged") {
      if (!shifterFormRef.current) {
        hpRef.current = Number(msg.hp ?? hpRef.current);
        setHp(hpRef.current);
      } else {
        const delta = Math.max(4, Math.round((100 - Number(msg.hp ?? 75)) * 0.4));
        hpRef.current = Math.max(0, hpRef.current - delta);
        setHp(hpRef.current);
        if (hpRef.current <= 0) {
          shifterFormRef.current = null;
          setActiveShifterForm(null);
          hpRef.current = 45;
          setMaxHpHud(100);
          setHp(45);
        }
      }
      setDamageFlash(true);
      audioRef.current.playDamageAlert();
      window.setTimeout(() => setDamageFlash(false), 260);
    } else if (msg.type === "scout:respawned" || msg.type === "titan:restarted") {
      const sp = msg.spawn as { x: number; y: number; z: number; yaw: number };
      pendingSpawnRef.current = sp;
      resetLocalStats();
      setStatusBanner("ACTIVE");
    } else if (msg.type === "scout:joined") {
      pushFeed(`${String(msg.playerName)} deployed with ODM Gear`);
    } else if (msg.type === "scout:left") {
      pushFeed(`${String(msg.playerName)} returned to Wall Rose`);
    }
  };

  const dispatchHostEvents = useCallback((events: TitanOutgoingEvent[]) => {
    const transport = roomTransportRef.current;
    if (!transport) return;
    const localId = transport.localPlayerId;
    for (const ev of events) {
      if (ev.targetId) {
        if (ev.targetId === localId) {
          applyTitanMessageRef.current(ev.payload);
        } else {
          transport.send(ev.payload, ev.targetId);
        }
      } else {
        applyTitanMessageRef.current(ev.payload);
        transport.send(ev.payload);
      }
    }
  }, []);

  const startHostSimulation = useCallback(() => {
    if (hostTickTimerRef.current !== null) {
      window.clearInterval(hostTickTimerRef.current);
    }
    let lastTick = performance.now();
    hostTickTimerRef.current = window.setInterval(() => {
      const host = hostEngineRef.current;
      const transport = roomTransportRef.current;
      if (!host || !transport || !transport.getIsHost()) return;

      const now = performance.now();
      const dt = Math.min(0.15, Math.max(0.016, (now - lastTick) / 1000));
      lastTick = now;

      const evs = host.tick(dt);
      if (evs.length > 0) dispatchHostEvents(evs);

      const snap = host.serializeSnapshot();
      applyTitanMessageRef.current(snap as unknown as Record<string, unknown>);
      transport.send(snap as unknown as Record<string, unknown>);

      if (now - lastMetaSyncAtRef.current >= 2500) {
        lastMetaSyncAtRef.current = now;
        void transport.updateRoomMeta({
          title: host.title,
          wave: host.wave,
          status: host.status,
          players: host.players.size,
          maxPlayers: 4,
        });
      }
    }, 70);
  }, [dispatchHostEvents]);

  const sendAction = useCallback(
    (payload: Record<string, unknown>) => {
      const transport = roomTransportRef.current;
      if (!transport) return;
      if (transport.getIsHost() && hostEngineRef.current) {
        const host = hostEngineRef.current;
        const pid = transport.localPlayerId;
        if (payload.type === "scout:state") {
          host.handleScoutState(pid, payload);
        } else if (payload.type === "scout:slash") {
          dispatchHostEvents(host.handleScoutSlash(pid, payload));
        } else if (payload.type === "restart_expedition") {
          dispatchHostEvents(host.resetExpedition());
        }
        return;
      }
      transport.send(payload);
    },
    [dispatchHostEvents],
  );

  const connectTitanLobby = useCallback(() => {
    setWsError(null);
    lobbyClientRef.current?.connect();
  }, []);

  useEffect(() => {
    const lobby = createWorkshopLobbyClient({
      channel: "titan",
      onStateChange: (state, detail) => {
        setWsStatus(state);
        setWsDetail(detail ?? null);
        if (state === "connected") {
          setWsError(null);
        } else if (state === "offline" && detail) {
          setWsError(detail);
        }
      },
      onRoomsChange: (rooms: WorkshopRoomSummary[]) => {
        setPublicRooms(
          rooms.map((r) => ({
            code: r.code,
            title: r.title,
            players: r.players,
            maxPlayers: r.maxPlayers,
            wave: r.wave ?? 1,
            status: r.status || "ACTIVE",
          })),
        );
      },
      onLatency: (rtt) => setWsLatency(rtt),
    });

    lobbyClientRef.current = lobby;
    lobby.connect();

    return () => {
      clearJoinTimeout();
      stopHostSimulation();
      void roomTransportRef.current?.leave();
      roomTransportRef.current = null;
      void lobby.disconnect();
      lobbyClientRef.current = null;
    };
  }, [clearJoinTimeout, stopHostSimulation]);

  const startSoloExpedition = useCallback(() => {
    audioRef.current.initOnGesture();
    musicRef.current.startOnGesture();
    (document.activeElement as HTMLElement | null)?.blur?.();
    pendingSpawnRef.current = { ...SCOUT_SPAWNS[0] };
    resetLocalStats();
    setWave(1);
    setTitansRemaining(5);
    setKills(0);
    setScore(0);
    setStatusBanner("ACTIVE");
    setFeed([
      `3rd-Person ODM Deployed! Hold Q/E Grapple · Press 1-4 or T to Choose Titan · G Transform!`,
    ]);
    setMode("SOLO");
    setSessionKey((k) => k + 1);
  }, [resetLocalStats]);

  const openCoopSession = useCallback(
    async (action: "create" | "join", code?: string) => {
      audioRef.current.initOnGesture();
      musicRef.current.startOnGesture();
      (document.activeElement as HTMLElement | null)?.blur?.();
      setWsError(null);
      clearJoinTimeout();
      stopHostSimulation();
      await roomTransportRef.current?.leave();
      roomTransportRef.current = null;

      const cleanName = scoutName.trim() || "Levi-Scout";
      const { session, error } = await openWorkshopRoom({
        channel: "titan",
        mode: action,
        code,
        playerName: cleanName,
        maxPlayers: 4,
        initialMeta: {
          title: roomTitle.trim() || "Wall Rose Sector",
          wave: 1,
          status: "ACTIVE",
        },
        onStatusChange: (st, detail) => {
          if (st === "offline" && detail) setWsError(detail);
        },
        onLatency: (rtt) => setWsLatency(rtt),
        onPeersChange: (peers, _hostId, isHostNow) => {
          if (isHostNow && !hostEngineRef.current && coopSnapshotRef.current) {
            hostEngineRef.current = TitanRoomHost.fromSnapshot(
              coopSnapshotRef.current as unknown as HostTitanSnapshot,
            );
            startHostSimulation();
            pushFeed("Squad host migrated — your client is coordinating Titan waves.");
          }
          const host = hostEngineRef.current;
          if (host && isHostNow && peers.some((p) => p.playerId === roomTransportRef.current?.localPlayerId)) {
            const presentIds = new Set(peers.map((p) => p.playerId));
            const evs: TitanOutgoingEvent[] = [];
            for (const p of Array.from(host.players.values())) {
              if (!presentIds.has(p.id)) evs.push(...host.removeScout(p.id));
            }
            if (evs.length > 0) dispatchHostEvents(evs);
          }
        },
        onMessage: (msg) => {
          const transport = roomTransportRef.current;
          if (transport?.getIsHost() && hostEngineRef.current) {
            const host = hostEngineRef.current;
            const sid = msg.senderId;
            if (msg.type === "peer:hello") {
              const added = host.addScout(sid, String(msg.playerName || "Scout"));
              if (!added.ok) {
                transport.send({ type: "error", message: added.error || "Squad room full." }, sid);
                return;
              }
              dispatchHostEvents(added.events);
              const snap = host.serializeSnapshot();
              applyTitanMessageRef.current(snap as unknown as Record<string, unknown>);
              transport.send(snap as unknown as Record<string, unknown>);
              return;
            }
            if (msg.type === "peer:left") {
              dispatchHostEvents(host.removeScout(sid));
              return;
            }
            if (msg.type === "scout:state") {
              host.handleScoutState(sid, msg);
              return;
            }
            if (msg.type === "scout:slash") {
              dispatchHostEvents(host.handleScoutSlash(sid, msg));
              return;
            }
            if (msg.type === "restart_expedition") {
              dispatchHostEvents(host.resetExpedition());
              return;
            }
          }
          applyTitanMessageRef.current(msg);
        },
      });

      if (error || !session) {
        setWsError(error || "Unable to open Supabase co-op squad room.");
        return;
      }

      roomTransportRef.current = session;

      if (action === "create") {
        const host = new TitanRoomHost(session.code, roomTitle);
        hostEngineRef.current = host;
        const added = host.addScout(session.localPlayerId, cleanName);
        dispatchHostEvents(added.events);
        startHostSimulation();
      } else {
        joinTimeoutRef.current = window.setTimeout(() => {
          if (modeRef.current !== "COOP" && roomTransportRef.current === session) {
            setWsError(
              `Squad "${session.code}" host did not respond (room may have expired).`,
            );
            const ghost = session.getPeers().length <= 1;
            void session.leave(ghost);
            roomTransportRef.current = null;
            void lobbyClientRef.current?.refreshRooms();
          }
        }, 4500);
      }
    },
    [
      clearJoinTimeout,
      dispatchHostEvents,
      pushFeed,
      roomTitle,
      scoutName,
      startHostSimulation,
      stopHostSimulation,
    ],
  );

  const createCoopRoom = useCallback(() => {
    void openCoopSession("create");
  }, [openCoopSession]);

  const joinCoopRoom = useCallback(
    (code: string) => {
      const cleaned = code.trim().toUpperCase();
      if (!cleaned) return;
      void openCoopSession("join", cleaned);
    },
    [openCoopSession],
  );

  const returnToLobby = useCallback(() => {
    if (document.pointerLockElement) document.exitPointerLock?.();
    clearJoinTimeout();
    stopHostSimulation();
    if (modeRef.current === "COOP") {
      void roomTransportRef.current?.leave();
      roomTransportRef.current = null;
      coopSnapshotRef.current = null;
      setCoopSnapshot(null);
    }
    audioRef.current.updateGasIntensity(0);
    setMode("LOBBY");
    void lobbyClientRef.current?.refreshRooms();
  }, [clearJoinTimeout, stopHostSimulation]);

  // Main Three.js ODM Gear + Titan Shifting Combat Simulation
  useEffect(() => {
    if (mode === "LOBBY") return;
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || 1024;
    const height = container.clientHeight || 620;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x9ab3c7);
    scene.fog = new THREE.FogExp2(0x9ab3c7, 0.0021);

    const camera = new THREE.PerspectiveCamera(settingsRef.current.fov || 76, width / height, 0.1, 820);
    camera.rotation.order = "YXZ";
    scene.add(camera);

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    renderer.setSize(width, height);
    const q = settingsRef.current.graphicsQuality;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, q === "high" ? 2 : q === "medium" ? 1.5 : 1));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.shadowMap.enabled = q !== "low";
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.domElement.style.display = "block";
    renderer.domElement.style.width = "100%";
    renderer.domElement.style.height = "100%";
    renderer.domElement.tabIndex = 0;
    renderer.domElement.style.outline = "none";
    container.appendChild(renderer.domElement);
    (document.activeElement as HTMLElement | null)?.blur?.();
    renderer.domElement.focus({ preventScroll: true });

    const pmrem = new THREE.PMREMGenerator(renderer);
    const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;
    pmrem.dispose();

    const hemi = new THREE.HemisphereLight(0xf3f7ff, 0x4b4135, 0.96);
    scene.add(hemi);

    const sun = new THREE.DirectionalLight(0xffeed2, 1.9);
    sun.position.set(110, 195, 86);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.camera.left = -225;
    sun.shadow.camera.right = 225;
    sun.shadow.camera.top = 225;
    sun.shadow.camera.bottom = -225;
    sun.shadow.camera.far = 480;
    scene.add(sun);

    const district = buildWalledDistrictScene(scene);

    // 3rd-Person Local Player Scout Avatar & Shifter Titan Avatars
    const activeCosmetics = cosmeticsRef.current;
    const localScoutAvatar: LocalScoutAvatarRig = buildLocalScoutAvatar(activeCosmetics);
    scene.add(localScoutAvatar.group);

    const localShifterAvatars: Record<TitanPowerId, LocalShifterAvatarRig> = {
      attack: buildLocalShifterRig("attack"),
      armored: buildLocalShifterRig("armored"),
      jaw: buildLocalShifterRig("jaw"),
      colossal: buildLocalShifterRig("colossal"),
    };
    for (const pid of Object.keys(localShifterAvatars) as TitanPowerId[]) {
      localShifterAvatars[pid].group.visible = false;
      scene.add(localShifterAvatars[pid].group);
    }

    // Optional 1st-Person Viewmodels (when toggling camera view with [C])
    const blades = buildOdmBladeViewmodels(activeCosmetics);
    blades.root.visible = false;
    camera.add(blades.root);

    const shifterArmModels: Record<
      TitanPowerId,
      ReturnType<typeof buildTitanFirstPersonArms>
    > = {
      attack: buildTitanFirstPersonArms("attack"),
      armored: buildTitanFirstPersonArms("armored"),
      jaw: buildTitanFirstPersonArms("jaw"),
      colossal: buildTitanFirstPersonArms("colossal"),
    };
    for (const pid of Object.keys(shifterArmModels) as TitanPowerId[]) {
      shifterArmModels[pid].root.visible = false;
      camera.add(shifterArmModels[pid].root);
    }

    // 3D ODM Grapple Cables + Anchor Flares
    const makeCableLine = (colorCss: string) => {
      const geo = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(),
        new THREE.Vector3(),
      ]);
      const mat = new THREE.LineBasicMaterial({ color: colorCss });
      const line = new THREE.Line(geo, mat);
      line.visible = false;
      line.frustumCulled = false;
      scene.add(line);
      return line;
    };
    const leftCableLine = makeCableLine(activeCosmetics.cableColorHex);
    const rightCableLine = makeCableLine(activeCosmetics.cableColorHex);

    const anchorDotGeo = new THREE.SphereGeometry(0.35, 8, 8);
    const anchorDotMat = new THREE.MeshBasicMaterial({ color: activeCosmetics.cableColorHex });
    const leftAnchorDot = new THREE.Mesh(anchorDotGeo, anchorDotMat);
    const rightAnchorDot = new THREE.Mesh(anchorDotGeo, anchorDotMat);
    leftAnchorDot.visible = false;
    rightAnchorDot.visible = false;
    scene.add(leftAnchorDot, rightAnchorDot);

    // Thunder Spear Active Projectiles & Shockwave Rings
    const activeSpears: {
      mesh: THREE.Mesh;
      x: number;
      y: number;
      z: number;
      vx: number;
      vy: number;
      vz: number;
      ttl: number;
    }[] = [];
    const spearGeo = new THREE.CylinderGeometry(0.08, 0.12, 1.4, 6);
    spearGeo.rotateX(Math.PI / 2);
    const spearMat = new THREE.MeshBasicMaterial({ color: 0xffe478 });

    const shockwaves: { mesh: THREE.Mesh; maxScale: number; life: number; maxLife: number }[] = [];
    const ringGeo = new THREE.RingGeometry(0.8, 1.4, 32);
    ringGeo.rotateX(-Math.PI / 2);
    const spawnShockwave = (wx: number, wy: number, wz: number, maxScale: number, colorHex: number) => {
      const mat = new THREE.MeshBasicMaterial({
        color: colorHex,
        transparent: true,
        opacity: 0.85,
        side: THREE.DoubleSide,
      });
      const m = new THREE.Mesh(ringGeo, mat);
      m.position.set(wx, Math.max(0.25, wy), wz);
      scene.add(m);
      shockwaves.push({ mesh: m, maxScale, life: 0.55, maxLife: 0.55 });
    };

    // Shifter Lightning Pillar Effect
    const lightningBolts: { mesh: THREE.Mesh; life: number }[] = [];
    const boltGeo = new THREE.CylinderGeometry(0.85, 1.9, 110, 10, 1, true);
    const spawnTransformLightning = (wx: number, wz: number) => {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xffd54f,
        transparent: true,
        opacity: 0.95,
        side: THREE.DoubleSide,
      });
      const m = new THREE.Mesh(boltGeo, mat);
      m.position.set(wx, 55, wz);
      scene.add(m);
      lightningBolts.push({ mesh: m, life: 0.45 });
    };

    // Steam Burst Particles
    const steamParticles: {
      mesh: THREE.Mesh;
      vy: number;
      vx: number;
      vz: number;
      life: number;
      maxLife: number;
    }[] = [];
    const steamGeo = new THREE.SphereGeometry(1.1, 8, 8);
    const spawnSteamBurst = (wx: number, wy: number, wz: number, count: number, colorHex = 0xf4f2ee) => {
      for (let i = 0; i < count; i++) {
        const mat = new THREE.MeshBasicMaterial({
          color: colorHex,
          transparent: true,
          opacity: 0.65,
          depthWrite: false,
        });
        const m = new THREE.Mesh(steamGeo, mat);
        m.position.set(
          wx + (Math.random() - 0.5) * 3.4,
          wy + (Math.random() - 0.5) * 2.6,
          wz + (Math.random() - 0.5) * 3.4,
        );
        scene.add(m);
        steamParticles.push({
          mesh: m,
          vx: (Math.random() - 0.5) * 5.2,
          vy: 4.5 + Math.random() * 7.2,
          vz: (Math.random() - 0.5) * 5.2,
          life: 1.4 + Math.random() * 0.9,
          maxLife: 2.1,
        });
      }
    };

    // Solo local wave state
    let soloWave = 1;
    let soloSeq = 0;
    let soloScore = 0;
    let soloKills = 0;
    let soloStatus: "ACTIVE" | "VICTORY" | "DEFEAT" = "ACTIVE";
    let soloTitans: TitanEntity[] = [];
    if (mode === "SOLO") {
      const initW = makeSoloWave(1, 0);
      soloTitans = initW.titans;
      soloSeq = initW.nextSeq;
    }

    const titanRigs = new Map<string, TitanModelRig>();
    const teammateRigs = new Map<string, ScoutTeammateRig>();

    const initSp = pendingSpawnRef.current || SCOUT_SPAWNS[0];
    pendingSpawnRef.current = null;

    const player = {
      x: initSp.x,
      y: initSp.y,
      z: initSp.z,
      vx: 0,
      vy: 0,
      vz: 0,
      yaw: initSp.yaw,
      pitch: 0,
      eyeHeightCurrent: 1.55,
      grounded: false,
      slashAnim: 0,
      slashCooldown: 0,
      gasBurstCooldown: 0,
      specialCooldown: 0,
      spearCooldown: 0,
      walkPhase: 0,
      cameraShake: 0,
    };

    const hookL: HookAnchor = { active: false, x: 0, y: 0, z: 0 };
    const hookR: HookAnchor = { active: false, x: 0, y: 0, z: 0 };

    const keys: Record<string, boolean> = {};
    const releaseAllHooks = () => {
      if (hookL.active || hookR.active) {
        hookL.active = false;
        hookL.attachedTitanId = undefined;
        hookR.active = false;
        hookR.attachedTitanId = undefined;
        setHookState((prev) => ({ ...prev, left: false, right: false }));
      }
    };
    const clearKeys = () => {
      for (const prop of Object.keys(keys)) delete keys[prop];
      // Since Q and E only work while held, blur must immediately release hooks too
      releaseAllHooks();
    };
    const isInputFocused = (target: EventTarget | null) =>
      target instanceof HTMLInputElement ||
      target instanceof HTMLTextAreaElement ||
      target instanceof HTMLSelectElement;

    const computeCameraRigTransform = () => {
      const activeForm = shifterFormRef.current;
      const eyeY = player.y + player.eyeHeightCurrent;
      const view = cameraViewRef.current;
      const forward = new THREE.Vector3(0, 0, -1).applyEuler(
        new THREE.Euler(player.pitch, player.yaw, 0, "YXZ"),
      );
      if (view === "1ST") {
        const pos = new THREE.Vector3(player.x, eyeY, player.z);
        return { camPos: pos, forward, pivot: pos };
      }

      const rx = Math.cos(player.yaw);
      const rz = -Math.sin(player.yaw);
      const scaleMult = activeForm
        ? activeForm === "colossal"
          ? 4.4
          : activeForm === "jaw"
            ? 1.75
            : 2.9
        : view === "3RD WIDE"
          ? 1.38
          : 1.0;

      const desiredDist = 5.4 * scaleMult;
      const sideOffset = (activeForm ? 1.8 : 0.78) * Math.min(2.2, scaleMult);
      const pivot = new THREE.Vector3(
        player.x + rx * sideOffset,
        eyeY + (activeForm ? 1.2 : 0.48),
        player.z + rz * sideOffset,
      );

      const backDirX = -forward.x;
      const backDirY = -forward.y;
      const backDirZ = -forward.z;
      const camObstacle = raycastCityObstacles(
        pivot.x,
        pivot.y,
        pivot.z,
        backDirX,
        backDirY,
        backDirZ,
        desiredDist + 0.6,
      );
      const safeDist = camObstacle ? Math.max(1.25, camObstacle.dist - 0.55) : desiredDist;
      const camPos = new THREE.Vector3(
        pivot.x + backDirX * safeDist,
        Math.max(0.55, pivot.y + backDirY * safeDist),
        pivot.z + backDirZ * safeDist,
      );
      return { camPos, forward, pivot };
    };

    const resolveCrosshairAimTarget = (maxRange = 148) => {
      const { camPos, forward } = computeCameraRigTransform();
      const playerDistFromCam = Math.hypot(
        player.x - camPos.x,
        player.y + player.eyeHeightCurrent - camPos.y,
        player.z - camPos.z,
      );
      const minFocusDist = cameraViewRef.current === "1ST" ? 0.5 : Math.max(1.5, playerDistFromCam * 0.72);
      const worldHit = raycastCityObstacles(
        camPos.x + forward.x * minFocusDist,
        camPos.y + forward.y * minFocusDist,
        camPos.z + forward.z * minFocusDist,
        forward.x,
        forward.y,
        forward.z,
        maxRange,
      );

      const activeTitanList: {
        id: string;
        x: number;
        z: number;
        height: number;
        bodyRadius: number;
      }[] =
        mode === "SOLO"
          ? soloTitans
          : (coopSnapshotRef.current?.titans || []).map((t) => ({
              id: t.id,
              x: t.x,
              z: t.z,
              height: t.height,
              bodyRadius: (t.height / 10) * 1.9,
            }));

      let titanHitPoint: { x: number; y: number; z: number; id: string; dist: number } | null = null;
      const rayStartX = camPos.x + forward.x * minFocusDist;
      const rayStartY = camPos.y + forward.y * minFocusDist;
      const rayStartZ = camPos.z + forward.z * minFocusDist;

      for (const t of activeTitanList) {
        const cx = t.x;
        const cy = t.height * 0.68;
        const cz = t.z;
        const ocx = rayStartX - cx;
        const ocy = rayStartY - cy;
        const ocz = rayStartZ - cz;
        const proj = -(ocx * forward.x + ocy * forward.y + ocz * forward.z);
        if (proj < 1 || proj > maxRange) continue;
        const closestX = rayStartX + forward.x * proj;
        const closestY = rayStartY + forward.y * proj;
        const closestZ = rayStartZ + forward.z * proj;
        const dSq =
          (closestX - cx) * (closestX - cx) +
          (closestY - cy) * (closestY - cy) +
          (closestZ - cz) * (closestZ - cz);
        const r = t.bodyRadius * 1.75;
        if (dSq <= r * r) {
          if (!titanHitPoint || proj < titanHitPoint.dist) {
            titanHitPoint = { x: closestX, y: closestY, z: closestZ, id: t.id, dist: proj };
          }
        }
      }

      return { worldHit, titanHitPoint, camPos, forward, rayStartX, rayStartY, rayStartZ };
    };

    const fireGrapple = (side: "left" | "right" | "both") => {
      if (shifterFormRef.current || gasRef.current <= 0.5) return;
      const { worldHit, titanHitPoint } = resolveCrosshairAimTarget(148);

      let target: HookAnchor | null = null;
      if (titanHitPoint && (!worldHit || titanHitPoint.dist <= worldHit.dist)) {
        target = {
          active: true,
          x: titanHitPoint.x,
          y: titanHitPoint.y,
          z: titanHitPoint.z,
          attachedTitanId: titanHitPoint.id,
        };
      } else if (worldHit) {
        target = { active: true, x: worldHit.x, y: worldHit.y, z: worldHit.z };
      }

      if (!target) return;

      if (side === "left" || side === "both") {
        hookL.active = true;
        hookL.x = target.x;
        hookL.y = target.y;
        hookL.z = target.z;
        hookL.attachedTitanId = target.attachedTitanId;
      }
      if (side === "right" || side === "both") {
        hookR.active = true;
        hookR.x = target.x;
        hookR.y = target.y;
        hookR.z = target.z;
        hookR.attachedTitanId = target.attachedTitanId;
      }

      audioRef.current.playGrappleLaunch();
      setHookState((prev) => ({ ...prev, left: hookL.active, right: hookR.active }));
    };

    const releaseGrapple = (side: "left" | "right" | "both") => {
      let released = false;
      if ((side === "left" || side === "both") && hookL.active) {
        hookL.active = false;
        hookL.attachedTitanId = undefined;
        released = true;
      }
      if ((side === "right" || side === "both") && hookR.active) {
        hookR.active = false;
        hookR.attachedTitanId = undefined;
        released = true;
      }
      if (released) {
        audioRef.current.playHookRelease();
        setHookState((prev) => ({ ...prev, left: hookL.active, right: hookR.active }));
      }
    };

    const applyDamageToTitansSolo = (
      t: TitanEntity,
      idx: number,
      dmg: number,
      isCrit: boolean,
      staggerSec: number,
      labelOverride?: string,
    ) => {
      t.hp -= dmg;
      if (staggerSec > 0) {
        t.staggerTimer = Math.max(t.staggerTimer, staggerSec);
        t.telegraphTimer = 0;
      }
      if (t.hp <= 0) {
        spawnSteamBurst(t.x, t.height * 0.72, t.z, 20);
        soloTitans.splice(idx, 1);
        soloKills += 1;
        if (!player.grounded && !shifterFormRef.current) {
          airComboRef.current += 1;
          setAirCombo(airComboRef.current);
        }
        const comboBonus = airComboRef.current > 1 ? airComboRef.current * 45 : 0;
        const pts =
          (t.variant === "colossal"
            ? 1000
            : t.variant === "armored"
              ? 420
              : t.variant === "abnormal"
                ? 260
                : 150) + comboBonus;
        soloScore += pts;
        setKills(soloKills);
        setScore(soloScore);
        if (!shifterFormRef.current) {
          shifterChargeRef.current = Math.min(100, shifterChargeRef.current + 24);
          setShifterCharge(Math.round(shifterChargeRef.current));
        }
        audioRef.current.playNapeHit(true);
        setSlashFeedback({
          text: labelOverride || `NAPE SEVERED! ${dmg}`,
          crit: true,
          id: Date.now() + Math.random(),
        });
        pushFeed(`Slain ${t.variant.toUpperCase()} TITAN! (+${pts})`);
      } else {
        if (!shifterFormRef.current) {
          shifterChargeRef.current = Math.min(100, shifterChargeRef.current + 7);
          setShifterCharge(Math.round(shifterChargeRef.current));
        }
        audioRef.current.playNapeHit(isCrit);
        setSlashFeedback({
          text: labelOverride || (isCrit ? `NAPE CRIT ${dmg}` : staggerSec > 0 ? `TENDON CUT ${dmg}` : `HIT ${dmg}`),
          crit: isCrit,
          id: Date.now() + Math.random(),
        });
      }
    };

    const checkSoloWaveClear = () => {
      if (soloTitans.length === 0 && soloStatus === "ACTIVE") {
        if (soloWave < 4) {
          soloWave += 1;
          const nextW = makeSoloWave(soloWave, soloSeq);
          soloTitans = nextW.titans;
          soloSeq = nextW.nextSeq;
          setWave(soloWave);
          pushFeed(`WAVE ${soloWave}: Titans breached the inner square!`);
        } else {
          soloStatus = "VICTORY";
          setStatusBanner("VICTORY");
          pushFeed("DISTRICT SECURED! All Titan waves eliminated.");
        }
      }
      setTitansRemaining(soloTitans.length);
    };

    const transformIntoTitan = (overridePowerId?: TitanPowerId, forceToggleEject = false) => {
      if (shifterFormRef.current) {
        if (!overridePowerId || forceToggleEject || shifterFormRef.current === overridePowerId) {
          // Eject safely out of Titan body back to ODM Scout with upward pop!
          const prevName = TITAN_POWERS_BY_ID[shifterFormRef.current].name;
          shifterFormRef.current = null;
          shifterTimerRef.current = 0;
          setActiveShifterForm(null);
          setShifterTimer(0);
          hpRef.current = 100;
          setMaxHpHud(100);
          setHp(100);
          player.vy = 14;
          pushFeed(`Ejected from ${prevName} into ODM Gear!`);
          return;
        }
      }

      if (overridePowerId) {
        selectedPowerRef.current = overridePowerId;
        setSelectedPower(overridePowerId);
      }

      if (!shifterFormRef.current && shifterChargeRef.current < 100) {
        pushFeed(
          `Selected ${TITAN_POWERS_BY_ID[selectedPowerRef.current].name} (Charging ${Math.round(shifterChargeRef.current)}%)`,
        );
        return;
      }

      const power = TITAN_POWERS_BY_ID[overridePowerId || selectedPowerRef.current];
      releaseAllHooks();
      setTitanPickerOpen(false);
      shifterFormRef.current = power.id;
      shifterChargeRef.current = 0;
      shifterTimerRef.current = power.durationSec;
      hpRef.current = power.maxHp;

      setActiveShifterForm(power.id);
      setShifterCharge(0);
      setShifterTimer(power.durationSec);
      setMaxHpHud(power.maxHp);
      setHp(power.maxHp);
      setShiftFlash(true);
      window.setTimeout(() => setShiftFlash(false), 360);

      player.cameraShake = 0.65;
      audioRef.current.playTitanTransformThunder();
      spawnTransformLightning(player.x, player.z);
      spawnSteamBurst(
        player.x,
        player.y + 4,
        player.z,
        22,
        power.id === "colossal" ? 0xff9b54 : 0xfff3d1,
      );

      // Transformation Shockwave (Colossal triggers massive Transformation Nuke!)
      const nukeRadius = power.id === "colossal" ? 38 : 20;
      const nukeDmg = power.id === "colossal" ? 320 : 115;
      spawnShockwave(player.x, player.y + 0.5, player.z, nukeRadius, power.accentColor);

      if (mode === "SOLO") {
        for (let i = soloTitans.length - 1; i >= 0; i--) {
          const t = soloTitans[i];
          const d = Math.hypot(t.x - player.x, t.z - player.z);
          if (d <= nukeRadius) {
            applyDamageToTitansSolo(
              t,
              i,
              nukeDmg,
              true,
              3.0,
              power.id === "colossal" ? `COLOSSAL BLAST ${nukeDmg}` : `SHIFT SHOCK ${nukeDmg}`,
            );
          }
        }
        checkSoloWaveClear();
      } else {
        for (const t of coopSnapshotRef.current?.titans || []) {
          const d = Math.hypot(t.x - player.x, t.z - player.z);
          if (d <= nukeRadius) {
            sendAction({
              type: "scout:slash",
              titanId: t.id,
              damage: nukeDmg,
              isNapeCrit: true,
              staggerSec: 3.0,
            });
          }
        }
      }

      pushFeed(`TRANSFORMED: ${power.name.toUpperCase()} (${power.specialName} [V])!`);
    };

    externalTransformFnRef.current = (powerId?: TitanPowerId) => transformIntoTitan(powerId, false);

    const executePrimaryAttack = () => {
      if (player.slashCooldown > 0) return;

      // A. TITAN SHIFTER MELEE SMASH / CLAW CLEAVE
      if (shifterFormRef.current) {
        const power = TITAN_POWERS_BY_ID[shifterFormRef.current];
        player.slashCooldown = shifterFormRef.current === "jaw" ? 0.32 : 0.48;
        player.slashAnim = 1.0;
        player.cameraShake = 0.28;
        audioRef.current.playTitanSmash();

        const eyeY = player.y + player.eyeHeightCurrent;
        const forward = new THREE.Vector3(0, 0, -1).applyEuler(
          new THREE.Euler(player.pitch * 0.5, player.yaw, 0, "YXZ"),
        );

        if (mode === "SOLO") {
          for (let i = soloTitans.length - 1; i >= 0; i--) {
            const t = soloTitans[i];
            const dx = t.x - player.x;
            const dz = t.z - player.z;
            const d = Math.hypot(dx, dz);
            if (d <= power.punchRange + t.bodyRadius) {
              const dot = (dx * forward.x + dz * forward.z) / Math.max(0.1, d);
              if (dot > 0.1 || d < power.punchRange * 0.5) {
                const isNapeShot = eyeY >= t.height * 0.65 || shifterFormRef.current === "jaw";
                const dmg = Math.round(power.punchDamage * (isNapeShot ? 1.45 : 1.0));
                applyDamageToTitansSolo(t, i, dmg, isNapeShot, 1.5, `${power.name.split(" ")[0].toUpperCase()} SMASH ${dmg}`);
              }
            }
          }
          checkSoloWaveClear();
        } else {
          for (const t of coopSnapshotRef.current?.titans || []) {
            const d = Math.hypot(t.x - player.x, t.z - player.z);
            if (d <= power.punchRange + (t.height / 10) * 1.9) {
              sendAction({
                type: "scout:slash",
                titanId: t.id,
                damage: Math.round(power.punchDamage * 1.25),
                isNapeCrit: true,
                staggerSec: 1.5,
              });
              break;
            }
          }
        }
        return;
      }

      // B. SCOUT ODM TWIN-BLADE SPIN SLASH
      if (bladeDurabilityRef.current <= 0) {
        pushFeed("Blades snapped! Press [R] to swap blade pair.");
        return;
      }
      player.slashCooldown = 0.26;
      player.slashAnim = 1.0;

      const totalSpeed = Math.hypot(player.vx, player.vy, player.vz);
      const kmh = Math.round(totalSpeed * 3.6);
      audioRef.current.playBladeSlash(kmh);

      bladeDurabilityRef.current = Math.max(0, bladeDurabilityRef.current - 7);
      setBladeDurability(bladeDurabilityRef.current);

      const eyeY = player.y + player.eyeHeightCurrent;
      const forward = new THREE.Vector3(0, 0, -1).applyEuler(
        new THREE.Euler(player.pitch, player.yaw, 0, "YXZ"),
      );
      const momentumMult = 1 + Math.min(2.7, totalSpeed / 15);

      if (mode === "SOLO") {
        for (let i = soloTitans.length - 1; i >= 0; i--) {
          const t = soloTitans[i];
          const sinY = Math.sin(t.yaw);
          const cosY = Math.cos(t.yaw);
          const scale = t.height / 10;
          const crouchOffset = t.staggerTimer > 0 ? 0.62 : 1.0;

          const napeWx = t.x + sinY * (-0.95 * scale);
          const napeWy = t.height * 0.795 * crouchOffset;
          const napeWz = t.z + cosY * (-0.95 * scale);

          const toNapeX = napeWx - player.x;
          const toNapeY = napeWy - eyeY;
          const toNapeZ = napeWz - player.z;
          const dNape = Math.hypot(toNapeX, toNapeY, toNapeZ);

          const toBodyX = t.x - player.x;
          const toBodyY = t.height * 0.6 * crouchOffset - eyeY;
          const toBodyZ = t.z - player.z;
          const dBody = Math.hypot(toBodyX, toBodyY, toBodyZ);

          const slashRange = Math.max(6.8, t.bodyRadius * 2.9);
          const napeHit = dNape <= Math.max(5.0, t.bodyRadius * 2.2);
          const bodyHit = dBody <= slashRange;

          if (napeHit || bodyHit) {
            const checkDir = napeHit
              ? (toNapeX * forward.x + toNapeY * forward.y + toNapeZ * forward.z) / Math.max(0.1, dNape)
              : (toBodyX * forward.x + toBodyY * forward.y + toBodyZ * forward.z) / Math.max(0.1, dBody);

            if (checkDir > 0.2 || dNape < 4.0) {
              // Tendon Cut when slashing lower legs -> kneels Titan so nape becomes reachable!
              const isTendonCut = !napeHit && eyeY < t.height * 0.44;
              const armorResist = t.variant === "armored" && !napeHit && !isTendonCut ? 0.45 : 1.0;
              const baseDmg = napeHit ? 68 : isTendonCut ? 32 : 25;
              const dmg = Math.max(8, Math.round(baseDmg * momentumMult * armorResist));

              player.vy = Math.max(player.vy, 6.2);
              applyDamageToTitansSolo(
                t,
                i,
                dmg,
                napeHit,
                isTendonCut ? 3.4 : 0,
                t.variant === "armored" && !napeHit ? `ARMOR DEFLECT ${dmg}` : undefined,
              );
              break;
            }
          }
        }
        checkSoloWaveClear();
      } else {
        const titans = coopSnapshotRef.current?.titans || [];
        for (const t of titans) {
          const sinY = Math.sin(t.yaw);
          const cosY = Math.cos(t.yaw);
          const scale = t.height / 10;
          const crouchOffset = t.staggerTimer > 0 ? 0.62 : 1.0;
          const bodyRad = scale * 1.9;
          const napeWx = t.x + sinY * (-0.95 * scale);
          const napeWy = t.height * 0.795 * crouchOffset;
          const napeWz = t.z + cosY * (-0.95 * scale);

          const dNape = Math.hypot(napeWx - player.x, napeWy - eyeY, napeWz - player.z);
          const dBody = Math.hypot(t.x - player.x, t.height * 0.6 * crouchOffset - eyeY, t.z - player.z);
          const napeHit = dNape <= Math.max(5.0, bodyRad * 2.2);
          const bodyHit = dBody <= Math.max(6.8, bodyRad * 2.9);

          if (napeHit || bodyHit) {
            const isTendonCut = !napeHit && eyeY < t.height * 0.44;
            const dmg = Math.round((napeHit ? 68 : 28) * momentumMult);
            player.vy = Math.max(player.vy, 6.2);
            sendAction({
              type: "scout:slash",
              titanId: t.id,
              damage: dmg,
              isNapeCrit: napeHit,
              staggerSec: isTendonCut ? 3.4 : 0,
            });
            break;
          }
        }
      }
    };

    const executeTitanSpecial = () => {
      if (!shifterFormRef.current || player.specialCooldown > 0) return;
      const power = TITAN_POWERS_BY_ID[shifterFormRef.current];
      player.specialCooldown = power.specialCooldown;
      setSpecialCooldownHud(Number(power.specialCooldown.toFixed(1)));
      player.slashAnim = 1.0;
      player.cameraShake = 0.55;

      const forward = new THREE.Vector3(0, 0, -1).applyEuler(
        new THREE.Euler(player.pitch * 0.35, player.yaw, 0, "YXZ"),
      );

      if (power.id === "attack" || power.id === "armored" || power.id === "jaw") {
        // Explosive forward Titan Rush / Uppercut / Jaw Pounce
        const lungeVel = power.id === "jaw" ? 42 : power.id === "armored" ? 36 : 30;
        player.vx += forward.x * lungeVel;
        player.vy += power.id === "attack" ? 13 : power.id === "jaw" ? 16 : 6;
        player.vz += forward.z * lungeVel;
        audioRef.current.playTitanSmash();
        spawnShockwave(player.x + forward.x * 5, player.y + 1, player.z + forward.z * 5, 16, power.accentColor);
      } else {
        // Colossal Scorching Steam Blast AoE
        audioRef.current.playExplosion();
        spawnSteamBurst(player.x, player.y + 6, player.z, 26, 0xff8c38);
        spawnShockwave(player.x, player.y + 1, player.z, 28, 0xff6229);
      }

      const blastRange = power.id === "colossal" ? 28 : 20;
      const blastDmg = power.id === "colossal" ? 290 : power.id === "jaw" ? 255 : 230;

      if (mode === "SOLO") {
        for (let i = soloTitans.length - 1; i >= 0; i--) {
          const t = soloTitans[i];
          const d = Math.hypot(t.x - player.x, t.z - player.z);
          if (d <= blastRange + t.bodyRadius) {
            applyDamageToTitansSolo(t, i, blastDmg, true, 3.2, `${power.specialName.toUpperCase()} ${blastDmg}`);
          }
        }
        checkSoloWaveClear();
      } else {
        for (const t of coopSnapshotRef.current?.titans || []) {
          const d = Math.hypot(t.x - player.x, t.z - player.z);
          if (d <= blastRange + (t.height / 10) * 1.9) {
            sendAction({
              type: "scout:slash",
              titanId: t.id,
              damage: blastDmg,
              isNapeCrit: true,
              staggerSec: 3.2,
            });
          }
        }
      }
    };

    const fireThunderSpear = () => {
      if (shifterFormRef.current || spearsRef.current <= 0 || player.spearCooldown > 0) return;
      spearsRef.current -= 1;
      setThunderSpears(spearsRef.current);
      player.spearCooldown = 0.7;

      const eyeY = player.y + player.eyeHeightCurrent;
      const { worldHit, titanHitPoint, camPos, forward } = resolveCrosshairAimTarget(175);
      let aimTarget: THREE.Vector3;
      if (titanHitPoint && (!worldHit || titanHitPoint.dist <= worldHit.dist)) {
        aimTarget = new THREE.Vector3(titanHitPoint.x, titanHitPoint.y, titanHitPoint.z);
      } else if (worldHit) {
        aimTarget = new THREE.Vector3(worldHit.x, worldHit.y, worldHit.z);
      } else {
        aimTarget = camPos.clone().addScaledVector(forward, 130);
      }

      const startPos = new THREE.Vector3(player.x, eyeY - 0.12, player.z).addScaledVector(
        forward,
        1.15,
      );
      const spearDir = aimTarget.clone().sub(startPos).normalize();
      const mesh = new THREE.Mesh(spearGeo, spearMat);
      mesh.position.copy(startPos);
      mesh.lookAt(startPos.clone().add(spearDir));
      scene.add(mesh);

      activeSpears.push({
        mesh,
        x: mesh.position.x,
        y: mesh.position.y,
        z: mesh.position.z,
        vx: spearDir.x * 84,
        vy: spearDir.y * 84,
        vz: spearDir.z * 84,
        ttl: 2.4,
      });
      audioRef.current.playThunderSpearFire();
    };

    const reloadOrResupply = () => {
      let nearStation = false;
      for (const s of SUPPLY_STATIONS) {
        if (Math.hypot(player.x - s.x, player.z - s.z) < 6.8 && Math.abs(player.y - s.y) < 4.5) {
          nearStation = true;
          break;
        }
      }
      if (nearStation) {
        gasRef.current = 100;
        bladePairsRef.current = 4;
        bladeDurabilityRef.current = 100;
        spearsRef.current = 3;
        if (!shifterFormRef.current) {
          hpRef.current = 100;
          setHp(100);
        }
        setGas(100);
        setBladePairs(4);
        setBladeDurability(100);
        setThunderSpears(3);
        audioRef.current.playResupply();
        pushFeed("Supply Depot: Gas, Blades & 3 Thunder Spears restored!");
      } else if (!shifterFormRef.current && bladePairsRef.current > 0 && bladeDurabilityRef.current < 100) {
        bladePairsRef.current -= 1;
        bladeDurabilityRef.current = 100;
        setBladePairs(bladePairsRef.current);
        setBladeDurability(100);
        audioRef.current.playResupply();
        pushFeed(`Fresh Ultrahard Steel blades equipped (${bladePairsRef.current} left)`);
      }
    };

    let isDraggingLook = false;

    const onKeyDown = (e: KeyboardEvent) => {
      if (isInputFocused(e.target)) return;
      const k = e.key.toLowerCase();
      if (
        ["Space", "Tab", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code) ||
        [" ", "tab", "arrowup", "arrowdown", "arrowleft", "arrowright"].includes(k)
      ) {
        e.preventDefault();
      }
      audioRef.current.initOnGesture();
      musicRef.current.startOnGesture();

      keys[k] = true;
      if (e.code) keys[e.code] = true;

      // Q and E work STRICTLY while held: fire on initial keydown, release immediately on keyup!
      if (!e.repeat) {
        if (k === "q" || e.code === "KeyQ") {
          fireGrapple("left");
        } else if (k === "e" || e.code === "KeyE") {
          fireGrapple("right");
        } else if (k === "1" || e.code === "Digit1") {
          setSelectedPower("attack");
          selectedPowerRef.current = "attack";
          if (titanPickerOpenRef.current || shifterChargeRef.current >= 100) {
            if (titanPickerOpenRef.current) transformIntoTitan("attack", false);
            else pushFeed("Titan Choice: ATTACK TITAN ([G] to Transform)");
          } else {
            pushFeed("Titan Choice: ATTACK TITAN");
          }
        } else if (k === "2" || e.code === "Digit2") {
          setSelectedPower("armored");
          selectedPowerRef.current = "armored";
          if (titanPickerOpenRef.current || shifterChargeRef.current >= 100) {
            if (titanPickerOpenRef.current) transformIntoTitan("armored", false);
            else pushFeed("Titan Choice: ARMORED TITAN ([G] to Transform)");
          } else {
            pushFeed("Titan Choice: ARMORED TITAN");
          }
        } else if (k === "3" || e.code === "Digit3") {
          setSelectedPower("jaw");
          selectedPowerRef.current = "jaw";
          if (titanPickerOpenRef.current || shifterChargeRef.current >= 100) {
            if (titanPickerOpenRef.current) transformIntoTitan("jaw", false);
            else pushFeed("Titan Choice: JAW TITAN ([G] to Transform)");
          } else {
            pushFeed("Titan Choice: JAW TITAN");
          }
        } else if (k === "4" || e.code === "Digit4") {
          setSelectedPower("colossal");
          selectedPowerRef.current = "colossal";
          if (titanPickerOpenRef.current || shifterChargeRef.current >= 100) {
            if (titanPickerOpenRef.current) transformIntoTitan("colossal", false);
            else pushFeed("Titan Choice: COLOSSAL TITAN ([G] to Transform)");
          } else {
            pushFeed("Titan Choice: COLOSSAL TITAN");
          }
        } else if (k === "t" || e.code === "KeyT") {
          setTitanPickerOpen((open) => {
            const next = !open;
            if (next && document.pointerLockElement) document.exitPointerLock?.();
            return next;
          });
        } else if (k === "g" || e.code === "KeyG") {
          transformIntoTitan(undefined, true);
        } else if (k === "v" || e.code === "KeyV") {
          if (shifterFormRef.current) executeTitanSpecial();
          else executePrimaryAttack();
        } else if (k === "x" || e.code === "KeyX") {
          fireThunderSpear();
        } else if (k === "c" || e.code === "KeyC") {
          setCameraView((prev) =>
            prev === "3RD" ? "3RD WIDE" : prev === "3RD WIDE" ? "1ST" : "3RD",
          );
        } else if (k === "r" || e.code === "KeyR") {
          reloadOrResupply();
        } else if (k === "f" || e.code === "KeyF") {
          executePrimaryAttack();
        } else if (k === " " || e.code === "Space") {
          if (shifterFormRef.current) {
            if (player.grounded) {
              const power = TITAN_POWERS_BY_ID[shifterFormRef.current];
              player.vy = power.jumpVel;
              player.grounded = false;
              audioRef.current.playTitanSmash();
            }
          } else if (player.grounded) {
            player.vy = 10.8;
            player.grounded = false;
            audioRef.current.playGasDash();
          } else if (player.gasBurstCooldown <= 0 && gasRef.current >= 4) {
            player.gasBurstCooldown = 0.42;
            gasRef.current = Math.max(0, gasRef.current - 5);
            setGas(Math.round(gasRef.current));
            const dashDir = new THREE.Vector3(0, 0, -1).applyEuler(
              new THREE.Euler(player.pitch * 0.7, player.yaw, 0, "YXZ"),
            );
            player.vx += dashDir.x * 16.5;
            player.vy += Math.max(4.5, dashDir.y * 14 + 3.5);
            player.vz += dashDir.z * 16.5;
            audioRef.current.playGasDash();
          }
        } else if (k === "m" || e.code === "KeyM") {
          updateWorkshopSettings({ muted: !settingsRef.current.muted });
        }
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      keys[k] = false;
      if (e.code) keys[e.code] = false;

      // Retract Q/E hooks immediately when key is released!
      if (k === "q" || e.code === "KeyQ") {
        releaseGrapple("left");
      } else if (k === "e" || e.code === "KeyE") {
        releaseGrapple("right");
      }
    };

    const onMouseMove = (e: MouseEvent) => {
      if (titanPickerOpenRef.current) return;
      const locked = document.pointerLockElement === renderer.domElement;
      if (!locked && !isDraggingLook) return;
      const sens = 0.0022 * (settingsRef.current.mouseSensitivity || 1);
      player.yaw -= e.movementX * sens;
      player.pitch = THREE.MathUtils.clamp(player.pitch - e.movementY * sens, -1.48, 1.48);
    };

    const onMouseDown = (e: MouseEvent) => {
      if (titanPickerOpenRef.current) return;
      audioRef.current.initOnGesture();
      musicRef.current.startOnGesture();
      (document.activeElement as HTMLElement | null)?.blur?.();
      renderer.domElement.focus({ preventScroll: true });

      if (e.button === 0) {
        if (document.pointerLockElement !== renderer.domElement) {
          renderer.domElement.requestPointerLock?.();
          isDraggingLook = true;
        }
        executePrimaryAttack();
      } else if (e.button === 2) {
        fireGrapple("both");
      }
    };

    const onMouseUp = (e: MouseEvent) => {
      if (e.button === 0) isDraggingLook = false;
      else if (e.button === 2) releaseGrapple("both");
    };

    const onPointerLockChange = () => {
      setPointerLocked(document.pointerLockElement === renderer.domElement);
    };
    const onContextMenu = (e: MouseEvent) => e.preventDefault();

    window.addEventListener("keydown", onKeyDown, { capture: true, passive: false });
    window.addEventListener("keyup", onKeyUp, { capture: true });
    window.addEventListener("blur", clearKeys);
    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup", onMouseUp);
    document.addEventListener("pointerlockchange", onPointerLockChange);
    renderer.domElement.addEventListener("mousedown", onMouseDown);
    renderer.domElement.addEventListener("contextmenu", onContextMenu);

    const onResize = () => {
      if (!container) return;
      const nw = container.clientWidth;
      const nh = container.clientHeight;
      if (nw <= 0 || nh <= 0) return;
      camera.aspect = nw / nh;
      camera.updateProjectionMatrix();
      renderer.setSize(nw, nh);
    };
    const ro = new ResizeObserver(onResize);
    ro.observe(container);

    const clock = new THREE.Clock();
    let rafId = 0;
    let disposed = false;
    let lastHudSync = 0;
    let lastNetSend = 0;

    const tick = () => {
      if (disposed) return;
      const dt = Math.min(clock.getDelta(), 0.05);
      const nowMs = performance.now();

      if (pendingSpawnRef.current) {
        player.x = pendingSpawnRef.current.x;
        player.y = pendingSpawnRef.current.y;
        player.z = pendingSpawnRef.current.z;
        player.yaw = pendingSpawnRef.current.yaw;
        player.vx = 0;
        player.vy = 0;
        player.vz = 0;
        releaseAllHooks();
        pendingSpawnRef.current = null;
      }

      player.slashCooldown = Math.max(0, player.slashCooldown - dt);
      player.gasBurstCooldown = Math.max(0, player.gasBurstCooldown - dt);
      player.specialCooldown = Math.max(0, player.specialCooldown - dt);
      player.spearCooldown = Math.max(0, player.spearCooldown - dt);
      player.slashAnim = Math.max(0, player.slashAnim - dt * 4.5);
      player.cameraShake = Math.max(0, player.cameraShake - dt * 1.4);

      const gameActive =
        mode === "SOLO" ? soloStatus === "ACTIVE" : (coopSnapshotRef.current?.status ?? "ACTIVE") === "ACTIVE";

      // Smoothly transition eye height when Titan Shifted vs ODM Scout
      const targetEyeHeight = shifterFormRef.current
        ? TITAN_POWERS_BY_ID[shifterFormRef.current].eyeHeight
        : 1.55;
      player.eyeHeightCurrent = THREE.MathUtils.lerp(
        player.eyeHeightCurrent,
        targetEyeHeight,
        Math.min(1, 7 * dt),
      );

      // Update Shifter Duration & Passive Charge
      if (shifterFormRef.current) {
        shifterTimerRef.current = Math.max(0, shifterTimerRef.current - dt);
        if (shifterTimerRef.current <= 0) {
          shifterFormRef.current = null;
          setActiveShifterForm(null);
          hpRef.current = 100;
          setMaxHpHud(100);
          setHp(100);
          player.vy = 12;
          pushFeed("Titan Shifter energy exhausted — returned to ODM Gear!");
        }
      } else if (gameActive) {
        shifterChargeRef.current = Math.min(100, shifterChargeRef.current + 2.4 * dt);
      }

      // Sync 1st-person vs 3rd-person avatars
      const activeForm = shifterFormRef.current;
      const isFirstPerson = cameraViewRef.current === "1ST";
      blades.root.visible = isFirstPerson && activeForm === null;
      for (const pid of Object.keys(shifterArmModels) as TitanPowerId[]) {
        shifterArmModels[pid].root.visible = isFirstPerson && activeForm === pid;
      }
      localScoutAvatar.group.visible = !isFirstPerson && activeForm === null;
      for (const pid of Object.keys(localShifterAvatars) as TitanPowerId[]) {
        localShifterAvatars[pid].group.visible = !isFirstPerson && activeForm === pid;
      }

      // Reticle range check (uses camera crosshair target!)
      const aimTarget = resolveCrosshairAimTarget(148);
      const aimHit = Boolean(aimTarget.worldHit || aimTarget.titanHitPoint);
      const eyeY = player.y + player.eyeHeightCurrent;

      // Movement & Physics (ODM Gear vs Shifted Titan)
      let gasIntensity = 0;
      if (gameActive) {
        const fwdInput =
          (keys["w"] || keys["KeyW"] || keys["arrowup"] || keys["ArrowUp"] ? 1 : 0) -
          (keys["s"] || keys["KeyS"] || keys["arrowdown"] || keys["ArrowDown"] ? 1 : 0);
        const sideInput =
          (keys["d"] || keys["KeyD"] || keys["arrowright"] || keys["ArrowRight"] ? 1 : 0) -
          (keys["a"] || keys["KeyA"] || keys["arrowleft"] || keys["ArrowLeft"] ? 1 : 0);

        const fx = -Math.sin(player.yaw);
        const fz = -Math.cos(player.yaw);
        const rx = Math.cos(player.yaw);
        const rz = -Math.sin(player.yaw);
        let mx = fx * fwdInput + rx * sideInput;
        let mz = fz * fwdInput + rz * sideInput;
        const mLen = Math.hypot(mx, mz);
        if (mLen > 0.001) {
          mx /= mLen;
          mz /= mLen;
        }

        if (activeForm) {
          // Titan Shifter Movement Physics (high-stride heavy stomping or Jaw sprint)
          const power = TITAN_POWERS_BY_ID[activeForm];
          const sprinting = Boolean(keys["shift"] || keys["ShiftLeft"] || keys["ShiftRight"]);
          const moveSpeed = power.speed * (sprinting ? 1.25 : 1.0);
          const targetVx = mx * moveSpeed;
          const targetVz = mz * moveSpeed;
          player.vx += (targetVx - player.vx) * Math.min(1, 9 * dt);
          player.vz += (targetVz - player.vz) * Math.min(1, 9 * dt);
          if (player.grounded && mLen > 0.001) player.walkPhase += dt * 7.5;
          player.vy -= 26 * dt;
        } else {
          // Hold-to-grapple safeguard: if Q/E key isn't physically held (outside RMB hold), enforce hook state
          const reelBoosting =
            (keys[" "] || keys["Space"] || keys["shift"] || keys["ShiftLeft"] || keys["ShiftRight"]) &&
            gasRef.current > 0.5;

          const updateTitanHookFollow = (hk: HookAnchor) => {
            if (!hk.active || !hk.attachedTitanId) return;
            const list = mode === "SOLO" ? soloTitans : coopSnapshotRef.current?.titans || [];
            const target = list.find((t) => t.id === hk.attachedTitanId);
            if (!target) {
              hk.active = false;
              return;
            }
            hk.x = target.x;
            hk.y = target.height * 0.72;
            hk.z = target.z;
          };
          updateTitanHookFollow(hookL);
          updateTitanHookFollow(hookR);

          const activeHooks: HookAnchor[] = [];
          if (hookL.active) activeHooks.push(hookL);
          if (hookR.active) activeHooks.push(hookR);

          if (activeHooks.length > 0 && gasRef.current > 0.2) {
            let avgX = 0;
            let avgY = 0;
            let avgZ = 0;
            for (const h of activeHooks) {
              avgX += h.x;
              avgY += h.y;
              avgZ += h.z;
            }
            avgX /= activeHooks.length;
            avgY /= activeHooks.length;
            avgZ /= activeHooks.length;

            const toX = avgX - player.x;
            const toY = avgY - eyeY;
            const toZ = avgZ - player.z;
            const dist = Math.max(0.5, Math.hypot(toX, toY, toZ));
            const ux = toX / dist;
            const uy = toY / dist;
            const uz = toZ / dist;

            const pullForce = (activeHooks.length === 2 ? 44 : 33) * (reelBoosting ? 1.48 : 1.0);
            player.vx += ux * pullForce * dt;
            player.vy += (uy * pullForce + 5.5) * dt;
            player.vz += uz * pullForce * dt;

            if (mLen > 0.001) {
              const steerForce = reelBoosting ? 25 : 18;
              player.vx += mx * steerForce * dt;
              player.vz += mz * steerForce * dt;
            }

            gasIntensity = reelBoosting ? 1.0 : 0.65;
            gasRef.current = Math.max(0, gasRef.current - (reelBoosting ? 4.8 : 2.3) * dt);
          } else {
            if (player.grounded) {
              if (airComboRef.current > 0) {
                airComboRef.current = 0;
                setAirCombo(0);
              }
              const sprinting = Boolean(keys["shift"] || keys["ShiftLeft"] || keys["ShiftRight"]);
              const groundSpeed = sprinting ? 14.8 : 9.4;
              const targetVx = mx * groundSpeed;
              const targetVz = mz * groundSpeed;
              player.vx += (targetVx - player.vx) * Math.min(1, 12 * dt);
              player.vz += (targetVz - player.vz) * Math.min(1, 12 * dt);
              if (mLen > 0.001) player.walkPhase += dt * (sprinting ? 14 : 9);
            } else {
              if (mLen > 0.001) {
                player.vx += mx * 17 * dt;
                player.vz += mz * 17 * dt;
              }
              if (reelBoosting) {
                player.vy += 12.8 * dt;
                gasIntensity = 0.55;
                gasRef.current = Math.max(0, gasRef.current - 3.4 * dt);
              }
            }
            if (player.grounded) {
              gasRef.current = Math.min(100, gasRef.current + 10.5 * dt);
            }
          }

          player.vy -= 17.2 * dt;
          const drag = Math.exp(-0.3 * dt);
          player.vx *= drag;
          player.vz *= drag;

          const spd = Math.hypot(player.vx, player.vy, player.vz);
          if (spd > 50) {
            const k = 50 / spd;
            player.vx *= k;
            player.vy *= k;
            player.vz *= k;
          }
        }

        player.x += player.vx * dt;
        player.y += player.vy * dt;
        player.z += player.vz * dt;

        const col = resolvePlayerCityCollision(
          player.x,
          player.y,
          player.z,
          player.vy,
          activeForm ? 1.8 : 0.65,
          activeForm ? player.eyeHeightCurrent + 0.8 : 1.8,
        );
        player.x = col.x;
        player.y = col.y;
        player.z = col.z;
        player.vy = col.vy;
        player.grounded = col.grounded;

        // Auto-resupply on touching Supply Depots
        if (!activeForm) {
          for (const s of SUPPLY_STATIONS) {
            if (
              Math.hypot(player.x - s.x, player.z - s.z) < 2.7 &&
              Math.abs(player.y - s.y) < 2.4 &&
              (gasRef.current < 98 ||
                bladePairsRef.current < 4 ||
                bladeDurabilityRef.current < 95 ||
                spearsRef.current < 3)
            ) {
              gasRef.current = 100;
              bladePairsRef.current = 4;
              bladeDurabilityRef.current = 100;
              spearsRef.current = 3;
              hpRef.current = 100;
              setGas(100);
              setBladePairs(4);
              setBladeDurability(100);
              setThunderSpears(3);
              setHp(100);
              audioRef.current.playResupply();
              pushFeed("Resupplied Gas, Blades & Thunder Spears!");
              break;
            }
          }
        }
      }

      audioRef.current.updateGasIntensity(gasIntensity);

      // Update Thunder Spears in flight
      for (let i = activeSpears.length - 1; i >= 0; i--) {
        const sp = activeSpears[i];
        sp.ttl -= dt;
        const stepX = sp.vx * dt;
        const stepY = sp.vy * dt;
        const stepZ = sp.vz * dt;
        const stepLen = Math.hypot(stepX, stepY, stepZ);
        const worldCheck = raycastCityObstacles(
          sp.x,
          sp.y,
          sp.z,
          stepX / Math.max(0.01, stepLen),
          stepY / Math.max(0.01, stepLen),
          stepZ / Math.max(0.01, stepLen),
          stepLen,
        );

        sp.x += stepX;
        sp.y += stepY;
        sp.z += stepZ;
        sp.mesh.position.set(sp.x, sp.y, sp.z);

        let detonated = Boolean(worldCheck) || sp.ttl <= 0;
        const targetTitans = mode === "SOLO" ? soloTitans : coopSnapshotRef.current?.titans || [];
        for (const t of targetTitans) {
          const rad = (t.height / 10) * 2.1;
          if (Math.hypot(sp.x - t.x, sp.z - t.z) <= rad && sp.y >= 0 && sp.y <= t.height + 1.5) {
            detonated = true;
            break;
          }
        }

        if (detonated) {
          audioRef.current.playExplosion();
          spawnSteamBurst(sp.x, sp.y, sp.z, 14, 0xffaa44);
          spawnShockwave(sp.x, sp.y, sp.z, 12, 0xff7838);

          if (mode === "SOLO") {
            for (let ti = soloTitans.length - 1; ti >= 0; ti--) {
              const t = soloTitans[ti];
              if (Math.hypot(sp.x - t.x, sp.z - t.z) <= 13 && Math.abs(sp.y - t.height * 0.65) <= t.height) {
                applyDamageToTitansSolo(t, ti, 185, true, 3.2, "THUNDER SPEAR 185");
              }
            }
            checkSoloWaveClear();
          } else {
            for (const t of coopSnapshotRef.current?.titans || []) {
              if (Math.hypot(sp.x - t.x, sp.z - t.z) <= 13) {
                sendAction({
                  type: "scout:slash",
                  titanId: t.id,
                  damage: 185,
                  isNapeCrit: true,
                  staggerSec: 3.2,
                });
              }
            }
          }
          scene.remove(sp.mesh);
          activeSpears.splice(i, 1);
        }
      }

      // Camera & 3rd-Person Avatar / 1st-Person Viewmodel Animation
      const horizSpeed = Math.hypot(player.vx, player.vz);
      const totalSpeed = Math.hypot(player.vx, player.vy, player.vz);
      const bob =
        player.grounded && horizSpeed > 1.2
          ? Math.sin(player.walkPhase) * (activeForm ? 0.22 : 0.05)
          : 0;
      const shakeX = (Math.random() - 0.5) * player.cameraShake * 0.45;
      const shakeY = (Math.random() - 0.5) * player.cameraShake * 0.45;

      const rigCam = computeCameraRigTransform();
      camera.position.set(rigCam.camPos.x + shakeX, rigCam.camPos.y + bob + shakeY, rigCam.camPos.z);
      camera.rotation.set(player.pitch, player.yaw, 0, "YXZ");

      const targetFov = THREE.MathUtils.clamp(75 + (totalSpeed - 8) * 0.62, 75, 102);
      if (Math.abs(camera.fov - targetFov) > 0.15) {
        camera.fov = THREE.MathUtils.lerp(camera.fov, targetFov, Math.min(1, 8 * dt));
        camera.updateProjectionMatrix();
      }

      const sa = player.slashAnim;
      if (activeForm) {
        const sRig = localShifterAvatars[activeForm];
        sRig.group.position.set(player.x, player.y, player.z);
        sRig.group.rotation.y = player.yaw;
        const tSwing = player.grounded && horizSpeed > 1.5 ? Math.sin(player.walkPhase) : 0;
        sRig.leftLeg.rotation.x = tSwing * 0.65;
        sRig.rightLeg.rotation.x = -tSwing * 0.65;
        sRig.torso.rotation.x = THREE.MathUtils.clamp(horizSpeed * 0.012, 0, 0.28);
        sRig.lowerJaw.rotation.x = sa > 0 ? 0.52 : 0.14;
        sRig.leftArm.rotation.x = -tSwing * 0.45 - Math.sin(sa * Math.PI) * 1.45;
        sRig.rightArm.rotation.x = tSwing * 0.45 - Math.sin(sa * Math.PI) * 1.65;

        if (isFirstPerson) {
          const arms = shifterArmModels[activeForm];
          arms.leftArm.position.z = -0.38 - Math.sin(sa * Math.PI) * 0.72;
          arms.rightArm.position.z = -0.38 - Math.sin(Math.min(1, sa * 1.15) * Math.PI) * 0.82;
          arms.leftArm.rotation.x = 0.14 + Math.sin(sa * Math.PI) * 0.38;
          arms.rightArm.rotation.x = 0.14 + Math.sin(sa * Math.PI) * 0.45;
        }
      } else {
        localScoutAvatar.group.position.set(player.x, player.y, player.z);
        localScoutAvatar.group.rotation.y = player.yaw;

        // ODM banking tilt forward while soaring, vertical run stride on rooftops/streets
        const airTilt = !player.grounded ? THREE.MathUtils.clamp(totalSpeed * 0.02, 0.12, 0.58) : 0;
        localScoutAvatar.bodyGroup.rotation.x = THREE.MathUtils.lerp(
          localScoutAvatar.bodyGroup.rotation.x,
          -airTilt,
          0.2,
        );
        // Survey Corps cape billows backward (+Z) behind the Scout with air speed
        localScoutAvatar.cloak.rotation.x = -Math.min(
          0.85,
          0.08 + totalSpeed * 0.024 + Math.sin(nowMs * 0.018) * (totalSpeed > 6 ? 0.12 : 0.02),
        );

        const stride = player.grounded && horizSpeed > 1.2 ? Math.sin(player.walkPhase) * 0.72 : 0;
        localScoutAvatar.leftLeg.rotation.x = player.grounded ? stride : -0.35;
        localScoutAvatar.rightLeg.rotation.x = player.grounded ? -stride : -0.15;

        localScoutAvatar.leftArm.rotation.set(
          -Math.sin(sa * Math.PI) * 1.8 - stride * 0.5,
          0,
          -0.25 - Math.sin(sa * Math.PI) * 0.8,
        );
        localScoutAvatar.rightArm.rotation.set(
          -Math.sin(sa * Math.PI) * 1.8 + stride * 0.5,
          0,
          0.25 + Math.sin(sa * Math.PI) * 0.8,
        );
        localScoutAvatar.leftBlade.rotation.y = sa * Math.PI * 2.5;
        localScoutAvatar.rightBlade.rotation.y = -sa * Math.PI * 2.5;

        if (isFirstPerson) {
          blades.leftBlade.rotation.set(
            0.15 - Math.sin(sa * Math.PI) * 1.35,
            -0.24 - Math.sin(sa * Math.PI) * 0.9,
            0.35 + sa * Math.PI * 2.0,
          );
          blades.rightBlade.rotation.set(
            0.15 - Math.sin(sa * Math.PI) * 1.35,
            0.24 + Math.sin(sa * Math.PI) * 0.9,
            -0.35 - sa * Math.PI * 2.0,
          );
        }
      }

      // Active 3D Grapple Cables (launch directly from 3rd-person Scout waist launchers!)
      localScoutAvatar.group.updateMatrixWorld(true);
      const updateCableVisual = (
        hk: HookAnchor,
        sideSign: -1 | 1,
        line: THREE.Line,
        dot: THREE.Mesh,
      ) => {
        if (!hk.active || activeForm) {
          line.visible = false;
          dot.visible = false;
          return;
        }
        line.visible = true;
        dot.visible = true;
        dot.position.set(hk.x, hk.y, hk.z);

        const start = new THREE.Vector3();
        if (!isFirstPerson) {
          const anchorObj =
            sideSign < 0 ? localScoutAvatar.leftHipAnchor : localScoutAvatar.rightHipAnchor;
          anchorObj.getWorldPosition(start);
        } else {
          const hipOffset = new THREE.Vector3(sideSign * 0.42, -0.58, -0.15).applyEuler(
            new THREE.Euler(0, player.yaw, 0, "YXZ"),
          );
          start.set(
            player.x + hipOffset.x,
            player.y + player.eyeHeightCurrent + hipOffset.y,
            player.z + hipOffset.z,
          );
        }
        line.geometry.setFromPoints([start, new THREE.Vector3(hk.x, hk.y, hk.z)]);
      };
      updateCableVisual(hookL, -1, leftCableLine, leftAnchorDot);
      updateCableVisual(hookR, 1, rightCableLine, rightAnchorDot);

      // Solo Titan AI Simulation
      if (mode === "SOLO" && soloStatus === "ACTIVE") {
        for (const t of soloTitans) {
          if (t.staggerTimer > 0) {
            t.staggerTimer = Math.max(0, t.staggerTimer - dt);
            t.telegraphTimer = 0;
            continue;
          }
          const dx = player.x - t.x;
          const dz = player.z - t.z;
          const dHoriz = Math.max(0.01, Math.hypot(dx, dz));
          t.yaw = Math.atan2(dx / dHoriz, dz / dHoriz);

          if (t.telegraphTimer > 0) {
            t.telegraphTimer -= dt;
            if (t.telegraphTimer <= 0) {
              const sd = Math.hypot(player.x - t.x, player.z - t.z);
              if (sd < t.bodyRadius * 2.15 && player.y < t.height * 0.92) {
                const baseDmg = t.variant === "colossal" ? 42 : t.variant === "armored" ? 32 : 24;
                const resist = activeForm ? 1 - TITAN_POWERS_BY_ID[activeForm].damageResist : 1;
                const dmg = Math.max(4, Math.round(baseDmg * resist));
                hpRef.current = Math.max(0, hpRef.current - dmg);
                setHp(hpRef.current);
                setDamageFlash(true);
                player.cameraShake = 0.45;
                audioRef.current.playDamageAlert();
                window.setTimeout(() => setDamageFlash(false), 260);
                player.vx += (dx / dHoriz) * 13;
                player.vy = Math.max(player.vy, 9);
                player.vz += (dz / dHoriz) * 13;
                if (hpRef.current <= 0) {
                  if (activeForm) {
                    shifterFormRef.current = null;
                    setActiveShifterForm(null);
                    hpRef.current = 45;
                    setMaxHpHud(100);
                    setHp(45);
                    pushFeed("Titan Shell broken — ejected back into ODM Scout!");
                  } else {
                    soloStatus = "DEFEAT";
                    setStatusBanner("DEFEAT");
                  }
                }
              }
            }
          } else {
            if (dHoriz > t.bodyRadius * 1.45) {
              const resolved = resolveTitanCityPush(
                t.x + (dx / dHoriz) * t.speed * dt,
                t.z + (dz / dHoriz) * t.speed * dt,
                t.bodyRadius,
              );
              t.x = resolved.x;
              t.z = resolved.z;
              t.stepPhase += dt * t.speed * 0.95;
            }
            t.attackCooldown -= dt;
            if (t.attackCooldown <= 0 && dHoriz < t.bodyRadius * 2.35 && player.y < t.height * 0.95) {
              t.telegraphTimer = 0.85;
              t.attackCooldown = t.variant === "abnormal" ? 2.4 : 3.2;
            }
          }
        }
      }

      // Sync 3D Titan Rigs (Billboard HP, Stagger Kneel, Telegraph Ring, Nape Glow)
      const renderTitans =
        mode === "SOLO"
          ? soloTitans
          : (coopSnapshotRef.current?.titans || []).map((st) => ({
              ...st,
              bodyRadius: (st.height / 10) * 1.9,
              stepPhase: nowMs * 0.004,
            }));

      const liveTitanIds = new Set(renderTitans.map((t) => t.id));
      for (const [id, rig] of titanRigs.entries()) {
        if (!liveTitanIds.has(id)) {
          scene.remove(rig.group);
          disposeTitanHierarchy(rig.group);
          titanRigs.delete(id);
        }
      }

      for (const t of renderTitans) {
        let rig = titanRigs.get(t.id);
        if (!rig) {
          rig = buildTitanRig(t.variant);
          scene.add(rig.group);
          titanRigs.set(t.id, rig);
        }
        rig.group.position.x = THREE.MathUtils.lerp(rig.group.position.x, t.x, mode === "SOLO" ? 1 : 0.35);
        rig.group.position.z = THREE.MathUtils.lerp(rig.group.position.z, t.z, mode === "SOLO" ? 1 : 0.35);
        rig.group.rotation.y = t.yaw;

        // Kneel pose when staggered so nape drops and exposes itself cleanly!
        if (t.staggerTimer > 0) {
          rig.torso.rotation.x = THREE.MathUtils.lerp(rig.torso.rotation.x, 0.58, 0.2);
          rig.group.position.y = THREE.MathUtils.lerp(rig.group.position.y, -t.height * 0.24, 0.2);
          rig.leftArm.rotation.x = -0.3;
          rig.rightArm.rotation.x = -0.3;
          rig.lowerJaw.rotation.x = 0.08;
          (rig.telegraphRing.material as THREE.MeshBasicMaterial).opacity = 0;
        } else {
          rig.torso.rotation.x = THREE.MathUtils.lerp(rig.torso.rotation.x, 0, 0.2);
          rig.group.position.y = THREE.MathUtils.lerp(rig.group.position.y, 0, 0.2);
          const phase = mode === "SOLO" ? t.stepPhase : nowMs * 0.0045;
          rig.leftLeg.rotation.x = Math.sin(phase) * 0.55;
          rig.rightLeg.rotation.x = -Math.sin(phase) * 0.55;
          if (t.telegraphTimer > 0) {
            rig.leftArm.rotation.x = -2.25;
            rig.rightArm.rotation.x = -2.25;
            rig.lowerJaw.rotation.x = 0.56;
            (rig.telegraphRing.material as THREE.MeshBasicMaterial).opacity = 0.78;
          } else {
            rig.leftArm.rotation.x = -Math.sin(phase) * 0.45 - 0.15;
            rig.rightArm.rotation.x = Math.sin(phase) * 0.45 - 0.15;
            rig.lowerJaw.rotation.x =
              t.variant === "abnormal" ? 0.34 + Math.sin(phase * 1.4) * 0.12 : 0.16;
            (rig.telegraphRing.material as THREE.MeshBasicMaterial).opacity = 0;
          }
        }

        const napeScale = 0.96 + Math.sin(nowMs * 0.008) * 0.09;
        rig.napeMesh.scale.set(napeScale, napeScale, 1);

        const hpRatio = Math.max(0, Math.min(1, t.hp / Math.max(1, t.maxHp)));
        rig.hpBarFill.scale.x = Math.max(0.01, hpRatio);
        rig.hpBarGroup.lookAt(camera.position);
      }

      // Sync Co-op Teammate Scouts / Shifted Titan Avatars
      if (mode === "COOP" && coopSnapshotRef.current) {
        const remoteScouts = coopSnapshotRef.current.players.filter((p) => p.id !== localScoutId);
        const liveScoutIds = new Set(remoteScouts.map((p) => p.id));
        for (const [id, rig] of teammateRigs.entries()) {
          if (!liveScoutIds.has(id)) {
            scene.remove(rig.group, rig.leftCable, rig.rightCable);
            disposeTitanHierarchy(rig.group);
            rig.leftCable.geometry.dispose();
            rig.rightCable.geometry.dispose();
            teammateRigs.delete(id);
          }
        }
        for (const p of remoteScouts) {
          let rig = teammateRigs.get(p.id);
          if (!rig) {
            rig = buildScoutTeammateRig(p.color);
            scene.add(rig.group, rig.leftCable, rig.rightCable);
            teammateRigs.set(p.id, rig);
          }
          rig.group.visible = p.alive;
          rig.scoutMeshGroup.visible = !p.shifterForm;
          rig.shifterMeshGroup.visible = Boolean(p.shifterForm);
          rig.group.position.x = THREE.MathUtils.lerp(rig.group.position.x, p.x, 0.35);
          rig.group.position.y = THREE.MathUtils.lerp(rig.group.position.y, p.y, 0.35);
          rig.group.position.z = THREE.MathUtils.lerp(rig.group.position.z, p.z, 0.35);
          rig.group.rotation.y = p.yaw;

          if (p.alive && !p.shifterForm && p.hookLeft?.active) {
            rig.leftCable.visible = true;
            rig.leftCable.geometry.setFromPoints([
              new THREE.Vector3(rig.group.position.x, rig.group.position.y + 1.0, rig.group.position.z),
              new THREE.Vector3(p.hookLeft.x, p.hookLeft.y, p.hookLeft.z),
            ]);
          } else {
            rig.leftCable.visible = false;
          }
          if (p.alive && !p.shifterForm && p.hookRight?.active) {
            rig.rightCable.visible = true;
            rig.rightCable.geometry.setFromPoints([
              new THREE.Vector3(rig.group.position.x, rig.group.position.y + 1.0, rig.group.position.z),
              new THREE.Vector3(p.hookRight.x, p.hookRight.y, p.hookRight.z),
            ]);
          } else {
            rig.rightCable.visible = false;
          }
        }
      }

      // Animate Shockwaves, Lightning Bolts & Steam Particles
      for (let i = shockwaves.length - 1; i >= 0; i--) {
        const sw = shockwaves[i];
        sw.life -= dt;
        if (sw.life <= 0) {
          scene.remove(sw.mesh);
          (sw.mesh.material as THREE.Material).dispose();
          shockwaves.splice(i, 1);
          continue;
        }
        const prog = 1 - sw.life / sw.maxLife;
        sw.mesh.scale.setScalar(1 + prog * sw.maxScale);
        (sw.mesh.material as THREE.MeshBasicMaterial).opacity = (1 - prog) * 0.8;
      }

      for (let i = lightningBolts.length - 1; i >= 0; i--) {
        const lb = lightningBolts[i];
        lb.life -= dt;
        if (lb.life <= 0) {
          scene.remove(lb.mesh);
          (lb.mesh.material as THREE.Material).dispose();
          lightningBolts.splice(i, 1);
          continue;
        }
        (lb.mesh.material as THREE.MeshBasicMaterial).opacity = (lb.life / 0.45) * 0.95;
      }

      for (let i = steamParticles.length - 1; i >= 0; i--) {
        const sp = steamParticles[i];
        sp.life -= dt;
        if (sp.life <= 0) {
          scene.remove(sp.mesh);
          (sp.mesh.material as THREE.Material).dispose();
          steamParticles.splice(i, 1);
          continue;
        }
        sp.mesh.position.x += sp.vx * dt;
        sp.mesh.position.y += sp.vy * dt;
        sp.mesh.position.z += sp.vz * dt;
        const tNorm = sp.life / sp.maxLife;
        sp.mesh.scale.setScalar(1 + (1 - tNorm) * 2.2);
        (sp.mesh.material as THREE.MeshBasicMaterial).opacity = tNorm * 0.55;
      }

      // Throttled HUD & Co-op Sync
      if (nowMs - lastHudSync > 70) {
        lastHudSync = nowMs;
        setSpeedKmh(Math.round(totalSpeed * 3.6));
        setGas(Math.round(gasRef.current));
        setShifterCharge(Math.round(shifterChargeRef.current));
        setShifterTimer(Math.ceil(shifterTimerRef.current));
        setSpecialCooldownHud(Number(player.specialCooldown.toFixed(1)));
      setHookState({
        left: hookL.active,
        right: hookR.active,
        rangeOk: aimHit && !activeForm,
      });
    }

      if (mode === "COOP" && nowMs - lastNetSend > 60) {
        lastNetSend = nowMs;
        sendAction({
          type: "scout:state",
          x: player.x,
          y: player.y,
          z: player.z,
          yaw: player.yaw,
          shifterForm: shifterFormRef.current,
          hookLeft: hookL.active && !shifterFormRef.current ? { active: true, x: hookL.x, y: hookL.y, z: hookL.z } : null,
          hookRight: hookR.active && !shifterFormRef.current ? { active: true, x: hookR.x, y: hookR.y, z: hookR.z } : null,
        });
      }

      renderer.render(scene, camera);
      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);

    return () => {
      disposed = true;
      externalTransformFnRef.current = null;
      cancelAnimationFrame(rafId);
      audioRef.current.updateGasIntensity(0);
      if (document.pointerLockElement === renderer.domElement) {
        document.exitPointerLock?.();
      }
      window.removeEventListener("keydown", onKeyDown, { capture: true });
      window.removeEventListener("keyup", onKeyUp, { capture: true });
      window.removeEventListener("blur", clearKeys);
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup", onMouseUp);
      document.removeEventListener("pointerlockchange", onPointerLockChange);
      renderer.domElement.removeEventListener("mousedown", onMouseDown);
      renderer.domElement.removeEventListener("contextmenu", onContextMenu);
      ro.disconnect();

      disposeTitanHierarchy(localScoutAvatar.group);
      for (const pid of Object.keys(localShifterAvatars) as TitanPowerId[]) {
        disposeTitanHierarchy(localShifterAvatars[pid].group);
      }
      disposeTitanHierarchy(blades.root);
      for (const pid of Object.keys(shifterArmModels) as TitanPowerId[]) {
        disposeTitanHierarchy(shifterArmModels[pid].root);
      }
      for (const rig of titanRigs.values()) disposeTitanHierarchy(rig.group);
      for (const rig of teammateRigs.values()) {
        disposeTitanHierarchy(rig.group);
        rig.leftCable.geometry.dispose();
        rig.rightCable.geometry.dispose();
      }
      for (const sp of steamParticles) (sp.mesh.material as THREE.Material).dispose();
      for (const sw of shockwaves) (sw.mesh.material as THREE.Material).dispose();
      for (const lb of lightningBolts) (lb.mesh.material as THREE.Material).dispose();
      steamGeo.dispose();
      spearGeo.dispose();
      spearMat.dispose();
      ringGeo.dispose();
      boltGeo.dispose();
      anchorDotGeo.dispose();
      anchorDotMat.dispose();
      leftCableLine.geometry.dispose();
      rightCableLine.geometry.dispose();
      district.dispose();
      envTex.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [mode, sessionKey, localScoutId, sendAction, pushFeed]);

  // Lobby View (3-Tab Hub: Deploy & Squad, Scout Gear & Cosmetics, Audio & Controls)
  if (mode === "LOBBY") {
    const activeBladePreset =
      TITAN_BLADE_PRESETS.find((b) => b.id === cosmetics.bladeFinish) || TITAN_BLADE_PRESETS[0];
    const currentTrackUrl = musicRef.current.getCurrentTrack().url;
    return (
      <div className="gw-fps-lobby">
        <div className="gw-hero-deck theme-titan">
          <img className="gw-hero-deck-bg" src={cardTitanImg} alt="" />
          <div className="gw-hero-deck-scrim" />
          <div className="gw-hero-deck-content">
            <span className="gw-hero-deck-kicker">GNOSIS ODM 3D Combat · Titan Shifter Expedition</span>
            <h3>Titan Assault: ODM Revolution</h3>
            <p>
              Hold <b>Q / E</b> or <b>Right-Click</b> to grapple rooftops &amp; Titans, slice leg tendons to
              kneel armored giants, customize your Scout cloak, scarf &amp; blade metallurgy, and press{" "}
              <b>G</b> to unleash your chosen Titan Shifter.
            </p>
          </div>
          <div className="gw-hero-deck-actions">
            <button
              type="button"
              className={`gw-btn ${musicOn && !muted ? "gw-btn-primary" : ""}`}
              onClick={() => {
                musicRef.current.startOnGesture();
                updateWorkshopSettings({ musicEnabled: !musicOn });
              }}
            >
              {musicOn ? "♪ Music On" : "♪ Music Off"}
            </button>
            <button
              type="button"
              className={`gw-btn ${!muted ? "gw-btn-primary" : ""}`}
              onClick={() => updateWorkshopSettings({ muted: !muted })}
            >
              {muted ? "Muted" : "SFX On"}
            </button>
            <span className={`gw-ws-badge ${wsStatus === "connected" ? "connected" : wsStatus === "connecting" || wsStatus === "probing" || wsStatus === "reconnecting" ? "connecting" : "error"}`}>
              {wsStatus === "connected"
                ? `● SUPABASE REALTIME${wsLatency !== null ? ` · ${wsLatency}ms` : ""}`
                : wsStatus === "probing" || wsStatus === "connecting" || wsStatus === "reconnecting"
                  ? "◌ CONNECTING REALTIME..."
                  : wsStatus === "unconfigured"
                    ? "◇ SOLO READY (SUPABASE NOT CONFIGURED)"
                    : "✕ REALTIME OFFLINE (SOLO READY)"}
            </span>
          </div>
        </div>

        {/* 3-Tab Hub Navigation */}
        <div className="gw-menu-tabs" role="tablist" aria-label="Titan Assault Hub Sections">
          {(
            [
              ["deploy", "Deploy & Squad"],
              ["gear", "Scout Gear & Cosmetics"],
              ["settings", "Audio & Controls"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={lobbyTab === id}
              className={`gw-menu-tab ${lobbyTab === id ? "active" : ""}`}
              onClick={() => {
                audioRef.current.initOnGesture();
                musicRef.current.startOnGesture();
                setLobbyTab(id);
              }}
            >
              {label}
            </button>
          ))}
        </div>

        {(wsError || wsDetail) && (
          <div className="gw-fps-error">
            <span>{wsError || wsDetail}</span>
            <button type="button" className="gw-btn" onClick={connectTitanLobby}>
              Reconnect
            </button>
          </div>
        )}

        {lobbyTab === "deploy" && (
          <>
            {/* Select Titan Power Lineage */}
            <div className="gw-titan-power-grid" aria-label="Titan Shifter Power Selection">
              {TITAN_POWERS.map((pw) => {
                const active = pw.id === selectedPower;
                return (
                  <button
                    key={pw.id}
                    type="button"
                    className={`gw-titan-power-card ${active ? "selected" : ""}`}
                    onClick={() => setSelectedPower(pw.id)}
                  >
                    <div className="gw-titan-power-head">
                      <span
                        className="gw-car-swatch"
                        style={{
                          background: `#${pw.skinColor.toString(16).padStart(6, "0")}`,
                          borderColor: `#${pw.accentColor.toString(16).padStart(6, "0")}`,
                        }}
                      />
                      <small>{pw.title}</small>
                    </div>
                    <strong>{pw.name}</strong>
                    <p>{pw.specialDesc}</p>
                    <div className="gw-car-mini-specs">
                      <span>HP {pw.maxHp}</span>
                      <span>DMG {pw.punchDamage}</span>
                      <span>SPECIAL: {pw.specialName}</span>
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="gw-fps-lobby-grid">
              <div className="gw-fps-panel">
                <h4>Scout Regiment Deployment</h4>

                <label className="gw-fps-field">
                  <span>Scout Callsign</span>
                  <input
                    type="text"
                    value={scoutName}
                    maxLength={18}
                    onChange={(e) => setScoutName(e.target.value)}
                    placeholder="Enter scout callsign…"
                  />
                </label>

                <button type="button" className="brass-button" onClick={startSoloExpedition}>
                  Deploy Solo ({TITAN_POWERS_BY_ID[selectedPower].name}) →
                </button>

                <div className="gw-fps-divider" />

                <label className="gw-fps-field">
                  <span>Co-op Squad Title</span>
                  <input
                    type="text"
                    value={roomTitle}
                    maxLength={32}
                    onChange={(e) => setRoomTitle(e.target.value)}
                  />
                </label>

                <button
                  type="button"
                  className="gw-btn gw-btn-primary"
                  disabled={wsStatus !== "connected"}
                  onClick={createCoopRoom}
                >
                  Create Co-op Scout Squad (Up to 4 Players) →
                </button>

                <div className="gw-fps-code-row">
                  <input
                    type="text"
                    value={joinCode}
                    maxLength={8}
                    placeholder="Squad code (e.g. T9K2P)"
                    onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                    onKeyDown={(e) => e.key === "Enter" && joinCoopRoom(joinCode)}
                  />
                  <button
                    type="button"
                    className="gw-btn"
                    disabled={wsStatus !== "connected"}
                    onClick={() => joinCoopRoom(joinCode)}
                  >
                    Join Code
                  </button>
                </div>
              </div>

              <div className="gw-fps-panel">
                <div className="gw-fps-panel-top">
                  <h4>Active Co-op Squads &amp; Loadout</h4>
                  <button
                    type="button"
                    className="gw-btn"
                    disabled={wsStatus !== "connected"}
                    onClick={() => void lobbyClientRef.current?.refreshRooms()}
                  >
                    Refresh
                  </button>
                </div>

                {publicRooms.length === 0 ? (
                  <div className="gw-fps-empty">
                    <p>No active Co-op Scout squads yet.</p>
                    <small>Deploy solo instantly or create a Co-op Squad for teammates.</small>
                  </div>
                ) : (
                  <div className="gw-fps-room-list">
                    {publicRooms.map((r) => (
                      <div key={r.code} className="gw-fps-room-row">
                        <div>
                          <strong>{r.title}</strong>
                          <small>
                            CODE: {r.code} · WAVE {r.wave}/4 · {r.players}/{r.maxPlayers} Scouts
                          </small>
                        </div>
                        <button
                          type="button"
                          className="gw-btn gw-btn-primary"
                          disabled={r.players >= r.maxPlayers}
                          onClick={() => joinCoopRoom(r.code)}
                        >
                          Join →
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                <div className="gw-fps-arsenal-preview">
                  <small>EQUIPPED SCOUT COSMETICS</small>
                  <div className="gw-fps-weapons-mini">
                    <span><b>Cloak</b> {TITAN_CLOAK_PRESETS.find((c) => c.hex === cosmetics.cloakColorHex)?.name || cosmetics.cloakColorHex}</span>
                    <span><b>Scarf</b> {TITAN_SCARF_PRESETS.find((s) => s.hex === cosmetics.scarfColorHex)?.name || cosmetics.scarfColorHex}</span>
                    <span><b>Blades</b> {activeBladePreset.label}</span>
                    <span><b>Cables</b> {TITAN_CABLE_PRESETS.find((k) => k.hex === cosmetics.cableColorHex)?.name || cosmetics.cableColorHex}</span>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}

        {lobbyTab === "gear" && (
          <div className="gw-fps-lobby-grid">
            <div className="gw-fps-panel">
              <div className="gw-fps-panel-top">
                <h4>Scout Uniform &amp; ODM Metallurgy</h4>
                <button
                  type="button"
                  className="gw-btn"
                  onClick={() => updateCosmetics(DEFAULT_TITAN_COSMETICS)}
                >
                  Reset Standard Uniform
                </button>
              </div>

              <div className="gw-custom-section">
                <div className="gw-custom-head">
                  <small>1. REGIMENT CLOAK COLOR</small>
                </div>
                <div className="gw-swatch-row">
                  {TITAN_CLOAK_PRESETS.map((cl) => (
                    <button
                      key={cl.id}
                      type="button"
                      className={`gw-swatch-btn ${cosmetics.cloakColorHex === cl.hex ? "active" : ""}`}
                      onClick={() => updateCosmetics({ cloakColorHex: cl.hex })}
                    >
                      <i style={{ background: cl.hex }} />
                      <span>{cl.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="gw-custom-section">
                <div className="gw-custom-head">
                  <small>2. NECK SCARF ACCENT</small>
                </div>
                <div className="gw-swatch-row">
                  {TITAN_SCARF_PRESETS.map((sc) => (
                    <button
                      key={sc.id}
                      type="button"
                      className={`gw-swatch-btn ${cosmetics.scarfColorHex === sc.hex ? "active" : ""}`}
                      onClick={() => updateCosmetics({ scarfColorHex: sc.hex })}
                    >
                      <i style={{ background: sc.hex }} />
                      <span>{sc.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="gw-custom-section">
                <div className="gw-custom-head">
                  <small>3. ULTRAHARD BLADE FINISH (3RD &amp; 1ST PERSON)</small>
                </div>
                <div className="gw-pill-grid">
                  {TITAN_BLADE_PRESETS.map((bl) => (
                    <button
                      key={bl.id}
                      type="button"
                      className={`gw-btn ${cosmetics.bladeFinish === bl.id ? "gw-btn-primary" : ""}`}
                      onClick={() => {
                        audioRef.current.initOnGesture();
                        audioRef.current.playBladeSlash(80);
                        updateCosmetics({ bladeFinish: bl.id });
                      }}
                    >
                      {bl.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="gw-custom-section">
                <div className="gw-custom-head">
                  <small>4. ODM GRAPPLE CABLE &amp; ANCHOR FLARE</small>
                </div>
                <div className="gw-swatch-row">
                  {TITAN_CABLE_PRESETS.map((cb) => (
                    <button
                      key={cb.id}
                      type="button"
                      className={`gw-swatch-btn ${cosmetics.cableColorHex === cb.hex ? "active" : ""}`}
                      onClick={() => updateCosmetics({ cableColorHex: cb.hex })}
                    >
                      <i style={{ background: cb.hex }} />
                      <span>{cb.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="gw-fps-panel">
              <h4>Equipped Expedition Kit · Live Preview</h4>
              <div className="gw-scout-preview-stage">
                <svg viewBox="0 0 180 210" width="100%" height="185" aria-label="Live Scout Cosmetic Silhouette">
                  <defs>
                    <linearGradient id="bladeGrad" x1="0" y1="0" x2="1" y2="1">
                      <stop offset="0%" stopColor={`#${activeBladePreset.color.toString(16).padStart(6, "0")}`} />
                      <stop offset="100%" stopColor="#ffffff" stopOpacity="0.45" />
                    </linearGradient>
                  </defs>
                  {/* Twin ODM Grapple Cables */}
                  <line x1="56" y1="126" x2="10" y2="34" stroke={cosmetics.cableColorHex} strokeWidth="2.4" strokeDasharray="5 3" opacity="0.9" />
                  <line x1="124" y1="126" x2="170" y2="34" stroke={cosmetics.cableColorHex} strokeWidth="2.4" strokeDasharray="5 3" opacity="0.9" />
                  <circle cx="10" cy="34" r="3.5" fill={cosmetics.cableColorHex} />
                  <circle cx="170" cy="34" r="3.5" fill={cosmetics.cableColorHex} />
                  {/* Twin Ultrahard Blades */}
                  <polygon points="48,136 16,84 22,80 54,132" fill="url(#bladeGrad)" />
                  <polygon points="132,136 164,84 158,80 126,132" fill="url(#bladeGrad)" />
                  <rect x="44" y="130" width="12" height="5" fill={`#${activeBladePreset.guardColor.toString(16).padStart(6, "0")}`} />
                  <rect x="124" y="130" width="12" height="5" fill={`#${activeBladePreset.guardColor.toString(16).padStart(6, "0")}`} />
                  {/* Scout Regiment Cloak */}
                  <path d="M62,60 L118,60 L132,148 L90,140 L48,148 Z" fill={cosmetics.cloakColorHex} stroke="#0c0f12" strokeWidth="1.5" />
                  {/* Scout Jacket & Harness */}
                  <rect x="74" y="64" width="32" height="52" rx="4" fill="#6b5239" />
                  <rect x="70" y="114" width="40" height="8" rx="2" fill="#2a221c" />
                  {/* Legs & Boots */}
                  <rect x="75" y="122" width="12" height="62" rx="3" fill="#cfc8b8" />
                  <rect x="93" y="122" width="12" height="62" rx="3" fill="#cfc8b8" />
                  <rect x="74" y="158" width="14" height="28" rx="2" fill="#3a2719" />
                  <rect x="92" y="158" width="14" height="28" rx="2" fill="#3a2719" />
                  {/* Neck Scarf Accent */}
                  <path d="M72,56 Q90,68 108,56 L104,70 Q90,76 76,70 Z" fill={cosmetics.scarfColorHex} />
                  {/* Head */}
                  <circle cx="90" cy="40" r="15" fill="#e8c7a8" />
                  <path d="M74,38 Q90,22 106,38 Q98,28 74,38 Z" fill="#1e2229" />
                </svg>
                <div className="gw-weapon-dossier" style={{ border: "none", padding: 0, background: "transparent" }}>
                  <small>ACTIVE REGIMENT CONFIGURATION</small>
                  <h4>
                    {scoutName || "Levi-Scout"} · <span>{activeBladePreset.label}</span>
                  </h4>
                  <p>
                    Custom cloak, scarf, blade metallurgy, and cable flare render live on your 3rd-person
                    Scout rig and 1st-person dual ODM viewmodel inside the walled district.
                  </p>
                  <div className="gw-stat-pills">
                    <div>
                      <span>Cloak</span>
                      <strong>{TITAN_CLOAK_PRESETS.find((c) => c.hex === cosmetics.cloakColorHex)?.name || "Custom"}</strong>
                    </div>
                    <div>
                      <span>Scarf</span>
                      <strong>{TITAN_SCARF_PRESETS.find((s) => s.hex === cosmetics.scarfColorHex)?.name || "Custom"}</strong>
                    </div>
                    <div>
                      <span>Blades</span>
                      <strong>{activeBladePreset.label}</strong>
                    </div>
                    <div>
                      <span>Shifter Form</span>
                      <strong>{TITAN_POWERS_BY_ID[selectedPower].name}</strong>
                    </div>
                  </div>
                </div>
              </div>
              <div style={{ marginTop: 14 }}>
                <button type="button" className="brass-button" onClick={startSoloExpedition}>
                  Launch Solo with Equipped Kit →
                </button>
              </div>
            </div>
          </div>
        )}

        {lobbyTab === "settings" && (
          <div className="gw-fps-lobby-grid">
            <div className="gw-fps-panel">
              <div className="gw-fps-panel-top">
                <h4>Audio, Camera &amp; Aim Settings</h4>
                <button type="button" className="gw-btn" onClick={resetWorkshopSettings}>
                  Reset Defaults
                </button>
              </div>

              <div className="gw-playlist-box">
                <small>ACTIVE SOUNDTRACK TRACK</small>
                <select
                  value={currentTrackUrl}
                  onChange={(e) => {
                    musicRef.current.startOnGesture();
                    selectActiveSoundtrackByUrl(e.target.value);
                  }}
                >
                  {playlistItems.map((track) => (
                    <option key={track.id} value={track.url}>
                      {track.title} {track.artist ? `— ${track.artist}` : ""}
                    </option>
                  ))}
                </select>
                <label className="gw-btn" style={{ marginTop: 8, cursor: "pointer", display: "inline-block" }}>
                  + Upload Local Track
                  <input
                    type="file"
                    accept="audio/*,.mp3,.m4a,.wav,.ogg"
                    hidden
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) registerSessionTrackFile(f);
                    }}
                  />
                </label>
              </div>

              <label className="gw-fps-field">
                <span>Music Volume: {Math.round(settings.musicVolume * 100)}%</span>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={Math.round(settings.musicVolume * 100)}
                  onChange={(e) => {
                    musicRef.current.startOnGesture();
                    updateWorkshopSettings({ musicVolume: Number(e.target.value) / 100 });
                  }}
                />
              </label>

              <label className="gw-fps-field">
                <span>ODM Gas &amp; Blade SFX Volume: {Math.round(settings.sfxVolume * 100)}%</span>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={Math.round(settings.sfxVolume * 100)}
                  onChange={(e) => updateWorkshopSettings({ sfxVolume: Number(e.target.value) / 100 })}
                />
              </label>

              <label className="gw-fps-field">
                <span>Mouse Look Sensitivity: {settings.mouseSensitivity.toFixed(2)}×</span>
                <input
                  type="range"
                  min={25}
                  max={300}
                  value={Math.round(settings.mouseSensitivity * 100)}
                  onChange={(e) =>
                    updateWorkshopSettings({ mouseSensitivity: Number(e.target.value) / 100 })
                  }
                />
              </label>

              <label className="gw-fps-field">
                <span>Camera Field of View: {settings.fov}°</span>
                <input
                  type="range"
                  min={64}
                  max={100}
                  value={settings.fov}
                  onChange={(e) => updateWorkshopSettings({ fov: Number(e.target.value) })}
                />
              </label>
            </div>

            <div className="gw-fps-panel">
              <h4>ODM &amp; Titan Shifter Controls</h4>
              <div className="gw-controls-grid">
                <div><b>Hold Q / E</b><span>Left &amp; Right Hooks</span></div>
                <div><b>Hold RMB</b><span>Dual Hook Zip</span></div>
                <div><b>W / A / S / D</b><span>Run &amp; Air-Steer</span></div>
                <div><b>Space / Shift</b><span>Gas Dash &amp; Boost</span></div>
                <div><b>LMB / F</b><span>Slash Nape / Smash</span></div>
                <div><b>X</b><span>Thunder Spear Break</span></div>
                <div><b>G / T / 1–4</b><span>Choose &amp; Shift Titan</span></div>
                <div><b>V / C</b><span>Titan Special / Camera</span></div>
                <div><b>R</b><span>Swap Blade Pair</span></div>
                <div><b>M</b><span>Mute Master Audio</span></div>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  const activePowerSpec = activeShifterForm
    ? TITAN_POWERS_BY_ID[activeShifterForm]
    : TITAN_POWERS_BY_ID[selectedPower];

  return (
    <div className={`gw-fps-stage-root ${activeShifterForm ? "is-titan-shifted" : ""}`}>
      <div ref={mountRef} className="gw-fps-canvas" />

      {damageFlash && <div className="gw-fps-damage-vignette" aria-hidden="true" />}
      {shiftFlash && <div className="gw-titan-shift-flash" aria-hidden="true" />}
      {speedKmh > 68 && !activeShifterForm && (
        <div className="gw-titan-speedlines" aria-hidden="true" />
      )}

      {/* Reticle & Hold-to-Grapple Pips */}
      <div className={`gw-titan-reticle ${hookState.rangeOk ? "in-range" : ""}`} aria-hidden="true">
        {!activeShifterForm && (
          <span className={`hook-pip left ${hookState.left ? "active" : ""}`}>HOLD Q</span>
        )}
        <i className="reticle-ring" />
        {!activeShifterForm && (
          <span className={`hook-pip right ${hookState.right ? "active" : ""}`}>HOLD E</span>
        )}
        {slashFeedback && (
          <div
            key={slashFeedback.id}
            className={`gw-fps-hit-dmg ${slashFeedback.crit ? "headshot" : ""}`}
          >
            {slashFeedback.text}
          </div>
        )}
      </div>

      {/* Top-Left Wave, Combo & Feed */}
      <div className="gw-fps-hud-tl">
        <div className="gw-fps-room-chip">
          <span>
            {mode === "COOP" && coopSnapshot ? (
              <>
                SQUAD <b>{coopSnapshot.code}</b> · SCORE <b>{coopSnapshot.teamScore}</b>
              </>
            ) : (
              <>
                SOLO · SCORE <b>{score}</b> · KILLS <b>{kills}</b>
                {airCombo > 1 && <b style={{ color: "#73ffdb", marginLeft: 8 }}>{airCombo}× AIR</b>}
              </>
            )}
          </span>
          {mode === "COOP" && coopSnapshot && (
            <button
              type="button"
              className="gw-fps-copy-btn"
              onClick={() => {
                navigator.clipboard?.writeText(coopSnapshot.code);
                setCopiedCode(true);
                window.setTimeout(() => setCopiedCode(false), 1200);
              }}
            >
              {copiedCode ? "Copied ✓" : "Copy Code"}
            </button>
          )}
        </div>

        <div className="gw-fps-objective-box">
          <small>EXPANDED WALL ROSE (420M) · WAVE {wave} / 4</small>
          <strong>
            {titansRemaining} {titansRemaining === 1 ? "Titan" : "Titans"} Remaining
          </strong>
          <span>
            {activeShifterForm
              ? `${activePowerSpec.name}: [LMB] Smash · [V] ${activePowerSpec.specialName} · [G] Eject`
              : "Hold [Q/E] Grapple · [X] Spear · [1-4/T] Choose Titan · [G] Transform · [C] Cam"}
          </span>
        </div>

        <div className="gw-fps-feed">
          {feed.map((f, idx) => (
            <div key={idx}>{f}</div>
          ))}
        </div>
      </div>

      {/* Top-Right Controls & Squad List */}
      <div className="gw-fps-hud-tr">
        <div className="gw-fps-top-btns">
          <button
            type="button"
            className="gw-btn"
            onClick={() =>
              setCameraView((prev) =>
                prev === "3RD" ? "3RD WIDE" : prev === "3RD WIDE" ? "1ST" : "3RD",
              )
            }
          >
            Cam: {cameraView} [C]
          </button>
          <button
            type="button"
            className={`gw-btn ${titanPickerOpen ? "gw-btn-primary" : ""}`}
            onClick={() => setTitanPickerOpen((o) => !o)}
          >
            Titans [T]
          </button>
          <button
            type="button"
            className={`gw-btn ${musicOn && !muted ? "gw-btn-primary" : ""}`}
            onClick={() => {
              musicRef.current.startOnGesture();
              updateWorkshopSettings({ musicEnabled: !musicOn });
            }}
          >
            {musicOn ? "♪ Music" : "Music Off"}
          </button>
          <button
            type="button"
            className={`gw-btn ${muted ? "" : "gw-btn-primary"}`}
            onClick={() => updateWorkshopSettings({ muted: !muted })}
          >
            {muted ? "Muted" : "SFX"}
          </button>
          <button type="button" className="gw-btn" onClick={returnToLobby}>
            Leave Squad
          </button>
          <button type="button" className="gw-btn" onClick={onToggleFullscreen}>
            {isFullscreen ? "Exit FS" : "Fullscreen"}
          </button>
        </div>

        {mode === "COOP" && coopSnapshot && (
          <div className="gw-fps-squad-list">
            {coopSnapshot.players.map((p) => (
              <div key={p.id} className="gw-fps-squad-row">
                <span className="sq-dot" style={{ background: p.color }} />
                <b>
                  {p.name}
                  {p.shifterForm ? ` [${p.shifterForm.toUpperCase()}]` : ""}
                  {p.id === localScoutId ? " (YOU)" : ""}
                </b>
                <span>
                  {p.alive ? `${p.hp} HP` : `DOWN ${p.respawnTimer}s`} · {p.kills}K
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Bottom-Center Live Titan Transform Choice Bar */}
      <div className="gw-titan-choice-bar" aria-label="Titan Transform Choice">
        {TITAN_POWERS.map((pw, idx) => {
          const isSelected = (activeShifterForm || selectedPower) === pw.id;
          return (
            <button
              key={pw.id}
              type="button"
              className={`gw-titan-choice-pill ${isSelected ? "selected" : ""} ${
                activeShifterForm === pw.id ? "transformed" : ""
              }`}
              onClick={() => {
                setSelectedPower(pw.id);
                selectedPowerRef.current = pw.id;
                if (shifterChargeRef.current >= 100 || activeShifterForm) {
                  externalTransformFnRef.current?.(pw.id);
                }
              }}
            >
              <span className="choice-key">{idx + 1}</span>
              <b>{pw.name.replace(" Titan", "")}</b>
            </button>
          );
        })}
        <button
          type="button"
          className={`gw-titan-choice-pill shift-trigger ${
            shifterCharge >= 100 ? "ready" : ""
          } ${activeShifterForm ? "transformed" : ""}`}
          onClick={() => externalTransformFnRef.current?.()}
        >
          <span className="choice-key">G</span>
          <b>{activeShifterForm ? "Eject" : shifterCharge >= 100 ? "SHIFT!" : `${shifterCharge}%`}</b>
        </button>
      </div>

      {/* Bottom-Left Velocity, HP, Gas & Titan Shifter Gauge */}
      <div className="gw-fps-hud-bl gw-titan-hud-bl">
        <div className="gw-titan-speed-row">
          <div>
            <small>{activeShifterForm ? "TITAN FORM" : "ODM VELOCITY"}</small>
            <strong className="tabular-nums">
              {activeShifterForm ? activePowerSpec.name.split(" ")[0].toUpperCase() : `${speedKmh} KM/H`}
            </strong>
          </div>
          <div>
            <small>HP</small>
            <strong className="tabular-nums">
              {hp}/{maxHpHud}
            </strong>
          </div>
        </div>

        {!activeShifterForm ? (
          <>
            <small style={{ marginTop: 8 }}>ODM GAS ({gas}%)</small>
            <div className="gw-fps-hp-bar">
              <i
                style={{
                  width: `${gas}%`,
                  background: gas < 25 ? "#e05a47" : "linear-gradient(90deg, #52c6d4, #a3fff0)",
                }}
              />
            </div>
            <small style={{ marginTop: 8 }}>
              TITAN SHIFT [G]:{" "}
              <b style={{ color: shifterCharge >= 100 ? "#ffd257" : "#c7b9a4" }}>
                {shifterCharge >= 100 ? `READY (${activePowerSpec.name})!` : `${shifterCharge}%`}
              </b>
            </small>
            <div className="gw-fps-hp-bar">
              <i
                style={{
                  width: `${shifterCharge}%`,
                  background: shifterCharge >= 100 ? "#ffd257" : "linear-gradient(90deg, #b08d57, #ffaa3b)",
                }}
              />
            </div>
          </>
        ) : (
          <>
            <small style={{ marginTop: 8, color: "#ffd257" }}>
              SHIFTER DURATION ({shifterTimer}s) · [V]{" "}
              {specialCooldownHud > 0 ? `${specialCooldownHud}s` : "SPECIAL READY"}
            </small>
            <div className="gw-fps-hp-bar">
              <i
                style={{
                  width: `${Math.min(100, (shifterTimer / activePowerSpec.durationSec) * 100)}%`,
                  background: "linear-gradient(90deg, #ff7838, #ffd257)",
                }}
              />
            </div>
          </>
        )}
      </div>

      {/* Bottom-Right Blades & Thunder Spears */}
      <div className="gw-fps-hud-br">
        {activeShifterForm ? (
          <div className="gw-fps-ammo-readout">
            <div>
              <small>{activePowerSpec.title.toUpperCase()}</small>
              <strong>{activePowerSpec.specialName}</strong>
            </div>
            <div className="gw-fps-ammo-nums">
              <b>[V]</b>
              <small>{specialCooldownHud > 0 ? `${specialCooldownHud}s` : "READY"}</small>
            </div>
          </div>
        ) : (
          <>
            <div className="gw-fps-ammo-readout">
              <div>
                <small>BLADES · [X] SPEARS: {thunderSpears}</small>
                <strong>Ultrahard Steel</strong>
              </div>
              <div className="gw-fps-ammo-nums">
                <b>{bladeDurability}%</b>
                <small>/ {bladePairs} pairs (R)</small>
              </div>
            </div>
            <div className="gw-fps-hp-bar">
              <i
                style={{
                  width: `${bladeDurability}%`,
                  background: bladeDurability < 25 ? "#e05a47" : "#dce4ee",
                }}
              />
            </div>
          </>
        )}
      </div>

      {/* Interactive Titan Transform Choice Overlay [T] */}
      {titanPickerOpen && statusBanner === "ACTIVE" && (
        <div className="gw-titan-wheel-overlay" role="dialog" aria-label="Choose Titan Transform">
          <div className="gw-titan-wheel-modal">
            <div className="gw-titan-wheel-head">
              <div>
                <small>IN-GAME TITAN SHIFTER SELECTION</small>
                <h4>Choose Your Titan Transform</h4>
              </div>
              <button
                type="button"
                className="gw-btn"
                onClick={() => setTitanPickerOpen(false)}
              >
                Close [T]
              </button>
            </div>
            <div className="gw-titan-wheel-grid">
              {TITAN_POWERS.map((pw, idx) => {
                const chosen = selectedPower === pw.id;
                return (
                  <button
                    key={pw.id}
                    type="button"
                    className={`gw-titan-power-card ${chosen ? "selected" : ""}`}
                    onClick={() => {
                      setSelectedPower(pw.id);
                      selectedPowerRef.current = pw.id;
                      if (shifterChargeRef.current >= 100 || activeShifterForm) {
                        externalTransformFnRef.current?.(pw.id);
                      } else {
                        setTitanPickerOpen(false);
                      }
                    }}
                  >
                    <div className="gw-titan-power-head">
                      <span
                        className="gw-car-swatch"
                        style={{
                          background: `#${pw.skinColor.toString(16).padStart(6, "0")}`,
                          borderColor: `#${pw.accentColor.toString(16).padStart(6, "0")}`,
                        }}
                      />
                      <small>
                        KEY [{idx + 1}] · {pw.title}
                      </small>
                    </div>
                    <strong>{pw.name}</strong>
                    <p>{pw.specialDesc}</p>
                    <div className="gw-car-mini-specs">
                      <span>HP {pw.maxHp}</span>
                      <span>DMG {pw.punchDamage}</span>
                      <span>
                        {shifterCharge >= 100 || activeShifterForm
                          ? "Click to Transform!"
                          : `Arm Form (${shifterCharge}%)`}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {!pointerLocked && !titanPickerOpen && statusBanner === "ACTIVE" && (
        <div className="gw-fps-lock-prompt">
          Click arena to aim (3rd-Person) · <b>Hold Q/E/RMB</b> Hooks · <b>1–4 / T</b> Choose Titan ·{" "}
          <b>G</b> Transform · <b>C</b> Camera
        </div>
      )}

      {(statusBanner === "VICTORY" || statusBanner === "DEFEAT") && (
        <div className="gw-race-overlay">
          <div className="gw-race-modal">
            <p className="eyebrow">
              {statusBanner === "VICTORY" ? "Wall Rose Secured" : "Scout Down"}
            </p>
            <h3>{statusBanner === "VICTORY" ? "Titan Breach Repelled!" : "District Overrun"}</h3>
            <p>
              {statusBanner === "VICTORY"
                ? "Every Titan wave fell to your ODM Regiment blades & Titan Powers."
                : "Regroup on the battlements and launch another expedition."}
            </p>
            <div className="gw-race-modal-actions">
              <button
                type="button"
                className="brass-button"
                onClick={() => {
                  if (mode === "COOP") sendAction({ type: "restart_expedition" });
                  else startSoloExpedition();
                }}
              >
                {mode === "COOP" ? "Restart Squad Expedition" : "Play Again"}
              </button>
              <button type="button" className="gw-btn" onClick={returnToLobby}>
                Return to Squad Lobby
              </button>
              <button type="button" className="gw-btn" onClick={onExit}>
                Back to Workshop
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
