import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { OBJLoader } from "three/addons/loaders/OBJLoader.js";
import { FBXLoader } from "three/addons/loaders/FBXLoader.js";

export type ExternalModelFormat = "gltf" | "glb" | "obj" | "fbx";

const modelCache = new Map<string, Promise<THREE.Group | null>>();

function detectFormat(url: string, explicitExt?: string): ExternalModelFormat | null {
  const clean = (explicitExt || url.split("?")[0].split("#")[0]).toLowerCase();
  if (clean.endsWith(".glb")) return "glb";
  if (clean.endsWith(".gltf")) return "gltf";
  if (clean.endsWith(".obj")) return "obj";
  if (clean.endsWith(".fbx")) return "fbx";
  return null;
}

const FALLBACK_WHITE_PNG_DATA_URL =
  "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAIAAAD91JpzAAAADklEQVQI12P4//8/AwAI/AL+X2z4WAAAAABJRU5ErkJggg==";

function upgradeTemplateMaterialsAndTagShared(root: THREE.Object3D): void {
  root.traverse((child) => {
    if (!(child as THREE.Mesh).isMesh) return;
    const m = child as THREE.Mesh;
    m.castShadow = true;
    m.receiveShadow = true;
    if (m.geometry) {
      m.geometry.userData = { ...m.geometry.userData, sharedAsset: true };
    }

    const srcMats = Array.isArray(m.material) ? m.material : [m.material];
    const upgraded: THREE.Material[] = [];

    for (const mat of srcMats) {
      if (!mat) continue;
      if ((mat as THREE.MeshBasicMaterial).isMeshBasicMaterial) {
        const basic = mat as THREE.MeshBasicMaterial;
        const std = new THREE.MeshStandardMaterial({
          name: basic.name,
          color: basic.color ? basic.color.clone() : new THREE.Color(0xffffff),
          map: basic.map || null,
          transparent: basic.transparent,
          opacity: basic.opacity,
          side: basic.side,
          roughness: 0.56,
          metalness: 0.16,
        });
        if (std.map) {
          std.map.userData = { ...std.map.userData, sharedAsset: true };
        }
        basic.dispose();
        upgraded.push(std);
      } else {
        const anyMat = mat as THREE.MeshStandardMaterial;
        if (anyMat.map) {
          anyMat.map.userData = { ...anyMat.map.userData, sharedAsset: true };
        }
        upgraded.push(mat);
      }
    }

    if (upgraded.length > 0) {
      m.material = Array.isArray(m.material) ? upgraded : upgraded[0];
    }
  });
}

function cloneMaterialsSafely(root: THREE.Object3D): void {
  root.traverse((child) => {
    if (!(child as THREE.Mesh).isMesh) return;
    const m = child as THREE.Mesh;
    if (Array.isArray(m.material)) {
      m.material = m.material.map((mat) => (mat ? mat.clone() : mat));
    } else if (m.material) {
      m.material = m.material.clone();
    }
  });
}

/**
 * Disposes an Object3D hierarchy while skipping shared cached geometries/textures
 * tagged with `userData.sharedAsset = true` so subsequent instances remain intact.
 */
export function disposeSafeHierarchy(root: THREE.Object3D): void {
  root.traverse((obj) => {
    if ((obj as THREE.Mesh).isMesh || (obj as THREE.Sprite).isSprite) {
      const m = obj as THREE.Mesh;
      if (m.geometry && !m.geometry.userData?.sharedAsset) {
        m.geometry.dispose();
      }
      const mats = Array.isArray(m.material) ? m.material : [m.material];
      for (const mat of mats) {
        if (!mat) continue;
        const std = mat as THREE.MeshStandardMaterial;
        if (std.map && !std.map.userData?.sharedAsset) {
          std.map.dispose();
        }
        mat.dispose();
      }
    }
  });
}

async function fetchOrLoadTemplate(
  url: string,
  fileName?: string,
): Promise<THREE.Group | null> {
  const fmt = detectFormat(url, fileName);
  if (!fmt) return null;

  const cacheKey = `${url}::${fileName || ""}`;
  let pending = modelCache.get(cacheKey);
  if (!pending) {
    pending = (async () => {
      try {
        let sceneGroup: THREE.Group | null = null;
        if (fmt === "glb" || fmt === "gltf") {
          const loader = new GLTFLoader();
          const gltf = await loader.loadAsync(url);
          sceneGroup = gltf.scene || null;
        } else if (fmt === "obj") {
          const loader = new OBJLoader();
          sceneGroup = await loader.loadAsync(url);
        } else if (fmt === "fbx") {
          const mgr = new THREE.LoadingManager();
          mgr.setURLModifier((reqUrl) => {
            if (reqUrl === url || reqUrl.startsWith("blob:") || reqUrl.startsWith("data:") || reqUrl.startsWith("/")) {
              return reqUrl;
            }
            // FBX exports with unbundled relative texture filenames (e.g. PG_02e8b8d0.png)
            return FALLBACK_WHITE_PNG_DATA_URL;
          });
          const loader = new FBXLoader(mgr);
          sceneGroup = await loader.loadAsync(url);
        }
        if (sceneGroup) {
          upgradeTemplateMaterialsAndTagShared(sceneGroup);
        }
        return sceneGroup;
      } catch {
        return null;
      }
    })();
    modelCache.set(cacheKey, pending);
  }

  return await pending;
}

/**
 * Loads a cached external 3D asset preserving its internal child hierarchy & node names
 * (such as vehicle `body`, `wheel-front-left`, `wheelFrontLeft`, etc.) and clones materials cleanly.
 */
export async function loadRawModelClone(
  url: string,
  options?: { fileName?: string },
): Promise<THREE.Group | null> {
  const base = await fetchOrLoadTemplate(url, options?.fileName);
  if (!base) return null;
  const cloned = base.clone(true);
  cloneMaterialsSafely(cloned);
  return cloned;
}

/**
 * Normalizes any imported external 3D asset (GLB/GLTF/OBJ/FBX) to a predictable
 * max bounding dimension and grounds its base on Y = 0 (or centers it).
 */
export function normalizeExternalModelGroup(
  rawGroup: THREE.Group,
  targetSize = 2.0,
  groundAtZero = false,
): THREE.Group {
  const container = new THREE.Group();
  rawGroup.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(rawGroup);
  const size = new THREE.Vector3();
  const center = new THREE.Vector3();
  box.getSize(size);
  box.getCenter(center);

  const maxDim = Math.max(size.x, size.y, size.z, 0.001);
  const scale = targetSize / maxDim;

  rawGroup.scale.multiplyScalar(scale);
  rawGroup.position.set(
    -center.x * scale,
    groundAtZero ? -box.min.y * scale : -center.y * scale,
    -center.z * scale,
  );

  rawGroup.traverse((child) => {
    if ((child as THREE.Mesh).isMesh) {
      const m = child as THREE.Mesh;
      m.castShadow = true;
      m.receiveShadow = true;
    }
  });

  container.add(rawGroup);
  return container;
}

/**
 * Safely loads an external 3D asset from URL or Blob URL (e.g., local /assets/models/*.glb
 * or user-uploaded .glb/.obj/.fbx). Returns null cleanly if missing or unsupported.
 */
export async function loadExternalModel(
  url: string,
  options?: {
    targetSize?: number;
    groundAtZero?: boolean;
    fileName?: string;
  },
): Promise<THREE.Group | null> {
  const cloned = await loadRawModelClone(url, { fileName: options?.fileName });
  if (!cloned) return null;
  return normalizeExternalModelGroup(
    cloned,
    options?.targetSize ?? 2.0,
    options?.groundAtZero ?? false,
  );
}
