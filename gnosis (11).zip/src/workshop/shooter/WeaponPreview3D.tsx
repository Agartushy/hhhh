import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import { disposeSafeHierarchy, loadExternalModel } from "../assets/modelLoader";
import { type KnifeModelId, type OperativeCustomization, type WeaponSkinId } from "./cosmetics";
import { buildDetailedWeaponMesh, buildOperativeModel } from "./models";
import type { WeaponId } from "./weapons";

export interface WeaponPreview3DProps {
  mode: "weapon" | "operative";
  weaponId: WeaponId;
  skinId: WeaponSkinId;
  knifeId: KnifeModelId;
  operative?: OperativeCustomization;
  team?: "vanguard" | "syndicate";
  animTrigger?: "idle" | "inspect" | "fire" | "reload";
  animSeq?: number;
}

function disposeObj(root: THREE.Object3D) {
  root.traverse((obj) => {
    obj.userData.disposed = true;
  });
  disposeSafeHierarchy(root);
}

export function WeaponPreview3D({
  mode,
  weaponId,
  skinId,
  knifeId,
  operative,
  team = "vanguard",
  animTrigger = "idle",
  animSeq = 0,
}: WeaponPreview3DProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);
  const [customModelLabel, setCustomModelLabel] = useState<string | null>(null);
  const [customModelError, setCustomModelError] = useState<string | null>(null);
  const [customGroup, setCustomGroup] = useState<THREE.Group | null>(null);

  const animRef = useRef({ trigger: animTrigger, elapsed: 0, seq: animSeq });
  useEffect(() => {
    animRef.current = { trigger: animTrigger, elapsed: 0, seq: animSeq };
  }, [animTrigger, animSeq]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const w = container.clientWidth || 520;
    const h = container.clientHeight || 310;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0c111a);

    const camera = new THREE.PerspectiveCamera(42, w / h, 0.05, 40);
    const camPos = mode === "operative" ? new THREE.Vector3(0, 1.35, 3.35) : new THREE.Vector3(0.45, 0.24, 1.08);
    camera.position.copy(camPos);

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    renderer.setSize(w, h);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    container.appendChild(renderer.domElement);

    const pmrem = new THREE.PMREMGenerator(renderer);
    const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;
    pmrem.dispose();

    const hemi = new THREE.HemisphereLight(0xdbeafe, 0x1e293b, 0.85);
    const keyLight = new THREE.DirectionalLight(0xfff1dc, 1.9);
    keyLight.position.set(2.5, 4.2, 3.2);
    const rimLight = new THREE.DirectionalLight(0x38bdf8, 1.1);
    rimLight.position.set(-3.2, 2.0, -2.5);
    scene.add(hemi, keyLight, rimLight);

    const pedGeo = new THREE.CylinderGeometry(
      mode === "operative" ? 0.95 : 0.42,
      mode === "operative" ? 1.05 : 0.46,
      0.06,
      32,
    );
    const pedMat = new THREE.MeshStandardMaterial({
      color: 0x161f2e,
      metalness: 0.72,
      roughness: 0.28,
    });
    const ped = new THREE.Mesh(pedGeo, pedMat);
    ped.position.y = mode === "operative" ? -0.04 : -0.26;
    scene.add(ped);

    const ringGeo = new THREE.RingGeometry(
      mode === "operative" ? 0.98 : 0.43,
      mode === "operative" ? 1.03 : 0.46,
      40,
    );
    ringGeo.rotateX(-Math.PI / 2);
    const ringMat = new THREE.MeshBasicMaterial({
      color: team === "vanguard" ? 0xf59e0b : 0x38bdf8,
      side: THREE.DoubleSide,
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.position.y = mode === "operative" ? -0.008 : -0.228;
    scene.add(ring);

    const pivot = new THREE.Group();
    scene.add(pivot);

    let boltRef: THREE.Object3D | undefined;
    let magRef: THREE.Object3D | undefined;
    let muzzleRef: THREE.Mesh | undefined;
    let bladeRef: THREE.Object3D | undefined;

    if (customGroup && mode === "weapon") {
      const cloned = customGroup.clone(true);
      cloned.scale.multiplyScalar(0.55);
      cloned.position.set(0, -0.02, 0);
      pivot.add(cloned);
    } else if (mode === "operative") {
      const rig = buildOperativeModel(team, "OPERATIVE PREVIEW", operative);
      rig.nameSprite.visible = false;
      rig.hpBarFill.visible = false;
      pivot.add(rig.group);
    } else {
      const built = buildDetailedWeaponMesh(weaponId, skinId, knifeId);
      built.group.position.set(0, 0, weaponId === "sniper" ? 0.35 : 0.16);
      pivot.add(built.group);
      boltRef = built.boltOrSlide;
      magRef = built.magMesh;
      muzzleRef = built.muzzleFlash;
      bladeRef = built.bladePivot;
      pivot.rotation.y = Math.PI * 0.32;
    }

    let dragging = false;
    let lastX = 0;
    let lastY = 0;
    let targetYaw = mode === "operative" ? 0.25 : Math.PI * 0.34;
    let targetPitch = mode === "operative" ? 0.04 : 0.12;
    let targetZoom = mode === "operative" ? 3.35 : 1.08;

    const onDown = (e: PointerEvent) => {
      dragging = true;
      lastX = e.clientX;
      lastY = e.clientY;
    };
    const onMove = (e: PointerEvent) => {
      if (!dragging) return;
      const dx = e.clientX - lastX;
      const dy = e.clientY - lastY;
      lastX = e.clientX;
      lastY = e.clientY;
      targetYaw += dx * 0.012;
      targetPitch = THREE.MathUtils.clamp(targetPitch + dy * 0.008, -0.65, 0.75);
    };
    const onUp = () => {
      dragging = false;
    };
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      targetZoom = THREE.MathUtils.clamp(
        targetZoom + e.deltaY * 0.0018,
        mode === "operative" ? 2.1 : 0.62,
        mode === "operative" ? 5.2 : 2.1,
      );
    };

    renderer.domElement.addEventListener("pointerdown", onDown);
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    renderer.domElement.addEventListener("wheel", onWheel, { passive: false });

    const ro = new ResizeObserver(() => {
      const nw = container.clientWidth;
      const nh = container.clientHeight;
      if (nw > 0 && nh > 0) {
        camera.aspect = nw / nh;
        camera.updateProjectionMatrix();
        renderer.setSize(nw, nh);
      }
    });
    ro.observe(container);

    const clock = new THREE.Clock();
    let raf = 0;
    let destroyed = false;

    const renderLoop = () => {
      if (destroyed) return;
      const dt = Math.min(clock.getDelta(), 0.05);

      if (!dragging) {
        targetYaw += dt * 0.35;
      }

      const anim = animRef.current;
      anim.elapsed += dt;

      let extraYaw = 0;
      let extraPitch = 0;
      let kickZ = 0;

      if (mode === "weapon") {
        if (anim.trigger === "inspect" && anim.elapsed < 2.2) {
          const p = anim.elapsed / 2.2;
          extraYaw = Math.sin(p * Math.PI * 2) * 0.75;
          extraPitch = Math.sin(p * Math.PI) * 0.28;
          if (bladeRef && knifeId === "karambit-aether") {
            bladeRef.rotation.x = Math.sin(p * Math.PI * 4) * 0.35;
          }
        } else if (anim.trigger === "fire" && anim.elapsed < 0.36) {
          const decay = 1 - anim.elapsed / 0.36;
          kickZ = Math.sin(decay * Math.PI) * 0.08;
          extraPitch = -decay * 0.14;
          if (boltRef) boltRef.position.z += decay * 0.03;
          if (muzzleRef) muzzleRef.visible = anim.elapsed < 0.07 && weaponId !== "knife";
        } else if (anim.trigger === "reload" && anim.elapsed < 1.25) {
          const rp = Math.sin((anim.elapsed / 1.25) * Math.PI);
          extraPitch = -0.35 * rp;
          if (magRef) magRef.position.y -= 0.09 * rp;
        } else if (muzzleRef) {
          muzzleRef.visible = false;
        }
      }

      pivot.rotation.y = THREE.MathUtils.damp(pivot.rotation.y, targetYaw + extraYaw, 10, dt);
      pivot.rotation.x = THREE.MathUtils.damp(pivot.rotation.x, targetPitch + extraPitch, 10, dt);
      pivot.position.z = THREE.MathUtils.damp(pivot.position.z, kickZ, 18, dt);

      const dir = camPos.clone().normalize().multiplyScalar(targetZoom);
      camera.position.lerp(new THREE.Vector3(dir.x, mode === "operative" ? 1.32 : 0.22, dir.z), 0.15);
      camera.lookAt(0, mode === "operative" ? 1.05 : 0.0, 0);

      renderer.render(scene, camera);
      raf = requestAnimationFrame(renderLoop);
    };
    raf = requestAnimationFrame(renderLoop);

    return () => {
      destroyed = true;
      cancelAnimationFrame(raf);
      ro.disconnect();
      renderer.domElement.removeEventListener("pointerdown", onDown);
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      renderer.domElement.removeEventListener("wheel", onWheel);
      disposeObj(pivot);
      pedGeo.dispose();
      pedMat.dispose();
      ringGeo.dispose();
      ringMat.dispose();
      envTex.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [mode, weaponId, skinId, knifeId, operative, team, customGroup]);

  return (
    <div className="gw-preview-wrap">
      <div
        ref={mountRef}
        className="gw-preview-canvas"
        aria-label="Interactive 3D inspection viewport"
      />
      <div className="gw-preview-overlay-meta">
        <span>Drag to orbit · Scroll to zoom</span>
        {mode === "weapon" && (
          <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
            {customModelLabel && (
              <button
                type="button"
                className="gw-btn"
                onClick={() => {
                  setCustomGroup(null);
                  setCustomModelLabel(null);
                  setCustomModelError(null);
                }}
              >
                Reset Built-in Model
              </button>
            )}
            <button
              type="button"
              className="gw-btn"
              title="Import local .glb, .gltf, .obj, or .fbx 3D mesh"
              onClick={() => fileRef.current?.click()}
            >
              {customModelLabel ? `Loaded: ${customModelLabel}` : "Load .GLB/.OBJ/.FBX"}
            </button>
            <input
              ref={fileRef}
              type="file"
              accept=".glb,.gltf,.obj,.fbx"
              style={{ display: "none" }}
              onChange={async (e) => {
                const file = e.target.files?.[0];
                if (!file) return;
                setCustomModelError(null);
                const objUrl = URL.createObjectURL(file);
                try {
                  const ext = file.name.toLowerCase();
                  const grp = await loadExternalModel(objUrl, {
                    targetSize: 1.0,
                    fileName: file.name,
                  });
                  if (grp) {
                    setCustomGroup(grp);
                    setCustomModelLabel(file.name.slice(0, 22));
                  } else {
                    setCustomModelError(`Could not parse ${ext} file.`);
                  }
                } catch {
                  setCustomModelError("Unsupported or corrupted 3D file.");
                } finally {
                  URL.revokeObjectURL(objUrl);
                  e.target.value = "";
                }
              }}
            />
          </div>
        )}
      </div>
      {customModelError && (
        <div className="gw-fps-error" style={{ marginTop: 8 }}>
          <span>{customModelError}</span>
        </div>
      )}
    </div>
  );
}
