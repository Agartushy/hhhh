export type WeaponId =
  | "starter_pistol"
  | "pistol"
  | "smg"
  | "shotgun"
  | "carbine"
  | "sniper"
  | "knife";

export type WeaponCollectionCategory =
  | "Rifles"
  | "SMGs"
  | "Shotguns"
  | "Pistols"
  | "Snipers"
  | "Knives";

export type WeaponEquipSlot = "primary" | "secondary" | "melee";

export interface WeaponSpec {
  id: WeaponId;
  slot: number;
  equipSlot: WeaponEquipSlot;
  price: number;
  allowedInPistolRound: boolean;
  penetrationPower: number;
  name: string;
  category: string;
  collectionCategory: WeaponCollectionCategory;
  fireMode: "AUTO" | "SEMI" | "MELEE";
  rpm: number;
  damage: number;
  headshotMult: number;
  armorPen: number;
  pellets: number;
  magSize: number;
  reserveMax: number;
  reloadSec: number;
  baseSpread: number;
  moveSpread: number;
  adsSpread: number;
  airSpread: number;
  crouchMult: number;
  moveSpeedMult: number;
  recoilPitch: number;
  recoilYaw: number;
  recoilRecovery: number;
  adsFov: number;
  range: number;
  colorHex: number;
  accentHex: number;
  weightKg: number;
  muzzleVelocityMps: number;
  lore: string;
}

export const WEAPON_CATEGORIES: WeaponCollectionCategory[] = [
  "Pistols",
  "SMGs",
  "Shotguns",
  "Rifles",
  "Snipers",
  "Knives",
];

export const WEAPON_LIST: WeaponSpec[] = [
  {
    id: "carbine",
    slot: 1,
    equipSlot: "primary",
    price: 2700,
    allowedInPistolRound: false,
    penetrationPower: 0.82,
    name: "MK-IV Vanguard Rifle",
    category: "Assault Rifle",
    collectionCategory: "Rifles",
    fireMode: "AUTO",
    rpm: 600,
    damage: 28,
    headshotMult: 2.15,
    armorPen: 0.78,
    pellets: 1,
    magSize: 30,
    reserveMax: 120,
    reloadSec: 1.75,
    baseSpread: 0.0055,
    moveSpread: 0.028,
    adsSpread: 0.0018,
    airSpread: 0.06,
    crouchMult: 0.65,
    moveSpeedMult: 0.96,
    recoilPitch: 0.026,
    recoilYaw: 0.01,
    recoilRecovery: 9.2,
    adsFov: 56,
    range: 150,
    colorHex: 0x303640,
    accentHex: 0xe69f3a,
    weightKg: 3.4,
    muzzleVelocityMps: 890,
    lore: "Modular bull-pup carbine with free-floated Picatinny shroud and crisp 2-stage match trigger.",
  },
  {
    id: "smg",
    slot: 1,
    equipSlot: "primary",
    price: 1250,
    allowedInPistolRound: false,
    penetrationPower: 0.48,
    name: "Vesper-9 PDW",
    category: "Submachine Gun",
    collectionCategory: "SMGs",
    fireMode: "AUTO",
    rpm: 880,
    damage: 17,
    headshotMult: 1.8,
    armorPen: 0.6,
    pellets: 1,
    magSize: 36,
    reserveMax: 144,
    reloadSec: 1.35,
    baseSpread: 0.011,
    moveSpread: 0.015,
    adsSpread: 0.006,
    airSpread: 0.036,
    crouchMult: 0.75,
    moveSpeedMult: 1.06,
    recoilPitch: 0.017,
    recoilYaw: 0.012,
    recoilRecovery: 11.5,
    adsFov: 62,
    range: 95,
    colorHex: 0x242c37,
    accentHex: 0x4cc4ff,
    weightKg: 2.3,
    muzzleVelocityMps: 420,
    lore: "Compact roller-delayed SMG engineered for high-tempo flanking and tight run-and-gun spreads.",
  },
  {
    id: "shotgun",
    slot: 1,
    equipSlot: "primary",
    price: 1450,
    allowedInPistolRound: false,
    penetrationPower: 0.36,
    name: "Breaker-12 Trench",
    category: "Combat Shotgun",
    collectionCategory: "Shotguns",
    fireMode: "SEMI",
    rpm: 82,
    damage: 17,
    headshotMult: 1.55,
    armorPen: 0.52,
    pellets: 8,
    magSize: 8,
    reserveMax: 32,
    reloadSec: 1.9,
    baseSpread: 0.052,
    moveSpread: 0.02,
    adsSpread: 0.035,
    airSpread: 0.04,
    crouchMult: 0.8,
    moveSpeedMult: 1.0,
    recoilPitch: 0.068,
    recoilYaw: 0.022,
    recoilRecovery: 7.5,
    adsFov: 64,
    range: 55,
    colorHex: 0x473528,
    accentHex: 0xe87a38,
    weightKg: 3.8,
    muzzleVelocityMps: 390,
    lore: "Heavy-walled 12-gauge pump scattergun with ventilated heat shield and walnut-composite stock.",
  },
  {
    id: "sniper",
    slot: 1,
    equipSlot: "primary",
    price: 4200,
    allowedInPistolRound: false,
    penetrationPower: 1.05,
    name: "Longbow Rail-X",
    category: "Rail Sniper",
    collectionCategory: "Snipers",
    fireMode: "SEMI",
    rpm: 48,
    damage: 112,
    headshotMult: 2.35,
    armorPen: 0.95,
    pellets: 1,
    magSize: 5,
    reserveMax: 20,
    reloadSec: 2.25,
    baseSpread: 0.034,
    moveSpread: 0.065,
    adsSpread: 0.0004,
    airSpread: 0.095,
    crouchMult: 0.6,
    moveSpeedMult: 0.88,
    recoilPitch: 0.092,
    recoilYaw: 0.016,
    recoilRecovery: 6.0,
    adsFov: 28,
    range: 220,
    colorHex: 0x1d232b,
    accentHex: 0x8ad6ff,
    weightKg: 5.9,
    muzzleVelocityMps: 1450,
    lore: "Electromagnetically assisted anti-materiel precision rifle with 8x illuminated ballistic optic.",
  },
  {
    id: "starter_pistol",
    slot: 2,
    equipSlot: "secondary",
    price: 0,
    allowedInPistolRound: true,
    penetrationPower: 0.45,
    name: "P9 Service Pistol",
    category: "Standard Issue Sidearm",
    collectionCategory: "Pistols",
    fireMode: "SEMI",
    rpm: 380,
    damage: 25,
    headshotMult: 2.2,
    armorPen: 0.56,
    pellets: 1,
    magSize: 12,
    reserveMax: 48,
    reloadSec: 1.1,
    baseSpread: 0.005,
    moveSpread: 0.012,
    adsSpread: 0.0022,
    airSpread: 0.034,
    crouchMult: 0.72,
    moveSpeedMult: 1.12,
    recoilPitch: 0.024,
    recoilYaw: 0.006,
    recoilRecovery: 14.0,
    adsFov: 64,
    range: 95,
    colorHex: 0x2c323a,
    accentHex: 0x9fb2c8,
    weightKg: 0.88,
    muzzleVelocityMps: 365,
    lore: "Standard-issue 9mm service pistol issued to all operatives at round deployment.",
  },
  {
    id: "pistol",
    slot: 2,
    equipSlot: "secondary",
    price: 650,
    allowedInPistolRound: true,
    penetrationPower: 0.65,
    name: "Meridian .45",
    category: "Heavy Sidearm",
    collectionCategory: "Pistols",
    fireMode: "SEMI",
    rpm: 360,
    damage: 38,
    headshotMult: 2.3,
    armorPen: 0.74,
    pellets: 1,
    magSize: 10,
    reserveMax: 50,
    reloadSec: 1.2,
    baseSpread: 0.004,
    moveSpread: 0.013,
    adsSpread: 0.0016,
    airSpread: 0.035,
    crouchMult: 0.68,
    moveSpeedMult: 1.09,
    recoilPitch: 0.034,
    recoilYaw: 0.008,
    recoilRecovery: 12.2,
    adsFov: 62,
    range: 112,
    colorHex: 0x26292e,
    accentHex: 0xf2ca6b,
    weightKg: 1.15,
    muzzleVelocityMps: 410,
    lore: "Match-grade heavy sidearm featuring milled slide serrations, tritium sights, and high-penetration .45 ACP.",
  },
  {
    id: "knife",
    slot: 3,
    equipSlot: "melee",
    price: 0,
    allowedInPistolRound: true,
    penetrationPower: 0,
    name: "Tactical Blade",
    category: "Melee Cosmetic",
    collectionCategory: "Knives",
    fireMode: "MELEE",
    rpm: 115,
    damage: 65,
    headshotMult: 1.65,
    armorPen: 1.0,
    pellets: 1,
    magSize: 0,
    reserveMax: 0,
    reloadSec: 0,
    baseSpread: 0,
    moveSpread: 0,
    adsSpread: 0,
    airSpread: 0,
    crouchMult: 1.0,
    moveSpeedMult: 1.18,
    recoilPitch: 0.018,
    recoilYaw: 0.024,
    recoilRecovery: 16.0,
    adsFov: 74,
    range: 3.1,
    colorHex: 0x262a33,
    accentHex: 0x56d8ff,
    weightKg: 0.35,
    muzzleVelocityMps: 0,
    lore: "Close-quarters stealth melee slot giving maximum sprint mobility and devastating silent strikes.",
  },
];

export const FIREARM_LIST: WeaponSpec[] = WEAPON_LIST.filter((w) => w.id !== "knife");

export const BUYABLE_WEAPON_LIST: WeaponSpec[] = WEAPON_LIST.filter((w) => w.price > 0);

export const WEAPONS_BY_ID: Record<WeaponId, WeaponSpec> = {
  carbine: WEAPON_LIST[0],
  smg: WEAPON_LIST[1],
  shotgun: WEAPON_LIST[2],
  sniper: WEAPON_LIST[3],
  starter_pistol: WEAPON_LIST[4],
  pistol: WEAPON_LIST[5],
  knife: WEAPON_LIST[6],
};
