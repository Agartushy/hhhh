import type { WeaponId } from "./weapons";

export class ShooterAudioEngine {
  private ctx: AudioContext | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private muted = false;
  private volume = 0.82;

  initOnGesture() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") this.ctx.resume().catch(() => {});
      return;
    }
    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      this.ctx = ctx;

      const buf = ctx.createBuffer(1, ctx.sampleRate * 0.5, ctx.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      this.noiseBuf = buf;
    } catch {
      // Audio blocked
    }
  }

  setMuted(m: boolean) {
    this.muted = m;
  }

  setVolume(v: number) {
    this.volume = Math.max(0, Math.min(1, v));
  }

  playShot(weaponId: WeaponId, volumeScale = 1) {
    if (!this.ctx || this.muted || !this.noiseBuf || this.volume <= 0.001) return;
    volumeScale *= this.volume;
    try {
      const ctx = this.ctx;
      const t = ctx.currentTime;
      const noise = ctx.createBufferSource();
      noise.buffer = this.noiseBuf;

      const filter = ctx.createBiquadFilter();
      filter.type = "bandpass";
      const gain = ctx.createGain();

      const osc = ctx.createOscillator();
      const oscGain = ctx.createGain();

      if (weaponId === "shotgun") {
        filter.frequency.setValueAtTime(620, t);
        filter.Q.value = 0.8;
        gain.gain.setValueAtTime(0.28 * volumeScale, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.24);
        osc.type = "triangle";
        osc.frequency.setValueAtTime(140, t);
        osc.frequency.exponentialRampToValueAtTime(36, t + 0.19);
        oscGain.gain.setValueAtTime(0.24 * volumeScale, t);
        oscGain.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
      } else if (weaponId === "sniper") {
        filter.frequency.setValueAtTime(1350, t);
        filter.Q.value = 0.6;
        gain.gain.setValueAtTime(0.3 * volumeScale, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.34);
        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(340, t);
        osc.frequency.exponentialRampToValueAtTime(48, t + 0.26);
        oscGain.gain.setValueAtTime(0.18 * volumeScale, t);
        oscGain.gain.exponentialRampToValueAtTime(0.001, t + 0.28);
      } else if (weaponId === "smg") {
        filter.frequency.setValueAtTime(1600, t);
        filter.Q.value = 1.4;
        gain.gain.setValueAtTime(0.14 * volumeScale, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.08);
        osc.type = "square";
        osc.frequency.setValueAtTime(210, t);
        osc.frequency.exponentialRampToValueAtTime(75, t + 0.07);
        oscGain.gain.setValueAtTime(0.08 * volumeScale, t);
        oscGain.gain.exponentialRampToValueAtTime(0.001, t + 0.08);
      } else if (weaponId === "starter_pistol") {
        filter.frequency.setValueAtTime(1450, t);
        filter.Q.value = 1.25;
        gain.gain.setValueAtTime(0.15 * volumeScale, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.09);
        osc.type = "triangle";
        osc.frequency.setValueAtTime(280, t);
        osc.frequency.exponentialRampToValueAtTime(85, t + 0.085);
        oscGain.gain.setValueAtTime(0.1 * volumeScale, t);
        oscGain.gain.exponentialRampToValueAtTime(0.001, t + 0.09);
      } else if (weaponId === "pistol") {
        filter.frequency.setValueAtTime(1150, t);
        filter.Q.value = 1.1;
        gain.gain.setValueAtTime(0.19 * volumeScale, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.11);
        osc.type = "triangle";
        osc.frequency.setValueAtTime(240, t);
        osc.frequency.exponentialRampToValueAtTime(65, t + 0.1);
        oscGain.gain.setValueAtTime(0.12 * volumeScale, t);
        oscGain.gain.exponentialRampToValueAtTime(0.001, t + 0.11);
      } else {
        // Carbine
        filter.frequency.setValueAtTime(1250, t);
        filter.Q.value = 1.0;
        gain.gain.setValueAtTime(0.18 * volumeScale, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);
        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(190, t);
        osc.frequency.exponentialRampToValueAtTime(58, t + 0.1);
        oscGain.gain.setValueAtTime(0.11 * volumeScale, t);
        oscGain.gain.exponentialRampToValueAtTime(0.001, t + 0.11);
      }

      noise.connect(filter).connect(gain).connect(ctx.destination);
      osc.connect(oscGain).connect(ctx.destination);
      noise.start(t);
      noise.stop(t + 0.36);
      osc.start(t);
      osc.stop(t + 0.3);
    } catch {
      // Ignore
    }
  }

  playHitmarker(headshot: boolean) {
    if (!this.ctx || this.muted || this.volume <= 0.001) return;
    const v = this.volume;
    try {
      const ctx = this.ctx;
      const t = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(headshot ? 1950 : 1280, t);
      osc.frequency.exponentialRampToValueAtTime(headshot ? 1100 : 720, t + 0.055);
      gain.gain.setValueAtTime((headshot ? 0.16 : 0.11) * v, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.06);
      osc.connect(gain).connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.065);
    } catch {
      // Ignore
    }
  }

  playKnifeSwing() {
    if (!this.ctx || this.muted || !this.noiseBuf || this.volume <= 0.001) return;
    const v = this.volume;
    try {
      const ctx = this.ctx;
      const t = ctx.currentTime;
      const noise = ctx.createBufferSource();
      noise.buffer = this.noiseBuf;
      const filter = ctx.createBiquadFilter();
      filter.type = "bandpass";
      filter.frequency.setValueAtTime(2200, t);
      filter.frequency.exponentialRampToValueAtTime(640, t + 0.14);
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.18 * v, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);
      noise.connect(filter).connect(gain).connect(ctx.destination);
      noise.start(t);
      noise.stop(t + 0.16);
    } catch {
      // Ignore
    }
  }

  playReload() {
    if (!this.ctx || this.muted || this.volume <= 0.001) return;
    const v = this.volume;
    try {
      const ctx = this.ctx;
      const t = ctx.currentTime;
      [0, 0.22].forEach((offset, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "square";
        osc.frequency.setValueAtTime(i === 0 ? 480 : 760, t + offset);
        gain.gain.setValueAtTime(0.06 * v, t + offset);
        gain.gain.exponentialRampToValueAtTime(0.001, t + offset + 0.05);
        osc.connect(gain).connect(ctx.destination);
        osc.start(t + offset);
        osc.stop(t + offset + 0.06);
      });
    } catch {
      // Ignore
    }
  }

  playDamage() {
    if (!this.ctx || this.muted || this.volume <= 0.001) return;
    const v = this.volume;
    try {
      const ctx = this.ctx;
      const t = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(110, t);
      osc.frequency.exponentialRampToValueAtTime(42, t + 0.15);
      gain.gain.setValueAtTime(0.15 * v, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.16);
      osc.connect(gain).connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.17);
    } catch {
      // Ignore
    }
  }

  playObjectiveChime() {
    if (!this.ctx || this.muted || this.volume <= 0.001) return;
    const v = this.volume;
    try {
      const ctx = this.ctx;
      const t = ctx.currentTime;
      [392, 523.25, 659.25].forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "triangle";
        osc.frequency.value = freq;
        gain.gain.setValueAtTime(0.08 * v, t + i * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.001, t + i * 0.08 + 0.35);
        osc.connect(gain).connect(ctx.destination);
        osc.start(t + i * 0.08);
        osc.stop(t + i * 0.08 + 0.38);
      });
    } catch {
      // Ignore
    }
  }

  playBombBeep(urgent = false) {
    if (!this.ctx || this.muted || this.volume <= 0.001) return;
    const v = this.volume;
    try {
      const ctx = this.ctx;
      const t = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(urgent ? 1760 : 1220, t);
      gain.gain.setValueAtTime(0.08 * v, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.08);
      osc.connect(gain).connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.09);
    } catch {
      // Ignore
    }
  }

  playRoundHorn() {
    if (!this.ctx || this.muted || this.volume <= 0.001) return;
    const v = this.volume;
    try {
      const ctx = this.ctx;
      const t = ctx.currentTime;
      [293.66, 440, 587.33].forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sawtooth";
        osc.frequency.value = freq;
        gain.gain.setValueAtTime(0.055 * v, t + i * 0.06);
        gain.gain.exponentialRampToValueAtTime(0.001, t + i * 0.06 + 0.35);
        osc.connect(gain).connect(ctx.destination);
        osc.start(t + i * 0.06);
        osc.stop(t + i * 0.06 + 0.38);
      });
    } catch {
      // Ignore
    }
  }

  playExplosion() {
    if (!this.ctx || this.muted || !this.noiseBuf || this.volume <= 0.001) return;
    const v = this.volume;
    try {
      const ctx = this.ctx;
      const t = ctx.currentTime;
      const noise = ctx.createBufferSource();
      noise.buffer = this.noiseBuf;
      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.setValueAtTime(420, t);
      filter.frequency.exponentialRampToValueAtTime(75, t + 0.45);
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.32 * v, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.48);
      noise.connect(filter).connect(gain).connect(ctx.destination);
      noise.start(t);
      noise.stop(t + 0.5);
    } catch {
      // Ignore
    }
  }

  dispose() {
    try {
      if (this.ctx && this.ctx.state !== "closed") this.ctx.close().catch(() => {});
    } catch {
      // Ignore
    }
    this.ctx = null;
  }
}
