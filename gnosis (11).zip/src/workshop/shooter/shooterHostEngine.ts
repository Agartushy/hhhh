import {
  getDamageMultAtDistance,
  getFpsMapDef,
  raycastArenaObstacles,
  resolveCircleBoxCollisions,
  traceBulletPath,
  type FpsMapId,
} from "./mapData";
import { WEAPONS_BY_ID, type WeaponId } from "./weapons";

export type ShooterTeam = "vanguard" | "syndicate";
export type ShooterMode = "DEFUSAL" | "TDM";
export type RoundPhase = "BUY_FREEZE" | "LIVE" | "ROUND_END" | "MATCH_END";

export const ARMOR_REFILL_PRICE = 400;
export const MAX_PLAYER_MONEY = 16000;

export interface TeamBotComposition {
  alphaBots: number;
  bravoBots: number;
}

export interface ShooterOutgoingEvent {
  targetId?: string;
  payload: Record<string, unknown>;
}

interface PlayerHistorySample {
  t: number;
  x: number;
  y: number;
  z: number;
}

export interface HostShooterPlayer {
  id: string;
  name: string;
  team: ShooterTeam;
  color: string;
  slot: number;
  isBot: boolean;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  crouching: boolean;
  weaponId: WeaponId;
  ownedWeapons: WeaponId[];
  money: number;
  hp: number;
  maxHp: number;
  armor: number;
  maxArmor: number;
  alive: boolean;
  respawnTimer: number;
  kills: number;
  deaths: number;
  assists: number;
  damageDealt: number;
  score: number;
  shotBudgetMs: number;
  lastShotCheckAt: number;
  history: PlayerHistorySample[];
  damageContributors: Map<string, number>;
  botPatrolDir: number;
  botCooldown: number;
}

export interface HostShooterSnapshot {
  type: "room:snapshot";
  code: string;
  title: string;
  mapId: FpsMapId;
  mode: ShooterMode;
  fillBots: boolean;
  alphaBotCount: number;
  bravoBotCount: number;
  round: number;
  maxRounds: number;
  isPistolRound: boolean;
  phase: RoundPhase;
  phaseTimer: number;
  vanguardRounds: number;
  syndicateRounds: number;
  vanguardKills: number;
  syndicateKills: number;
  roundWinnerTeam: ShooterTeam | null;
  winnerTeam: ShooterTeam | "draw" | null;
  winReason: string | null;
  bombPlanted: boolean;
  bombSiteId: "A" | "B" | null;
  bombX: number;
  bombY: number;
  bombZ: number;
  bombTimer: number;
  plantProgress: number;
  defuseProgress: number;
  players: {
    id: string;
    name: string;
    team: ShooterTeam;
    color: string;
    isBot: boolean;
    x: number;
    y: number;
    z: number;
    yaw: number;
    pitch: number;
    crouching: boolean;
    weaponId: WeaponId;
    ownedWeapons: WeaponId[];
    money: number;
    hp: number;
    maxHp: number;
    armor: number;
    alive: boolean;
    respawnTimer: number;
    kills: number;
    deaths: number;
    assists: number;
    damageDealt: number;
    score: number;
  }[];
  pickups: { id: string; kind: "medkit" | "ammo"; active: boolean }[];
}

function getTeamColor(team: ShooterTeam): string {
  return team === "vanguard" ? "#e69f3a" : "#4ea8ff";
}

function getTeamDisplayName(team: ShooterTeam): string {
  return team === "vanguard" ? "Team Alpha" : "Team Bravo";
}

function clampBotCount(n: number | undefined, fallback = 4): number {
  const v = typeof n === "number" && Number.isFinite(n) ? Math.floor(n) : fallback;
  return Math.max(0, Math.min(10, v));
}

function sanitizeOwnedWeapons(list?: WeaponId[]): WeaponId[] {
  const out: WeaponId[] = [];
  if (Array.isArray(list)) {
    for (const id of list) {
      if (id in WEAPONS_BY_ID && !out.includes(id)) out.push(id);
    }
  }
  if (!out.includes("starter_pistol") && !out.includes("pistol")) {
    out.push("starter_pistol");
  }
  if (!out.includes("knife")) {
    out.push("knife");
  }
  return out;
}

function pickBestOwnedWeapon(owned: WeaponId[]): WeaponId {
  const priority: WeaponId[] = ["sniper", "carbine", "shotgun", "smg", "pistol", "starter_pistol", "knife"];
  for (const w of priority) {
    if (owned.includes(w)) return w;
  }
  return "starter_pistol";
}

function rayIntersectsVerticalCylinder(
  ox: number,
  oy: number,
  oz: number,
  dx: number,
  dy: number,
  dz: number,
  maxDist: number,
  cx: number,
  baseY: number,
  cz: number,
  radius: number,
  height: number,
): { tEntry: number; hitY: number } | null {
  const fx = ox - cx;
  const fz = oz - cz;
  const a = dx * dx + dz * dz;

  if (a < 1e-6) {
    if (fx * fx + fz * fz > radius * radius) return null;
    if (Math.abs(dy) < 1e-6) return null;
    const ty1 = (baseY - oy) / dy;
    const ty2 = (baseY + height - oy) / dy;
    const tMin = Math.max(0.01, Math.min(ty1, ty2));
    const tMax = Math.min(maxDist, Math.max(ty1, ty2));
    if (tMax < tMin || tMin >= maxDist) return null;
    return { tEntry: tMin, hitY: oy + dy * tMin };
  }

  const b = 2 * (fx * dx + fz * dz);
  const c = fx * fx + fz * fz - radius * radius;
  const disc = b * b - 4 * a * c;
  if (disc < 0) return null;

  const sqrtDisc = Math.sqrt(disc);
  const t0 = (-b - sqrtDisc) / (2 * a);
  const t1 = (-b + sqrtDisc) / (2 * a);
  if (t1 <= 0 || t0 >= maxDist) return null;

  const tStart = Math.max(0.01, t0);
  const tEnd = Math.min(maxDist, t1);
  if (tEnd < tStart) return null;

  const yMin = baseY;
  const yMax = baseY + height;
  const yStart = oy + dy * tStart;
  const yEnd = oy + dy * tEnd;

  if (Math.max(yStart, yEnd) < yMin || Math.min(yStart, yEnd) > yMax) {
    return null;
  }

  let tHit = tStart;
  let hitY = yStart;
  if (hitY < yMin || hitY > yMax) {
    if (Math.abs(dy) > 1e-6) {
      const targetY = hitY < yMin ? yMin : yMax;
      const tVertical = (targetY - oy) / dy;
      if (tVertical >= tStart && tVertical <= tEnd) {
        tHit = tVertical;
        hitY = targetY;
      } else {
        return null;
      }
    } else {
      return null;
    }
  }

  if (tHit >= maxDist) return null;
  return { tEntry: tHit, hitY };
}

export class ShooterRoomHost {
  code: string;
  title: string;
  mapId: FpsMapId;
  mode: ShooterMode;
  fillBots: boolean;
  alphaBotCount: number;
  bravoBotCount: number;
  round = 1;
  maxRounds = 7;
  phase: RoundPhase;
  phaseTimer: number;
  vanguardRounds = 0;
  syndicateRounds = 0;
  vanguardKills = 0;
  syndicateKills = 0;
  roundWinnerTeam: ShooterTeam | null = null;
  winnerTeam: ShooterTeam | "draw" | null = null;
  winReason: string | null = null;
  bombPlanted = false;
  bombSiteId: "A" | "B" | null = null;
  bombX = 0;
  bombY = 0;
  bombZ = 0;
  bombTimer = 0;
  plantProgress = 0;
  defuseProgress = 0;
  activePlanterId: string | null = null;
  activeDefuserId: string | null = null;
  alphaLossStreak = 0;
  bravoLossStreak = 0;
  roundSpawnSeed = 0;
  players = new Map<string, HostShooterPlayer>();
  pickups: { id: string; kind: "medkit" | "ammo"; x: number; y: number; z: number; active: boolean; respawnTimer: number }[];
  nextEntitySeq = 1;

  constructor(
    code: string,
    title: string,
    mode: ShooterMode,
    botConfig: boolean | TeamBotComposition,
    mapId: FpsMapId = "desert-outpost",
  ) {
    this.code = code;
    this.mapId = getFpsMapDef(mapId).id;
    const mapDef = getFpsMapDef(this.mapId);
    this.title = title.trim().slice(0, 36) || `${mapDef.name} ${code}`;
    this.mode = mode;
    if (typeof botConfig === "boolean") {
      this.alphaBotCount = botConfig ? 2 : 0;
      this.bravoBotCount = botConfig ? 2 : 0;
    } else {
      this.alphaBotCount = clampBotCount(botConfig.alphaBots, 4);
      this.bravoBotCount = clampBotCount(botConfig.bravoBots, 4);
    }
    this.fillBots = this.alphaBotCount > 0 || this.bravoBotCount > 0;
    this.phase = mode === "DEFUSAL" ? "BUY_FREEZE" : "LIVE";
    this.phaseTimer = mode === "DEFUSAL" ? 3.5 : 300;
    this.pickups = mapDef.pickups.map((p) => ({
      ...p,
      active: true,
      respawnTimer: 0,
    }));
    this.syncBotFill();
  }

  isPistolRound(): boolean {
    return this.mode === "DEFUSAL" && this.round === 1;
  }

  static fromSnapshot(snap: HostShooterSnapshot): ShooterRoomHost {
    const botConfig: TeamBotComposition = {
      alphaBots:
        typeof snap.alphaBotCount === "number"
          ? snap.alphaBotCount
          : snap.fillBots
            ? snap.players.filter((p) => p.team === "vanguard" && p.isBot).length
            : 0,
      bravoBots:
        typeof snap.bravoBotCount === "number"
          ? snap.bravoBotCount
          : snap.fillBots
            ? snap.players.filter((p) => p.team === "syndicate" && p.isBot).length
            : 0,
    };
    const host = new ShooterRoomHost(
      snap.code,
      snap.title,
      snap.mode,
      botConfig,
      snap.mapId || "desert-outpost",
    );
    host.round = snap.round;
    host.maxRounds = snap.maxRounds;
    host.phase = snap.phase;
    host.phaseTimer = snap.phaseTimer;
    host.vanguardRounds = snap.vanguardRounds;
    host.syndicateRounds = snap.syndicateRounds;
    host.vanguardKills = snap.vanguardKills;
    host.syndicateKills = snap.syndicateKills;
    host.roundWinnerTeam = snap.roundWinnerTeam ?? null;
    host.winnerTeam = snap.winnerTeam;
    host.winReason = snap.winReason;
    host.bombPlanted = snap.bombPlanted;
    host.bombSiteId = snap.bombSiteId;
    host.bombX = snap.bombX;
    host.bombY = snap.bombY;
    host.bombZ = snap.bombZ;
    host.bombTimer = snap.bombTimer;
    host.plantProgress = snap.plantProgress;
    host.defuseProgress = snap.defuseProgress;
    host.players.clear();
    snap.players.forEach((p, idx) => {
      const owned = sanitizeOwnedWeapons(p.ownedWeapons);
      const validWeapon = owned.includes(p.weaponId) ? p.weaponId : pickBestOwnedWeapon(owned);
      host.players.set(p.id, {
        ...p,
        weaponId: validWeapon,
        ownedWeapons: owned,
        money: typeof p.money === "number" ? p.money : 800,
        slot: idx,
        maxArmor: 50,
        shotBudgetMs: 1100,
        lastShotCheckAt: Date.now(),
        history: [{ t: Date.now(), x: p.x, y: p.y, z: p.z }],
        damageContributors: new Map(),
        botPatrolDir: idx % 2 === 0 ? 1 : -1,
        botCooldown: 0.6,
      });
    });
    for (const spk of snap.pickups) {
      const target = host.pickups.find((p) => p.id === spk.id);
      if (target) target.active = spk.active;
    }
    return host;
  }

  private getTeamSpawn(team: ShooterTeam, playerId: string) {
    const mapDef = getFpsMapDef(this.mapId);
    const list = team === "vanguard" ? mapDef.vanguardSpawns : mapDef.syndicateSpawns;
    let idx = 0;
    let k = 0;
    for (const p of this.players.values()) {
      if (p.team === team) {
        if (p.id === playerId) {
          idx = k;
          break;
        }
        k++;
      }
    }
    // Rotate/offset across team courtyard spawn points each round so positions vary cleanly
    const rotated = (idx + this.roundSpawnSeed * 3) % list.length;
    const base = list[rotated];
    const yawFacing = team === "vanguard" ? 0 : Math.PI;
    const row = Math.floor(idx / list.length);
    if (row === 0) {
      return { x: base.x, y: base.y, z: base.z, yaw: yawFacing };
    }
    const inwardDir = team === "vanguard" ? -1 : 1;
    const latOffset = (row % 2 === 1 ? -1 : 1) * Math.ceil(row * 0.5) * 1.9;
    const depthOffset = inwardDir * row * 2.1;
    const resolved = resolveCircleBoxCollisions(
      base.x + latOffset,
      base.y,
      base.z + depthOffset,
      0.56,
      this.mapId,
    );
    return { x: resolved.x, y: resolved.floorY, z: resolved.z, yaw: yawFacing };
  }

  private assignBotRoundWeapon(bot: HostShooterPlayer, idx: number) {
    if (this.isPistolRound()) {
      bot.ownedWeapons = ["starter_pistol", "knife"];
      if (bot.money >= WEAPONS_BY_ID.pistol.price && idx % 3 === 1) {
        bot.money -= WEAPONS_BY_ID.pistol.price;
        bot.ownedWeapons = ["pistol", "knife"];
        bot.weaponId = "pistol";
      } else {
        bot.weaponId = "starter_pistol";
      }
      return;
    }

    // Round 2+ or TDM: spend real accrued funds on tactical primaries/sidearms
    const preferredOrder: WeaponId[] =
      idx % 5 === 4
        ? ["sniper", "carbine", "smg", "pistol"]
        : idx % 4 === 3
          ? ["shotgun", "smg", "pistol"]
          : idx % 3 === 1
            ? ["smg", "carbine", "pistol"]
            : ["carbine", "smg", "pistol"];

    for (const candidate of preferredOrder) {
      if (bot.ownedWeapons.includes(candidate)) break;
      const spec = WEAPONS_BY_ID[candidate];
      if (bot.money >= spec.price) {
        bot.money -= spec.price;
        if (spec.equipSlot === "primary") {
          bot.ownedWeapons = bot.ownedWeapons.filter(
            (w) => WEAPONS_BY_ID[w].equipSlot !== "primary",
          );
        } else if (spec.equipSlot === "secondary") {
          bot.ownedWeapons = bot.ownedWeapons.filter(
            (w) => WEAPONS_BY_ID[w].equipSlot !== "secondary",
          );
        }
        bot.ownedWeapons.push(candidate);
        break;
      }
    }
    bot.weaponId = pickBestOwnedWeapon(bot.ownedWeapons);
  }

  private syncBotFill() {
    const targetForTeam = (t: ShooterTeam) =>
      t === "vanguard" ? this.alphaBotCount : this.bravoBotCount;

    for (const team of ["vanguard", "syndicate"] as ShooterTeam[]) {
      const desired = targetForTeam(team);
      const existingBots = Array.from(this.players.values()).filter(
        (p) => p.team === team && p.isBot,
      );

      while (existingBots.length > desired) {
        const removed = existingBots.pop()!;
        this.players.delete(removed.id);
      }

      let botIndex = existingBots.length;
      while (botIndex < desired) {
        const botNum = botIndex + 1;
        const botId = `BOT-${team}-${++this.nextEntitySeq}`;
        const label = team === "vanguard" ? "Alpha" : "Bravo";
        const startMoney = this.mode === "TDM" ? 3200 : 800;
        const bot: HostShooterPlayer = {
          id: botId,
          name: `[BOT] ${label}-${String(botNum).padStart(2, "0")}`,
          team,
          color: getTeamColor(team),
          slot: this.players.size,
          isBot: true,
          x: 0,
          y: 0,
          z: 0,
          yaw: team === "vanguard" ? 0 : Math.PI,
          pitch: 0,
          crouching: false,
          weaponId: "starter_pistol",
          ownedWeapons: ["starter_pistol", "knife"],
          money: startMoney,
          hp: 100,
          maxHp: 100,
          armor: 50,
          maxArmor: 50,
          alive: true,
          respawnTimer: 0,
          kills: 0,
          deaths: 0,
          assists: 0,
          damageDealt: 0,
          score: 0,
          shotBudgetMs: 1100,
          lastShotCheckAt: Date.now(),
          history: [],
          damageContributors: new Map(),
          botPatrolDir: botIndex % 2 === 0 ? 1 : -1,
          botCooldown: 0.65 + (botIndex % 4) * 0.14,
        };
        this.players.set(botId, bot);
        this.assignBotRoundWeapon(bot, botIndex);
        const sp = this.getTeamSpawn(team, botId);
        bot.x = sp.x;
        bot.y = sp.y;
        bot.z = sp.z;
        bot.yaw = sp.yaw;
        bot.history = [{ t: Date.now(), x: sp.x, y: sp.y, z: sp.z }];
        botIndex++;
      }
    }
  }

  addHumanPlayer(
    playerId: string,
    rawName: string,
    preferredTeam: ShooterTeam | "auto" = "vanguard",
  ): {
    ok: boolean;
    error?: string;
    player?: HostShooterPlayer;
    spawn?: { x: number; y: number; z: number; yaw: number };
    events: ShooterOutgoingEvent[];
  } {
    const existing = this.players.get(playerId);
    if (existing) {
      const sp = { x: existing.x, y: existing.y, z: existing.z, yaw: existing.yaw };
      return { ok: true, player: existing, spawn: sp, events: [] };
    }

    const humanCount = Array.from(this.players.values()).filter((p) => !p.isBot).length;
    if (humanCount >= 8) {
      return { ok: false, error: `Room ${this.code} is full (8/8 human players).`, events: [] };
    }

    const vCount = Array.from(this.players.values()).filter(
      (p) => p.team === "vanguard" && !p.isBot,
    ).length;
    const sCount = Array.from(this.players.values()).filter(
      (p) => p.team === "syndicate" && !p.isBot,
    ).length;

    const team: ShooterTeam =
      preferredTeam === "vanguard" || preferredTeam === "syndicate"
        ? preferredTeam
        : vCount <= sCount
          ? "vanguard"
          : "syndicate";

    const startingCash =
      this.mode === "TDM" ? 3200 : this.round === 1 ? 800 : 800 + (this.round - 1) * 1400;

    const player: HostShooterPlayer = {
      id: playerId,
      name: rawName.trim().slice(0, 18) || `Operative-${humanCount + 1}`,
      team,
      color: getTeamColor(team),
      slot: this.players.size,
      isBot: false,
      x: 0,
      y: 0,
      z: 0,
      yaw: team === "vanguard" ? 0 : Math.PI,
      pitch: 0,
      crouching: false,
      weaponId: "starter_pistol",
      ownedWeapons: ["starter_pistol", "knife"],
      money: Math.min(MAX_PLAYER_MONEY, startingCash),
      hp: 100,
      maxHp: 100,
      armor: 50,
      maxArmor: 50,
      alive: true,
      respawnTimer: 0,
      kills: 0,
      deaths: 0,
      assists: 0,
      damageDealt: 0,
      score: 0,
      shotBudgetMs: 1100,
      lastShotCheckAt: Date.now(),
      history: [],
      damageContributors: new Map(),
      botPatrolDir: 1,
      botCooldown: 0,
    };
    this.players.set(playerId, player);
    const sp = this.getTeamSpawn(team, playerId);
    player.x = sp.x;
    player.y = sp.y;
    player.z = sp.z;
    player.yaw = sp.yaw;
    player.history = [{ t: Date.now(), x: sp.x, y: sp.y, z: sp.z }];

    const events: ShooterOutgoingEvent[] = [
      {
        targetId: playerId,
        payload: {
          type: "room:joined",
          playerId,
          team,
          playerColor: player.color,
          spawn: sp,
          snapshot: this.serializeSnapshot(),
        },
      },
      {
        payload: {
          type: "player:joined",
          playerId,
          playerName: player.name,
          team,
        },
      },
    ];
    return { ok: true, player, spawn: sp, events };
  }

  removePlayer(playerId: string): ShooterOutgoingEvent[] {
    const existing = this.players.get(playerId);
    if (!existing) return [];
    this.players.delete(playerId);
    return [
      {
        payload: {
          type: "player:left",
          playerId,
          playerName: existing.name,
        },
      },
    ];
  }

  switchTeam(playerId: string, requestedTeam?: ShooterTeam): ShooterOutgoingEvent[] {
    const p = this.players.get(playerId);
    if (!p) return [];
    if (!p.alive && this.mode === "DEFUSAL" && this.phase === "LIVE") return [];
    const nextTeam: ShooterTeam =
      requestedTeam === "vanguard" || requestedTeam === "syndicate"
        ? requestedTeam
        : p.team === "vanguard"
          ? "syndicate"
          : "vanguard";
    if (nextTeam === p.team) return [];

    p.team = nextTeam;
    p.color = getTeamColor(nextTeam);
    const sp = this.getTeamSpawn(nextTeam, playerId);
    p.x = sp.x;
    p.y = sp.y;
    p.z = sp.z;
    p.yaw = sp.yaw;
    p.hp = p.maxHp;
    p.armor = p.maxArmor;
    p.alive = true;
    return [
      {
        targetId: playerId,
        payload: {
          type: "player:respawned",
          spawn: sp,
          team: nextTeam,
          weaponId: p.weaponId,
          ownedWeapons: [...p.ownedWeapons],
          resetWeapons: false,
        },
      },
    ];
  }

  buyWeapon(playerId: string, requestedWeaponId: WeaponId): ShooterOutgoingEvent[] {
    const p = this.players.get(playerId);
    if (!p) return [];
    if (!p.alive) {
      return [
        {
          targetId: playerId,
          payload: { type: "shop:error", message: "Eliminated operatives cannot purchase gear." },
        },
      ];
    }
    if (this.phase !== "BUY_FREEZE" && this.phase !== "LIVE") {
      return [
        {
          targetId: playerId,
          payload: { type: "shop:error", message: "Armory is closed between rounds." },
        },
      ];
    }
    if (!(requestedWeaponId in WEAPONS_BY_ID)) {
      return [
        {
          targetId: playerId,
          payload: { type: "shop:error", message: "Unknown weapon requested." },
        },
      ];
    }

    const spec = WEAPONS_BY_ID[requestedWeaponId];
    if (this.isPistolRound() && !spec.allowedInPistolRound) {
      return [
        {
          targetId: playerId,
          payload: {
            type: "shop:error",
            message: "Round 1 is Pistol Round — primary weapons unlock in Round 2.",
          },
        },
      ];
    }

    if (p.ownedWeapons.includes(requestedWeaponId)) {
      p.weaponId = requestedWeaponId;
      return [
        {
          targetId: playerId,
          payload: { type: "shop:error", message: `${spec.name} is already in your loadout.` },
        },
      ];
    }

    if (spec.price > p.money) {
      return [
        {
          targetId: playerId,
          payload: {
            type: "shop:error",
            message: `Insufficient funds for ${spec.name} ($${spec.price} needed, $${p.money} available).`,
          },
        },
      ];
    }

    p.money -= spec.price;
    if (spec.equipSlot === "primary") {
      p.ownedWeapons = p.ownedWeapons.filter((w) => WEAPONS_BY_ID[w].equipSlot !== "primary");
    } else if (spec.equipSlot === "secondary") {
      p.ownedWeapons = p.ownedWeapons.filter((w) => WEAPONS_BY_ID[w].equipSlot !== "secondary");
    }
    p.ownedWeapons = sanitizeOwnedWeapons([...p.ownedWeapons, requestedWeaponId]);
    p.weaponId = requestedWeaponId;

    return [
      {
        targetId: playerId,
        payload: {
          type: "shop:purchased",
          kind: "weapon",
          weaponId: requestedWeaponId,
          money: p.money,
          ownedWeapons: [...p.ownedWeapons],
        },
      },
    ];
  }

  buyArmor(playerId: string): ShooterOutgoingEvent[] {
    const p = this.players.get(playerId);
    if (!p || !p.alive) return [];
    if (this.phase !== "BUY_FREEZE" && this.phase !== "LIVE") return [];
    if (p.armor >= p.maxArmor) {
      return [
        {
          targetId: playerId,
          payload: { type: "shop:error", message: "Ballistic armor vest is already full." },
        },
      ];
    }
    if (p.money < ARMOR_REFILL_PRICE) {
      return [
        {
          targetId: playerId,
          payload: {
            type: "shop:error",
            message: `Need $${ARMOR_REFILL_PRICE} to replenish armor vest.`,
          },
        },
      ];
    }
    p.money -= ARMOR_REFILL_PRICE;
    p.armor = p.maxArmor;
    return [
      {
        targetId: playerId,
        payload: {
          type: "shop:purchased",
          kind: "armor",
          armor: p.armor,
          money: p.money,
        },
      },
    ];
  }

  resetMatch(): ShooterOutgoingEvent[] {
    this.round = 1;
    this.phase = this.mode === "DEFUSAL" ? "BUY_FREEZE" : "LIVE";
    this.phaseTimer = this.mode === "DEFUSAL" ? 3.5 : 300;
    this.vanguardRounds = 0;
    this.syndicateRounds = 0;
    this.vanguardKills = 0;
    this.syndicateKills = 0;
    this.roundWinnerTeam = null;
    this.winnerTeam = null;
    this.winReason = null;
    this.alphaLossStreak = 0;
    this.bravoLossStreak = 0;
    this.roundSpawnSeed += 1;

    for (const p of this.players.values()) {
      p.kills = 0;
      p.deaths = 0;
      p.assists = 0;
      p.damageDealt = 0;
      p.score = 0;
      p.money = this.mode === "TDM" ? 3200 : 800;
      p.ownedWeapons = ["starter_pistol", "knife"];
      p.weaponId = "starter_pistol";
      p.alive = false;
    }
    this.syncBotFill();
    return this.resetPlayersForRound(true);
  }

  continueNextRound(): ShooterOutgoingEvent[] {
    if (this.phase !== "ROUND_END") return [];
    this.round += 1;
    this.roundSpawnSeed += 1;
    this.phase = this.mode === "DEFUSAL" ? "BUY_FREEZE" : "LIVE";
    this.phaseTimer = this.mode === "DEFUSAL" ? 3.5 : 300;
    this.roundWinnerTeam = null;
    this.winReason = null;
    this.syncBotFill();
    return this.resetPlayersForRound(false);
  }

  private resetPlayersForRound(forceStarterReset: boolean): ShooterOutgoingEvent[] {
    this.bombPlanted = false;
    this.bombSiteId = null;
    this.bombX = 0;
    this.bombY = 0;
    this.bombZ = 0;
    this.bombTimer = 0;
    this.plantProgress = 0;
    this.defuseProgress = 0;
    this.activePlanterId = null;
    this.activeDefuserId = null;

    for (const pk of this.pickups) {
      pk.active = true;
      pk.respawnTimer = 0;
    }

    const events: ShooterOutgoingEvent[] = [];
    let botIdx = 0;
    for (const p of this.players.values()) {
      const lostGear = forceStarterReset || !p.alive || this.isPistolRound();
      if (lostGear) {
        p.ownedWeapons = ["starter_pistol", "knife"];
        p.weaponId = "starter_pistol";
      } else {
        p.ownedWeapons = sanitizeOwnedWeapons(p.ownedWeapons);
        p.weaponId = pickBestOwnedWeapon(p.ownedWeapons);
      }

      if (p.isBot) {
        this.assignBotRoundWeapon(p, botIdx);
        botIdx++;
      }

      const sp = this.getTeamSpawn(p.team, p.id);
      p.x = sp.x;
      p.y = sp.y;
      p.z = sp.z;
      p.yaw = sp.yaw;
      p.pitch = 0;
      p.crouching = false;
      p.hp = p.maxHp;
      p.armor = p.maxArmor;
      p.alive = true;
      p.respawnTimer = 0;
      p.damageContributors.clear();
      p.history = [{ t: Date.now(), x: sp.x, y: sp.y, z: sp.z }];

      if (!p.isBot) {
        events.push({
          targetId: p.id,
          payload: {
            type: "player:respawned",
            spawn: sp,
            team: p.team,
            weaponId: p.weaponId,
            ownedWeapons: [...p.ownedWeapons],
            money: p.money,
            resetWeapons: lostGear,
          },
        });
      }
    }
    return events;
  }

  private awardRoundWin(
    winner: ShooterTeam,
    reason: string,
    events: ShooterOutgoingEvent[],
  ) {
    if (this.phase === "ROUND_END" || this.phase === "MATCH_END") return;
    if (winner === "vanguard") {
      this.vanguardRounds += 1;
      this.alphaLossStreak = 0;
      this.bravoLossStreak = Math.min(4, this.bravoLossStreak + 1);
    } else {
      this.syndicateRounds += 1;
      this.bravoLossStreak = 0;
      this.alphaLossStreak = Math.min(4, this.alphaLossStreak + 1);
    }

    const loserStreak = winner === "vanguard" ? this.bravoLossStreak : this.alphaLossStreak;
    const winnerBonus = 3250;
    const loserBonus = 1900 + Math.max(0, loserStreak - 1) * 500;

    for (const p of this.players.values()) {
      const reward = p.team === winner ? winnerBonus : loserBonus;
      p.money = Math.min(MAX_PLAYER_MONEY, p.money + reward);
    }

    this.roundWinnerTeam = winner;
    this.phase = "ROUND_END";
    this.phaseTimer = 0;
    this.winReason = reason;
    events.push({
      payload: {
        type: "round:ended",
        winnerTeam: winner,
        reason,
        vanguardRounds: this.vanguardRounds,
        syndicateRounds: this.syndicateRounds,
      },
    });

    if (this.vanguardRounds >= 4 || this.syndicateRounds >= 4) {
      this.phase = "MATCH_END";
      this.winnerTeam = this.vanguardRounds >= 4 ? "vanguard" : "syndicate";
      this.winReason = reason;
    }
  }

  handlePlayerState(playerId: string, msg: Record<string, unknown>) {
    const p = this.players.get(playerId);
    if (!p || !p.alive || this.phase === "BUY_FREEZE") return;
    const mapDef = getFpsMapDef(this.mapId);

    if (typeof msg.x === "number" && Number.isFinite(msg.x)) {
      const clampedX = Math.max(-mapDef.halfW + 2, Math.min(mapDef.halfW - 2, msg.x));
      if (Math.abs(clampedX - p.x) < 18) p.x = clampedX;
    }
    if (typeof msg.y === "number" && Number.isFinite(msg.y)) {
      p.y = Math.max(0, Math.min(14, msg.y));
    }
    if (typeof msg.z === "number" && Number.isFinite(msg.z)) {
      const clampedZ = Math.max(-mapDef.halfD + 2, Math.min(mapDef.halfD - 2, msg.z));
      if (Math.abs(clampedZ - p.z) < 18) p.z = clampedZ;
    }
    if (typeof msg.yaw === "number" && Number.isFinite(msg.yaw)) p.yaw = msg.yaw;
    if (typeof msg.pitch === "number" && Number.isFinite(msg.pitch)) p.pitch = msg.pitch;
    p.crouching = Boolean(msg.crouching);

    if (typeof msg.weaponId === "string" && msg.weaponId in WEAPONS_BY_ID) {
      const req = msg.weaponId as WeaponId;
      if (
        p.ownedWeapons.includes(req) &&
        (!this.isPistolRound() || WEAPONS_BY_ID[req].allowedInPistolRound)
      ) {
        p.weaponId = req;
      }
    }
  }

  handlePlantTick(playerId: string): ShooterOutgoingEvent[] {
    const events: ShooterOutgoingEvent[] = [];
    if (this.mode !== "DEFUSAL" || this.phase !== "LIVE") return events;
    const p = this.players.get(playerId);
    if (!p || !p.alive || p.team !== "vanguard" || this.bombPlanted) return events;

    const mapDef = getFpsMapDef(this.mapId);
    const nearSite = mapDef.bombSites.find(
      (s) => Math.hypot(p.x - s.x, p.z - s.z) <= s.radius && Math.abs(p.y - s.y) <= 2.4,
    );
    if (!nearSite) {
      this.plantProgress = 0;
      this.activePlanterId = null;
      return events;
    }

    this.activePlanterId = playerId;
    this.plantProgress = Math.min(100, this.plantProgress + 10);
    if (this.plantProgress >= 100) {
      this.bombPlanted = true;
      this.bombSiteId = nearSite.id;
      this.bombX = p.x;
      this.bombY = p.y;
      this.bombZ = p.z;
      this.bombTimer = 35;
      this.plantProgress = 0;
      this.activePlanterId = null;
      p.score += 150;
      p.money = Math.min(MAX_PLAYER_MONEY, p.money + 300);
      events.push({
        payload: {
          type: "bomb:planted",
          siteId: nearSite.id,
          planterName: p.name,
        },
      });
    }
    return events;
  }

  handleDefuseTick(playerId: string): ShooterOutgoingEvent[] {
    const events: ShooterOutgoingEvent[] = [];
    if (this.mode !== "DEFUSAL" || this.phase !== "LIVE") return events;
    const p = this.players.get(playerId);
    if (!p || !p.alive || p.team !== "syndicate" || !this.bombPlanted) return events;

    const dist = Math.hypot(p.x - this.bombX, p.z - this.bombZ);
    if (dist > 4.2 || Math.abs(p.y - this.bombY) > 2.4) {
      this.defuseProgress = 0;
      this.activeDefuserId = null;
      return events;
    }

    this.activeDefuserId = playerId;
    this.defuseProgress = Math.min(100, this.defuseProgress + 9);
    if (this.defuseProgress >= 100) {
      p.score += 200;
      p.money = Math.min(MAX_PLAYER_MONEY, p.money + 300);
      events.push({
        payload: { type: "bomb:defused", defuserName: p.name },
      });
      this.awardRoundWin("syndicate", `Aether Charge defused by ${p.name}!`, events);
    }
    return events;
  }

  handlePlayerShot(
    shooterId: string,
    origin: { x: number; y: number; z: number },
    rays: { dx: number; dy: number; dz: number }[],
    requestedWeaponId?: WeaponId,
  ): ShooterOutgoingEvent[] {
    const events: ShooterOutgoingEvent[] = [];
    const shooter = this.players.get(shooterId);
    if (!shooter || this.phase !== "LIVE" || !shooter.alive) return events;

    if (
      !shooter.isBot &&
      Math.hypot(origin.x - shooter.x, origin.z - shooter.z) > 6.5
    ) {
      origin = { x: shooter.x, y: shooter.y + (shooter.crouching ? 1.08 : 1.62), z: shooter.z };
    }

    if (
      requestedWeaponId &&
      requestedWeaponId in WEAPONS_BY_ID &&
      shooter.ownedWeapons.includes(requestedWeaponId) &&
      (!this.isPistolRound() || WEAPONS_BY_ID[requestedWeaponId].allowedInPistolRound)
    ) {
      shooter.weaponId = requestedWeaponId;
    }
    if (
      !shooter.ownedWeapons.includes(shooter.weaponId) ||
      (this.isPistolRound() && !WEAPONS_BY_ID[shooter.weaponId].allowedInPistolRound)
    ) {
      shooter.weaponId = shooter.ownedWeapons.includes("pistol") ? "pistol" : "starter_pistol";
    }

    const spec = WEAPONS_BY_ID[shooter.weaponId] || WEAPONS_BY_ID.starter_pistol;

    const now = Date.now();
    const elapsed = Math.min(400, Math.max(0, now - shooter.lastShotCheckAt));
    shooter.lastShotCheckAt = now;
    const intervalMs = Math.max(24, (60000 / spec.rpm) * 0.68);
    const maxBucket = Math.max(1100, intervalMs * 2.2);
    shooter.shotBudgetMs = Math.min(maxBucket, shooter.shotBudgetMs + elapsed);
    if (shooter.shotBudgetMs < intervalMs * 0.55) {
      return events;
    }
    shooter.shotBudgetMs = Math.max(0, shooter.shotBudgetMs - intervalMs);

    const clampedRays = rays.slice(0, Math.max(1, spec.pellets));
    const tracerEnds: { x: number; y: number; z: number; hitWorld: boolean }[] = [];
    let totalHitDamage = 0;
    let anyHeadshot = false;
    let anyWallbang = false;
    let anyKilled = false;

    for (const r of clampedRays) {
      const len = Math.hypot(r.dx, r.dy, r.dz);
      if (len < 0.0001) continue;
      const dx = r.dx / len;
      const dy = r.dy / len;
      const dz = r.dz / len;

      const bulletTrace = traceBulletPath(
        origin.x,
        origin.y,
        origin.z,
        dx,
        dy,
        dz,
        spec.range,
        this.mapId,
        spec.penetrationPower,
      );

      let bestT = bulletTrace.endDist;
      let hitTarget: HostShooterPlayer | null = null;
      let hitLocation: "head" | "body" = "body";

      for (const target of this.players.values()) {
        if (target.id === shooter.id || target.team === shooter.team || !target.alive) {
          continue;
        }

        const headBaseOffset = target.crouching ? 1.1 : 1.44;
        const headHeight = 0.48;
        const headRadius = spec.id === "knife" ? 0.48 : 0.31;
        const bodyHeight = headBaseOffset;
        const bodyRadius = spec.id === "knife" ? 0.78 : 0.48;

        const testAtPos = (px: number, py: number, pz: number) => {
          const headHit = rayIntersectsVerticalCylinder(
            origin.x,
            origin.y,
            origin.z,
            dx,
            dy,
            dz,
            bestT,
            px,
            py + headBaseOffset,
            pz,
            headRadius,
            headHeight,
          );
          const bodyHit = rayIntersectsVerticalCylinder(
            origin.x,
            origin.y,
            origin.z,
            dx,
            dy,
            dz,
            bestT,
            px,
            py,
            pz,
            bodyRadius,
            bodyHeight,
          );
          if (headHit && (!bodyHit || headHit.tEntry <= bodyHit.tEntry)) {
            return { tEntry: headHit.tEntry, loc: "head" as const };
          }
          if (bodyHit) {
            return { tEntry: bodyHit.tEntry, loc: "body" as const };
          }
          return null;
        };

        let hitCandidate = testAtPos(target.x, target.y, target.z);

        if (!hitCandidate && target.history.length > 0) {
          for (let hi = target.history.length - 1; hi >= 0; hi--) {
            const hist = target.history[hi];
            if (now - hist.t > 280) break;
            hitCandidate = testAtPos(hist.x, hist.y, hist.z);
            if (hitCandidate) break;
          }
        }

        if (hitCandidate && hitCandidate.tEntry < bestT) {
          bestT = hitCandidate.tEntry;
          hitTarget = target;
          hitLocation = hitCandidate.loc;
        }
      }

      const penCheck = hitTarget ? getDamageMultAtDistance(bulletTrace, bestT) : { blocked: false, mult: 1, penetratedCount: 0 };
      if (hitTarget && penCheck.blocked) {
        hitTarget = null;
        bestT = bulletTrace.endDist;
      }

      if (spec.id !== "knife") {
        tracerEnds.push({
          x: origin.x + dx * bestT,
          y: origin.y + dy * bestT,
          z: origin.z + dz * bestT,
          hitWorld: hitTarget === null && bulletTrace.stoppedAtSolid,
        });
      }

      if (hitTarget && penCheck.mult > 0) {
        const isHeadshot = hitLocation === "head";
        const isWallbang = penCheck.penetratedCount > 0;
        const falloff =
          spec.id === "knife"
            ? 1
            : spec.id === "shotgun"
              ? Math.max(0.38, 1 - bestT / (spec.range * 1.15))
              : Math.max(0.74, 1 - bestT / (spec.range * 2.5));

        const rawDmg = Math.max(
          1,
          Math.round(spec.damage * (isHeadshot ? spec.headshotMult : 1) * falloff * penCheck.mult),
        );
        let hpDmg = rawDmg;
        if (hitTarget.armor > 0) {
          const armorAbsorb = Math.min(
            hitTarget.armor,
            Math.round(rawDmg * (1 - spec.armorPen) * 0.75),
          );
          hitTarget.armor = Math.max(0, hitTarget.armor - armorAbsorb);
          hpDmg = Math.max(1, rawDmg - Math.round(armorAbsorb * 0.65));
        }

        hitTarget.hp = Math.max(0, hitTarget.hp - hpDmg);
        shooter.damageDealt += hpDmg;
        hitTarget.damageContributors.set(
          shooter.id,
          (hitTarget.damageContributors.get(shooter.id) || 0) + hpDmg,
        );
        totalHitDamage += hpDmg;
        if (isHeadshot) anyHeadshot = true;
        if (isWallbang) anyWallbang = true;

        if (!hitTarget.isBot) {
          events.push({
            targetId: hitTarget.id,
            payload: {
              type: "player:damaged",
              hp: Math.round(hitTarget.hp),
              armor: Math.round(hitTarget.armor),
              fromX: origin.x,
              fromZ: origin.z,
            },
          });
        }

        if (hitTarget.hp <= 0) {
          anyKilled = true;
          hitTarget.alive = false;
          hitTarget.deaths += 1;
          hitTarget.respawnTimer = this.mode === "TDM" ? 3.2 : 0;
          shooter.kills += 1;
          shooter.score += isHeadshot ? 135 : spec.id === "knife" ? 160 : 100;
          const killReward = spec.id === "knife" ? 1500 : 300;
          shooter.money = Math.min(MAX_PLAYER_MONEY, shooter.money + killReward);
          if (shooter.team === "vanguard") this.vanguardKills += 1;
          else this.syndicateKills += 1;

          for (const [aid, dmg] of hitTarget.damageContributors.entries()) {
            if (aid !== shooter.id && dmg >= 30) {
              const assister = this.players.get(aid);
              if (assister) {
                assister.assists += 1;
                assister.score += 40;
              }
            }
          }

          events.push({
            payload: {
              type: "combat:kill",
              killerId: shooter.id,
              killerName: shooter.name,
              killerTeam: shooter.team,
              victimId: hitTarget.id,
              victimName: hitTarget.name,
              victimTeam: hitTarget.team,
              weaponId: spec.id,
              headshot: isHeadshot,
              hitLocation,
              wallbang: isWallbang,
              penetratedCount: penCheck.penetratedCount,
            },
          });
        }
      }
    }

    if (spec.id !== "knife") {
      events.push({
        payload: {
          type: "combat:shot",
          shooterId: shooter.id,
          weaponId: spec.id,
          origin,
          ends: tracerEnds,
        },
      });
    }

    if (totalHitDamage > 0 && !shooter.isBot) {
      events.push({
        targetId: shooter.id,
        payload: {
          type: "combat:hit_confirm",
          damage: totalHitDamage,
          headshot: anyHeadshot,
          wallbang: anyWallbang,
          killed: anyKilled,
        },
      });
    }

    return events;
  }

  tick(dt: number): ShooterOutgoingEvent[] {
    const events: ShooterOutgoingEvent[] = [];
    const now = Date.now();
    const playerList = Array.from(this.players.values());

    if (this.phase === "BUY_FREEZE") {
      this.phaseTimer -= dt;
      if (this.phaseTimer <= 0) {
        this.phase = "LIVE";
        this.phaseTimer = 180;
      }
      return events;
    }

    if (this.phase === "ROUND_END" || this.phase === "MATCH_END") {
      return events;
    }

    this.phaseTimer = Math.max(0, this.phaseTimer - dt);

    for (const p of playerList) {
      if (p.alive) {
        p.history.push({ t: now, x: p.x, y: p.y, z: p.z });
        if (p.history.length > 7) p.history.shift();
      } else if (this.mode === "TDM") {
        p.respawnTimer -= dt;
        if (p.respawnTimer <= 0) {
          const sp = this.getTeamSpawn(p.team, p.id);
          p.x = sp.x;
          p.y = sp.y;
          p.z = sp.z;
          p.yaw = sp.yaw;
          p.hp = p.maxHp;
          p.armor = p.maxArmor;
          p.alive = true;
          p.respawnTimer = 0;
          p.damageContributors.clear();
          if (!p.isBot) {
            events.push({
              targetId: p.id,
              payload: {
                type: "player:respawned",
                spawn: sp,
                team: p.team,
                weaponId: p.weaponId,
                ownedWeapons: [...p.ownedWeapons],
                money: p.money,
                resetWeapons: false,
              },
            });
          }
        }
      }
    }

    for (const bot of playerList) {
      if (!bot.isBot || !bot.alive) continue;
      const enemies = playerList.filter((o) => o.team !== bot.team && o.alive);
      if (enemies.length === 0) continue;

      let target = enemies[0];
      let bestDist = Math.hypot(target.x - bot.x, target.z - bot.z);
      for (let i = 1; i < enemies.length; i++) {
        const d = Math.hypot(enemies[i].x - bot.x, enemies[i].z - bot.z);
        if (d < bestDist) {
          target = enemies[i];
          bestDist = d;
        }
      }

      const dx = target.x - bot.x;
      const dz = target.z - bot.z;
      const dH = Math.max(0.01, Math.hypot(dx, dz));
      bot.yaw = Math.atan2(-dx / dH, -dz / dH);
      const speed = 5.4;
      const moveX = (dH > 12 ? dx / dH : 0) + (-dz / dH) * bot.botPatrolDir * 0.72;
      const moveZ = (dH > 12 ? dz / dH : 0) + (dx / dH) * bot.botPatrolDir * 0.72;
      const mL = Math.hypot(moveX, moveZ);
      if (mL > 0.01) {
        const res = resolveCircleBoxCollisions(
          bot.x + (moveX / mL) * speed * dt,
          bot.y,
          bot.z + (moveZ / mL) * speed * dt,
          0.55,
          this.mapId,
        );
        if (Math.hypot(res.x - bot.x, res.z - bot.z) < speed * dt * 0.25) {
          bot.botPatrolDir *= -1;
        }
        bot.x = res.x;
        bot.y = res.floorY;
        bot.z = res.z;
      }

      bot.botCooldown -= dt;
      const eyeY = bot.y + 1.55;
      // Aim primarily center-mass (chest ~1.18m) rather than guaranteed head-level lock
      const ty = target.y + (target.crouching ? 0.78 : 1.18) - eyeY;
      const d3 = Math.max(0.01, Math.hypot(dx, ty, dz));
      if (bot.botCooldown <= 0 && d3 < 52) {
        const wallD = raycastArenaObstacles(
          bot.x,
          eyeY,
          bot.z,
          dx / d3,
          ty / d3,
          dz / d3,
          d3,
          this.mapId,
        );
        if (wallD >= d3 - 0.8) {
          events.push(
            ...this.handlePlayerShot(
              bot.id,
              { x: bot.x, y: eyeY, z: bot.z },
              [
                {
                  dx: dx / d3 + (Math.random() - 0.5) * 0.065,
                  dy: ty / d3 + (Math.random() - 0.5) * 0.045,
                  dz: dz / d3 + (Math.random() - 0.5) * 0.065,
                },
              ],
              bot.weaponId,
            ),
          );
          bot.botCooldown = 0.48 + Math.random() * 0.28;
        } else {
          bot.botCooldown = 0.25;
        }
      }
    }

    const livingPlayers = playerList.filter((p) => p.alive);
    for (const pk of this.pickups) {
      if (!pk.active) {
        pk.respawnTimer -= dt;
        if (pk.respawnTimer <= 0) pk.active = true;
        continue;
      }
      for (const p of livingPlayers) {
        const dist = Math.hypot(p.x - pk.x, p.z - pk.z);
        if (dist < 1.9 && Math.abs(p.y + 0.6 - pk.y) < 2.2) {
          if (pk.kind === "medkit" && p.hp < p.maxHp) {
            p.hp = Math.min(p.maxHp, p.hp + 40);
            pk.active = false;
            pk.respawnTimer = 18;
            if (!p.isBot) {
              events.push({
                targetId: p.id,
                payload: { type: "pickup:collected", kind: "medkit", hp: p.hp },
              });
            }
            break;
          } else if (pk.kind === "ammo") {
            pk.active = false;
            pk.respawnTimer = 18;
            if (!p.isBot) {
              events.push({
                targetId: p.id,
                payload: { type: "pickup:collected", kind: "ammo" },
              });
            }
            break;
          }
        }
      }
    }

    if (this.mode === "TDM") {
      if (this.vanguardKills >= 25 || this.syndicateKills >= 25 || this.phaseTimer <= 0) {
        this.phase = "MATCH_END";
        this.winnerTeam =
          this.vanguardKills > this.syndicateKills
            ? "vanguard"
            : this.syndicateKills > this.vanguardKills
              ? "syndicate"
              : "draw";
        this.winReason =
          this.winnerTeam === "draw"
            ? "Match time expired — Draw!"
            : `${this.winnerTeam.toUpperCase()} won Team Deathmatch (${this.vanguardKills} - ${this.syndicateKills})`;
      }
    } else {
      const vAlive = playerList.filter((p) => p.team === "vanguard" && p.alive).length;
      const sAlive = playerList.filter((p) => p.team === "syndicate" && p.alive).length;
      const vTotal = playerList.filter((p) => p.team === "vanguard").length;
      const sTotal = playerList.filter((p) => p.team === "syndicate").length;

      if (!this.bombPlanted && this.activePlanterId) {
        const planter = this.players.get(this.activePlanterId);
        if (!planter || !planter.alive) {
          this.activePlanterId = null;
          this.plantProgress = 0;
        }
      }

      if (this.bombPlanted) {
        this.bombTimer = Math.max(0, this.bombTimer - dt);
        if (this.bombTimer <= 0) {
          events.push({ payload: { type: "bomb:detonated", siteId: this.bombSiteId } });
          this.awardRoundWin("vanguard", "Aether Charge detonated!", events);
        }
      }

      if (this.phase === "LIVE" && vTotal > 0 && sTotal > 0) {
        if (sAlive === 0) {
          this.awardRoundWin("vanguard", `${getTeamDisplayName("syndicate")} eliminated!`, events);
        } else if (vAlive === 0) {
          this.awardRoundWin("syndicate", `${getTeamDisplayName("vanguard")} eliminated!`, events);
        }
      }
    }

    return events;
  }

  serializeSnapshot(): HostShooterSnapshot {
    return {
      type: "room:snapshot",
      code: this.code,
      title: this.title,
      mapId: this.mapId,
      mode: this.mode,
      fillBots: this.fillBots,
      alphaBotCount: this.alphaBotCount,
      bravoBotCount: this.bravoBotCount,
      round: this.round,
      maxRounds: this.maxRounds,
      isPistolRound: this.isPistolRound(),
      phase: this.phase,
      phaseTimer: Number(this.phaseTimer.toFixed(1)),
      vanguardRounds: this.vanguardRounds,
      syndicateRounds: this.syndicateRounds,
      vanguardKills: this.vanguardKills,
      syndicateKills: this.syndicateKills,
      roundWinnerTeam: this.roundWinnerTeam,
      winnerTeam: this.winnerTeam,
      winReason: this.winReason,
      bombPlanted: this.bombPlanted,
      bombSiteId: this.bombSiteId,
      bombX: Number(this.bombX.toFixed(2)),
      bombY: Number(this.bombY.toFixed(2)),
      bombZ: Number(this.bombZ.toFixed(2)),
      bombTimer: Number(this.bombTimer.toFixed(1)),
      plantProgress: Math.round(this.plantProgress),
      defuseProgress: Math.round(this.defuseProgress),
      players: Array.from(this.players.values()).map((p) => ({
        id: p.id,
        name: p.name,
        team: p.team,
        color: p.color,
        isBot: p.isBot,
        x: Number(p.x.toFixed(3)),
        y: Number(p.y.toFixed(3)),
        z: Number(p.z.toFixed(3)),
        yaw: Number(p.yaw.toFixed(4)),
        pitch: Number(p.pitch.toFixed(4)),
        crouching: p.crouching,
        weaponId: p.weaponId,
        ownedWeapons: [...p.ownedWeapons],
        money: p.money,
        hp: Math.round(p.hp),
        maxHp: p.maxHp,
        armor: Math.round(p.armor),
        alive: p.alive,
        respawnTimer: Number(p.respawnTimer.toFixed(1)),
        kills: p.kills,
        deaths: p.deaths,
        assists: p.assists,
        damageDealt: Math.round(p.damageDealt),
        score: p.score,
      })),
      pickups: this.pickups.map((pk) => ({
        id: pk.id,
        kind: pk.kind,
        active: pk.active,
      })),
    };
  }
}
