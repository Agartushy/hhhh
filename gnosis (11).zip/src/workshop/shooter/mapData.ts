export type FpsMapId = "mansion" | "blockline" | "desert-outpost" | "arctic-facility";

export type BoxMaterialType = "wood" | "stone" | "concrete" | "metal";

export type BoxStyle =
  | "wall"
  | "building"
  | "platform"
  | "pillar"
  | "crate"
  | "barrier"
  | "container-amber"
  | "container-blue"
  | "container-slate"
  | "arch"
  | "mansion-wall"
  | "mansion-floor"
  | "mansion-roof"
  | "wood-stair"
  | "wood-door"
  | "wood-wall"
  | "furniture-wood"
  | "hedge"
  | "fence"
  | "sandstone"
  | "concrete"
  | "metal-cover"
  | "ice-wall";

export interface MaterialProperties {
  id: BoxMaterialType;
  label: string;
  penetrable: boolean;
  baseDamageMult: number;
  thicknessDecayPerMeter: number;
  maxThickness: number;
}

export const MATERIAL_PROPERTIES: Record<BoxMaterialType, MaterialProperties> = {
  wood: {
    id: "wood",
    label: "Timber / Wood",
    penetrable: true,
    baseDamageMult: 0.78,
    thicknessDecayPerMeter: 0.55,
    maxThickness: 2.55,
  },
  stone: {
    id: "stone",
    label: "Solid Sandstone / Masonry",
    penetrable: false,
    baseDamageMult: 0,
    thicknessDecayPerMeter: 999,
    maxThickness: 0,
  },
  concrete: {
    id: "concrete",
    label: "Reinforced Concrete",
    penetrable: false,
    baseDamageMult: 0,
    thicknessDecayPerMeter: 999,
    maxThickness: 0,
  },
  metal: {
    id: "metal",
    label: "Steel / Metal Plating",
    penetrable: false,
    baseDamageMult: 0,
    thicknessDecayPerMeter: 999,
    maxThickness: 0,
  },
};

export interface ArenaBox {
  id: string;
  x: number;
  y: number; // Bottom Y coordinate
  z: number;
  w: number;
  h: number;
  d: number;
  kind: "wall" | "building" | "crate" | "barrier" | "platform" | "pillar";
  style?: BoxStyle;
  material?: BoxMaterialType;
}

export function getBoxMaterial(box: ArenaBox): BoxMaterialType {
  if (box.material) return box.material;
  const s = box.style || box.kind;
  switch (s) {
    case "crate":
    case "wood-door":
    case "wood-wall":
    case "wood-stair":
    case "furniture-wood":
    case "hedge":
      return "wood";
    case "container-amber":
    case "container-blue":
    case "container-slate":
    case "fence":
    case "metal-cover":
      return "metal";
    case "sandstone":
    case "mansion-wall":
    case "wall":
    case "pillar":
      return "stone";
    case "building":
    case "barrier":
    case "platform":
    case "arch":
    case "concrete":
    case "ice-wall":
    case "mansion-floor":
    case "mansion-roof":
    default:
      return "concrete";
  }
}

export interface BombSiteZone {
  id: "A" | "B";
  name: string;
  callout: string;
  x: number;
  y: number;
  z: number;
  radius: number;
}

export interface PickupSpawn {
  id: string;
  kind: "medkit" | "ammo";
  x: number;
  y: number;
  z: number;
}

export interface MapCallout {
  name: string;
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
}

export interface MapPropHint {
  kind: "tree" | "fountain" | "van" | "gazebo" | "lamp" | "palm" | "crane" | "snowbank" | "awning";
  x: number;
  y: number;
  z: number;
  rotY?: number;
  scale?: number;
  w?: number;
  d?: number;
  colorHex?: number;
}

export interface FpsMapDef {
  id: FpsMapId;
  name: string;
  subtitle: string;
  description: string;
  atmosphereTag: string;
  halfW: number;
  halfD: number;
  skyHex: number;
  fogHex: number;
  sunHex: number;
  floorPalette: [string, string];
  vanguardSpawns: { x: number; y: number; z: number; yaw: number }[];
  syndicateSpawns: { x: number; y: number; z: number; yaw: number }[];
  bombSites: BombSiteZone[];
  pickups: PickupSpawn[];
  callouts: MapCallout[];
  boxes: ArenaBox[];
  props: MapPropHint[];
  minimapAccent: string;
}

export const ARENA_HALF_W = 58;
export const ARENA_HALF_D = 48;
export const ARENA_HALF_SIZE = 58;

/**
 * 1. SIROCCO CITADEL (Classic Tactical Desert Compound — Dust/Mirage-Inspired Original Layout)
 * - Enclosed Team Alpha & Team Bravo spawn courtyards separated by tall 7.5–9m sandstone buildings (zero spawn-to-spawn sightlines).
 * - 3 strategic combat lanes:
 *   - West: A Long Corridor & Short A Catwalk into Site A Caravan Plaza (elevated stone dais + metal container + penetrable wood crates).
 *   - Center: Mid Canyon with Stone Doorframe & thin Penetrable Wooden Double-Doors (wallbangable!) + Connector arches.
 *   - East: Covered B Bazaar Tunnels with Wooden Partitions/Barricades leading into Site B Casbah Courtyard.
 */
const DESERT_OUTPOST_MAP: FpsMapDef = {
  id: "desert-outpost",
  name: "Sirocco Citadel",
  subtitle: "Tactical Desert Compound · Wood Doors, Bazaar & Long A",
  description:
    "Classic desert tactical map with sheltered team spawns, tall sandstone architecture, Long-A & Mid Catwalk, wallbangable wooden double-doors, covered B Bazaar tunnels, and wooden/stone/metal cover.",
  atmosphereTag: "HIGH NOON DESERT",
  halfW: ARENA_HALF_W,
  halfD: ARENA_HALF_D,
  skyHex: 0xebd0a2,
  fogHex: 0xe2c391,
  sunHex: 0xfff1cf,
  floorPalette: ["#d7bc8e", "#c2a170"],
  vanguardSpawns: [
    { x: -16, y: 0, z: 41.5, yaw: 0 },
    { x: -8, y: 0, z: 42.2, yaw: 0 },
    { x: 0, y: 0, z: 41.2, yaw: 0 },
    { x: 8, y: 0, z: 42.2, yaw: 0 },
    { x: 16, y: 0, z: 41.5, yaw: 0 },
    { x: -12, y: 0, z: 38.2, yaw: 0 },
    { x: 0, y: 0, z: 38.0, yaw: 0 },
    { x: 12, y: 0, z: 38.2, yaw: 0 },
  ],
  syndicateSpawns: [
    { x: -16, y: 0, z: -41.5, yaw: Math.PI },
    { x: -8, y: 0, z: -42.2, yaw: Math.PI },
    { x: 0, y: 0, z: -41.2, yaw: Math.PI },
    { x: 8, y: 0, z: -42.2, yaw: Math.PI },
    { x: 16, y: 0, z: -41.5, yaw: Math.PI },
    { x: -12, y: 0, z: -38.2, yaw: Math.PI },
    { x: 0, y: 0, z: -38.0, yaw: Math.PI },
    { x: 12, y: 0, z: -38.2, yaw: Math.PI },
  ],
  bombSites: [
    {
      id: "A",
      name: "Site A · Caravan Courtyard",
      callout: "SITE A (CARAVAN)",
      x: -38,
      y: 0,
      z: -12,
      radius: 6.6,
    },
    {
      id: "B",
      name: "Site B · Casbah Ruins",
      callout: "SITE B (CASBAH)",
      x: 38,
      y: 0,
      z: -10,
      radius: 6.6,
    },
  ],
  pickups: [
    { id: "des-med-cat", kind: "medkit", x: -16, y: 2.9, z: -6 },
    { id: "des-ammo-a", kind: "ammo", x: -45, y: 2.0, z: -12 },
    { id: "des-med-b", kind: "medkit", x: 32, y: 0.55, z: -16 },
    { id: "des-ammo-mid", kind: "ammo", x: 0, y: 0.55, z: 9 },
  ],
  callouts: [
    { name: "ALPHA SPAWN COURTYARD", minX: -28, maxX: 28, minZ: 33, maxZ: 48 },
    { name: "BRAVO FORTRESS SPAWN", minX: -28, maxX: 28, minZ: -48, maxZ: -33 },
    { name: "A LONG CORRIDOR", minX: -58, maxX: -22, minZ: 4, maxZ: 48 },
    { name: "SITE A · CARAVAN PLAZA", minX: -58, maxX: -22, minZ: -26, maxZ: 4 },
    { name: "A-SHORT CATWALK", minX: -22, maxX: -8, minZ: -12, maxZ: 10 },
    { name: "MID WOODEN DOORS", minX: -18, maxX: 18, minZ: -10, maxZ: 10 },
    { name: "MID PALACE ALLEY", minX: -22, maxX: 22, minZ: -33, maxZ: 33 },
    { name: "B BAZAAR TUNNELS", minX: 22, maxX: 58, minZ: 4, maxZ: 48 },
    { name: "SITE B · CASBAH", minX: 22, maxX: 58, minZ: -26, maxZ: 4 },
  ],
  boxes: [
    // Perimeter High Sandstone Fortress Walls (Solid Stone)
    { id: "wall-n", x: 0, y: 0, z: -ARENA_HALF_D, w: ARENA_HALF_W * 2, h: 12, d: 3, kind: "wall", style: "sandstone", material: "stone" },
    { id: "wall-s", x: 0, y: 0, z: ARENA_HALF_D, w: ARENA_HALF_W * 2, h: 12, d: 3, kind: "wall", style: "sandstone", material: "stone" },
    { id: "wall-w", x: -ARENA_HALF_W, y: 0, z: 0, w: 3, h: 12, d: ARENA_HALF_D * 2, kind: "wall", style: "sandstone", material: "stone" },
    { id: "wall-e", x: ARENA_HALF_W, y: 0, z: 0, w: 3, h: 12, d: ARENA_HALF_D * 2, kind: "wall", style: "sandstone", material: "stone" },

    // ==== ALPHA SPAWN FORTIFICATION (Blocks ALL Spawn-to-Spawn Sightlines) ====
    // Tall south gatehouses separating Alpha Spawn from Mid & Lanes
    { id: "des-a-gate-w", x: -11.5, y: 0, z: 32.5, w: 21, h: 7.8, d: 3.2, kind: "building", style: "sandstone", material: "stone" },
    { id: "des-a-gate-e", x: 14.5, y: 0, z: 32.5, w: 19, h: 7.8, d: 3.2, kind: "building", style: "sandstone", material: "stone" },
    { id: "des-a-gate-lintel", x: 2.0, y: 4.4, z: 32.5, w: 6.2, h: 3.4, d: 3.2, kind: "building", style: "sandstone", material: "stone" },
    // Sightline baffle directly outside Mid exit & East/West flank corners
    { id: "des-a-baffle-mid", x: 3.5, y: 0, z: 24.5, w: 11.5, h: 6.4, d: 2.6, kind: "building", style: "sandstone", material: "stone" },
    { id: "des-a-baffle-w", x: -29, y: 0, z: 31, w: 4.2, h: 6.5, d: 10.5, kind: "building", style: "sandstone", material: "stone" },
    { id: "des-a-crate-sp", x: -3.5, y: 0, z: 36.2, w: 2.4, h: 1.5, d: 1.8, kind: "crate", style: "crate", material: "wood" },

    // ==== BRAVO SPAWN FORTIFICATION (Blocks ALL Spawn-to-Spawn Sightlines) ====
    { id: "des-b-gate-w", x: -15.5, y: 0, z: -32.5, w: 21, h: 8.2, d: 3.2, kind: "building", style: "sandstone", material: "stone" },
    { id: "des-b-gate-e", x: 15.5, y: 0, z: -32.5, w: 21, h: 8.2, d: 3.2, kind: "building", style: "sandstone", material: "stone" },
    { id: "des-b-gate-lintel", x: 0, y: 4.5, z: -32.5, w: 10.2, h: 3.7, d: 3.2, kind: "building", style: "sandstone", material: "stone" },
    // Mid Sniper Nest Baffle (forces wide peek instead of instant spawn view)
    { id: "des-b-baffle-mid", x: -1.5, y: 0, z: -24.5, w: 13.0, h: 6.8, d: 2.8, kind: "building", style: "sandstone", material: "stone" },
    { id: "des-b-crate-sp", x: 6.5, y: 0, z: -36.2, w: 2.4, h: 1.5, d: 1.8, kind: "crate", style: "crate", material: "wood" },

    // ==== LANE DIVIDERS (Separate Mid from Long A & B Tunnels with tall architecture) ====
    // West Lane Building Block (between A-Long and Mid)
    { id: "des-div-sw", x: -21, y: 0, z: 16, w: 5.2, h: 8.5, d: 17.5, kind: "building", style: "sandstone", material: "stone" },
    { id: "des-div-nw", x: -21, y: 0, z: -18, w: 5.2, h: 8.5, d: 14.5, kind: "building", style: "sandstone", material: "stone" },
    // East Lane Building Block (between Mid and B Bazaar)
    { id: "des-div-se", x: 21, y: 0, z: 15, w: 5.2, h: 8.5, d: 16.5, kind: "building", style: "sandstone", material: "stone" },
    { id: "des-div-ne", x: 21, y: 0, z: -17, w: 5.2, h: 8.5, d: 15.5, kind: "building", style: "sandstone", material: "stone" },
    { id: "des-div-e-lintel", x: 21, y: 4.2, z: -1.2, w: 5.2, h: 4.3, d: 16.2, kind: "building", style: "sandstone", material: "stone" },

    // ==== MID CANYON & WALLBANGABLE WOODEN DOUBLE-DOORS ====
    // Stone doorway frame (unpenetrable)
    { id: "des-mid-frame-w", x: -12.8, y: 0, z: -1.0, w: 11.2, h: 7.4, d: 2.4, kind: "building", style: "sandstone", material: "stone" },
    { id: "des-mid-frame-e", x: 12.8, y: 0, z: -1.0, w: 11.2, h: 7.4, d: 2.4, kind: "building", style: "sandstone", material: "stone" },
    { id: "des-mid-frame-top", x: 0, y: 3.9, z: -1.0, w: 14.6, h: 3.5, d: 2.4, kind: "building", style: "sandstone", material: "stone" },
    // Twin Penetrable Wooden Double Doors (0.38m thick wood -> bullets punch through with damage reduction!)
    { id: "des-mid-door-w", x: -4.1, y: 0, z: -1.0, w: 6.2, h: 3.9, d: 0.38, kind: "barrier", style: "wood-door", material: "wood" },
    { id: "des-mid-door-e", x: 4.1, y: 0, z: -1.0, w: 6.2, h: 3.9, d: 0.38, kind: "barrier", style: "wood-door", material: "wood" },
    // Mid Tactical Cover (Concrete low blocks + Wood crates)
    { id: "des-mid-conc-s", x: -7.5, y: 0, z: 11.5, w: 4.2, h: 1.45, d: 1.6, kind: "barrier", style: "concrete", material: "concrete" },
    { id: "des-mid-crate-s", x: 7.5, y: 0, z: 12.5, w: 2.4, h: 1.85, d: 2.2, kind: "crate", style: "crate", material: "wood" },
    { id: "des-mid-crate-n", x: -6.5, y: 0, z: -11.5, w: 2.3, h: 1.7, d: 2.3, kind: "crate", style: "crate", material: "wood" },
    { id: "des-mid-conc-n", x: 8.0, y: 0, z: -13.0, w: 4.6, h: 1.5, d: 1.7, kind: "barrier", style: "concrete", material: "concrete" },

    // ==== A-SHORT ELEVATED CATWALK (Links Mid to Site A) ====
    { id: "des-cat-step1", x: -11.5, y: 0, z: 8.0, w: 4.0, h: 0.9, d: 2.4, kind: "platform", style: "wood-stair", material: "wood" },
    { id: "des-cat-step2", x: -13.5, y: 0, z: 5.5, w: 4.0, h: 1.75, d: 2.6, kind: "platform", style: "wood-stair", material: "wood" },
    { id: "des-cat-deck", x: -16.0, y: 0, z: -5.5, w: 4.8, h: 2.4, d: 13.5, kind: "platform", style: "sandstone", material: "stone" },
    { id: "des-cat-parapet", x: -13.9, y: 2.4, z: -5.5, w: 0.55, h: 1.0, d: 12.0, kind: "barrier", style: "sandstone", material: "stone" },
    { id: "des-cat-exit1", x: -20.5, y: 0, z: -8.5, w: 4.2, h: 1.5, d: 4.4, kind: "platform", style: "wood-stair", material: "wood" },
    { id: "des-cat-exit2", x: -23.5, y: 0, z: -8.5, w: 3.0, h: 0.75, d: 4.4, kind: "platform", style: "wood-stair", material: "wood" },

    // ==== WEST LANE: A LONG & SITE A CARAVAN PLAZA ====
    // A Long Corner House / Pit Block (blocks spawn-to-Site-A long line until rounded)
    { id: "des-a-long-bldg", x: -46.5, y: 0, z: 22.0, w: 12.0, h: 7.4, d: 7.5, kind: "building", style: "sandstone", material: "stone" },
    { id: "des-a-long-wall", x: -46.5, y: 0, z: 7.5, w: 9.0, h: 4.2, d: 2.4, kind: "building", style: "sandstone", material: "stone" },
    // Penetrable Wooden Barricade & Crates along A Long
    { id: "des-a-wood-bar", x: -34.0, y: 0, z: 16.5, w: 5.4, h: 1.9, d: 0.44, kind: "barrier", style: "wood-wall", material: "wood" },
    { id: "des-a-crate-long", x: -36.5, y: 0, z: 7.0, w: 2.4, h: 1.85, d: 2.4, kind: "crate", style: "crate", material: "wood" },
    // Site A Dais Platform + Stairs
    { id: "des-a-dais", x: -48.5, y: 0, z: -12.0, w: 10.5, h: 1.5, d: 13.0, kind: "platform", style: "concrete", material: "concrete" },
    { id: "des-a-dais-step", x: -42.5, y: 0, z: -12.0, w: 2.2, h: 0.75, d: 6.5, kind: "platform", style: "wood-stair", material: "wood" },
    // Site A Solid Metal Container + Penetrable Wooden Bomb Crates
    { id: "des-a-container", x: -34.0, y: 0, z: -19.5, w: 3.4, h: 3.0, d: 7.8, kind: "building", style: "container-amber", material: "metal" },
    { id: "des-a-crate1", x: -38.5, y: 0, z: -10.5, w: 2.3, h: 2.0, d: 2.3, kind: "crate", style: "crate", material: "wood" },
    { id: "des-a-crate2", x: -36.2, y: 0, z: -9.8, w: 1.9, h: 1.25, d: 1.9, kind: "crate", style: "crate", material: "wood" },
    // North A Archway Exit toward Bravo Spawn
    { id: "des-a-north-house", x: -45.0, y: 0, z: -30.5, w: 16.5, h: 7.8, d: 5.5, kind: "building", style: "sandstone", material: "stone" },

    // ==== EAST LANE: B BAZAAR COVERED TUNNELS & SITE B CASBAH ====
    // Tunnel Outer Walls & Roof
    { id: "des-b-tun-w", x: 27.5, y: 0, z: 16.5, w: 3.2, h: 6.2, d: 16.5, kind: "building", style: "sandstone", material: "stone" },
    { id: "des-b-tun-e", x: 50.5, y: 0, z: 16.5, w: 3.4, h: 6.2, d: 16.5, kind: "building", style: "sandstone", material: "stone" },
    { id: "des-b-tun-roof", x: 39.0, y: 5.2, z: 16.5, w: 26.2, h: 1.0, d: 16.5, kind: "building", style: "concrete", material: "concrete" },
    // Tunnel Interior Wooden Market Stalls & Exit Wooden Door (penetrable!)
    { id: "des-b-tun-crate", x: 39.0, y: 0, z: 18.0, w: 2.4, h: 1.85, d: 2.4, kind: "crate", style: "crate", material: "wood" },
    { id: "des-b-tun-wood", x: 34.5, y: 0, z: 7.8, w: 5.2, h: 3.2, d: 0.42, kind: "barrier", style: "wood-door", material: "wood" },
    { id: "des-b-tun-conc", x: 44.5, y: 0, z: 9.5, w: 4.5, h: 1.5, d: 1.6, kind: "barrier", style: "concrete", material: "concrete" },
    // Site B Casbah Structures
    { id: "des-b-pillar", x: 38.5, y: 0, z: -10.0, w: 2.8, h: 6.8, d: 2.8, kind: "pillar", style: "sandstone", material: "stone" },
    { id: "des-b-crate1", x: 33.8, y: 0, z: -6.5, w: 2.3, h: 1.9, d: 2.3, kind: "crate", style: "crate", material: "wood" },
    { id: "des-b-crate2", x: 42.5, y: 0, z: -7.5, w: 2.1, h: 1.35, d: 2.1, kind: "crate", style: "crate", material: "wood" },
    { id: "des-b-container", x: 48.0, y: 0, z: -14.5, w: 3.6, h: 3.0, d: 8.2, kind: "building", style: "container-blue", material: "metal" },
    { id: "des-b-north-bunker", x: 43.0, y: 0, z: -29.5, w: 18.0, h: 7.4, d: 5.5, kind: "building", style: "sandstone", material: "stone" },
    // Back-Site B Stone Cover
    { id: "des-b-conc-cov", x: 32.0, y: 0, z: -21.0, w: 5.5, h: 1.65, d: 1.6, kind: "barrier", style: "concrete", material: "concrete" },
  ],
  props: [
    { kind: "palm", x: -50, y: 0, z: 38, scale: 1.2 },
    { kind: "palm", x: 50, y: 0, z: 38, scale: 1.15 },
    { kind: "palm", x: -50, y: 0, z: -38, scale: 1.15 },
    { kind: "palm", x: 50, y: 0, z: -38, scale: 1.2 },
    { kind: "palm", x: -29, y: 0, z: -2, scale: 1.05 },
    { kind: "awning", x: -35, y: 4.3, z: -5, w: 8, d: 5, colorHex: 0xa8432a },
    { kind: "awning", x: 37, y: 4.4, z: -2, w: 9, d: 5, colorHex: 0x2f5f7a },
    { kind: "awning", x: 0, y: 4.6, z: 16, w: 10, d: 5, colorHex: 0xb8762c },
  ],
  minimapAccent: "#e09f46",
};

/**
 * 2. ESTATE: MANSION (CS 1.6 Mansion-Inspired 2-Story Compound & Surrounding Grounds)
 */
const MANSION_MAP: FpsMapDef = {
  id: "mansion",
  name: "Estate: Mansion",
  subtitle: "2-Story Manor · Classic Yard & Interior Rooms",
  description:
    "Inspired by CS 1.6 Mansion: infiltrate a sprawling 2-story manor with dual stairwells, upper gallery balconies, furnished rooms, surrounded by hedged gardens, fountain plaza, delivery van cover, and stone perimeter walls.",
  atmosphereTag: "TWILIGHT COURTYARD",
  halfW: ARENA_HALF_W,
  halfD: ARENA_HALF_D,
  skyHex: 0x3b4d6b,
  fogHex: 0x3b4d6b,
  sunHex: 0xffe4bc,
  floorPalette: ["#4d6a41", "#3e5735"],
  vanguardSpawns: [
    { x: -16, y: 0, z: 40, yaw: 0 },
    { x: -6, y: 0, z: 40.5, yaw: 0 },
    { x: 6, y: 0, z: 40.5, yaw: 0 },
    { x: 16, y: 0, z: 40, yaw: 0 },
  ],
  syndicateSpawns: [
    { x: -15, y: 0, z: -40, yaw: Math.PI },
    { x: -5, y: 0, z: -40.5, yaw: Math.PI },
    { x: 5, y: 0, z: -40.5, yaw: Math.PI },
    { x: 15, y: 0, z: -40, yaw: Math.PI },
  ],
  bombSites: [
    {
      id: "A",
      name: "Site A · Grand Dining Hall",
      callout: "SITE A (DINING HALL)",
      x: -11,
      y: 0,
      z: -2,
      radius: 6.2,
    },
    {
      id: "B",
      name: "Site B · Upper Study Gallery",
      callout: "SITE B (2F STUDY)",
      x: 11,
      y: 4.0,
      z: -2,
      radius: 5.8,
    },
  ],
  pickups: [
    { id: "mans-med-fountain", kind: "medkit", x: 0, y: 0.65, z: 27 },
    { id: "mans-ammo-foyer", kind: "ammo", x: 0, y: 0.65, z: 4.5 },
    { id: "mans-med-gallery", kind: "medkit", x: 0, y: 4.65, z: -7.5 },
    { id: "mans-ammo-west", kind: "ammo", x: -37, y: 0.65, z: 0 },
  ],
  callouts: [
    { name: "FRONT GATE & VAN", minX: -30, maxX: 30, minZ: 28, maxZ: 48 },
    { name: "FOUNTAIN LAWN", minX: -24, maxX: 24, minZ: 15, maxZ: 28 },
    { name: "MANSION FOYER", minX: -20, maxX: 20, minZ: 2, maxZ: 15 },
    { name: "DINING HALL (SITE A)", minX: -20, maxX: 0, minZ: -15, maxZ: 2 },
    { name: "OAK LIBRARY & STUDY (SITE B)", minX: 0, maxX: 20, minZ: -15, maxZ: 2 },
    { name: "WEST HEDGE MAZE", minX: -56, maxX: -21, minZ: -28, maxZ: 32 },
    { name: "EAST GAZEBO GARDEN", minX: 21, maxX: 56, minZ: -28, maxZ: 32 },
    { name: "NORTH PATIO TERRACE", minX: -32, maxX: 32, minZ: -48, maxZ: -16 },
  ],
  boxes: [
    { id: "wall-n", x: 0, y: 0, z: -ARENA_HALF_D, w: ARENA_HALF_W * 2, h: 10, d: 3, kind: "wall", style: "wall", material: "stone" },
    { id: "wall-s", x: 0, y: 0, z: ARENA_HALF_D, w: ARENA_HALF_W * 2, h: 10, d: 3, kind: "wall", style: "wall", material: "stone" },
    { id: "wall-w", x: -ARENA_HALF_W, y: 0, z: 0, w: 3, h: 10, d: ARENA_HALF_D * 2, kind: "wall", style: "wall", material: "stone" },
    { id: "wall-e", x: ARENA_HALF_W, y: 0, z: 0, w: 3, h: 10, d: ARENA_HALF_D * 2, kind: "wall", style: "wall", material: "stone" },

    { id: "ms-front-w", x: -12, y: 0, z: 14.5, w: 16, h: 8.6, d: 1.4, kind: "building", style: "mansion-wall", material: "stone" },
    { id: "ms-front-e", x: 12, y: 0, z: 14.5, w: 16, h: 8.6, d: 1.4, kind: "building", style: "mansion-wall", material: "stone" },
    { id: "ms-front-lintel", x: 0, y: 3.4, z: 14.5, w: 8, h: 5.2, d: 1.4, kind: "building", style: "mansion-wall", material: "stone" },
    { id: "ms-porch-pl", x: -4.6, y: 0, z: 18.2, w: 1.1, h: 4.2, d: 1.1, kind: "pillar", style: "pillar", material: "stone" },
    { id: "ms-porch-pr", x: 4.6, y: 0, z: 18.2, w: 1.1, h: 4.2, d: 1.1, kind: "pillar", style: "pillar", material: "stone" },
    { id: "ms-porch-deck", x: 0, y: 4.0, z: 16.8, w: 11.4, h: 0.45, d: 4.6, kind: "platform", style: "mansion-floor", material: "concrete" },

    { id: "ms-back-w", x: -12.2, y: 0, z: -14.5, w: 15.6, h: 8.6, d: 1.4, kind: "building", style: "mansion-wall", material: "stone" },
    { id: "ms-back-e", x: 12.2, y: 0, z: -14.5, w: 15.6, h: 8.6, d: 1.4, kind: "building", style: "mansion-wall", material: "stone" },
    { id: "ms-back-lintel", x: 0, y: 3.4, z: -14.5, w: 9, h: 5.2, d: 1.4, kind: "building", style: "mansion-wall", material: "stone" },

    { id: "ms-west-s", x: -20, y: 0, z: 9.2, w: 1.4, h: 8.6, d: 10.6, kind: "building", style: "mansion-wall", material: "stone" },
    { id: "ms-west-n", x: -20, y: 0, z: -9.2, w: 1.4, h: 8.6, d: 10.6, kind: "building", style: "mansion-wall", material: "stone" },
    { id: "ms-west-lintel", x: -20, y: 3.4, z: 0, w: 1.4, h: 5.2, d: 7.8, kind: "building", style: "mansion-wall", material: "stone" },

    { id: "ms-east-s", x: 20, y: 0, z: 9.2, w: 1.4, h: 8.6, d: 10.6, kind: "building", style: "mansion-wall", material: "stone" },
    { id: "ms-east-n", x: 20, y: 0, z: -9.2, w: 1.4, h: 8.6, d: 10.6, kind: "building", style: "mansion-wall", material: "stone" },
    { id: "ms-east-lintel", x: 20, y: 3.4, z: 0, w: 1.4, h: 5.2, d: 7.8, kind: "building", style: "mansion-wall", material: "stone" },

    { id: "ms-mid-split", x: 0, y: 0, z: -7.5, w: 1.4, h: 3.8, d: 12.5, kind: "building", style: "mansion-wall", material: "stone" },
    // Wooden foyer reception screen blocking straight doorway-to-doorway snipes while penetrable
    { id: "ms-foyer-screen", x: 0, y: 0, z: 9.8, w: 3.8, h: 2.3, d: 0.45, kind: "barrier", style: "wood-wall", material: "wood" },

    { id: "ms-2f-north-deck", x: 0, y: 3.65, z: -9.0, w: 38.6, h: 0.35, d: 9.8, kind: "platform", style: "mansion-floor", material: "concrete" },
    { id: "ms-2f-west-deck", x: -13.5, y: 3.65, z: 2.0, w: 11.6, h: 0.35, d: 14.0, kind: "platform", style: "mansion-floor", material: "concrete" },
    { id: "ms-2f-east-deck", x: 11.5, y: 3.65, z: -1.5, w: 15.6, h: 0.35, d: 24.5, kind: "platform", style: "mansion-floor", material: "concrete" },
    { id: "ms-2f-rail-n", x: 0, y: 4.0, z: -4.2, w: 15.0, h: 0.95, d: 0.45, kind: "barrier", style: "fence", material: "metal" },
    { id: "ms-2f-rail-w", x: -7.9, y: 4.0, z: 2.0, w: 0.45, h: 0.95, d: 12.0, kind: "barrier", style: "fence", material: "metal" },
    { id: "ms-2f-rail-e", x: 3.9, y: 4.0, z: 4.2, w: 0.45, h: 0.95, d: 12.0, kind: "barrier", style: "fence", material: "metal" },

    { id: "ms-roof-main", x: 0, y: 8.4, z: 0, w: 42.4, h: 1.6, d: 31.4, kind: "building", style: "mansion-roof", material: "concrete" },

    { id: "ms-ws-1", x: -14.5, y: 0, z: 12.6, w: 3.6, h: 0.8, d: 1.8, kind: "platform", style: "wood-stair", material: "wood" },
    { id: "ms-ws-2", x: -14.5, y: 0, z: 11.0, w: 3.6, h: 1.6, d: 1.8, kind: "platform", style: "wood-stair", material: "wood" },
    { id: "ms-ws-3", x: -14.5, y: 0, z: 9.4, w: 3.6, h: 2.4, d: 1.8, kind: "platform", style: "wood-stair", material: "wood" },
    { id: "ms-ws-4", x: -14.5, y: 0, z: 7.8, w: 3.6, h: 3.2, d: 1.8, kind: "platform", style: "wood-stair", material: "wood" },

    { id: "ms-es-1", x: 24.5, y: 0, z: -20.5, w: 3.8, h: 0.8, d: 2.2, kind: "platform", style: "wood-stair", material: "wood" },
    { id: "ms-es-2", x: 24.5, y: 0, z: -18.5, w: 3.8, h: 1.6, d: 2.2, kind: "platform", style: "wood-stair", material: "wood" },
    { id: "ms-es-3", x: 24.5, y: 0, z: -16.5, w: 3.8, h: 2.4, d: 2.2, kind: "platform", style: "wood-stair", material: "wood" },
    { id: "ms-es-4", x: 24.5, y: 0, z: -14.5, w: 3.8, h: 3.2, d: 2.2, kind: "platform", style: "wood-stair", material: "wood" },
    { id: "ms-es-deck", x: 24.0, y: 3.65, z: -8.5, w: 6.4, h: 0.35, d: 10.2, kind: "platform", style: "mansion-floor", material: "concrete" },
    { id: "ms-es-bridge", x: 20.5, y: 3.65, z: -4.5, w: 4.2, h: 0.35, d: 3.6, kind: "platform", style: "mansion-floor", material: "concrete" },

    { id: "furn-dining-tbl", x: -10.5, y: 0, z: -2.0, w: 4.8, h: 1.05, d: 2.4, kind: "crate", style: "furniture-wood", material: "wood" },
    { id: "furn-dining-c1", x: -10.5, y: 0, z: 0.3, w: 1.1, h: 0.85, d: 0.9, kind: "barrier", style: "furniture-wood", material: "wood" },
    { id: "furn-dining-c2", x: -10.5, y: 0, z: -4.3, w: 1.1, h: 0.85, d: 0.9, kind: "barrier", style: "furniture-wood", material: "wood" },
    { id: "furn-sideboard", x: -4.2, y: 0, z: -11.8, w: 4.4, h: 1.4, d: 1.4, kind: "crate", style: "furniture-wood", material: "wood" },
    { id: "furn-shelf-e1", x: 9.5, y: 0, z: -12.2, w: 4.6, h: 2.7, d: 1.3, kind: "crate", style: "furniture-wood", material: "wood" },
    { id: "furn-shelf-e2", x: 15.8, y: 0, z: -6.5, w: 1.3, h: 2.7, d: 4.8, kind: "crate", style: "furniture-wood", material: "wood" },
    { id: "furn-foyer-sofa", x: 8.5, y: 0, z: 8.2, w: 4.2, h: 1.0, d: 1.6, kind: "barrier", style: "furniture-wood", material: "wood" },
    { id: "furn-2f-desk", x: 11.5, y: 4.0, z: -2.5, w: 3.8, h: 1.05, d: 1.8, kind: "crate", style: "furniture-wood", material: "wood" },
    { id: "furn-2f-crate", x: 14.2, y: 4.0, z: 3.5, w: 2.2, h: 1.4, d: 2.2, kind: "crate", style: "crate", material: "wood" },

    { id: "yard-fountain-rim", x: 0, y: 0, z: 27, w: 5.4, h: 1.25, d: 5.4, kind: "barrier", style: "mansion-wall", material: "stone" },
    { id: "yard-van-body", x: -14, y: 0, z: 31.5, w: 6.8, h: 2.7, d: 3.1, kind: "building", style: "container-slate", material: "metal" },
    { id: "yard-van-cab", x: -9.6, y: 0, z: 31.5, w: 2.2, h: 1.9, d: 2.9, kind: "crate", style: "container-slate", material: "metal" },
    { id: "yard-truck-crates", x: 14.5, y: 0, z: 31, w: 3.6, h: 1.75, d: 2.6, kind: "crate", style: "crate", material: "wood" },
    { id: "hedge-w1", x: -32, y: 0, z: 16, w: 2.4, h: 2.4, d: 15, kind: "barrier", style: "hedge", material: "wood" },
    { id: "hedge-w2", x: -36, y: 0, z: -14, w: 2.4, h: 2.4, d: 16, kind: "barrier", style: "hedge", material: "wood" },
    { id: "hedge-w3", x: -46, y: 0, z: 2, w: 8.0, h: 2.0, d: 3.0, kind: "barrier", style: "hedge", material: "wood" },
    { id: "hedge-e1", x: 32, y: 0, z: 16, w: 2.4, h: 2.4, d: 15, kind: "barrier", style: "hedge", material: "wood" },
    { id: "hedge-e2", x: 36, y: 0, z: -15, w: 2.4, h: 2.4, d: 14, kind: "barrier", style: "hedge", material: "wood" },
    { id: "hedge-e3", x: 46, y: 0, z: 4, w: 7.6, h: 2.0, d: 3.0, kind: "barrier", style: "hedge", material: "wood" },
    { id: "north-wall-w", x: -16, y: 0, z: -29, w: 8.5, h: 2.0, d: 1.5, kind: "barrier", style: "mansion-wall", material: "stone" },
    { id: "north-wall-e", x: 14, y: 0, z: -29, w: 8.5, h: 2.0, d: 1.5, kind: "barrier", style: "mansion-wall", material: "stone" },
    { id: "north-crate-c", x: 0, y: 0, z: -25.5, w: 3.2, h: 1.85, d: 2.2, kind: "crate", style: "crate", material: "wood" },
    { id: "gate-pillar-w", x: -24, y: 0, z: 36, w: 3.2, h: 4.4, d: 3.2, kind: "pillar", style: "mansion-wall", material: "stone" },
    { id: "gate-pillar-e", x: 24, y: 0, z: 36, w: 3.2, h: 4.4, d: 3.2, kind: "pillar", style: "mansion-wall", material: "stone" },
  ],
  props: [
    { kind: "fountain", x: 0, y: 0.85, z: 27, scale: 1.15 },
    { kind: "van", x: -13, y: 0, z: 31.5, scale: 1 },
    { kind: "gazebo", x: 38, y: 0, z: 2, scale: 1.1 },
    { kind: "tree", x: -42, y: 0, z: 28, scale: 1.2 },
    { kind: "tree", x: -44, y: 0, z: -24, scale: 1.15 },
    { kind: "tree", x: 42, y: 0, z: 28, scale: 1.2 },
    { kind: "tree", x: 44, y: 0, z: -24, scale: 1.1 },
    { kind: "tree", x: -26, y: 0, z: -32, scale: 1.05 },
    { kind: "tree", x: 28, y: 0, z: -34, scale: 1.15 },
    { kind: "lamp", x: -6.5, y: 0, z: 20, scale: 1 },
    { kind: "lamp", x: 6.5, y: 0, z: 20, scale: 1 },
    { kind: "lamp", x: -7.0, y: 0, z: -18, scale: 1 },
    { kind: "lamp", x: 7.0, y: 0, z: -18, scale: 1 },
  ],
  minimapAccent: "#c8a96e",
};

/**
 * 3. DISTRICT-7: BLOCKLINE (Symmetric 3-lane Arena with Tall Spawn Sightline Shields)
 */
const BLOCKLINE_MAP: FpsMapDef = {
  id: "blockline",
  name: "District-7: Blockline",
  subtitle: "3-Lane Symmetrical Arena · Heaven & Cargo",
  description:
    "Tight 3-lane tactical complex with Mid Clocktower Atrium, elevated A-Heaven & B-Heaven overlooks, and climbable shipping containers.",
  atmosphereTag: "CLEAR DAYLIGHT",
  halfW: ARENA_HALF_W,
  halfD: ARENA_HALF_D,
  skyHex: 0xa9c9e8,
  fogHex: 0xa9c9e8,
  sunHex: 0xfff5e4,
  floorPalette: ["#c9c4ba", "#bcb6ab"],
  vanguardSpawns: [
    { x: -6, y: 0, z: 40, yaw: 0 },
    { x: 6, y: 0, z: 40, yaw: 0 },
    { x: -13, y: 0, z: 41.5, yaw: -0.1 },
    { x: 13, y: 0, z: 41.5, yaw: 0.1 },
  ],
  syndicateSpawns: [
    { x: -6, y: 0, z: -40, yaw: Math.PI },
    { x: 6, y: 0, z: -40, yaw: Math.PI },
    { x: -13, y: 0, z: -41.5, yaw: Math.PI + 0.1 },
    { x: 13, y: 0, z: -41.5, yaw: Math.PI - 0.1 },
  ],
  bombSites: [
    { id: "A", name: "Site A · Reactor Yard", callout: "SITE A (REACTOR)", x: -36, y: 0, z: -2, radius: 6.8 },
    { id: "B", name: "Site B · Cargo Depot", callout: "SITE B (CARGO)", x: 36, y: 0, z: -2, radius: 6.8 },
  ],
  pickups: [
    { id: "med-mid", kind: "medkit", x: 0, y: 0.55, z: 12 },
    { id: "ammo-a", kind: "ammo", x: -36, y: 3.8, z: -15 },
    { id: "med-b", kind: "medkit", x: 36, y: 3.8, z: -15 },
    { id: "ammo-mid", kind: "ammo", x: 0, y: 0.55, z: -12 },
  ],
  callouts: [
    { name: "VANGUARD SPAWN", minX: -26, maxX: 26, minZ: 30, maxZ: 48 },
    { name: "SYNDICATE SPAWN", minX: -26, maxX: 26, minZ: -48, maxZ: -30 },
    { name: "SITE A · REACTOR", minX: -56, maxX: -22, minZ: -14, maxZ: 10 },
    { name: "A-HEAVEN BALCONY", minX: -56, maxX: -22, minZ: -32, maxZ: -14 },
    { name: "A-MAIN CORRIDOR", minX: -56, maxX: -22, minZ: 10, maxZ: 46 },
    { name: "SITE B · CARGO", minX: 22, maxX: 56, minZ: -14, maxZ: 10 },
    { name: "B-HEAVEN OVERLOOK", minX: 22, maxX: 56, minZ: -32, maxZ: -14 },
    { name: "B-TUNNEL APPROACH", minX: 22, maxX: 56, minZ: 10, maxZ: 46 },
    { name: "MID ATRIUM", minX: -22, maxX: 22, minZ: -30, maxZ: 30 },
  ],
  boxes: [
    { id: "wall-n", x: 0, y: 0, z: -ARENA_HALF_D, w: ARENA_HALF_W * 2, h: 10, d: 3, kind: "wall", style: "wall", material: "stone" },
    { id: "wall-s", x: 0, y: 0, z: ARENA_HALF_D, w: ARENA_HALF_W * 2, h: 10, d: 3, kind: "wall", style: "wall", material: "stone" },
    { id: "wall-w", x: -ARENA_HALF_W, y: 0, z: 0, w: 3, h: 10, d: ARENA_HALF_D * 2, kind: "wall", style: "wall", material: "stone" },
    { id: "wall-e", x: ARENA_HALF_W, y: 0, z: 0, w: 3, h: 10, d: ARENA_HALF_D * 2, kind: "wall", style: "wall", material: "stone" },

    { id: "div-w-south", x: -20, y: 0, z: 15, w: 2.6, h: 6.5, d: 18, kind: "building", style: "building", material: "concrete" },
    { id: "div-w-north", x: -20, y: 0, z: -15, w: 2.6, h: 6.5, d: 18, kind: "building", style: "building", material: "concrete" },
    { id: "div-w-arch", x: -20, y: 4.2, z: 0, w: 2.6, h: 2.3, d: 12, kind: "building", style: "arch", material: "concrete" },

    { id: "div-e-south", x: 20, y: 0, z: 15, w: 2.6, h: 6.5, d: 18, kind: "building", style: "building", material: "concrete" },
    { id: "div-e-north", x: 20, y: 0, z: -15, w: 2.6, h: 6.5, d: 18, kind: "building", style: "building", material: "concrete" },
    { id: "div-e-arch", x: 20, y: 4.2, z: 0, w: 2.6, h: 2.3, d: 12, kind: "building", style: "arch", material: "concrete" },

    // Tall spawn sightline shields so teams cannot spot each other immediately on round start
    { id: "vg-wall-l", x: -12, y: 0, z: 31, w: 7.5, h: 4.2, d: 2.0, kind: "building", style: "concrete", material: "concrete" },
    { id: "vg-wall-r", x: 12, y: 0, z: 31, w: 7.5, h: 4.2, d: 2.0, kind: "building", style: "concrete", material: "concrete" },
    { id: "vg-crate-c", x: 0, y: 0, z: 26, w: 14.4, h: 3.2, d: 2.2, kind: "building", style: "concrete", material: "concrete" },
    { id: "vg-tower-l", x: -26, y: 0, z: 42, w: 5, h: 8, d: 5, kind: "building", style: "container-amber", material: "metal" },
    { id: "vg-tower-r", x: 26, y: 0, z: 42, w: 5, h: 8, d: 5, kind: "building", style: "container-amber", material: "metal" },

    { id: "sy-wall-l", x: -12, y: 0, z: -31, w: 7.5, h: 4.2, d: 2.0, kind: "building", style: "concrete", material: "concrete" },
    { id: "sy-wall-r", x: 12, y: 0, z: -31, w: 7.5, h: 4.2, d: 2.0, kind: "building", style: "concrete", material: "concrete" },
    { id: "sy-crate-c", x: 0, y: 0, z: -26, w: 14.4, h: 3.2, d: 2.2, kind: "building", style: "concrete", material: "concrete" },
    { id: "sy-tower-l", x: -26, y: 0, z: -42, w: 5, h: 8, d: 5, kind: "building", style: "container-blue", material: "metal" },
    { id: "sy-tower-r", x: 26, y: 0, z: -42, w: 5, h: 8, d: 5, kind: "building", style: "container-blue", material: "metal" },

    { id: "mid-plaza-base", x: 0, y: 0, z: 0, w: 12, h: 0.7, d: 12, kind: "platform", style: "platform", material: "concrete" },
    { id: "mid-obelisk", x: 0, y: 0.7, z: 0, w: 3.4, h: 8.5, d: 3.4, kind: "pillar", style: "pillar", material: "stone" },
    { id: "mid-cov-sw", x: -8.5, y: 0, z: 12, w: 4.2, h: 1.45, d: 1.5, kind: "barrier", style: "barrier", material: "concrete" },
    { id: "mid-cov-se", x: 8.5, y: 0, z: 12, w: 4.2, h: 1.45, d: 1.5, kind: "barrier", style: "barrier", material: "concrete" },
    { id: "mid-cov-nw", x: -8.5, y: 0, z: -12, w: 4.2, h: 1.45, d: 1.5, kind: "barrier", style: "barrier", material: "concrete" },
    { id: "mid-cov-ne", x: 8.5, y: 0, z: -12, w: 4.2, h: 1.45, d: 1.5, kind: "barrier", style: "barrier", material: "concrete" },
    { id: "mid-crate-w", x: -13, y: 0, z: 0, w: 2.4, h: 2.0, d: 2.4, kind: "crate", style: "crate", material: "wood" },
    { id: "mid-crate-e", x: 13, y: 0, z: 0, w: 2.4, h: 2.0, d: 2.4, kind: "crate", style: "crate", material: "wood" },

    { id: "a-heaven-deck", x: -36, y: 0, z: -18, w: 18, h: 3.2, d: 9, kind: "platform", style: "platform", material: "concrete" },
    { id: "a-heaven-step1", x: -24.5, y: 0, z: -18, w: 2.8, h: 1.1, d: 4.8, kind: "platform", style: "platform", material: "concrete" },
    { id: "a-heaven-step2", x: -26.5, y: 0, z: -18, w: 2.8, h: 2.2, d: 4.8, kind: "platform", style: "platform", material: "concrete" },
    { id: "a-heaven-parapet", x: -36, y: 3.2, z: -13.9, w: 14, h: 1.05, d: 0.7, kind: "barrier", style: "barrier", material: "concrete" },
    { id: "a-reactor-pillar-1", x: -31, y: 0, z: -4, w: 2.2, h: 5.2, d: 2.2, kind: "pillar", style: "pillar", material: "stone" },
    { id: "a-reactor-pillar-2", x: -41, y: 0, z: 2, w: 2.2, h: 5.2, d: 2.2, kind: "pillar", style: "pillar", material: "stone" },
    { id: "a-crate-1", x: -35, y: 0, z: -2, w: 2.4, h: 2.2, d: 2.4, kind: "crate", style: "crate", material: "wood" },
    { id: "a-crate-2", x: -37.5, y: 0, z: -2.2, w: 2.0, h: 1.25, d: 2.0, kind: "crate", style: "crate", material: "wood" },
    { id: "a-main-block", x: -42, y: 0, z: 18, w: 8.5, h: 4.5, d: 5, kind: "building", style: "building", material: "concrete" },
    { id: "a-south-crate", x: -30, y: 0, z: 22, w: 2.4, h: 1.8, d: 2.4, kind: "crate", style: "crate", material: "wood" },
    { id: "a-west-container", x: -50, y: 0, z: -2, w: 4.5, h: 3.6, d: 11, kind: "building", style: "container-slate", material: "metal" },

    { id: "b-heaven-deck", x: 36, y: 0, z: -18, w: 18, h: 3.2, d: 9, kind: "platform", style: "platform", material: "concrete" },
    { id: "b-heaven-step1", x: 24.5, y: 0, z: -18, w: 2.8, h: 1.1, d: 4.8, kind: "platform", style: "platform", material: "concrete" },
    { id: "b-heaven-step2", x: 26.5, y: 0, z: -18, w: 2.8, h: 2.2, d: 4.8, kind: "platform", style: "platform", material: "concrete" },
    { id: "b-heaven-parapet", x: 36, y: 3.2, z: -13.9, w: 14, h: 1.05, d: 0.7, kind: "barrier", style: "barrier", material: "concrete" },
    { id: "b-cont-red", x: 32, y: 0, z: -4, w: 3.8, h: 2.8, d: 8.2, kind: "crate", style: "container-amber", material: "metal" },
    { id: "b-cont-step", x: 32, y: 0, z: 1.2, w: 2.4, h: 1.4, d: 2.4, kind: "crate", style: "crate", material: "wood" },
    { id: "b-cont-blue", x: 43, y: 0, z: 1, w: 3.8, h: 3.2, d: 9.0, kind: "crate", style: "container-blue", material: "metal" },
    { id: "b-crate-site", x: 37, y: 0, z: 3, w: 2.4, h: 1.7, d: 2.4, kind: "crate", style: "crate", material: "wood" },
    { id: "b-tunnel-roof", x: 42, y: 3.8, z: 20, w: 14, h: 0.9, d: 11, kind: "building", style: "arch", material: "concrete" },
    { id: "b-tunnel-wall", x: 48.5, y: 0, z: 20, w: 2.0, h: 4.7, d: 11, kind: "building", style: "building", material: "concrete" },
    { id: "b-south-cov", x: 31, y: 0, z: 21, w: 4.5, h: 1.5, d: 1.6, kind: "barrier", style: "barrier", material: "concrete" },
    { id: "b-east-container", x: 51, y: 0, z: -3, w: 4.2, h: 3.6, d: 10, kind: "building", style: "container-slate", material: "metal" },
  ],
  props: [
    { kind: "lamp", x: -16, y: 0, z: 26, scale: 1 },
    { kind: "lamp", x: 16, y: 0, z: -26, scale: 1 },
  ],
  minimapAccent: "#f59e0b",
};

/**
 * 4. CRYO-SECTOR 04: ARCTIC FACILITY
 */
const ARCTIC_FACILITY_MAP: FpsMapDef = {
  id: "arctic-facility",
  name: "Cryo-Sector 04",
  subtitle: "Arctic Research Compound · Turbine Catwalks",
  description:
    "Sub-zero industrial research compound surrounded by glacial drifts, frosted steel containers, dual turbine silos, and raised security catwalks.",
  atmosphereTag: "ARCTIC OVERCAST",
  halfW: ARENA_HALF_W,
  halfD: ARENA_HALF_D,
  skyHex: 0xc5d8ea,
  fogHex: 0xbcd1e5,
  sunHex: 0xeef7ff,
  floorPalette: ["#d6e3f0", "#bfd1e4"],
  vanguardSpawns: [
    { x: -12, y: 0, z: 40, yaw: 0 },
    { x: -4, y: 0, z: 41, yaw: 0 },
    { x: 4, y: 0, z: 41, yaw: 0 },
    { x: 12, y: 0, z: 40, yaw: 0 },
  ],
  syndicateSpawns: [
    { x: -12, y: 0, z: -40, yaw: Math.PI },
    { x: -4, y: 0, z: -41, yaw: Math.PI },
    { x: 4, y: 0, z: -41, yaw: Math.PI },
    { x: 12, y: 0, z: -40, yaw: Math.PI },
  ],
  bombSites: [
    { id: "A", name: "Site A · Cryo Turbine", callout: "SITE A (TURBINE)", x: -35, y: 0, z: -4, radius: 6.4 },
    { id: "B", name: "Site B · Sub-Zero Hangar", callout: "SITE B (HANGAR)", x: 35, y: 0, z: -4, radius: 6.4 },
  ],
  pickups: [
    { id: "arc-med-c", kind: "medkit", x: 0, y: 0.6, z: 0 },
    { id: "arc-ammo-a", kind: "ammo", x: -35, y: 0.6, z: 10 },
    { id: "arc-med-b", kind: "medkit", x: 35, y: 0.6, z: -16 },
    { id: "arc-ammo-n", kind: "ammo", x: 0, y: 0.6, z: -26 },
  ],
  callouts: [
    { name: "CRYO TURBINE (SITE A)", minX: -56, maxX: -18, minZ: -20, maxZ: 16 },
    { name: "HANGAR BAY (SITE B)", minX: 18, maxX: 56, minZ: -20, maxZ: 16 },
    { name: "CORE REACTOR HUB", minX: -18, maxX: 18, minZ: -16, maxZ: 16 },
    { name: "SOUTH SNOW YARD", minX: -48, maxX: 48, minZ: 16, maxZ: 48 },
    { name: "NORTH EXTRACTION", minX: -48, maxX: 48, minZ: -48, maxZ: -16 },
  ],
  boxes: [
    { id: "wall-n", x: 0, y: 0, z: -ARENA_HALF_D, w: ARENA_HALF_W * 2, h: 10, d: 3, kind: "wall", style: "ice-wall", material: "concrete" },
    { id: "wall-s", x: 0, y: 0, z: ARENA_HALF_D, w: ARENA_HALF_W * 2, h: 10, d: 3, kind: "wall", style: "ice-wall", material: "concrete" },
    { id: "wall-w", x: -ARENA_HALF_W, y: 0, z: 0, w: 3, h: 10, d: ARENA_HALF_D * 2, kind: "wall", style: "ice-wall", material: "concrete" },
    { id: "wall-e", x: ARENA_HALF_W, y: 0, z: 0, w: 3, h: 10, d: ARENA_HALF_D * 2, kind: "wall", style: "ice-wall", material: "concrete" },

    { id: "arc-silo-w", x: -16, y: 0, z: 0, w: 5.5, h: 8.5, d: 5.5, kind: "pillar", style: "container-blue", material: "metal" },
    { id: "arc-silo-e", x: 16, y: 0, z: 0, w: 5.5, h: 8.5, d: 5.5, kind: "pillar", style: "container-blue", material: "metal" },
    { id: "arc-deck-n", x: 0, y: 0, z: -20, w: 22, h: 2.4, d: 6.5, kind: "platform", style: "platform", material: "concrete" },
    { id: "arc-step-w1", x: -12.6, y: 0, z: -20, w: 2.5, h: 0.85, d: 4.5, kind: "platform", style: "platform", material: "concrete" },
    { id: "arc-step-w2", x: -10.8, y: 0, z: -20, w: 2.5, h: 1.65, d: 4.5, kind: "platform", style: "platform", material: "concrete" },
    { id: "arc-step-e1", x: 12.6, y: 0, z: -20, w: 2.5, h: 0.85, d: 4.5, kind: "platform", style: "platform", material: "concrete" },
    { id: "arc-step-e2", x: 10.8, y: 0, z: -20, w: 2.5, h: 1.65, d: 4.5, kind: "platform", style: "platform", material: "concrete" },

    { id: "arc-a-cont", x: -38, y: 0, z: 4, w: 4.2, h: 3.2, d: 10.5, kind: "building", style: "container-blue", material: "metal" },
    { id: "arc-a-crate", x: -32, y: 0, z: -5, w: 2.4, h: 1.9, d: 2.4, kind: "crate", style: "crate", material: "wood" },
    { id: "arc-a-ice", x: -49, y: 0, z: -10, w: 5.5, h: 4.2, d: 9.0, kind: "building", style: "ice-wall", material: "concrete" },

    { id: "arc-b-cont", x: 38, y: 0, z: 4, w: 4.2, h: 3.2, d: 10.5, kind: "building", style: "container-slate", material: "metal" },
    { id: "arc-b-crate", x: 32, y: 0, z: -5, w: 2.4, h: 1.9, d: 2.4, kind: "crate", style: "crate", material: "wood" },
    { id: "arc-b-roof", x: 42, y: 4.2, z: -12, w: 15, h: 1.0, d: 12, kind: "building", style: "arch", material: "concrete" },
    { id: "arc-b-wall", x: 49, y: 0, z: -12, w: 2.2, h: 5.2, d: 12, kind: "building", style: "building", material: "concrete" },

    // Tall central blast shield blocking direct spawn-to-spawn sightlines
    { id: "arc-mid-1", x: 0, y: 0, z: 12, w: 18.0, h: 3.4, d: 2.2, kind: "building", style: "concrete", material: "concrete" },
    { id: "arc-mid-2", x: -8, y: 0, z: -6, w: 2.5, h: 1.9, d: 2.4, kind: "crate", style: "crate", material: "wood" },
    { id: "arc-mid-3", x: 8, y: 0, z: -6, w: 2.5, h: 1.9, d: 2.4, kind: "crate", style: "crate", material: "wood" },
  ],
  props: [
    { kind: "snowbank", x: -48, y: 0, z: 32, scale: 1.4 },
    { kind: "snowbank", x: 48, y: 0, z: 32, scale: 1.3 },
    { kind: "crane", x: -46, y: 0, z: -32, scale: 1.1 },
    { kind: "crane", x: 46, y: 0, z: -32, scale: 1.1 },
  ],
  minimapAccent: "#38bdf8",
};

export const FPS_MAPS: Record<FpsMapId, FpsMapDef> = {
  "desert-outpost": DESERT_OUTPOST_MAP,
  mansion: MANSION_MAP,
  blockline: BLOCKLINE_MAP,
  "arctic-facility": ARCTIC_FACILITY_MAP,
};

export const FPS_MAP_LIST: FpsMapDef[] = [
  DESERT_OUTPOST_MAP,
  MANSION_MAP,
  BLOCKLINE_MAP,
  ARCTIC_FACILITY_MAP,
];

export function getFpsMapDef(mapId?: string): FpsMapDef {
  if (mapId && mapId in FPS_MAPS) {
    return FPS_MAPS[mapId as FpsMapId];
  }
  return DESERT_OUTPOST_MAP;
}

export const VANGUARD_SPAWNS = DESERT_OUTPOST_MAP.vanguardSpawns;
export const SYNDICATE_SPAWNS = DESERT_OUTPOST_MAP.syndicateSpawns;
export const PLAYER_SPAWNS = VANGUARD_SPAWNS;
export const BOMB_SITES = DESERT_OUTPOST_MAP.bombSites;
export const PICKUP_SPAWNS = DESERT_OUTPOST_MAP.pickups;
export const MAP_CALLOUTS = DESERT_OUTPOST_MAP.callouts;
export const ARENA_BOXES = DESERT_OUTPOST_MAP.boxes;
export const ENEMY_SPAWN_POINTS = SYNDICATE_SPAWNS;

export function getMapCallout(x: number, z: number, mapId: FpsMapId = "desert-outpost"): string {
  const map = getFpsMapDef(mapId);
  for (const c of map.callouts) {
    if (x >= c.minX && x <= c.maxX && z >= c.minZ && z <= c.maxZ) {
      return c.name;
    }
  }
  return `${map.name.toUpperCase()} GROUNDS`;
}

export function resolveCircleBoxCollisions(
  x: number,
  y: number,
  z: number,
  radius: number,
  mapId: FpsMapId = "desert-outpost",
): { x: number; y: number; z: number; floorY: number } {
  const map = getFpsMapDef(mapId);
  let nx = x;
  let nz = z;
  let floorY = 0;

  const boundX = map.halfW - 2.0 - radius;
  const boundZ = map.halfD - 2.0 - radius;
  nx = Math.max(-boundX, Math.min(boundX, nx));
  nz = Math.max(-boundZ, Math.min(boundZ, nz));

  for (const b of map.boxes) {
    if (b.kind === "wall") continue;
    const halfW = b.w * 0.5;
    const halfD = b.d * 0.5;
    const minX = b.x - halfW;
    const maxX = b.x + halfW;
    const minZ = b.z - halfD;
    const maxZ = b.z + halfD;
    const topY = b.y + b.h;

    if (
      nx >= minX - radius * 0.45 &&
      nx <= maxX + radius * 0.45 &&
      nz >= minZ - radius * 0.45 &&
      nz <= maxZ + radius * 0.45
    ) {
      if (y >= topY - 1.18 && topY > floorY) {
        floorY = topY;
      }
    }

    if (y + 1.68 > b.y && y < topY - 0.58) {
      const closestX = Math.max(minX, Math.min(nx, maxX));
      const closestZ = Math.max(minZ, Math.min(nz, maxZ));
      const dx = nx - closestX;
      const dz = nz - closestZ;
      const distSq = dx * dx + dz * dz;
      if (distSq < radius * radius) {
        const dist = Math.sqrt(distSq);
        if (dist > 0.0001) {
          const push = radius - dist;
          nx += (dx / dist) * push;
          nz += (dz / dist) * push;
        } else {
          const penLeft = Math.abs(nx - minX);
          const penRight = Math.abs(maxX - nx);
          const penTop = Math.abs(nz - minZ);
          const penBottom = Math.abs(maxZ - nz);
          const m = Math.min(penLeft, penRight, penTop, penBottom);
          if (m === penLeft) nx = minX - radius;
          else if (m === penRight) nx = maxX + radius;
          else if (m === penTop) nz = minZ - radius;
          else nz = maxZ + radius;
        }
      }
    }
  }

  return { x: nx, y: Math.max(y, floorY), z: nz, floorY };
}

export function rayIntersectsBoxInterval(
  ox: number,
  oy: number,
  oz: number,
  dx: number,
  dy: number,
  dz: number,
  maxDist: number,
  box: ArenaBox,
): { tEnter: number; tExit: number } | null {
  const minX = box.x - box.w * 0.5;
  const maxX = box.x + box.w * 0.5;
  const minY = box.y;
  const maxY = box.y + box.h;
  const minZ = box.z - box.d * 0.5;
  const maxZ = box.z + box.d * 0.5;

  let tmin = 0;
  let tmax = maxDist;

  const invX = Math.abs(dx) > 1e-8 ? 1 / dx : 1e9;
  const tx1 = (minX - ox) * invX;
  const tx2 = (maxX - ox) * invX;
  tmin = Math.max(tmin, Math.min(tx1, tx2));
  tmax = Math.min(tmax, Math.max(tx1, tx2));

  const invY = Math.abs(dy) > 1e-8 ? 1 / dy : 1e9;
  const ty1 = (minY - oy) * invY;
  const ty2 = (maxY - oy) * invY;
  tmin = Math.max(tmin, Math.min(ty1, ty2));
  tmax = Math.min(tmax, Math.max(ty1, ty2));

  const invZ = Math.abs(dz) > 1e-8 ? 1 / dz : 1e9;
  const tz1 = (minZ - oz) * invZ;
  const tz2 = (maxZ - oz) * invZ;
  tmin = Math.max(tmin, Math.min(tz1, tz2));
  tmax = Math.min(tmax, Math.max(tz1, tz2));

  if (tmax >= tmin && tmax > 0.001 && tmin <= maxDist) {
    return { tEnter: Math.max(0.001, tmin), tExit: Math.min(maxDist, tmax) };
  }
  return null;
}

export function rayIntersectsBox(
  ox: number,
  oy: number,
  oz: number,
  dx: number,
  dy: number,
  dz: number,
  maxDist: number,
  box: ArenaBox,
): number | null {
  const hit = rayIntersectsBoxInterval(ox, oy, oz, dx, dy, dz, maxDist, box);
  return hit ? hit.tEnter : null;
}

export function raycastArenaObstacles(
  ox: number,
  oy: number,
  oz: number,
  dx: number,
  dy: number,
  dz: number,
  maxDist: number,
  mapId: FpsMapId = "desert-outpost",
): number {
  const map = getFpsMapDef(mapId);
  let closest = maxDist;
  for (const box of map.boxes) {
    const t = rayIntersectsBox(ox, oy, oz, dx, dy, dz, closest, box);
    if (t !== null && t < closest) {
      closest = t;
    }
  }
  if (dy < -0.001 && oy > 0) {
    const tGround = -oy / dy;
    if (tGround > 0 && tGround < closest) closest = tGround;
  }
  return closest;
}

export interface BulletPenetrationStep {
  boxId: string;
  material: BoxMaterialType;
  thickness: number;
  tEnter: number;
  tExit: number;
  cumulativeDamageMult: number;
}

export interface BulletTraceResult {
  endDist: number;
  stoppedAtSolid: boolean;
  penetrations: BulletPenetrationStep[];
}

export const MAX_BULLET_PENETRATIONS = 2;

/**
 * Traces a bullet ray through arena obstacles with material-based penetration:
 * - Solid stone, concrete, and metal surfaces stop bullets immediately.
 * - Penetrable wooden objects (doors, crates, barricades) allow up to 2 penetrations
 *   with thickness- and weapon-power-dependent damage reduction.
 */
export function traceBulletPath(
  ox: number,
  oy: number,
  oz: number,
  dx: number,
  dy: number,
  dz: number,
  maxDist: number,
  mapId: FpsMapId,
  weaponPenetrationPower: number,
): BulletTraceResult {
  const map = getFpsMapDef(mapId);

  let effectiveMax = maxDist;
  if (dy < -0.001 && oy > 0) {
    const tGround = -oy / dy;
    if (tGround > 0 && tGround < effectiveMax) effectiveMax = tGround;
  }

  const hits: {
    box: ArenaBox;
    material: BoxMaterialType;
    tEnter: number;
    tExit: number;
  }[] = [];

  for (const box of map.boxes) {
    const interval = rayIntersectsBoxInterval(ox, oy, oz, dx, dy, dz, effectiveMax, box);
    if (interval) {
      hits.push({
        box,
        material: getBoxMaterial(box),
        tEnter: interval.tEnter,
        tExit: interval.tExit,
      });
    }
  }

  hits.sort((a, b) => a.tEnter - b.tEnter);

  const penetrations: BulletPenetrationStep[] = [];
  let cumulativeMult = 1.0;

  for (const h of hits) {
    if (h.tEnter >= effectiveMax) break;
    const matProps = MATERIAL_PROPERTIES[h.material];
    const thickness = Math.max(0.05, h.tExit - h.tEnter);
    const maxThickAllowed =
      matProps.maxThickness * Math.min(1.2, Math.max(0.42, weaponPenetrationPower));

    if (
      !matProps.penetrable ||
      weaponPenetrationPower <= 0 ||
      penetrations.length >= MAX_BULLET_PENETRATIONS ||
      thickness > maxThickAllowed
    ) {
      return {
        endDist: h.tEnter,
        stoppedAtSolid: true,
        penetrations,
      };
    }

    const atten = Math.exp(
      -(thickness * matProps.thicknessDecayPerMeter) / Math.max(0.32, weaponPenetrationPower),
    );
    const stepMult = Math.max(0.24, Math.min(0.88, matProps.baseDamageMult * atten));
    cumulativeMult *= stepMult;

    if (cumulativeMult < 0.16) {
      return {
        endDist: h.tEnter,
        stoppedAtSolid: true,
        penetrations,
      };
    }

    penetrations.push({
      boxId: h.box.id,
      material: h.material,
      thickness,
      tEnter: h.tEnter,
      tExit: h.tExit,
      cumulativeDamageMult: cumulativeMult,
    });
  }

  return {
    endDist: effectiveMax,
    stoppedAtSolid: effectiveMax < maxDist - 0.05,
    penetrations,
  };
}

export function getDamageMultAtDistance(
  trace: BulletTraceResult,
  targetDist: number,
): { blocked: boolean; mult: number; penetratedCount: number } {
  if (targetDist > trace.endDist) {
    return { blocked: true, mult: 0, penetratedCount: 0 };
  }
  let mult = 1.0;
  let penetratedCount = 0;
  for (const p of trace.penetrations) {
    if (p.tEnter < targetDist) {
      mult = p.cumulativeDamageMult;
      penetratedCount += 1;
    }
  }
  return { blocked: false, mult, penetratedCount };
}
