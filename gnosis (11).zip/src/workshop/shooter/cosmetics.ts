import { useSyncExternalStore } from "react";
import * as THREE from "three";
import type { WeaponId } from "./weapons";

export type SkinRarity = "Standard" | "Spec" | "Classified" | "Exotic" | "Mythic";

export type WeaponSkinId =
  | "standard"
  | "neon-pulse"
  | "cyberpunk-edge"
  | "forged-carbon"
  | "sovereign-gold"
  | "liquid-chrome"
  | "arctic-frost"
  | "dune-tactical"
  | "stealth-ops"
  | "glitch-matrix"
  | "prism-abstract"
  | "foundry-hazard"
  | "aether-futurist"
  | "obsidian-minimal";

export interface WeaponSkinSpec {
  id: WeaponSkinId;
  name: string;
  rarity: SkinRarity;
  themeLabel: string;
  baseHex: string;
  secondaryHex: string;
  accentHex: string;
  pattern:
    | "solid"
    | "neon-grid"
    | "cyber-circuit"
    | "carbon-weave"
    | "gold-filigree"
    | "chrome-mirror"
    | "arctic-camo"
    | "desert-camo"
    | "tactical-stripe"
    | "glitch-scan"
    | "abstract-shards"
    | "industrial-hazard"
    | "futurist-hex"
    | "minimal-split";
  metalness: number;
  roughness: number;
  clearcoat: number;
  emissiveIntensity: number;
  previewSwatches: [string, string, string];
}

export type KnifeModelId =
  | "karambit-aether"
  | "bowie-vanguard"
  | "butterfly-chronos"
  | "kunai-obsidian"
  | "kukri-solstice"
  | "dagger-rail";

export interface KnifeSpec {
  id: KnifeModelId;
  name: string;
  rarity: SkinRarity;
  silhouette: string;
  bladeLengthCm: number;
  drawStyle: string;
  defaultEdgeHex: number;
  gripHex: number;
  lore: string;
}

export interface OperativeCustomization {
  visorHex: string;
  armorTrimHex: string;
  gloveHex: string;
  badgeTag: string;
}

export interface FpsCosmeticsState {
  equippedSkins: Record<WeaponId, WeaponSkinId>;
  equippedKnife: KnifeModelId;
  operative: OperativeCustomization;
}

export const WEAPON_SKINS: WeaponSkinSpec[] = [
  {
    id: "standard",
    name: "Factory Ordnance",
    rarity: "Standard",
    themeLabel: "Mil-Spec Matte",
    baseHex: "#2d333d",
    secondaryHex: "#1c2027",
    accentHex: "#d6943c",
    pattern: "solid",
    metalness: 0.62,
    roughness: 0.44,
    clearcoat: 0.1,
    emissiveIntensity: 0.05,
    previewSwatches: ["#2d333d", "#1c2027", "#d6943c"],
  },
  {
    id: "neon-pulse",
    name: "Hyperdrive Neon",
    rarity: "Exotic",
    themeLabel: "Neon",
    baseHex: "#131726",
    secondaryHex: "#202744",
    accentHex: "#00f0ff",
    pattern: "neon-grid",
    metalness: 0.55,
    roughness: 0.28,
    clearcoat: 0.65,
    emissiveIntensity: 0.72,
    previewSwatches: ["#131726", "#ff2a9d", "#00f0ff"],
  },
  {
    id: "cyberpunk-edge",
    name: "Nightgrid 2099",
    rarity: "Exotic",
    themeLabel: "Cyberpunk",
    baseHex: "#1b1426",
    secondaryHex: "#311847",
    accentHex: "#ffe600",
    pattern: "cyber-circuit",
    metalness: 0.68,
    roughness: 0.3,
    clearcoat: 0.5,
    emissiveIntensity: 0.58,
    previewSwatches: ["#1b1426", "#ff2975", "#ffe600"],
  },
  {
    id: "forged-carbon",
    name: "Carbon Aero Weave",
    rarity: "Classified",
    themeLabel: "Carbon",
    baseHex: "#1a1d22",
    secondaryHex: "#2a2f38",
    accentHex: "#ff4f38",
    pattern: "carbon-weave",
    metalness: 0.48,
    roughness: 0.34,
    clearcoat: 0.72,
    emissiveIntensity: 0.18,
    previewSwatches: ["#1a1d22", "#353b46", "#ff4f38"],
  },
  {
    id: "sovereign-gold",
    name: "Sovereign Bullion",
    rarity: "Mythic",
    themeLabel: "Gold",
    baseHex: "#d4a438",
    secondaryHex: "#8c6518",
    accentHex: "#fff2b3",
    pattern: "gold-filigree",
    metalness: 0.94,
    roughness: 0.16,
    clearcoat: 0.85,
    emissiveIntensity: 0.16,
    previewSwatches: ["#d4a438", "#8c6518", "#fff2b3"],
  },
  {
    id: "liquid-chrome",
    name: "Quicksilver Mirror",
    rarity: "Classified",
    themeLabel: "Chrome",
    baseHex: "#dce3ec",
    secondaryHex: "#9aa6b8",
    accentHex: "#5ec2ff",
    pattern: "chrome-mirror",
    metalness: 0.96,
    roughness: 0.1,
    clearcoat: 0.95,
    emissiveIntensity: 0.12,
    previewSwatches: ["#dce3ec", "#9aa6b8", "#5ec2ff"],
  },
  {
    id: "arctic-frost",
    name: "Permafrost Vector",
    rarity: "Spec",
    themeLabel: "Arctic",
    baseHex: "#e4edf5",
    secondaryHex: "#9ab3c9",
    accentHex: "#31b7ff",
    pattern: "arctic-camo",
    metalness: 0.35,
    roughness: 0.46,
    clearcoat: 0.3,
    emissiveIntensity: 0.22,
    previewSwatches: ["#e4edf5", "#9ab3c9", "#31b7ff"],
  },
  {
    id: "dune-tactical",
    name: "Sirocco Sandstorm",
    rarity: "Spec",
    themeLabel: "Desert",
    baseHex: "#c9ae82",
    secondaryHex: "#8d714a",
    accentHex: "#e67f2e",
    pattern: "desert-camo",
    metalness: 0.25,
    roughness: 0.64,
    clearcoat: 0.08,
    emissiveIntensity: 0.06,
    previewSwatches: ["#c9ae82", "#8d714a", "#e67f2e"],
  },
  {
    id: "stealth-ops",
    name: "Blackout Division",
    rarity: "Spec",
    themeLabel: "Tactical",
    baseHex: "#242a26",
    secondaryHex: "#39443a",
    accentHex: "#8bd450",
    pattern: "tactical-stripe",
    metalness: 0.42,
    roughness: 0.52,
    clearcoat: 0.12,
    emissiveIntensity: 0.24,
    previewSwatches: ["#242a26", "#39443a", "#8bd450"],
  },
  {
    id: "glitch-matrix",
    name: "Desync Packet",
    rarity: "Mythic",
    themeLabel: "Glitch",
    baseHex: "#10131a",
    secondaryHex: "#2b1638",
    accentHex: "#36ff9f",
    pattern: "glitch-scan",
    metalness: 0.62,
    roughness: 0.26,
    clearcoat: 0.6,
    emissiveIntensity: 0.78,
    previewSwatches: ["#10131a", "#ff2667", "#36ff9f"],
  },
  {
    id: "prism-abstract",
    name: "Bauhaus Facet",
    rarity: "Classified",
    themeLabel: "Abstract",
    baseHex: "#222938",
    secondaryHex: "#f05a4f",
    accentHex: "#f8c946",
    pattern: "abstract-shards",
    metalness: 0.44,
    roughness: 0.36,
    clearcoat: 0.55,
    emissiveIntensity: 0.22,
    previewSwatches: ["#222938", "#f05a4f", "#f8c946"],
  },
  {
    id: "foundry-hazard",
    name: "Sector-7 Caution",
    rarity: "Spec",
    themeLabel: "Industrial",
    baseHex: "#3a3f46",
    secondaryHex: "#eab308",
    accentHex: "#f97316",
    pattern: "industrial-hazard",
    metalness: 0.64,
    roughness: 0.42,
    clearcoat: 0.22,
    emissiveIntensity: 0.14,
    previewSwatches: ["#3a3f46", "#eab308", "#f97316"],
  },
  {
    id: "aether-futurist",
    name: "Helios Prototype",
    rarity: "Mythic",
    themeLabel: "Futuristic",
    baseHex: "#f2f5fa",
    secondaryHex: "#323d4f",
    accentHex: "#4de1ff",
    pattern: "futurist-hex",
    metalness: 0.74,
    roughness: 0.2,
    clearcoat: 0.88,
    emissiveIntensity: 0.64,
    previewSwatches: ["#f2f5fa", "#323d4f", "#4de1ff"],
  },
  {
    id: "obsidian-minimal",
    name: "Monolith Zero",
    rarity: "Classified",
    themeLabel: "Minimalist",
    baseHex: "#15171c",
    secondaryHex: "#e6e8ed",
    accentHex: "#ef4444",
    pattern: "minimal-split",
    metalness: 0.5,
    roughness: 0.28,
    clearcoat: 0.65,
    emissiveIntensity: 0.28,
    previewSwatches: ["#15171c", "#e6e8ed", "#ef4444"],
  },
];

export const WEAPON_SKINS_BY_ID: Record<WeaponSkinId, WeaponSkinSpec> = Object.fromEntries(
  WEAPON_SKINS.map((s) => [s.id, s]),
) as Record<WeaponSkinId, WeaponSkinSpec>;

export const KNIFE_LIST: KnifeSpec[] = [
  {
    id: "karambit-aether",
    name: "Aether Claw Karambit",
    rarity: "Mythic",
    silhouette: "Curved talon blade with finger ring",
    bladeLengthCm: 19,
    drawStyle: "Reverse ring spin",
    defaultEdgeHex: 0x45e3ff,
    gripHex: 0x1e2430,
    lore: "Signature curved talon knife spun into reverse grip with plasma-honed inner bevel.",
  },
  {
    id: "bowie-vanguard",
    name: "Vanguard Clip Bowie",
    rarity: "Exotic",
    silhouette: "Heavy clip-point survival blade",
    bladeLengthCm: 28,
    drawStyle: "Heavy shoulder sweep",
    defaultEdgeHex: 0xf4a63a,
    gripHex: 0x2b2520,
    lore: "Full-tang combat Bowie with aggressive sawback spine and brass handguard.",
  },
  {
    id: "butterfly-chronos",
    name: "Chronos Balisong",
    rarity: "Mythic",
    silhouette: "Split-channel twin-handle balisong",
    bladeLengthCm: 23,
    drawStyle: "Twin-handle aerial flip",
    defaultEdgeHex: 0xc084fc,
    gripHex: 0x1c1e28,
    lore: "Precision titanium butterfly knife balanced for continuous aerial wrist flourishes.",
  },
  {
    id: "kunai-obsidian",
    name: "Wraith Shadow Kunai",
    rarity: "Classified",
    silhouette: "Symmetrical diamond throwing spear",
    bladeLengthCm: 22,
    drawStyle: "Index-ring twirl",
    defaultEdgeHex: 0xef4444,
    gripHex: 0x16181e,
    lore: "Cord-wrapped recon kunai balanced around an oversized pommel spin ring.",
  },
  {
    id: "kukri-solstice",
    name: "Solstice Forward Kukri",
    rarity: "Exotic",
    silhouette: "Forward-weighted recurve chopper",
    bladeLengthCm: 27,
    drawStyle: "Low arc cleave",
    defaultEdgeHex: 0x34d399,
    gripHex: 0x2a241d,
    lore: "Forward-swept recurve blade delivering unmistakable close-range impact silhouette.",
  },
  {
    id: "dagger-rail",
    name: "Vector Stiletto",
    rarity: "Classified",
    silhouette: "Needle-point twin-fuller stiletto",
    bladeLengthCm: 21,
    drawStyle: "Crisp palm roll",
    defaultEdgeHex: 0xe2e8f0,
    gripHex: 0x1f2633,
    lore: "Minimalist diamond-ground dagger forged from ultra-clean stainless alloy.",
  },
];

export const KNIVES_BY_ID: Record<KnifeModelId, KnifeSpec> = Object.fromEntries(
  KNIFE_LIST.map((k) => [k.id, k]),
) as Record<KnifeModelId, KnifeSpec>;

export const VISOR_PALETTE = [
  { name: "Team Default", hex: "#4cc4ff" },
  { name: "Vanguard Amber", hex: "#f59e0b" },
  { name: "Hyper Cyan", hex: "#22d3ee" },
  { name: "Crimson Optic", hex: "#f43f5e" },
  { name: "Emerald NVG", hex: "#34d399" },
  { name: "Royal Violet", hex: "#a78bfa" },
  { name: "Solar Gold", hex: "#fde047" },
];

export const TRIM_PALETTE = [
  { name: "Obsidian Slate", hex: "#28303d" },
  { name: "Carbon Titanium", hex: "#3f4754" },
  { name: "Sandstone Tan", hex: "#a68b67" },
  { name: "Arctic Pearl", hex: "#d9e2ec" },
  { name: "Hazard Copper", hex: "#c2612b" },
  { name: "Forest Olive", hex: "#3d4d3a" },
];

const COSMETICS_STORAGE_KEY = "gnosis-fps-cosmetics-v1";

const DEFAULT_COSMETICS: FpsCosmeticsState = {
  equippedSkins: {
    starter_pistol: "standard",
    carbine: "cyberpunk-edge",
    smg: "neon-pulse",
    shotgun: "foundry-hazard",
    pistol: "sovereign-gold",
    sniper: "aether-futurist",
    knife: "glitch-matrix",
  },
  equippedKnife: "karambit-aether",
  operative: {
    visorHex: "#4cc4ff",
    armorTrimHex: "#28303d",
    gloveHex: "#1d222b",
    badgeTag: "GNS",
  },
};

function loadCosmetics(): FpsCosmeticsState {
  if (typeof window === "undefined") return structuredClone(DEFAULT_COSMETICS);
  try {
    const raw = window.localStorage.getItem(COSMETICS_STORAGE_KEY);
    if (!raw) return structuredClone(DEFAULT_COSMETICS);
    const parsed = JSON.parse(raw) as Partial<FpsCosmeticsState>;
    const equippedSkins = { ...DEFAULT_COSMETICS.equippedSkins };
    if (parsed.equippedSkins && typeof parsed.equippedSkins === "object") {
      for (const k of Object.keys(equippedSkins) as WeaponId[]) {
        const candidate = parsed.equippedSkins[k];
        if (candidate && candidate in WEAPON_SKINS_BY_ID) {
          equippedSkins[k] = candidate;
        }
      }
    }
    const equippedKnife =
      parsed.equippedKnife && parsed.equippedKnife in KNIVES_BY_ID
        ? parsed.equippedKnife
        : DEFAULT_COSMETICS.equippedKnife;
    return {
      equippedSkins,
      equippedKnife,
      operative: {
        ...DEFAULT_COSMETICS.operative,
        ...(parsed.operative && typeof parsed.operative === "object" ? parsed.operative : {}),
      },
    };
  } catch {
    return structuredClone(DEFAULT_COSMETICS);
  }
}

let currentCosmetics: FpsCosmeticsState = loadCosmetics();
const cosmeticListeners = new Set<() => void>();

function commitCosmetics() {
  if (typeof window !== "undefined") {
    try {
      window.localStorage.setItem(COSMETICS_STORAGE_KEY, JSON.stringify(currentCosmetics));
    } catch {
      // Ignore storage quota errors
    }
  }
  for (const l of cosmeticListeners) {
    try {
      l();
    } catch {
      // Ignore subscriber errors
    }
  }
}

export function getFpsCosmetics(): FpsCosmeticsState {
  return currentCosmetics;
}

export function setWeaponSkin(weaponId: WeaponId, skinId: WeaponSkinId) {
  currentCosmetics = {
    ...currentCosmetics,
    equippedSkins: {
      ...currentCosmetics.equippedSkins,
      [weaponId]: skinId,
    },
  };
  commitCosmetics();
}

export function applySkinToAllWeapons(skinId: WeaponSkinId) {
  currentCosmetics = {
    ...currentCosmetics,
    equippedSkins: {
      starter_pistol: skinId,
      carbine: skinId,
      smg: skinId,
      shotgun: skinId,
      pistol: skinId,
      sniper: skinId,
      knife: skinId,
    },
  };
  commitCosmetics();
}

export function setEquippedKnife(knifeId: KnifeModelId) {
  currentCosmetics = {
    ...currentCosmetics,
    equippedKnife: knifeId,
  };
  commitCosmetics();
}

export function updateOperativeCustomization(patch: Partial<OperativeCustomization>) {
  currentCosmetics = {
    ...currentCosmetics,
    operative: {
      ...currentCosmetics.operative,
      ...patch,
    },
  };
  commitCosmetics();
}

export function useFpsCosmetics(): FpsCosmeticsState {
  return useSyncExternalStore(
    (l) => {
      cosmeticListeners.add(l);
      return () => cosmeticListeners.delete(l);
    },
    getFpsCosmetics,
    getFpsCosmetics,
  );
}

/**
 * Generates high-contrast procedural PBR surface textures for any of the 14 weapon/knife skins
 * so every finish visibly transforms the 3D receiver, slide, barrel shroud, and blade.
 */
export function createWeaponSkinTexture(skinId: WeaponSkinId): THREE.CanvasTexture {
  const skin = WEAPON_SKINS_BY_ID[skinId] || WEAPON_SKINS_BY_ID.standard;
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext("2d")!;

  ctx.fillStyle = skin.baseHex;
  ctx.fillRect(0, 0, 256, 256);

  switch (skin.pattern) {
    case "neon-grid": {
      const grad = ctx.createLinearGradient(0, 0, 256, 256);
      grad.addColorStop(0, "#121629");
      grad.addColorStop(0.55, "#28144a");
      grad.addColorStop(1, "#092d40");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 256, 256);
      ctx.strokeStyle = skin.accentHex;
      ctx.lineWidth = 3;
      for (let i = 0; i <= 256; i += 32) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i, 256);
        ctx.moveTo(0, i);
        ctx.lineTo(256, i);
        ctx.stroke();
      }
      ctx.fillStyle = "#ff2a9d";
      ctx.fillRect(0, 114, 256, 24);
      break;
    }
    case "cyber-circuit": {
      ctx.fillStyle = skin.baseHex;
      ctx.fillRect(0, 0, 256, 256);
      ctx.fillStyle = skin.secondaryHex;
      for (let y = 0; y < 256; y += 64) {
        ctx.fillRect(0, y, 256, 28);
      }
      ctx.strokeStyle = "#ff2975";
      ctx.lineWidth = 5;
      for (let i = 0; i < 8; i++) {
        const y = i * 32 + 12;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(90 + (i % 3) * 28, y);
        ctx.lineTo(130 + (i % 3) * 28, y + 18);
        ctx.lineTo(256, y + 18);
        ctx.stroke();
      }
      ctx.fillStyle = skin.accentHex;
      ctx.fillRect(0, 96, 256, 12);
      ctx.fillRect(0, 180, 256, 8);
      break;
    }
    case "carbon-weave": {
      for (let y = 0; y < 256; y += 16) {
        for (let x = 0; x < 256; x += 16) {
          const alt = ((x + y) / 16) % 2 === 0;
          ctx.fillStyle = alt ? "#181b21" : "#2c313b";
          ctx.fillRect(x, y, 16, 16);
          ctx.fillStyle = alt ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.22)";
          ctx.fillRect(x + 2, y + 2, 12, 4);
        }
      }
      ctx.fillStyle = skin.accentHex;
      ctx.fillRect(0, 116, 256, 10);
      break;
    }
    case "gold-filigree": {
      const g = ctx.createLinearGradient(0, 0, 256, 256);
      g.addColorStop(0, "#f5d77f");
      g.addColorStop(0.5, "#c99628");
      g.addColorStop(1, "#f7dc88");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, 256, 256);
      ctx.strokeStyle = "#7a5310";
      ctx.lineWidth = 6;
      for (let i = -256; i < 512; i += 44) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i + 256, 256);
        ctx.stroke();
      }
      break;
    }
    case "chrome-mirror": {
      const g = ctx.createLinearGradient(0, 0, 256, 128);
      g.addColorStop(0, "#f8fafc");
      g.addColorStop(0.35, "#94a3b8");
      g.addColorStop(0.65, "#ffffff");
      g.addColorStop(1, "#64748b");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, 256, 256);
      ctx.fillStyle = skin.accentHex;
      ctx.fillRect(0, 200, 256, 14);
      break;
    }
    case "arctic-camo": {
      ctx.fillStyle = "#e6eef6";
      ctx.fillRect(0, 0, 256, 256);
      const polys = [
        [
          [0, 30],
          [110, 0],
          [150, 86],
          [20, 110],
        ],
        [
          [120, 120],
          [256, 70],
          [256, 210],
          [140, 230],
        ],
        [
          [0, 170],
          [95, 130],
          [130, 256],
          [0, 256],
        ],
      ];
      polys.forEach((pts, idx) => {
        ctx.fillStyle = idx % 2 === 0 ? "#8da5be" : "#b9cadb";
        ctx.beginPath();
        pts.forEach(([px, py], pi) => (pi === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py)));
        ctx.closePath();
        ctx.fill();
      });
      ctx.fillStyle = skin.accentHex;
      ctx.fillRect(0, 118, 256, 9);
      break;
    }
    case "desert-camo": {
      ctx.fillStyle = "#cbb084";
      ctx.fillRect(0, 0, 256, 256);
      for (let i = 0; i < 16; i++) {
        ctx.fillStyle = i % 2 === 0 ? "#9e7c50" : "#6f5434";
        ctx.beginPath();
        ctx.ellipse(
          ((i * 59) % 240) + 8,
          ((i * 83) % 240) + 8,
          34,
          16,
          (i % 4) * 0.6,
          0,
          Math.PI * 2,
        );
        ctx.fill();
      }
      ctx.fillStyle = skin.accentHex;
      ctx.fillRect(0, 122, 256, 7);
      break;
    }
    case "tactical-stripe": {
      ctx.fillStyle = "#222925";
      ctx.fillRect(0, 0, 256, 256);
      ctx.fillStyle = "#364239";
      for (let i = -256; i < 512; i += 48) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i + 24, 0);
        ctx.lineTo(i + 150, 256);
        ctx.lineTo(i + 126, 256);
        ctx.closePath();
        ctx.fill();
      }
      ctx.fillStyle = skin.accentHex;
      ctx.fillRect(0, 118, 256, 8);
      break;
    }
    case "glitch-scan": {
      ctx.fillStyle = "#0e1118";
      ctx.fillRect(0, 0, 256, 256);
      const colors = ["#ff2667", "#36ff9f", "#38bdf8", "#a855f7"];
      for (let i = 0; i < 28; i++) {
        ctx.fillStyle = colors[i % colors.length];
        ctx.fillRect(((i * 73) % 180), (i * 19) % 244, 42 + (i % 5) * 20, 7 + (i % 3) * 4);
      }
      break;
    }
    case "abstract-shards": {
      ctx.fillStyle = "#222938";
      ctx.fillRect(0, 0, 256, 256);
      const shardPalette = ["#f05a4f", "#f8c946", "#38bdf8", "#e2e8f0"];
      for (let i = 0; i < 12; i++) {
        ctx.fillStyle = shardPalette[i % shardPalette.length];
        const bx = (i * 53) % 220;
        const by = (i * 71) % 220;
        ctx.beginPath();
        ctx.moveTo(bx, by);
        ctx.lineTo(bx + 76, by + 18);
        ctx.lineTo(bx + 24, by + 84);
        ctx.closePath();
        ctx.fill();
      }
      break;
    }
    case "industrial-hazard": {
      ctx.fillStyle = "#373c44";
      ctx.fillRect(0, 0, 256, 256);
      ctx.fillStyle = "#eab308";
      ctx.fillRect(0, 152, 256, 56);
      ctx.fillStyle = "#17191d";
      for (let i = -128; i < 384; i += 40) {
        ctx.beginPath();
        ctx.moveTo(i, 152);
        ctx.lineTo(i + 20, 152);
        ctx.lineTo(i + 48, 208);
        ctx.lineTo(i + 28, 208);
        ctx.closePath();
        ctx.fill();
      }
      break;
    }
    case "futurist-hex": {
      ctx.fillStyle = "#f2f6fb";
      ctx.fillRect(0, 0, 256, 256);
      ctx.fillStyle = "#293447";
      ctx.fillRect(0, 148, 256, 108);
      ctx.fillStyle = skin.accentHex;
      ctx.fillRect(0, 140, 256, 12);
      ctx.strokeStyle = "rgba(77, 225, 255, 0.45)";
      ctx.lineWidth = 3;
      for (let x = 16; x < 256; x += 48) {
        ctx.strokeRect(x, 28, 28, 80);
      }
      break;
    }
    case "minimal-split": {
      ctx.fillStyle = "#16181e";
      ctx.fillRect(0, 0, 256, 134);
      ctx.fillStyle = "#e8ecf2";
      ctx.fillRect(0, 134, 256, 122);
      ctx.fillStyle = skin.accentHex;
      ctx.fillRect(0, 128, 256, 10);
      break;
    }
    default: {
      ctx.fillStyle = skin.baseHex;
      ctx.fillRect(0, 0, 256, 256);
      ctx.fillStyle = skin.secondaryHex;
      ctx.fillRect(0, 156, 256, 100);
      ctx.fillStyle = skin.accentHex;
      ctx.fillRect(0, 148, 256, 8);
      break;
    }
  }

  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}
