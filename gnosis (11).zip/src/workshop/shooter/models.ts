import * as THREE from "three";
import { disposeSafeHierarchy, loadExternalModel } from "../assets/modelLoader";
import {
  createWeaponSkinTexture,
  KNIVES_BY_ID,
  WEAPON_SKINS_BY_ID,
  type KnifeModelId,
  type OperativeCustomization,
  type WeaponSkinId,
} from "./cosmetics";
import {
  getFpsMapDef,
  type FpsMapId,
  type MapPropHint,
} from "./mapData";
import { WEAPONS_BY_ID, type WeaponId } from "./weapons";

const EXTERNAL_WEAPON_MODELS: Record<
  Exclude<WeaponId, "knife">,
  { url: string; targetSize: number; offset: [number, number, number]; muzzleZ: number }
> = {
  carbine: {
    url: "/assets/models/weapons/carbine.glb",
    targetSize: 0.92,
    offset: [0, 0.015, -0.32],
    muzzleZ: -0.78,
  },
  smg: {
    url: "/assets/models/weapons/smg.glb",
    targetSize: 0.64,
    offset: [0, 0.01, -0.24],
    muzzleZ: -0.56,
  },
  shotgun: {
    url: "/assets/models/weapons/shotgun.glb",
    targetSize: 0.96,
    offset: [0, 0.012, -0.38],
    muzzleZ: -0.86,
  },
  starter_pistol: {
    url: "/assets/models/weapons/pistol.glb",
    targetSize: 0.3,
    offset: [0, 0.016, -0.17],
    muzzleZ: -0.33,
  },
  pistol: {
    url: "/assets/models/weapons/pistol.glb",
    targetSize: 0.35,
    offset: [0, 0.018, -0.18],
    muzzleZ: -0.36,
  },
  sniper: {
    url: "/assets/models/weapons/sniper.glb",
    targetSize: 1.24,
    offset: [0, 0.012, -0.45],
    muzzleZ: -1.06,
  },
};

const EXTERNAL_KNIFE_MODELS: Record<KnifeModelId, { url: string; targetSize: number }> = {
  "karambit-aether": { url: "/assets/models/weapons/combat_knife.fbx", targetSize: 0.36 },
  "butterfly-chronos": { url: "/assets/models/weapons/combat_knife.fbx", targetSize: 0.36 },
  "kunai-obsidian": { url: "/assets/models/weapons/knife.glb", targetSize: 0.36 },
  "bowie-vanguard": { url: "/assets/models/weapons/combat_knife.fbx", targetSize: 0.38 },
  "kukri-solstice": { url: "/assets/models/weapons/knife_round.glb", targetSize: 0.37 },
  "dagger-rail": { url: "/assets/models/weapons/knife.glb", targetSize: 0.36 },
};

function applyWeaponSkinToExternalModel(
  root: THREE.Object3D,
  skinId: WeaponSkinId,
  skinTex: THREE.CanvasTexture,
) {
  if (skinId === "standard") {
    root.traverse((c) => {
      if ((c as THREE.Mesh).isMesh) {
        const m = c as THREE.Mesh;
        m.castShadow = true;
        m.receiveShadow = true;
        const mats = Array.isArray(m.material) ? m.material : [m.material];
        for (const orig of mats) {
          if (!orig) continue;
          const nm = (orig.name || "").toLowerCase();
          if (nm.includes("combatknife") && (orig as THREE.MeshStandardMaterial).isMeshStandardMaterial) {
            const std = orig as THREE.MeshStandardMaterial;
            std.map = null;
            std.color.setHex(0x8d96a3);
            std.metalness = 0.78;
            std.roughness = 0.28;
            std.needsUpdate = true;
          }
        }
      }
    });
    return;
  }

  const skin = WEAPON_SKINS_BY_ID[skinId] || WEAPON_SKINS_BY_ID.standard;
  const skinMat = new THREE.MeshPhysicalMaterial({
    map: skinTex,
    color: 0xffffff,
    metalness: skin.metalness,
    roughness: skin.roughness,
    clearcoat: skin.clearcoat,
    emissive: new THREE.Color(skin.accentHex),
    emissiveIntensity: skin.emissiveIntensity * 0.34,
  });

  root.traverse((child) => {
    if (!(child as THREE.Mesh).isMesh) return;
    const mesh = child as THREE.Mesh;
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
    const nextMats = mats.map((orig) => {
      if (!orig) return orig;
      const nm = (orig.name || "").toLowerCase();
      // Preserve dark furniture/grip/optics while wrapping main receiver/slide/blade in active skin
      if (nm.includes("glass") || nm.includes("black") || nm === "dark") {
        if ((orig as THREE.MeshStandardMaterial).isMeshStandardMaterial) {
          const s = orig as THREE.MeshStandardMaterial;
          s.roughness = nm.includes("glass") ? 0.08 : 0.42;
          s.metalness = nm.includes("glass") ? 0.25 : 0.65;
        }
        return orig;
      }
      orig.dispose();
      return skinMat.clone();
    });
    mesh.material = Array.isArray(mesh.material) ? nextMats : nextMats[0];
  });
  skinMat.dispose();
}

export type TeamId = "vanguard" | "syndicate";

export interface ArenaBundle {
  siteBeacons: { id: "A" | "B"; ring: THREE.Mesh; core: THREE.Mesh }[];
  pickupMeshes: Map<string, THREE.Group>;
  reactorCoreMesh: THREE.Mesh | null;
  fountainWaterMesh: THREE.Mesh | null;
  chargeGroup: THREE.Group;
  chargeCore: THREE.Mesh;
  chargeRing: THREE.Mesh;
  dispose: () => void;
}

export interface DetailedWeaponBundle {
  group: THREE.Group;
  muzzleFlash: THREE.Mesh;
  boltOrSlide?: THREE.Object3D;
  magMesh?: THREE.Object3D;
  bladePivot?: THREE.Object3D;
}

function createThemedFloorTexture(
  c1: string,
  c2: string,
  mapId: FpsMapId,
  maxAnisotropy: number,
): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 512;
  c.height = 512;
  const ctx = c.getContext("2d")!;

  ctx.fillStyle = c1;
  ctx.fillRect(0, 0, 512, 512);

  if (mapId === "mansion") {
    // Rich manor lawn grass blades + manicured courtyard stone diamond pattern
    for (let x = 0; x < 512; x += 32) {
      for (let y = 0; y < 512; y += 32) {
        ctx.fillStyle = ((x + y) / 32) % 2 === 0 ? c1 : c2;
        ctx.fillRect(x, y, 32, 32);
        ctx.fillStyle = "rgba(255,255,255,0.03)";
        ctx.fillRect(x + 4, y + 6, 8, 12);
      }
    }
  } else if (mapId === "desert-outpost") {
    // Wind-rippled Sahara/Arabian courtyard sand with warm sandstone cobble seams
    for (let y = 0; y < 512; y += 16) {
      ctx.fillStyle = (y / 16) % 2 === 0 ? c1 : c2;
      ctx.globalAlpha = 0.24;
      ctx.fillRect(0, y, 512, 8);
    }
    ctx.globalAlpha = 1;
    for (let gx = 0; gx < 8; gx++) {
      for (let gy = 0; gy < 8; gy++) {
        ctx.strokeStyle = "rgba(110, 78, 42, 0.14)";
        ctx.lineWidth = 2;
        ctx.strokeRect(gx * 64 + 1, gy * 64 + 1, 62, 62);
        ctx.fillStyle = "rgba(255, 240, 210, 0.08)";
        ctx.fillRect(gx * 64 + 4, gy * 64 + 4, 54, 4);
      }
    }
  } else {
    for (let gx = 0; gx < 8; gx++) {
      for (let gy = 0; gy < 8; gy++) {
        ctx.fillStyle = (gx + gy) % 2 === 0 ? c1 : c2;
        ctx.fillRect(gx * 64 + 2, gy * 64 + 2, 60, 60);
        ctx.fillStyle = "rgba(255,255,255,0.14)";
        ctx.fillRect(gx * 64 + 4, gy * 64 + 4, 56, 3);
        ctx.fillStyle = "rgba(20,25,35,0.12)";
        ctx.fillRect(gx * 64 + 4, gy * 64 + 58, 56, 3);
      }
    }
  }

  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(16, 13);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createStuddedWallTexture(
  baseHex: string,
  trimHex: string,
  maxAnisotropy: number,
): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext("2d")!;

  ctx.fillStyle = baseHex;
  ctx.fillRect(0, 0, 256, 256);

  for (let row = 0; row < 4; row++) {
    const y = row * 64;
    const offset = (row % 2) * 64;
    for (let col = -1; col < 3; col++) {
      const x = col * 128 + offset;
      ctx.fillStyle = "rgba(255,255,255,0.06)";
      ctx.fillRect(x + 3, y + 3, 122, 6);
      ctx.fillStyle = "rgba(0,0,0,0.14)";
      ctx.fillRect(x + 3, y + 57, 122, 4);
      ctx.strokeStyle = trimHex;
      ctx.lineWidth = 2;
      ctx.strokeRect(x + 1, y + 1, 126, 62);
    }
  }

  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createMansionStuccoBrickTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = "#d8ccb8";
  ctx.fillRect(0, 0, 256, 256);

  // Subtle heritage masonry courses & wainscotting trim band at bottom
  ctx.fillStyle = "#b8ab96";
  for (let row = 0; row < 8; row++) {
    const y = row * 32;
    ctx.fillRect(0, y, 256, 2);
    const off = (row % 2) * 32;
    for (let x = off; x < 256; x += 64) {
      ctx.fillRect(x, y, 2, 32);
    }
  }
  ctx.fillStyle = "#694d36";
  ctx.fillRect(0, 224, 256, 32);

  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createParquetWoodTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = "#7a5230";
  ctx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 8; i++) {
    ctx.fillStyle = i % 2 === 0 ? "#855a36" : "#6c4627";
    ctx.fillRect(0, i * 32, 256, 30);
    ctx.fillStyle = "rgba(0,0,0,0.18)";
    ctx.fillRect(0, i * 32 + 30, 256, 2);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(6, 6);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createSandstoneTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = "#d5b584";
  ctx.fillRect(0, 0, 256, 256);

  // Stucco sandstone masonry blocks + warm terracotta base plinth
  for (let row = 0; row < 6; row++) {
    const y = row * 40;
    const off = (row % 2) * 32;
    for (let x = -32; x < 256; x += 64) {
      ctx.fillStyle = (row + Math.floor(x / 64)) % 2 === 0 ? "#d9ba8b" : "#caa571";
      ctx.fillRect(x + off + 2, y + 2, 60, 36);
      ctx.fillStyle = "rgba(255,244,220,0.12)";
      ctx.fillRect(x + off + 3, y + 3, 58, 4);
      ctx.fillStyle = "rgba(95,68,38,0.16)";
      ctx.fillRect(x + off + 2, y + 35, 60, 3);
    }
  }
  ctx.fillStyle = "#b08654";
  ctx.fillRect(0, 232, 256, 24);

  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createWoodDoorTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = "#7a4e28";
  ctx.fillRect(0, 0, 256, 256);

  for (let col = 0; col < 6; col++) {
    const x = col * 42 + 4;
    ctx.fillStyle = col % 2 === 0 ? "#8c5b30" : "#734822";
    ctx.fillRect(x, 6, 38, 244);
    ctx.fillStyle = "rgba(0,0,0,0.22)";
    ctx.fillRect(x + 38, 6, 4, 244);
  }
  // Iron reinforcement straps & cross-beam
  ctx.fillStyle = "#2b2f36";
  ctx.fillRect(0, 42, 256, 18);
  ctx.fillRect(0, 196, 256, 18);
  ctx.fillStyle = "#5c391b";
  ctx.fillRect(0, 118, 256, 20);
  ctx.strokeStyle = "#3b2310";
  ctx.lineWidth = 10;
  ctx.strokeRect(5, 5, 246, 246);

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createWoodWallTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = "#916336";
  ctx.fillRect(0, 0, 256, 256);

  for (let row = 0; row < 5; row++) {
    const y = row * 50 + 4;
    ctx.fillStyle = row % 2 === 0 ? "#9d6d3c" : "#80552c";
    ctx.fillRect(4, y, 248, 42);
    ctx.fillStyle = "rgba(45, 25, 10, 0.28)";
    ctx.fillRect(4, y + 42, 248, 4);
  }
  ctx.fillStyle = "#4d3118";
  ctx.fillRect(14, 0, 22, 256);
  ctx.fillRect(220, 0, 22, 256);

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createConcreteTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = "#8a857c";
  ctx.fillRect(0, 0, 256, 256);

  for (let i = 0; i < 4; i++) {
    ctx.fillStyle = i % 2 === 0 ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.06)";
    ctx.fillRect(0, i * 64, 256, 62);
    ctx.fillStyle = "rgba(30,28,25,0.22)";
    ctx.fillRect(0, i * 64 + 62, 256, 2);
  }
  ctx.fillStyle = "#524e47";
  for (let x = 32; x < 256; x += 64) {
    for (let y = 32; y < 256; y += 64) {
      ctx.fillRect(x - 3, y - 3, 6, 6);
    }
  }

  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createCrateTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext("2d")!;

  ctx.fillStyle = "#b5854b";
  ctx.fillRect(0, 0, 256, 256);

  ctx.fillStyle = "#9d6e37";
  for (let i = 0; i < 4; i++) {
    ctx.fillRect(24, 24 + i * 54, 208, 44);
  }

  ctx.strokeStyle = "#5c3f1d";
  ctx.lineWidth = 16;
  ctx.strokeRect(8, 8, 240, 240);

  ctx.beginPath();
  ctx.moveTo(18, 18);
  ctx.lineTo(238, 238);
  ctx.moveTo(238, 18);
  ctx.lineTo(18, 238);
  ctx.strokeStyle = "#7a5328";
  ctx.lineWidth = 14;
  ctx.stroke();

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createContainerTexture(
  mainHex: string,
  ribHex: string,
  maxAnisotropy: number,
): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = mainHex;
  ctx.fillRect(0, 0, 256, 256);

  for (let x = 16; x < 240; x += 24) {
    ctx.fillStyle = ribHex;
    ctx.fillRect(x, 18, 10, 220);
    ctx.fillStyle = "rgba(255,255,255,0.16)";
    ctx.fillRect(x + 10, 18, 4, 220);
  }

  ctx.strokeStyle = "rgba(18,22,28,0.45)";
  ctx.lineWidth = 14;
  ctx.strokeRect(7, 7, 242, 242);

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createSiteLabelTexture(label: string, accentHex: string): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 128;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = "rgba(20, 24, 32, 0.88)";
  ctx.fillRect(10, 14, 236, 100);
  ctx.strokeStyle = accentHex;
  ctx.lineWidth = 6;
  ctx.strokeRect(10, 14, 236, 100);
  ctx.fillStyle = accentHex;
  ctx.font = "900 44px sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(label, 128, 66);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function addMapProp(
  prop: MapPropHint,
  scene: THREE.Scene,
  geos: THREE.BufferGeometry[],
  mats: THREE.Material[],
  asyncQueue?: {
    url: string;
    targetSize: number;
    x: number;
    y: number;
    z: number;
    rotY?: number;
    hideOnLoad?: THREE.Object3D[];
  }[],
): THREE.Mesh | null {
  const s = prop.scale ?? 1;
  let waterMesh: THREE.Mesh | null = null;

  if (prop.kind === "tree") {
    const trunkGeo = new THREE.CylinderGeometry(0.45 * s, 0.65 * s, 4.4 * s, 8);
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x5c3c24, roughness: 0.9 });
    const trunk = new THREE.Mesh(trunkGeo, trunkMat);
    trunk.position.set(prop.x, prop.y + 2.2 * s, prop.z);
    trunk.castShadow = true;

    const canopyGeo1 = new THREE.ConeGeometry(2.6 * s, 4.6 * s, 8);
    const canopyMat = new THREE.MeshStandardMaterial({ color: 0x2e5c32, roughness: 0.85 });
    const canopy1 = new THREE.Mesh(canopyGeo1, canopyMat);
    canopy1.position.set(prop.x, prop.y + 5.6 * s, prop.z);
    canopy1.castShadow = true;

    const canopyGeo2 = new THREE.SphereGeometry(2.1 * s, 10, 8);
    const canopy2 = new THREE.Mesh(canopyGeo2, canopyMat);
    canopy2.position.set(prop.x, prop.y + 7.2 * s, prop.z);
    canopy2.castShadow = true;

    scene.add(trunk, canopy1, canopy2);
    geos.push(trunkGeo, canopyGeo1, canopyGeo2);
    mats.push(trunkMat, canopyMat);
    asyncQueue?.push({
      url: s >= 1.16 ? "/assets/models/props/tree_oak.glb" : "/assets/models/props/tree_pine.glb",
      targetSize: 8.8 * s,
      x: prop.x,
      y: prop.y,
      z: prop.z,
      rotY: prop.rotY ?? (prop.x + prop.z) * 0.13,
      hideOnLoad: [trunk, canopy1, canopy2],
    });
  } else if (prop.kind === "palm") {
    const trunkGeo = new THREE.CylinderGeometry(0.28 * s, 0.42 * s, 6.2 * s, 7);
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x7b5b3c, roughness: 0.9 });
    const trunk = new THREE.Mesh(trunkGeo, trunkMat);
    trunk.position.set(prop.x, prop.y + 3.1 * s, prop.z);
    trunk.castShadow = true;

    const leafMat = new THREE.MeshStandardMaterial({ color: 0x457d3b, roughness: 0.78 });
    const leafGeo = new THREE.ConeGeometry(2.6 * s, 1.4 * s, 6);
    const leaf = new THREE.Mesh(leafGeo, leafMat);
    leaf.position.set(prop.x, prop.y + 6.4 * s, prop.z);
    leaf.castShadow = true;
    scene.add(trunk, leaf);
    geos.push(trunkGeo, leafGeo);
    mats.push(trunkMat, leafMat);
    asyncQueue?.push({
      url: "/assets/models/props/tree_palm.glb",
      targetSize: 8.2 * s,
      x: prop.x,
      y: prop.y,
      z: prop.z,
      rotY: prop.rotY ?? prop.x * 0.2,
      hideOnLoad: [trunk, leaf],
    });
  } else if (prop.kind === "fountain") {
    const basinGeo = new THREE.CylinderGeometry(2.6 * s, 2.8 * s, 0.45 * s, 16);
    const stoneMat = new THREE.MeshStandardMaterial({ color: 0xc9c2b2, roughness: 0.65 });
    const basin = new THREE.Mesh(basinGeo, stoneMat);
    basin.position.set(prop.x, prop.y + 0.22 * s, prop.z);
    basin.castShadow = true;

    const waterGeo = new THREE.CylinderGeometry(2.3 * s, 2.3 * s, 0.14 * s, 16);
    const waterMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0c4a6e,
      emissiveIntensity: 0.35,
      roughness: 0.12,
      metalness: 0.45,
    });
    waterMesh = new THREE.Mesh(waterGeo, waterMat);
    waterMesh.position.set(prop.x, prop.y + 0.48 * s, prop.z);

    const spireGeo = new THREE.CylinderGeometry(0.32 * s, 0.55 * s, 2.1 * s, 12);
    const spire = new THREE.Mesh(spireGeo, stoneMat);
    spire.position.set(prop.x, prop.y + 1.2 * s, prop.z);

    scene.add(basin, waterMesh, spire);
    geos.push(basinGeo, waterGeo, spireGeo);
    mats.push(stoneMat, waterMat);
    asyncQueue?.push({
      url: "/assets/models/props/statue_obelisk.glb",
      targetSize: 3.1 * s,
      x: prop.x,
      y: prop.y + 0.42 * s,
      z: prop.z,
      rotY: 0,
      hideOnLoad: [spire],
    });
  } else if (prop.kind === "gazebo") {
    const colMat = new THREE.MeshStandardMaterial({ color: 0xe6dec8, roughness: 0.6 });
    const roofMat = new THREE.MeshStandardMaterial({ color: 0x5f3d28, roughness: 0.72 });
    const roofGeo = new THREE.ConeGeometry(4.2 * s, 2.2 * s, 8);
    const roof = new THREE.Mesh(roofGeo, roofMat);
    roof.position.set(prop.x, prop.y + 4.4 * s, prop.z);
    roof.castShadow = true;
    scene.add(roof);
    geos.push(roofGeo);
    mats.push(colMat, roofMat);

    const colGeo = new THREE.CylinderGeometry(0.18 * s, 0.18 * s, 3.6 * s, 8);
    geos.push(colGeo);
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      const col = new THREE.Mesh(colGeo, colMat);
      col.position.set(prop.x + Math.cos(a) * 3.1 * s, prop.y + 1.8 * s, prop.z + Math.sin(a) * 3.1 * s);
      col.castShadow = true;
      scene.add(col);
    }
    // Downloaded wooden picnic table inside the garden gazebo
    asyncQueue?.push({
      url: "/assets/models/props/picnic_table.glb",
      targetSize: 3.2 * s,
      x: prop.x,
      y: prop.y,
      z: prop.z,
      rotY: 0.4,
    });
  } else if (prop.kind === "lamp") {
    const poleGeo = new THREE.CylinderGeometry(0.1, 0.16, 4.4 * s, 8);
    const poleMat = new THREE.MeshStandardMaterial({ color: 0x1d232b, metalness: 0.7, roughness: 0.35 });
    const pole = new THREE.Mesh(poleGeo, poleMat);
    pole.position.set(prop.x, prop.y + 2.2 * s, prop.z);

    const bulbGeo = new THREE.SphereGeometry(0.32 * s, 10, 8);
    const bulbMat = new THREE.MeshStandardMaterial({
      color: 0xfff3c4,
      emissive: 0xf5b942,
      emissiveIntensity: 1.5,
      roughness: 0.2,
    });
    const bulb = new THREE.Mesh(bulbGeo, bulbMat);
    bulb.position.set(prop.x, prop.y + 4.55 * s, prop.z);

    scene.add(pole, bulb);
    geos.push(poleGeo, bulbGeo);
    mats.push(poleMat, bulbMat);
    asyncQueue?.push({
      url: "/assets/models/props/street_lamp.glb",
      targetSize: 4.8 * s,
      x: prop.x,
      y: prop.y,
      z: prop.z,
      rotY: prop.x < 0 ? Math.PI / 2 : -Math.PI / 2,
      hideOnLoad: [pole, bulb],
    });
  } else if (prop.kind === "van") {
    const wheelGeo = new THREE.CylinderGeometry(0.56, 0.56, 0.36, 14);
    wheelGeo.rotateX(Math.PI / 2);
    const wheelMat = new THREE.MeshStandardMaterial({ color: 0x16181d, roughness: 0.85 });
    const offsets: [number, number][] = [
      [-2.2, -1.55],
      [1.8, -1.55],
      [-2.2, 1.55],
      [1.8, 1.55],
    ];
    for (const [ox, oz] of offsets) {
      const wh = new THREE.Mesh(wheelGeo, wheelMat);
      wh.position.set(prop.x + ox, prop.y + 0.56, prop.z + oz);
      scene.add(wh);
    }
    geos.push(wheelGeo);
    mats.push(wheelMat);
  } else if (prop.kind === "crane") {
    const beamMat = new THREE.MeshStandardMaterial({ color: 0xe69f3a, metalness: 0.65, roughness: 0.38 });
    const towerGeo = new THREE.BoxGeometry(1.4 * s, 12 * s, 1.4 * s);
    const tower = new THREE.Mesh(towerGeo, beamMat);
    tower.position.set(prop.x, prop.y + 6 * s, prop.z);
    const jibGeo = new THREE.BoxGeometry(14 * s, 0.9 * s, 1.2 * s);
    const jib = new THREE.Mesh(jibGeo, beamMat);
    jib.position.set(prop.x, prop.y + 12.2 * s, prop.z);
    scene.add(tower, jib);
    geos.push(towerGeo, jibGeo);
    mats.push(beamMat);
  } else if (prop.kind === "snowbank") {
    const snowGeo = new THREE.SphereGeometry(3.2 * s, 12, 8);
    snowGeo.scale(1.6, 0.55, 1.1);
    const snowMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, roughness: 0.9 });
    const m = new THREE.Mesh(snowGeo, snowMat);
    m.position.set(prop.x, prop.y + 0.4, prop.z);
    scene.add(m);
    geos.push(snowGeo);
    mats.push(snowMat);
  } else if (prop.kind === "awning") {
    const awW = prop.w ?? 8;
    const awD = prop.d ?? 5;
    const clothGeo = new THREE.BoxGeometry(awW, 0.14, awD);
    const clothMat = new THREE.MeshStandardMaterial({
      color: prop.colorHex ?? 0xa8432a,
      roughness: 0.92,
      metalness: 0.02,
    });
    const cloth = new THREE.Mesh(clothGeo, clothMat);
    cloth.position.set(prop.x, prop.y, prop.z);
    cloth.rotation.x = 0.06;
    cloth.castShadow = true;
    cloth.receiveShadow = true;

    const beamGeo = new THREE.BoxGeometry(0.14, 0.16, awD + 0.25);
    const beamMat = new THREE.MeshStandardMaterial({ color: 0x6b4527, roughness: 0.85 });
    const beamL = new THREE.Mesh(beamGeo, beamMat);
    beamL.position.set(prop.x - awW * 0.48, prop.y - 0.1, prop.z);
    const beamR = new THREE.Mesh(beamGeo, beamMat);
    beamR.position.set(prop.x + awW * 0.48, prop.y - 0.1, prop.z);

    scene.add(cloth, beamL, beamR);
    geos.push(clothGeo, beamGeo);
    mats.push(clothMat, beamMat);
  }

  return waterMesh;
}

export function buildArenaScene(
  scene: THREE.Scene,
  maxAnisotropy: number,
  mapId: FpsMapId = "mansion",
): ArenaBundle {
  const mapDef = getFpsMapDef(mapId);
  const geos: THREE.BufferGeometry[] = [];
  const mats: THREE.Material[] = [];
  const texs: THREE.Texture[] = [];

  const floorTex = createThemedFloorTexture(
    mapDef.floorPalette[0],
    mapDef.floorPalette[1],
    mapDef.id,
    maxAnisotropy,
  );
  const wallTex = createStuddedWallTexture(
    mapId === "mansion" ? "#4e3f35" : mapId === "desert-outpost" ? "#b89564" : "#545c69",
    "rgba(25,28,36,0.42)",
    maxAnisotropy,
  );
  const buildingTex = createStuddedWallTexture(
    mapId === "arctic-facility" ? "#c2d4e6" : "#dad3c7",
    "rgba(120,112,102,0.35)",
    maxAnisotropy,
  );
  const mansionWallTex = createMansionStuccoBrickTexture(maxAnisotropy);
  const parquetTex = createParquetWoodTexture(maxAnisotropy);
  const crateTex = createCrateTexture(maxAnisotropy);
  const sandstoneTex = createSandstoneTexture(maxAnisotropy);
  const woodDoorTex = createWoodDoorTexture(maxAnisotropy);
  const woodWallTex = createWoodWallTexture(maxAnisotropy);
  const concreteTex = createConcreteTexture(maxAnisotropy);
  const contAmberTex = createContainerTexture("#d47e2a", "#9c5616", maxAnisotropy);
  const contBlueTex = createContainerTexture("#2d6fb8", "#1c4a80", maxAnisotropy);
  const contSlateTex = createContainerTexture("#47515e", "#303842", maxAnisotropy);
  texs.push(
    floorTex,
    wallTex,
    buildingTex,
    mansionWallTex,
    parquetTex,
    crateTex,
    sandstoneTex,
    woodDoorTex,
    woodWallTex,
    concreteTex,
    contAmberTex,
    contBlueTex,
    contSlateTex,
  );

  const floorGeo = new THREE.PlaneGeometry(mapDef.halfW * 2, mapDef.halfD * 2);
  floorGeo.rotateX(-Math.PI / 2);
  const floorMat = new THREE.MeshStandardMaterial({
    map: floorTex,
    roughness: mapId === "desert-outpost" ? 0.9 : 0.82,
    metalness: 0.04,
  });
  const floorMesh = new THREE.Mesh(floorGeo, floorMat);
  floorMesh.receiveShadow = true;
  scene.add(floorMesh);
  geos.push(floorGeo);
  mats.push(floorMat);

  // Extended surrounding desert dune vista beyond outer walls so the map sits in a real desert landscape
  if (mapDef.id === "desert-outpost") {
    const outerDesertGeo = new THREE.PlaneGeometry(380, 380);
    outerDesertGeo.rotateX(-Math.PI / 2);
    const outerDesertMat = new THREE.MeshStandardMaterial({
      color: 0xd8b885,
      roughness: 0.94,
      metalness: 0.02,
    });
    const outerDesert = new THREE.Mesh(outerDesertGeo, outerDesertMat);
    outerDesert.position.y = -0.06;
    outerDesert.receiveShadow = true;
    scene.add(outerDesert);
    geos.push(outerDesertGeo);
    mats.push(outerDesertMat);

    // Distant sculpted sand dune ridges & citadel spires framing the horizon
    const duneGeo = new THREE.SphereGeometry(28, 16, 10);
    duneGeo.scale(2.2, 0.42, 1.3);
    const duneMat = new THREE.MeshStandardMaterial({ color: 0xcca872, roughness: 0.92, metalness: 0.02 });
    const duneCoords: [number, number, number][] = [
      [-92, -3, -64],
      [96, -2, -58],
      [-88, -3, 66],
      [92, -2, 62],
      [0, -3, -95],
      [0, -3, 95],
    ];
    for (const [dx, dy, dz] of duneCoords) {
      const dm = new THREE.Mesh(duneGeo, duneMat);
      dm.position.set(dx, dy, dz);
      scene.add(dm);
    }
    geos.push(duneGeo);
    mats.push(duneMat);

    // Warm interior Bazaar lantern light inside B Tunnels so covered tunnels read clearly
    const tunnelLightS = new THREE.PointLight(0xffcf88, 2.8, 32, 1.3);
    tunnelLightS.position.set(39, 4.1, 18);
    const tunnelLightN = new THREE.PointLight(0xffcf88, 2.2, 26, 1.3);
    tunnelLightN.position.set(39, 4.1, 10);
    scene.add(tunnelLightS, tunnelLightN);
  }

  // Mansion interior hardwood parquet floor & driveway stone path
  if (mapDef.id === "mansion") {
    const interiorFloorGeo = new THREE.PlaneGeometry(40, 29);
    interiorFloorGeo.rotateX(-Math.PI / 2);
    const interiorFloorMat = new THREE.MeshStandardMaterial({
      map: parquetTex,
      roughness: 0.54,
      metalness: 0.12,
    });
    const interiorFloor = new THREE.Mesh(interiorFloorGeo, interiorFloorMat);
    interiorFloor.position.set(0, 0.03, 0);
    interiorFloor.receiveShadow = true;
    scene.add(interiorFloor);
    geos.push(interiorFloorGeo);
    mats.push(interiorFloorMat);

    const warmInteriorLight = new THREE.PointLight(0xffcf88, 2.2, 34, 1.4);
    warmInteriorLight.position.set(0, 3.2, 4);
    const diningLight = new THREE.PointLight(0xffb86b, 1.8, 26, 1.4);
    diningLight.position.set(-10, 3.1, -3);
    const studyLight = new THREE.PointLight(0xffe0a3, 1.8, 26, 1.4);
    studyLight.position.set(11, 6.8, -3);
    scene.add(warmInteriorLight, diningLight, studyLight);

    const pathGeo = new THREE.PlaneGeometry(11, 28);
    pathGeo.rotateX(-Math.PI / 2);
    const pathMat = new THREE.MeshStandardMaterial({ color: 0x7c7b77, roughness: 0.88 });
    const pathMesh = new THREE.Mesh(pathGeo, pathMat);
    pathMesh.position.set(0, 0.02, 29);
    pathMesh.receiveShadow = true;
    scene.add(pathMesh);
    geos.push(pathGeo);
    mats.push(pathMat);
  }

  // Painted Team Spawn Pads
  const vgPadGeo = new THREE.PlaneGeometry(34, 12);
  vgPadGeo.rotateX(-Math.PI / 2);
  const vgPadMat = new THREE.MeshStandardMaterial({
    color: 0xe69f3a,
    roughness: 0.72,
    metalness: 0.1,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const vgPad = new THREE.Mesh(vgPadGeo, vgPadMat);
  vgPad.position.set(0, 0.025, 40);
  vgPad.receiveShadow = true;

  const syPadGeo = new THREE.PlaneGeometry(34, 12);
  syPadGeo.rotateX(-Math.PI / 2);
  const syPadMat = new THREE.MeshStandardMaterial({
    color: 0x3b86d1,
    roughness: 0.72,
    metalness: 0.1,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const syPad = new THREE.Mesh(syPadGeo, syPadMat);
  syPad.position.set(0, 0.025, -40);
  syPad.receiveShadow = true;
  scene.add(vgPad, syPad);
  geos.push(vgPadGeo, syPadGeo);
  mats.push(vgPadMat, syPadMat);

  const wallMat = new THREE.MeshStandardMaterial({ map: wallTex, roughness: 0.76, metalness: 0.12 });
  const buildingMat = new THREE.MeshStandardMaterial({ map: buildingTex, roughness: 0.68, metalness: 0.06 });
  const mansionWallMat = new THREE.MeshStandardMaterial({ map: mansionWallTex, roughness: 0.72, metalness: 0.05 });
  const mansionFloorMat = new THREE.MeshStandardMaterial({ map: parquetTex, roughness: 0.56, metalness: 0.08 });
  const mansionRoofMat = new THREE.MeshStandardMaterial({ color: 0x5c2b24, roughness: 0.74, metalness: 0.15 });
  const woodStairMat = new THREE.MeshStandardMaterial({ color: 0x7b5231, roughness: 0.65, metalness: 0.08 });
  const furnitureMat = new THREE.MeshStandardMaterial({ color: 0x593922, roughness: 0.48, metalness: 0.14 });
  const hedgeMat = new THREE.MeshStandardMaterial({ color: 0x264d29, roughness: 0.92, metalness: 0.02 });
  const fenceMat = new THREE.MeshStandardMaterial({ color: 0x2a2f36, roughness: 0.45, metalness: 0.65 });
  const sandstoneMat = new THREE.MeshStandardMaterial({ map: sandstoneTex, roughness: 0.86, metalness: 0.04 });
  const woodDoorMat = new THREE.MeshStandardMaterial({ map: woodDoorTex, roughness: 0.72, metalness: 0.14 });
  const woodWallMat = new THREE.MeshStandardMaterial({ map: woodWallTex, roughness: 0.76, metalness: 0.08 });
  const concreteMat = new THREE.MeshStandardMaterial({ map: concreteTex, roughness: 0.82, metalness: 0.08 });
  const metalCoverMat = new THREE.MeshStandardMaterial({ color: 0x45515e, roughness: 0.42, metalness: 0.65 });
  const iceWallMat = new THREE.MeshStandardMaterial({ color: 0xa6cbe8, roughness: 0.28, metalness: 0.22 });
  const platformMat = new THREE.MeshStandardMaterial({ color: 0x8d949e, roughness: 0.56, metalness: 0.25 });
  const pillarMat = new THREE.MeshStandardMaterial({
    color: mapId === "mansion" ? 0xe5dfd3 : 0xd9a74e,
    roughness: 0.35,
    metalness: mapId === "mansion" ? 0.15 : 0.62,
  });
  const barrierMat = new THREE.MeshStandardMaterial({ color: 0x5d6572, roughness: 0.72, metalness: 0.18 });
  const archMat = new THREE.MeshStandardMaterial({ color: 0x3e4552, roughness: 0.65, metalness: 0.28 });
  const crateMat = new THREE.MeshStandardMaterial({ map: crateTex, roughness: 0.68, metalness: 0.08 });
  const contAmberMat = new THREE.MeshStandardMaterial({ map: contAmberTex, roughness: 0.45, metalness: 0.48 });
  const contBlueMat = new THREE.MeshStandardMaterial({ map: contBlueTex, roughness: 0.45, metalness: 0.48 });
  const contSlateMat = new THREE.MeshStandardMaterial({ map: contSlateTex, roughness: 0.48, metalness: 0.52 });
  const trimStripMat = new THREE.MeshStandardMaterial({ color: 0x222730, roughness: 0.42, metalness: 0.5 });

  mats.push(
    wallMat,
    buildingMat,
    mansionWallMat,
    mansionFloorMat,
    mansionRoofMat,
    woodStairMat,
    furnitureMat,
    hedgeMat,
    fenceMat,
    sandstoneMat,
    woodDoorMat,
    woodWallMat,
    concreteMat,
    metalCoverMat,
    iceWallMat,
    platformMat,
    pillarMat,
    barrierMat,
    archMat,
    crateMat,
    contAmberMat,
    contBlueMat,
    contSlateMat,
    trimStripMat,
  );

  const boxMeshesById = new Map<string, THREE.Mesh>();
  const asyncQueue: {
    url: string;
    targetSize: number;
    x: number;
    y: number;
    z: number;
    rotY?: number;
    groundAtZero?: boolean;
    hideOnLoad?: THREE.Object3D[];
  }[] = [];

  for (const b of mapDef.boxes) {
    const geo = new THREE.BoxGeometry(b.w, b.h, b.d);
    const style = b.style || b.kind;
    const mat =
      style === "wall"
        ? wallMat
        : style === "building"
          ? buildingMat
          : style === "mansion-wall"
            ? mansionWallMat
            : style === "mansion-floor"
              ? mansionFloorMat
              : style === "mansion-roof"
                ? mansionRoofMat
                : style === "wood-stair"
                  ? woodStairMat
                  : style === "wood-door"
                    ? woodDoorMat
                    : style === "wood-wall"
                      ? woodWallMat
                      : style === "concrete"
                        ? concreteMat
                        : style === "metal-cover"
                          ? metalCoverMat
                          : style === "furniture-wood"
                            ? furnitureMat
                            : style === "hedge"
                              ? hedgeMat
                              : style === "fence"
                                ? fenceMat
                                : style === "sandstone"
                                  ? sandstoneMat
                                  : style === "ice-wall"
                                    ? iceWallMat
                                    : style === "platform"
                                      ? platformMat
                                      : style === "pillar"
                                        ? pillarMat
                                        : style === "crate"
                                          ? crateMat
                                          : style === "container-amber"
                                            ? contAmberMat
                                            : style === "container-blue"
                                              ? contBlueMat
                                              : style === "container-slate"
                                                ? contSlateMat
                                                : style === "arch"
                                                  ? archMat
                                                  : barrierMat;

    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(b.x, b.y + b.h * 0.5, b.z);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    scene.add(mesh);
    geos.push(geo);
    boxMeshesById.set(b.id, mesh);

    if (style === "building" || style === "pillar" || (style === "sandstone" && b.kind === "building" && b.h >= 5.5)) {
      const capGeo = new THREE.BoxGeometry(b.w + 0.14, 0.22, b.d + 0.14);
      const cap = new THREE.Mesh(capGeo, style === "sandstone" ? concreteMat : trimStripMat);
      cap.position.set(b.x, b.y + b.h + 0.06, b.z);
      cap.castShadow = true;
      scene.add(cap);
      geos.push(capGeo);
    }
  }

  let fountainWaterMesh: THREE.Mesh | null = null;
  for (const p of mapDef.props) {
    const wMesh = addMapProp(p, scene, geos, mats, asyncQueue);
    if (wMesh) fountainWaterMesh = wMesh;
  }

  // Upgrade Mansion interior furniture & exterior tactical barrels/crates with real downloaded 3D GLBs
  if (mapDef.id === "mansion") {
    const sofaBox = boxMeshesById.get("furn-foyer-sofa");
    asyncQueue.push(
      {
        url: "/assets/models/props/sofa.glb",
        targetSize: 4.1,
        x: 8.5,
        y: 0,
        z: 8.2,
        rotY: Math.PI,
        hideOnLoad: sofaBox ? [sofaBox] : undefined,
      },
      { url: "/assets/models/props/chandelier.glb", targetSize: 2.6, x: 0, y: 5.5, z: 5.2, groundAtZero: false },
      { url: "/assets/models/props/chandelier.glb", targetSize: 2.3, x: -10.5, y: 5.7, z: -2.0, groundAtZero: false },
      { url: "/assets/models/props/grandfather_clock.glb", targetSize: 2.8, x: -2.4, y: 0, z: 1.4, rotY: 0 },
      { url: "/assets/models/props/grandfather_clock.glb", targetSize: 2.7, x: 17.8, y: 4.0, z: -10.8, rotY: -Math.PI / 2 },
      { url: "/assets/models/props/armchair.glb", targetSize: 1.65, x: -6.2, y: 0, z: -2.0, rotY: -Math.PI / 2 },
      { url: "/assets/models/props/armchair.glb", targetSize: 1.65, x: 8.4, y: 4.0, z: -2.5, rotY: Math.PI / 2 },
      { url: "/assets/models/props/potted_plant.glb", targetSize: 1.75, x: -3.6, y: 0, z: 15.8 },
      { url: "/assets/models/props/potted_plant.glb", targetSize: 1.75, x: 3.6, y: 0, z: 15.8 },
      { url: "/assets/models/props/potted_plant.glb", targetSize: 1.65, x: -3.8, y: 0, z: -15.8 },
      { url: "/assets/models/props/potted_plant.glb", targetSize: 1.65, x: 3.8, y: 0, z: -15.8 },
      { url: "/assets/models/props/picnic_table.glb", targetSize: 3.0, x: -39, y: 0, z: 4, rotY: Math.PI / 2 },
      { url: "/assets/models/props/barrel.glb", targetSize: 1.25, x: 12.2, y: 0, z: 31.2 },
      { url: "/assets/models/props/barrel.glb", targetSize: 1.25, x: -19.2, y: 0, z: 29.8 },
      // Mansion Estate Front Avenue Road Network + Parked Cars + Perimeter Barriers
      { url: "/assets/models/roads/road-bend.glb", targetSize: 10, x: -40, y: 0.02, z: 31, rotY: Math.PI / 2 },
      { url: "/assets/models/roads/road-straight.glb", targetSize: 10, x: -30, y: 0.02, z: 31, rotY: Math.PI / 2 },
      { url: "/assets/models/roads/road-straight.glb", targetSize: 10, x: -20, y: 0.02, z: 31, rotY: Math.PI / 2 },
      { url: "/assets/models/roads/road-straight.glb", targetSize: 10, x: -10, y: 0.02, z: 31, rotY: Math.PI / 2 },
      { url: "/assets/models/roads/road-crossroad.glb", targetSize: 10, x: 0, y: 0.02, z: 31, rotY: 0 },
      { url: "/assets/models/roads/road-straight.glb", targetSize: 10, x: 10, y: 0.02, z: 31, rotY: Math.PI / 2 },
      { url: "/assets/models/roads/road-straight.glb", targetSize: 10, x: 20, y: 0.02, z: 31, rotY: Math.PI / 2 },
      { url: "/assets/models/roads/road-straight.glb", targetSize: 10, x: 30, y: 0.02, z: 31, rotY: Math.PI / 2 },
      { url: "/assets/models/roads/road-bend.glb", targetSize: 10, x: 40, y: 0.02, z: 31, rotY: Math.PI },
      { url: "/assets/models/cars/sedan-sports.glb", targetSize: 4.5, x: 33.5, y: 0, z: 24.5, rotY: -Math.PI * 0.65 },
      { url: "/assets/models/cars/suv-luxury.glb", targetSize: 4.7, x: -34.5, y: 0, z: 24.5, rotY: Math.PI * 0.35 },
      { url: "/assets/models/racing/barrierRed.glb", targetSize: 3.4, x: -11.5, y: 0, z: 25.5, rotY: 0.12 },
      { url: "/assets/models/racing/barrierRed.glb", targetSize: 3.4, x: 11.5, y: 0, z: 25.5, rotY: -0.12 },
    );
  } else if (mapDef.id === "desert-outpost") {
    asyncQueue.push(
      { url: "/assets/models/props/barrel.glb", targetSize: 1.35, x: -32.2, y: 0, z: -17.5 },
      { url: "/assets/models/props/barrel.glb", targetSize: 1.35, x: 45.2, y: 0, z: -12.5 },
      { url: "/assets/models/props/barrel.glb", targetSize: 1.25, x: -18.0, y: 0, z: 36.8 },
      { url: "/assets/models/props/barrel.glb", targetSize: 1.25, x: 18.2, y: 0, z: -36.8 },
    );
  } else {
    asyncQueue.push(
      { url: "/assets/models/roads/road-straight.glb", targetSize: 10, x: -10, y: 0.02, z: 24, rotY: Math.PI / 2 },
      { url: "/assets/models/roads/road-crossroad.glb", targetSize: 10, x: 0, y: 0.02, z: 24, rotY: 0 },
      { url: "/assets/models/roads/road-straight.glb", targetSize: 10, x: 10, y: 0.02, z: 24, rotY: Math.PI / 2 },
      { url: "/assets/models/cars/sedan.glb", targetSize: 4.4, x: -24, y: 0, z: 24, rotY: Math.PI * 0.45 },
      { url: "/assets/models/roads/sign-highway-wide.glb", targetSize: 5.5, x: 24, y: 0, z: 24, rotY: -Math.PI / 2 },
      { url: "/assets/models/racing/barrierRed.glb", targetSize: 3.4, x: 0, y: 0, z: -22, rotY: 0 },
      { url: "/assets/models/props/wooden_crate.glb", targetSize: 1.6, x: -16, y: 0, z: 12, rotY: 0.35 },
      { url: "/assets/models/props/barrel.glb", targetSize: 1.3, x: 16, y: 0, z: -12 },
      { url: "/assets/models/props/barrel.glb", targetSize: 1.3, x: -15, y: 0, z: -12.5 },
    );
  }
  const crateUpgradeIds = [
    "yard-truck-crates",
    "north-crate-c",
    "furn-2f-crate",
    "des-mid-crate-s",
    "des-mid-crate-n",
    "des-a-crate1",
    "des-a-crate-long",
    "des-b-crate1",
    "des-b-tun-crate",
  ];
  for (const cid of crateUpgradeIds) {
    const bDef = mapDef.boxes.find((bx) => bx.id === cid);
    const bMesh = boxMeshesById.get(cid);
    if (bDef && bMesh) {
      asyncQueue.push({
        url: "/assets/models/props/wooden_crate.glb",
        targetSize: Math.max(bDef.w, bDef.h, bDef.d),
        x: bDef.x,
        y: bDef.y,
        z: bDef.z,
        hideOnLoad: [bMesh],
      });
    }
  }

  let reactorCoreMesh: THREE.Mesh | null = null;
  if (mapDef.id === "blockline" || mapDef.id === "arctic-facility") {
    const coreGeo = new THREE.OctahedronGeometry(1.15, 0);
    const coreMat = new THREE.MeshStandardMaterial({
      color: mapDef.id === "arctic-facility" ? 0x38bdf8 : 0xffd166,
      emissive: mapDef.id === "arctic-facility" ? 0x0ea5e9 : 0xe69524,
      emissiveIntensity: 1.2,
      roughness: 0.2,
      metalness: 0.7,
    });
    reactorCoreMesh = new THREE.Mesh(coreGeo, coreMat);
    reactorCoreMesh.position.set(0, mapDef.id === "arctic-facility" ? 6.5 : 10.7, 0);
    scene.add(reactorCoreMesh);
    geos.push(coreGeo);
    mats.push(coreMat);
  }

  // Bomb Sites A & B
  const siteBeacons: { id: "A" | "B"; ring: THREE.Mesh; core: THREE.Mesh }[] = [];
  for (const site of mapDef.bombSites) {
    const colorHex = site.id === "A" ? 0xf2a93b : 0x4cc4ff;
    const labelStr = site.id === "A" ? "SITE A" : "SITE B";
    const cssColor = site.id === "A" ? "#f2a93b" : "#4cc4ff";

    const ringGeo = new THREE.RingGeometry(site.radius - 0.38, site.radius, 40);
    ringGeo.rotateX(-Math.PI / 2);
    const ringMat = new THREE.MeshBasicMaterial({
      color: colorHex,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.85,
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.position.set(site.x, site.y + 0.04, site.z);

    const padGeo = new THREE.CircleGeometry(site.radius - 0.5, 36);
    padGeo.rotateX(-Math.PI / 2);
    const padMat = new THREE.MeshBasicMaterial({
      color: colorHex,
      transparent: true,
      opacity: 0.14,
      depthWrite: false,
    });
    const pad = new THREE.Mesh(padGeo, padMat);
    pad.position.set(site.x, site.y + 0.03, site.z);

    const markerGeo = new THREE.OctahedronGeometry(0.42, 0);
    const markerMat = new THREE.MeshStandardMaterial({
      color: colorHex,
      emissive: colorHex,
      emissiveIntensity: 0.9,
      roughness: 0.25,
      metalness: 0.6,
    });
    const core = new THREE.Mesh(markerGeo, markerMat);
    core.position.set(site.x, site.y + 2.9, site.z);

    const signTex = createSiteLabelTexture(labelStr, cssColor);
    texs.push(signTex);
    const signMat = new THREE.SpriteMaterial({ map: signTex, transparent: true });
    mats.push(signMat);
    const sign = new THREE.Sprite(signMat);
    sign.position.set(site.x, site.y + 3.85, site.z);
    sign.scale.set(2.8, 1.4, 1);

    scene.add(ring, pad, core, sign);
    geos.push(ringGeo, padGeo, markerGeo);
    mats.push(ringMat, padMat, markerMat);
    siteBeacons.push({ id: site.id, ring, core });
  }

  // Planted Aether Charge 3D Prop
  const chargeGroup = new THREE.Group();
  chargeGroup.visible = false;
  const chargeBaseGeo = new THREE.BoxGeometry(0.75, 0.34, 0.58);
  const chargeBaseMat = new THREE.MeshStandardMaterial({ color: 0x20242c, metalness: 0.72, roughness: 0.3 });
  const chargeBase = new THREE.Mesh(chargeBaseGeo, chargeBaseMat);
  chargeBase.position.y = 0.17;
  chargeBase.castShadow = true;

  const chargeCoreGeo = new THREE.OctahedronGeometry(0.24, 0);
  const chargeCoreMat = new THREE.MeshStandardMaterial({
    color: 0xff453a,
    emissive: 0xff2d20,
    emissiveIntensity: 1.8,
    roughness: 0.15,
    metalness: 0.5,
  });
  const chargeCore = new THREE.Mesh(chargeCoreGeo, chargeCoreMat);
  chargeCore.position.y = 0.52;

  const chargeRingGeo = new THREE.RingGeometry(0.85, 1.05, 32);
  chargeRingGeo.rotateX(-Math.PI / 2);
  const chargeRingMat = new THREE.MeshBasicMaterial({
    color: 0xff453a,
    side: THREE.DoubleSide,
    transparent: true,
    opacity: 0.8,
  });
  const chargeRing = new THREE.Mesh(chargeRingGeo, chargeRingMat);
  chargeRing.position.y = 0.05;

  chargeGroup.add(chargeBase, chargeCore, chargeRing);
  scene.add(chargeGroup);
  geos.push(chargeBaseGeo, chargeCoreGeo, chargeRingGeo);
  mats.push(chargeBaseMat, chargeCoreMat, chargeRingMat);

  // Pickups
  const pickupMeshes = new Map<string, THREE.Group>();
  const pkBoxGeo = new THREE.BoxGeometry(0.78, 0.56, 0.78);
  const pkStripeGeo = new THREE.BoxGeometry(0.82, 0.16, 0.82);
  const medMat = new THREE.MeshStandardMaterial({ color: 0xf4f6f8, roughness: 0.38, metalness: 0.12 });
  const medStripeMat = new THREE.MeshStandardMaterial({
    color: 0x34c759,
    emissive: 0x239640,
    emissiveIntensity: 0.65,
    roughness: 0.3,
  });
  const ammoMat = new THREE.MeshStandardMaterial({ color: 0x3b424d, roughness: 0.42, metalness: 0.45 });
  const ammoStripeMat = new THREE.MeshStandardMaterial({
    color: 0xf5b342,
    emissive: 0xb57916,
    emissiveIntensity: 0.65,
    roughness: 0.3,
  });
  geos.push(pkBoxGeo, pkStripeGeo);
  mats.push(medMat, medStripeMat, ammoMat, ammoStripeMat);

  for (const pk of mapDef.pickups) {
    const grp = new THREE.Group();
    grp.position.set(pk.x, pk.y, pk.z);
    const box = new THREE.Mesh(pkBoxGeo, pk.kind === "medkit" ? medMat : ammoMat);
    const stripe = new THREE.Mesh(pkStripeGeo, pk.kind === "medkit" ? medStripeMat : ammoStripeMat);
    box.castShadow = true;
    grp.add(box, stripe);
    scene.add(grp);
    pickupMeshes.set(pk.id, grp);
  }

  let arenaDisposed = false;
  const asyncPropRoots: THREE.Object3D[] = [];
  for (const item of asyncQueue) {
    loadExternalModel(item.url, {
      targetSize: item.targetSize,
      groundAtZero: item.groundAtZero ?? true,
    })
      .then((grp) => {
        if (!grp) return;
        if (arenaDisposed) {
          disposeSafeHierarchy(grp);
          return;
        }
        grp.position.set(item.x, item.y, item.z);
        if (item.rotY !== undefined) grp.rotation.y = item.rotY;
        scene.add(grp);
        asyncPropRoots.push(grp);
        if (item.hideOnLoad) {
          for (const h of item.hideOnLoad) h.visible = false;
        }
      })
      .catch(() => {
        // Fallback procedural arena props stay visible
      });
  }

  return {
    siteBeacons,
    pickupMeshes,
    reactorCoreMesh,
    fountainWaterMesh,
    chargeGroup,
    chargeCore,
    chargeRing,
    dispose: () => {
      arenaDisposed = true;
      for (const root of asyncPropRoots) {
        scene.remove(root);
        disposeSafeHierarchy(root);
      }
      for (const g of geos) g.dispose();
      for (const m of mats) m.dispose();
      for (const t of texs) t.dispose();
    },
  };
}

/**
 * Multi-part studio-grade 3D Knife builder supporting 6 distinct melee silhouettes + skin finishes.
 */
export function buildDetailedKnifeMesh(
  knifeId: KnifeModelId,
  skinId: WeaponSkinId = "standard",
): DetailedWeaponBundle {
  const kSpec = KNIVES_BY_ID[knifeId] || KNIVES_BY_ID["karambit-aether"];
  const skin = WEAPON_SKINS_BY_ID[skinId] || WEAPON_SKINS_BY_ID.standard;
  const skinTex = createWeaponSkinTexture(skin.id);
  const group = new THREE.Group();

  const bladeMat = new THREE.MeshPhysicalMaterial({
    map: skinTex,
    color: skin.id === "standard" ? kSpec.defaultEdgeHex : 0xffffff,
    metalness: Math.max(0.55, skin.metalness),
    roughness: Math.min(0.35, skin.roughness),
    clearcoat: Math.max(0.4, skin.clearcoat),
    emissive: new THREE.Color(skin.accentHex),
    emissiveIntensity: skin.emissiveIntensity * 0.45,
  });
  const gripMat = new THREE.MeshStandardMaterial({
    color: kSpec.gripHex,
    roughness: 0.72,
    metalness: 0.18,
  });
  const edgeGlowMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(skin.id === "standard" ? kSpec.defaultEdgeHex : skin.accentHex),
    emissive: new THREE.Color(skin.id === "standard" ? kSpec.defaultEdgeHex : skin.accentHex),
    emissiveIntensity: 0.55 + skin.emissiveIntensity * 0.5,
    metalness: 0.85,
    roughness: 0.15,
  });

  const bladePivot = new THREE.Group();
  const proceduralKnifeRoot = new THREE.Group();
  bladePivot.add(proceduralKnifeRoot);
  group.add(bladePivot);

  if (knifeId === "karambit-aether") {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.032, 0.008, 10, 22), bladeMat);
    ring.position.set(0, -0.02, 0.08);
    ring.rotation.y = Math.PI / 2;
    const handle = new THREE.Mesh(new THREE.BoxGeometry(0.024, 0.034, 0.12), gripMat);
    handle.position.set(0, -0.01, -0.01);
    const guard = new THREE.Mesh(new THREE.BoxGeometry(0.032, 0.044, 0.022), edgeGlowMat);
    guard.position.set(0, 0.0, -0.07);
    const curve1 = new THREE.Mesh(new THREE.BoxGeometry(0.01, 0.036, 0.11), bladeMat);
    curve1.position.set(0, 0.015, -0.14);
    curve1.rotation.x = 0.28;
    const curveTip = new THREE.Mesh(new THREE.ConeGeometry(0.02, 0.11, 4), bladeMat);
    curveTip.position.set(0, 0.048, -0.22);
    curveTip.rotation.x = -Math.PI * 0.34;
    proceduralKnifeRoot.add(ring, handle, guard, curve1, curveTip);
  } else if (knifeId === "butterfly-chronos") {
    const hL = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.022, 0.16), gripMat);
    hL.position.set(-0.012, -0.01, 0.02);
    hL.rotation.y = 0.06;
    const hR = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.022, 0.16), edgeGlowMat);
    hR.position.set(0.012, -0.01, 0.02);
    hR.rotation.y = -0.06;
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.01, 0.032, 0.21), bladeMat);
    blade.position.set(0, 0.01, -0.16);
    const tip = new THREE.Mesh(new THREE.ConeGeometry(0.019, 0.075, 4), bladeMat);
    tip.position.set(0, 0.01, -0.29);
    tip.rotation.x = -Math.PI / 2;
    proceduralKnifeRoot.add(hL, hR, blade, tip);
  } else if (knifeId === "kunai-obsidian") {
    const pommelRing = new THREE.Mesh(new THREE.TorusGeometry(0.028, 0.007, 10, 20), edgeGlowMat);
    pommelRing.position.set(0, 0, 0.09);
    pommelRing.rotation.y = Math.PI / 2;
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.13, 8), gripMat);
    shaft.rotation.x = Math.PI / 2;
    shaft.position.set(0, 0, 0.0);
    const spear = new THREE.Mesh(new THREE.ConeGeometry(0.034, 0.24, 4), bladeMat);
    spear.position.set(0, 0.0, -0.18);
    spear.rotation.x = -Math.PI / 2;
    proceduralKnifeRoot.add(pommelRing, shaft, spear);
  } else if (knifeId === "kukri-solstice") {
    const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.02, 0.14, 10), gripMat);
    handle.rotation.x = Math.PI / 2;
    handle.position.set(0, -0.01, 0.02);
    const belly = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.052, 0.16), bladeMat);
    belly.position.set(0, 0.01, -0.12);
    belly.rotation.x = -0.18;
    const tip = new THREE.Mesh(new THREE.ConeGeometry(0.03, 0.14, 4), edgeGlowMat);
    tip.position.set(0, -0.012, -0.24);
    tip.rotation.x = -Math.PI * 0.58;
    proceduralKnifeRoot.add(handle, belly, tip);
  } else {
    const isBowie = knifeId === "bowie-vanguard";
    const handle = new THREE.Mesh(new THREE.BoxGeometry(0.024, 0.036, 0.14), gripMat);
    handle.position.set(0, -0.005, 0.03);
    const pommel = new THREE.Mesh(new THREE.BoxGeometry(0.028, 0.04, 0.022), edgeGlowMat);
    pommel.position.set(0, -0.005, 0.11);
    const crossguard = new THREE.Mesh(
      new THREE.BoxGeometry(0.045, isBowie ? 0.075 : 0.062, 0.018),
      edgeGlowMat,
    );
    crossguard.position.set(0, 0.005, -0.05);
    const blade = new THREE.Mesh(
      new THREE.BoxGeometry(0.01, isBowie ? 0.046 : 0.028, isBowie ? 0.24 : 0.22),
      bladeMat,
    );
    blade.position.set(0, 0.012, -0.18);
    const fuller = new THREE.Mesh(new THREE.BoxGeometry(0.013, 0.008, 0.15), edgeGlowMat);
    fuller.position.set(0, 0.012, -0.16);
    const tip = new THREE.Mesh(new THREE.ConeGeometry(isBowie ? 0.026 : 0.018, 0.08, 4), bladeMat);
    tip.position.set(0, 0.012, -0.32);
    tip.rotation.x = -Math.PI / 2;
    proceduralKnifeRoot.add(handle, pommel, crossguard, blade, fuller, tip);
  }

  const knifeSpec = EXTERNAL_KNIFE_MODELS[knifeId] || EXTERNAL_KNIFE_MODELS["karambit-aether"];
  loadExternalModel(knifeSpec.url, { targetSize: knifeSpec.targetSize, groundAtZero: false })
    .then((extKnife) => {
      if (!extKnife) return;
      if (group.userData.disposed) {
        disposeSafeHierarchy(extKnife);
        return;
      }
      applyWeaponSkinToExternalModel(extKnife, skin.id, skinTex);
      extKnife.rotation.set(-Math.PI * 0.44, 0, Math.PI / 2);
      extKnife.position.set(0, 0.008, -0.12);
      proceduralKnifeRoot.visible = false;
      bladePivot.add(extKnife);
    })
    .catch(() => {
      // Keep procedural knife fallback visible
    });

  const flash = new THREE.Mesh(
    new THREE.OctahedronGeometry(0.02, 0),
    new THREE.MeshBasicMaterial({ visible: false }),
  );
  group.add(flash);
  return { group, muzzleFlash: flash, bladePivot };
}

/**
 * Multi-part studio-grade Firearm builder (12–18 sculpted sub-meshes per weapon)
 * applying active WeaponSkinId PBR + CanvasTexture plus animated bolt/slide and magazine parts.
 */
export function buildDetailedWeaponMesh(
  weaponId: WeaponId,
  skinId: WeaponSkinId = "standard",
  knifeId: KnifeModelId = "karambit-aether",
): DetailedWeaponBundle {
  if (weaponId === "knife") {
    return buildDetailedKnifeMesh(knifeId, skinId);
  }

  const spec = WEAPONS_BY_ID[weaponId];
  const skin = WEAPON_SKINS_BY_ID[skinId] || WEAPON_SKINS_BY_ID.standard;
  const skinTex = createWeaponSkinTexture(skin.id);
  const group = new THREE.Group();
  const proceduralRoot = new THREE.Group();
  group.add(proceduralRoot);

  const bodyMat = new THREE.MeshPhysicalMaterial({
    map: skinTex,
    color: skin.id === "standard" ? spec.colorHex : 0xffffff,
    metalness: skin.metalness,
    roughness: skin.roughness,
    clearcoat: skin.clearcoat,
    emissive: new THREE.Color(skin.accentHex),
    emissiveIntensity: skin.emissiveIntensity * 0.32,
  });
  const accentMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(skin.id === "standard" ? `#${spec.accentHex.toString(16).padStart(6, "0")}` : skin.accentHex),
    emissive: new THREE.Color(skin.accentHex),
    emissiveIntensity: skin.emissiveIntensity * 0.5,
    metalness: 0.78,
    roughness: 0.22,
  });
  const darkMetalMat = new THREE.MeshStandardMaterial({
    color: 0x161920,
    metalness: 0.72,
    roughness: 0.36,
  });
  const opticGlassMat = new THREE.MeshPhysicalMaterial({
    color: 0x22d3ee,
    emissive: 0x0ea5e9,
    emissiveIntensity: 0.45,
    roughness: 0.08,
    metalness: 0.2,
    clearcoat: 1,
  });

  let boltOrSlide: THREE.Object3D | undefined;
  let magMesh: THREE.Object3D | undefined;

  if (weaponId === "starter_pistol" || weaponId === "pistol") {
    const isHeavy = weaponId === "pistol";
    const slide = new THREE.Group();
    const slideBody = new THREE.Mesh(
      new THREE.BoxGeometry(isHeavy ? 0.064 : 0.056, isHeavy ? 0.056 : 0.048, isHeavy ? 0.34 : 0.28),
      bodyMat,
    );
    const rearSight = new THREE.Mesh(new THREE.BoxGeometry(0.046, 0.015, 0.022), accentMat);
    rearSight.position.set(0, 0.032, isHeavy ? 0.13 : 0.1);
    const frontSight = new THREE.Mesh(new THREE.BoxGeometry(0.016, 0.016, 0.016), opticGlassMat);
    frontSight.position.set(0, 0.032, isHeavy ? -0.14 : -0.11);
    slide.add(slideBody, rearSight, frontSight);
    slide.position.set(0, 0.028, isHeavy ? -0.16 : -0.14);
    boltOrSlide = slide;

    const frame = new THREE.Mesh(
      new THREE.BoxGeometry(isHeavy ? 0.056 : 0.05, 0.03, isHeavy ? 0.31 : 0.26),
      darkMetalMat,
    );
    frame.position.set(0, -0.012, isHeavy ? -0.15 : -0.13);
    const rail = new THREE.Mesh(
      new THREE.BoxGeometry(0.04, 0.016, isHeavy ? 0.09 : 0.06),
      accentMat,
    );
    rail.position.set(0, -0.032, isHeavy ? -0.24 : -0.19);
    const triggerGuard = new THREE.Mesh(new THREE.BoxGeometry(0.022, 0.034, 0.062), darkMetalMat);
    triggerGuard.position.set(0, -0.038, -0.12);
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.052, 0.14, 0.074), bodyMat);
    grip.position.set(0, -0.078, -0.03);
    grip.rotation.x = 0.24;

    const mag = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.115, 0.055), darkMetalMat);
    mag.position.set(0, -0.098, -0.025);
    mag.rotation.x = 0.24;
    magMesh = mag;

    const barrel = new THREE.Mesh(
      new THREE.CylinderGeometry(0.013, 0.013, isHeavy ? 0.08 : 0.05, 10),
      darkMetalMat,
    );
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.025, isHeavy ? -0.35 : -0.29);

    proceduralRoot.add(slide, frame, rail, triggerGuard, grip, mag, barrel);
  } else if (weaponId === "shotgun") {
    const rec = new THREE.Mesh(new THREE.BoxGeometry(0.088, 0.1, 0.36), bodyMat);
    rec.position.set(0, 0, -0.14);
    const stock = new THREE.Mesh(new THREE.BoxGeometry(0.072, 0.11, 0.24), darkMetalMat);
    stock.position.set(0, -0.022, 0.14);
    stock.rotation.x = 0.12;
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.058, 0.12, 0.07), darkMetalMat);
    grip.position.set(0, -0.075, -0.01);
    grip.rotation.x = 0.3;

    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.022, 0.62, 12), darkMetalMat);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.034, -0.58);
    const heatShield = new THREE.Mesh(new THREE.BoxGeometry(0.054, 0.028, 0.44), accentMat);
    heatShield.position.set(0, 0.048, -0.5);
    const tube = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.016, 0.54, 10), darkMetalMat);
    tube.rotation.x = Math.PI / 2;
    tube.position.set(0, -0.016, -0.54);

    const pump = new THREE.Mesh(new THREE.BoxGeometry(0.078, 0.068, 0.22), bodyMat);
    pump.position.set(0, -0.024, -0.45);
    boltOrSlide = pump;

    const shellHolder = new THREE.Mesh(new THREE.BoxGeometry(0.098, 0.042, 0.14), accentMat);
    shellHolder.position.set(-0.008, 0.004, -0.15);
    magMesh = shellHolder;

    proceduralRoot.add(rec, stock, grip, barrel, heatShield, tube, pump, shellHolder);
  } else if (weaponId === "sniper") {
    const rec = new THREE.Mesh(new THREE.BoxGeometry(0.088, 0.11, 0.48), bodyMat);
    rec.position.set(0, 0, -0.2);
    const stock = new THREE.Mesh(new THREE.BoxGeometry(0.068, 0.125, 0.26), darkMetalMat);
    stock.position.set(0, -0.018, 0.15);
    const cheekRest = new THREE.Mesh(new THREE.BoxGeometry(0.074, 0.028, 0.14), accentMat);
    cheekRest.position.set(0, 0.052, 0.14);
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.024, 0.84, 12), darkMetalMat);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.02, -0.78);
    const muzzleBrake = new THREE.Mesh(new THREE.BoxGeometry(0.048, 0.048, 0.12), accentMat);
    muzzleBrake.position.set(0, 0.02, -1.16);
    const bipod = new THREE.Mesh(new THREE.BoxGeometry(0.082, 0.036, 0.1), darkMetalMat);
    bipod.position.set(0, -0.05, -0.62);

    const scopeTube = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.028, 0.34, 14), darkMetalMat);
    scopeTube.rotation.x = Math.PI / 2;
    scopeTube.position.set(0, 0.1, -0.22);
    const scopeBell = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.028, 0.1, 14), bodyMat);
    scopeBell.rotation.x = Math.PI / 2;
    scopeBell.position.set(0, 0.1, -0.4);
    const scopeLens = new THREE.Mesh(new THREE.CylinderGeometry(0.034, 0.034, 0.015, 14), opticGlassMat);
    scopeLens.rotation.x = Math.PI / 2;
    scopeLens.position.set(0, 0.1, -0.448);

    const bolt = new THREE.Mesh(new THREE.BoxGeometry(0.095, 0.026, 0.12), accentMat);
    bolt.position.set(0.012, 0.024, -0.14);
    boltOrSlide = bolt;

    const mag = new THREE.Mesh(new THREE.BoxGeometry(0.052, 0.14, 0.11), darkMetalMat);
    mag.position.set(0, -0.1, -0.26);
    magMesh = mag;

    proceduralRoot.add(rec, stock, cheekRest, barrel, muzzleBrake, bipod, scopeTube, scopeBell, scopeLens, bolt, mag);
  } else if (weaponId === "smg") {
    const rec = new THREE.Mesh(new THREE.BoxGeometry(0.084, 0.11, 0.34), bodyMat);
    rec.position.set(0, 0, -0.16);
    const shroud = new THREE.Mesh(new THREE.BoxGeometry(0.072, 0.078, 0.18), accentMat);
    shroud.position.set(0, 0.008, -0.36);
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.016, 0.14, 10), darkMetalMat);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.012, -0.49);
    const wireStock = new THREE.Mesh(new THREE.BoxGeometry(0.056, 0.088, 0.16), darkMetalMat);
    wireStock.position.set(0, -0.012, 0.08);
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.052, 0.12, 0.068), darkMetalMat);
    grip.position.set(0, -0.09, -0.04);
    grip.rotation.x = 0.22;

    const mag = new THREE.Mesh(new THREE.BoxGeometry(0.044, 0.21, 0.062), accentMat);
    mag.position.set(0, -0.135, -0.24);
    mag.rotation.x = -0.14;
    magMesh = mag;

    const holoFrame = new THREE.Mesh(new THREE.BoxGeometry(0.054, 0.046, 0.076), darkMetalMat);
    holoFrame.position.set(0, 0.078, -0.16);
    const holoGlass = new THREE.Mesh(new THREE.BoxGeometry(0.038, 0.03, 0.01), opticGlassMat);
    holoGlass.position.set(0, 0.082, -0.18);

    const bolt = new THREE.Mesh(new THREE.BoxGeometry(0.092, 0.022, 0.075), accentMat);
    bolt.position.set(0, 0.022, -0.18);
    boltOrSlide = bolt;

    proceduralRoot.add(rec, shroud, barrel, wireStock, grip, mag, holoFrame, holoGlass, bolt);
  } else {
    const upper = new THREE.Mesh(new THREE.BoxGeometry(0.084, 0.075, 0.42), bodyMat);
    upper.position.set(0, 0.02, -0.18);
    const lower = new THREE.Mesh(new THREE.BoxGeometry(0.078, 0.064, 0.32), darkMetalMat);
    lower.position.set(0, -0.032, -0.14);
    const handguard = new THREE.Mesh(new THREE.BoxGeometry(0.074, 0.076, 0.28), bodyMat);
    handguard.position.set(0, 0.012, -0.46);
    const railTop = new THREE.Mesh(new THREE.BoxGeometry(0.046, 0.018, 0.46), accentMat);
    railTop.position.set(0, 0.064, -0.32);
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.018, 0.26, 12), darkMetalMat);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.016, -0.71);
    const compensator = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.02, 0.07, 10), accentMat);
    compensator.rotation.x = Math.PI / 2;
    compensator.position.set(0, 0.016, -0.84);
    const stock = new THREE.Mesh(new THREE.BoxGeometry(0.064, 0.11, 0.22), darkMetalMat);
    stock.position.set(0, -0.014, 0.12);
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.052, 0.13, 0.072), darkMetalMat);
    grip.position.set(0, -0.095, -0.02);
    grip.rotation.x = 0.26;
    const foregrip = new THREE.Mesh(new THREE.BoxGeometry(0.042, 0.09, 0.046), darkMetalMat);
    foregrip.position.set(0, -0.065, -0.46);

    const mag = new THREE.Mesh(new THREE.BoxGeometry(0.048, 0.19, 0.078), bodyMat);
    mag.position.set(0, -0.13, -0.25);
    mag.rotation.x = -0.22;
    magMesh = mag;

    const optic = new THREE.Mesh(new THREE.BoxGeometry(0.054, 0.048, 0.095), darkMetalMat);
    optic.position.set(0, 0.095, -0.18);
    const opticLens = new THREE.Mesh(new THREE.BoxGeometry(0.036, 0.032, 0.01), opticGlassMat);
    opticLens.position.set(0, 0.096, -0.22);

    const bolt = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.022, 0.085), accentMat);
    bolt.position.set(0.005, 0.024, -0.16);
    boltOrSlide = bolt;

    proceduralRoot.add(
      upper,
      lower,
      handguard,
      railTop,
      barrel,
      compensator,
      stock,
      grip,
      foregrip,
      mag,
      optic,
      opticLens,
      bolt,
    );
  }

  const flashGeo = new THREE.OctahedronGeometry(0.095, 0);
  const flashMat = new THREE.MeshBasicMaterial({
    color: 0xffd266,
    transparent: true,
    opacity: 0.92,
  });
  const muzzleFlash = new THREE.Mesh(flashGeo, flashMat);
  muzzleFlash.position.set(
    0,
    0.02,
    weaponId === "sniper" ? -1.24 : weaponId === "carbine" ? -0.9 : weaponId === "starter_pistol" ? -0.34 : -0.74,
  );
  muzzleFlash.visible = false;
  group.add(muzzleFlash);

  // Asynchronously replace procedural firearm geometry with real downloaded 3D GLB model + skin customization
  const extSpec = EXTERNAL_WEAPON_MODELS[weaponId];
  if (extSpec) {
    loadExternalModel(extSpec.url, { targetSize: extSpec.targetSize, groundAtZero: false })
      .then((extWeapon) => {
        if (!extWeapon) return;
        if (group.userData.disposed) {
          disposeSafeHierarchy(extWeapon);
          return;
        }
        applyWeaponSkinToExternalModel(extWeapon, skin.id, skinTex);
        extWeapon.rotation.y = Math.PI / 2;
        extWeapon.position.set(extSpec.offset[0], extSpec.offset[1], extSpec.offset[2]);
        proceduralRoot.visible = false;
        muzzleFlash.position.z = extSpec.muzzleZ;
        group.add(extWeapon);
      })
      .catch(() => {
        // Keep procedural weapon geometry as fallback
      });
  }

  return { group, muzzleFlash, boltOrSlide, magMesh };
}

export function buildFirstPersonWeapon(
  weaponId: WeaponId,
  teamColorHex: number = 0xe69f3a,
  skinId: WeaponSkinId = "standard",
  knifeId: KnifeModelId = "karambit-aether",
  gloveHex: string = "#22262e",
): DetailedWeaponBundle {
  const detail = buildDetailedWeaponMesh(weaponId, skinId, knifeId);
  const group = new THREE.Group();

  const sleeveMat = new THREE.MeshStandardMaterial({
    color: teamColorHex,
    roughness: 0.62,
    metalness: 0.12,
  });
  const gloveMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(gloveHex),
    roughness: 0.7,
    metalness: 0.15,
  });

  const rightArm = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.11, 0.32), sleeveMat);
  rightArm.position.set(0.08, -0.1, 0.08);
  rightArm.rotation.set(0.15, -0.2, 0);

  const rightHand = new THREE.Mesh(new THREE.BoxGeometry(0.085, 0.095, 0.1), gloveMat);
  rightHand.position.set(0.01, -0.06, -0.08);

  group.add(rightArm, rightHand);

  if (weaponId !== "knife") {
    const leftArm = new THREE.Mesh(new THREE.BoxGeometry(0.105, 0.105, 0.34), sleeveMat);
    leftArm.position.set(-0.14, -0.09, -0.12);
    leftArm.rotation.set(0.18, 0.48, 0);

    const leftHand = new THREE.Mesh(new THREE.BoxGeometry(0.082, 0.088, 0.1), gloveMat);
    leftHand.position.set(-0.02, -0.04, -0.28);
    group.add(leftArm, leftHand);
  }

  group.add(detail.group);

  return {
    group,
    muzzleFlash: detail.muzzleFlash,
    boltOrSlide: detail.boltOrSlide,
    magMesh: detail.magMesh,
    bladePivot: detail.bladePivot,
  };
}

function makeNameplateTexture(label: string, color: string, teamTag: string): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 64;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = "rgba(14, 18, 26, 0.86)";
  ctx.fillRect(6, 10, 244, 44);
  ctx.strokeStyle = color;
  ctx.lineWidth = 4;
  ctx.strokeRect(6, 10, 244, 44);
  ctx.fillStyle = color;
  ctx.fillRect(10, 14, 44, 36);
  ctx.fillStyle = "#11151d";
  ctx.font = "900 18px sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(teamTag, 32, 33);

  ctx.fillStyle = "#f4f6f9";
  ctx.font = "bold 20px monospace";
  ctx.textAlign = "left";
  ctx.fillText(label.slice(0, 13), 62, 33);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export interface BlockyCharacterRig {
  group: THREE.Group;
  bodyPivot: THREE.Group;
  headGroup: THREE.Group;
  leftLegPivot: THREE.Group;
  rightLegPivot: THREE.Group;
  leftArmPivot: THREE.Group;
  rightArmPivot: THREE.Group;
  muzzleFlash: THREE.Mesh;
  nameSprite: THREE.Sprite;
  hpBarFill: THREE.Mesh;
}

export function buildOperativeModel(
  team: TeamId,
  name: string,
  customization?: OperativeCustomization,
  weaponId: Exclude<WeaponId, "knife"> = "carbine",
): BlockyCharacterRig {
  const group = new THREE.Group();
  const isVanguard = team === "vanguard";
  const teamPrimary = isVanguard ? 0xe69f3a : 0x3b86d1;
  const teamAccent = customization?.visorHex
    ? new THREE.Color(customization.visorHex)
    : new THREE.Color(isVanguard ? 0xffcf70 : 0x67d4ff);
  const trimColor = customization?.armorTrimHex
    ? new THREE.Color(customization.armorTrimHex)
    : new THREE.Color(isVanguard ? 0x3a3228 : 0x253247);
  const pantsHex = isVanguard ? 0x2b2d34 : 0x232c3d;
  const skinHex = 0xe8c39e;

  const shirtMat = new THREE.MeshStandardMaterial({ color: teamPrimary, roughness: 0.58, metalness: 0.14 });
  const pantsMat = new THREE.MeshStandardMaterial({ color: pantsHex, roughness: 0.72, metalness: 0.1 });
  const vestMat = new THREE.MeshStandardMaterial({ color: trimColor, roughness: 0.42, metalness: 0.45 });
  const visorMat = new THREE.MeshStandardMaterial({
    color: teamAccent,
    emissive: teamAccent,
    emissiveIntensity: 0.75,
    roughness: 0.18,
    metalness: 0.8,
  });
  const skinMat = new THREE.MeshStandardMaterial({ color: skinHex, roughness: 0.65, metalness: 0.04 });
  const gunMat = new THREE.MeshStandardMaterial({ color: 0x1e222a, roughness: 0.35, metalness: 0.75 });

  const shadowGeo = new THREE.CircleGeometry(0.58, 18);
  shadowGeo.rotateX(-Math.PI / 2);
  const shadowMat = new THREE.MeshBasicMaterial({
    color: 0x090b10,
    transparent: true,
    opacity: 0.36,
    depthWrite: false,
  });
  const shadow = new THREE.Mesh(shadowGeo, shadowMat);
  shadow.position.y = 0.02;
  group.add(shadow);

  const bodyPivot = new THREE.Group();
  group.add(bodyPivot);

  const makeLeg = (xOff: number) => {
    const legPivot = new THREE.Group();
    legPivot.position.set(xOff, 0.74, 0);
    const upper = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.56, 0.32), pantsMat);
    upper.position.y = -0.28;
    upper.castShadow = true;
    const boot = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.2, 0.36), vestMat);
    boot.position.set(0, -0.64, 0.02);
    boot.castShadow = true;
    legPivot.add(upper, boot);
    return legPivot;
  };
  const leftLegPivot = makeLeg(-0.17);
  const rightLegPivot = makeLeg(0.17);
  bodyPivot.add(leftLegPivot, rightLegPivot);

  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.68, 0.38), shirtMat);
  torso.position.y = 1.08;
  torso.castShadow = true;

  const vest = new THREE.Mesh(new THREE.BoxGeometry(0.74, 0.46, 0.43), vestMat);
  vest.position.y = 1.12;
  vest.castShadow = true;

  const emblem = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.16, 0.46), visorMat);
  emblem.position.y = 1.18;

  const belt = new THREE.Mesh(new THREE.BoxGeometry(0.74, 0.12, 0.42), gunMat);
  belt.position.y = 0.8;

  const pack = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.42, 0.18), vestMat);
  pack.position.set(0, 1.12, -0.27);
  pack.castShadow = true;

  bodyPivot.add(torso, vest, emblem, belt, pack);

  const headGroup = new THREE.Group();
  headGroup.position.set(0, 1.66, 0);

  const headBlock = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.42, 14), skinMat);
  headBlock.castShadow = true;

  const helmet = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.22, 0.52), vestMat);
  helmet.position.set(0, 0.14, 0);
  helmet.castShadow = true;

  const helmStripe = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.24, 0.54), shirtMat);
  helmStripe.position.set(0, 0.15, 0);

  const visor = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.13, 0.1), visorMat);
  visor.position.set(0, 0.03, 0.22);

  headGroup.add(headBlock, helmet, helmStripe, visor);
  bodyPivot.add(headGroup);

  const leftArmPivot = new THREE.Group();
  leftArmPivot.position.set(-0.48, 1.34, 0);
  const leftArmMesh = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.62, 0.26), shirtMat);
  leftArmMesh.position.y = -0.25;
  leftArmMesh.castShadow = true;
  leftArmPivot.add(leftArmMesh);
  leftArmPivot.rotation.x = -0.45;

  const rightArmPivot = new THREE.Group();
  rightArmPivot.position.set(0.48, 1.34, 0);
  const rightArmMesh = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.62, 0.26), shirtMat);
  rightArmMesh.position.y = -0.25;
  rightArmMesh.castShadow = true;
  rightArmPivot.rotation.x = -0.95;

  const gunBody = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.14, 0.68), gunMat);
  gunBody.position.set(-0.08, -0.48, 0.32);
  gunBody.castShadow = true;

  const gunAccent = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.05, 0.32), visorMat);
  gunAccent.position.set(-0.08, -0.42, 0.28);

  const flash = new THREE.Mesh(
    new THREE.OctahedronGeometry(0.12, 0),
    new THREE.MeshBasicMaterial({ color: 0xffd166 }),
  );
  flash.position.set(-0.08, -0.48, 0.72);
  flash.visible = false;

  rightArmPivot.add(rightArmMesh, gunBody, gunAccent, flash);
  bodyPivot.add(leftArmPivot, rightArmPivot);

  const gunSpec = EXTERNAL_WEAPON_MODELS[weaponId] || EXTERNAL_WEAPON_MODELS.carbine;
  loadExternalModel(gunSpec.url, { targetSize: gunSpec.targetSize * 0.92, groundAtZero: false })
    .then((extGun) => {
      if (!extGun) return;
      if (group.userData.disposed) {
        disposeSafeHierarchy(extGun);
        return;
      }
      extGun.rotation.y = -Math.PI / 2;
      extGun.position.set(-0.08, -0.46, 0.32);
      gunBody.visible = false;
      gunAccent.visible = false;
      rightArmPivot.add(extGun);
    })
    .catch(() => {});

  const teamTag = customization?.badgeTag?.slice(0, 3).toUpperCase() || (isVanguard ? "VNG" : "SYN");
  const badgeColor = isVanguard ? "#f2a93b" : "#4cc4ff";
  const plateTex = makeNameplateTexture(name, badgeColor, teamTag);
  const nameSprite = new THREE.Sprite(
    new THREE.SpriteMaterial({ map: plateTex, transparent: true }),
  );
  nameSprite.position.set(0, 2.34, 0);
  nameSprite.scale.set(1.75, 0.44, 1);

  const hpBg = new THREE.Mesh(
    new THREE.PlaneGeometry(0.95, 0.09),
    new THREE.MeshBasicMaterial({ color: 0x10141c, side: THREE.DoubleSide }),
  );
  hpBg.position.set(0, 2.08, 0);

  const hpBarFill = new THREE.Mesh(
    new THREE.PlaneGeometry(0.9, 0.06),
    new THREE.MeshBasicMaterial({ color: isVanguard ? 0xf2a93b : 0x4cc4ff, side: THREE.DoubleSide }),
  );
  hpBarFill.position.set(0, 2.08, 0.01);

  group.add(nameSprite, hpBg, hpBarFill);

  return {
    group,
    bodyPivot,
    headGroup,
    leftLegPivot,
    rightLegPivot,
    leftArmPivot,
    rightArmPivot,
    muzzleFlash: flash,
    nameSprite,
    hpBarFill,
  };
}
