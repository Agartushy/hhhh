import {
  SCOUT_SPAWNS,
  TITAN_SPAWN_POINTS,
  resolveTitanCityPush,
} from "./cityData";
import type { TitanVariant } from "./models";
import type { TitanPowerId } from "./powers";

const PLAYER_COLORS = ["#e0a94f", "#5ec2f2", "#7ad979", "#ea7a66"];

export interface HostScout {
  id: string;
  name: string;
  color: string;
  slot: number;
  x: number;
  y: number;
  z: number;
  yaw: number;
  hp: number;
  maxHp: number;
  alive: boolean;
  respawnTimer: number;
  kills: number;
  score: number;
  shifterForm: TitanPowerId | null;
  hookLeft: { active: boolean; x: number; y: number; z: number } | null;
  hookRight: { active: boolean; x: number; y: number; z: number } | null;
}

export interface HostTitanEntity {
  id: string;
  variant: TitanVariant;
  x: number;
  z: number;
  yaw: number;
  hp: number;
  maxHp: number;
  height: number;
  speed: number;
  bodyRadius: number;
  attackCooldown: number;
  telegraphTimer: number;
  staggerTimer: number;
}

export interface HostTitanSnapshot {
  type: "titan:snapshot";
  code: string;
  title: string;
  wave: number;
  maxWaves: number;
  status: "ACTIVE" | "VICTORY" | "DEFEAT";
  teamScore: number;
  players: {
    id: string;
    name: string;
    color: string;
    x: number;
    y: number;
    z: number;
    yaw: number;
    hp: number;
    maxHp: number;
    alive: boolean;
    respawnTimer: number;
    kills: number;
    score: number;
    shifterForm: TitanPowerId | null;
    hookLeft: { active: boolean; x: number; y: number; z: number } | null;
    hookRight: { active: boolean; x: number; y: number; z: number } | null;
  }[];
  titans: {
    id: string;
    variant: TitanVariant;
    x: number;
    z: number;
    yaw: number;
    hp: number;
    maxHp: number;
    height: number;
    telegraphTimer: number;
    staggerTimer: number;
  }[];
}

export interface TitanOutgoingEvent {
  targetId?: string;
  payload: Record<string, unknown>;
}

export class TitanRoomHost {
  code: string;
  title: string;
  wave = 1;
  maxWaves = 4;
  status: "ACTIVE" | "VICTORY" | "DEFEAT" = "ACTIVE";
  teamScore = 0;
  players = new Map<string, HostScout>();
  titans: HostTitanEntity[] = [];
  nextTitanSeq = 1;

  constructor(code: string, title: string) {
    this.code = code;
    this.title = title.trim().slice(0, 36) || `Wall Rose Squad ${code}`;
    this.spawnWave(1);
  }

  static fromSnapshot(snap: HostTitanSnapshot): TitanRoomHost {
    const host = new TitanRoomHost(snap.code, snap.title);
    host.wave = snap.wave;
    host.maxWaves = snap.maxWaves;
    host.status = snap.status;
    host.teamScore = snap.teamScore;
    host.players.clear();
    snap.players.forEach((p, idx) => {
      host.players.set(p.id, {
        ...p,
        slot: idx,
      });
    });
    host.titans = snap.titans.map((t) => ({
      ...t,
      speed:
        t.variant === "colossal"
          ? 2.6
          : t.variant === "armored"
            ? 4.2
            : t.variant === "abnormal"
              ? 6.8
              : 4.5,
      bodyRadius: (t.height / 10) * 1.9,
      attackCooldown: 1.5,
    }));
    host.nextTitanSeq = snap.titans.length + 10;
    return host;
  }

  private spawnWave(wave: number) {
    this.titans = [];
    const count = wave === 1 ? 5 : wave === 2 ? 6 : wave === 3 ? 7 : 6;
    for (let i = 0; i < count; i++) {
      const sp = TITAN_SPAWN_POINTS[i % TITAN_SPAWN_POINTS.length];
      let variant: TitanVariant = "pure";
      if (wave === 2 && i % 2 === 0) variant = "abnormal";
      else if (wave === 3) variant = i < 2 ? "armored" : i % 2 === 0 ? "abnormal" : "pure";
      else if (wave >= 4) variant = i === 0 ? "colossal" : i < 3 ? "armored" : "abnormal";

      const maxHp =
        variant === "colossal"
          ? 560
          : variant === "armored"
            ? 260
            : variant === "abnormal"
              ? 150
              : 100;
      const height =
        variant === "colossal"
          ? 23
          : variant === "armored"
            ? 15.5
            : variant === "abnormal"
              ? 11.5
              : 8.5;
      const speed =
        variant === "colossal"
          ? 2.6
          : variant === "armored"
            ? 4.2
            : variant === "abnormal"
              ? 6.8
              : 4.5;

      this.titans.push({
        id: `T-${++this.nextTitanSeq}`,
        variant,
        x: sp.x + (Math.random() - 0.5) * 6,
        z: sp.z + (Math.random() - 0.5) * 6,
        yaw: 0,
        hp: maxHp,
        maxHp,
        height,
        speed,
        bodyRadius: (height / 10) * 1.9,
        attackCooldown: 1.5 + Math.random() * 1.2,
        telegraphTimer: 0,
        staggerTimer: 0,
      });
    }
  }

  addScout(
    playerId: string,
    rawName: string,
  ): {
    ok: boolean;
    error?: string;
    spawn?: { x: number; y: number; z: number; yaw: number };
    events: TitanOutgoingEvent[];
  } {
    const existing = this.players.get(playerId);
    if (existing) {
      return {
        ok: true,
        spawn: { x: existing.x, y: existing.y, z: existing.z, yaw: existing.yaw },
        events: [],
      };
    }
    if (this.players.size >= 4) {
      return { ok: false, error: `Scout Room ${this.code} is full (4/4 Scouts).`, events: [] };
    }
    const usedSlots = new Set(Array.from(this.players.values()).map((p) => p.slot));
    let slot = 0;
    while (usedSlots.has(slot)) slot++;
    const spawn = SCOUT_SPAWNS[slot % SCOUT_SPAWNS.length];
    const scout: HostScout = {
      id: playerId,
      name: rawName.trim().slice(0, 18) || `Scout-${slot + 1}`,
      color: PLAYER_COLORS[slot % PLAYER_COLORS.length],
      slot,
      x: spawn.x,
      y: spawn.y,
      z: spawn.z,
      yaw: spawn.yaw,
      hp: 100,
      maxHp: 100,
      alive: true,
      respawnTimer: 0,
      kills: 0,
      score: 0,
      shifterForm: null,
      hookLeft: null,
      hookRight: null,
    };
    this.players.set(playerId, scout);
    return {
      ok: true,
      spawn,
      events: [
        {
          targetId: playerId,
          payload: {
            type: "titan:joined",
            playerId,
            playerColor: scout.color,
            spawn,
            snapshot: this.serializeSnapshot(),
          },
        },
        {
          payload: {
            type: "scout:joined",
            playerId,
            playerName: scout.name,
          },
        },
      ],
    };
  }

  removeScout(playerId: string): TitanOutgoingEvent[] {
    const s = this.players.get(playerId);
    if (!s) return [];
    this.players.delete(playerId);
    return [{ payload: { type: "scout:left", playerId, playerName: s.name } }];
  }

  handleScoutState(playerId: string, msg: Record<string, unknown>) {
    const scout = this.players.get(playerId);
    if (!scout) return;
    if (typeof msg.x === "number" && Number.isFinite(msg.x)) scout.x = msg.x;
    if (typeof msg.y === "number" && Number.isFinite(msg.y)) scout.y = msg.y;
    if (typeof msg.z === "number" && Number.isFinite(msg.z)) scout.z = msg.z;
    if (typeof msg.yaw === "number" && Number.isFinite(msg.yaw)) scout.yaw = msg.yaw;
    if (
      msg.shifterForm === "attack" ||
      msg.shifterForm === "armored" ||
      msg.shifterForm === "jaw" ||
      msg.shifterForm === "colossal" ||
      msg.shifterForm === null
    ) {
      scout.shifterForm = msg.shifterForm;
    }
    scout.hookLeft =
      msg.hookLeft && typeof msg.hookLeft === "object"
        ? (msg.hookLeft as { active: boolean; x: number; y: number; z: number })
        : null;
    scout.hookRight =
      msg.hookRight && typeof msg.hookRight === "object"
        ? (msg.hookRight as { active: boolean; x: number; y: number; z: number })
        : null;
  }

  handleScoutSlash(playerId: string, msg: Record<string, unknown>): TitanOutgoingEvent[] {
    const events: TitanOutgoingEvent[] = [];
    const scout = this.players.get(playerId);
    if (!scout || !scout.alive || this.status !== "ACTIVE") return events;

    const titanId = typeof msg.titanId === "string" ? msg.titanId : "";
    const rawDmg = typeof msg.damage === "number" && Number.isFinite(msg.damage) ? msg.damage : 40;
    const damage = Math.max(10, Math.min(650, Math.round(rawDmg)));
    const isNapeCrit = Boolean(msg.isNapeCrit);
    const staggerSec =
      typeof msg.staggerSec === "number" && Number.isFinite(msg.staggerSec)
        ? Math.min(4.0, Math.max(0, msg.staggerSec))
        : 0;
    const titan = this.titans.find((t) => t.id === titanId);
    if (!titan) return events;

    // Basic spatial plausibility validation
    if (Math.hypot(scout.x - titan.x, scout.z - titan.z) > 26) {
      return events;
    }

    titan.hp -= damage;
    if (staggerSec > 0) {
      titan.staggerTimer = Math.max(titan.staggerTimer, staggerSec);
      titan.telegraphTimer = 0;
    }

    let killed = false;
    if (titan.hp <= 0) {
      killed = true;
      scout.kills += 1;
      const pts =
        titan.variant === "colossal"
          ? 1000
          : titan.variant === "armored"
            ? 420
            : titan.variant === "abnormal"
              ? 260
              : 150;
      scout.score += pts;
      this.teamScore += pts;
      events.push({
        payload: {
          type: "titan:killed",
          titanId: titan.id,
          killerId: scout.id,
          killerName: scout.name,
          variant: titan.variant,
          x: titan.x,
          y: titan.height * 0.78,
          z: titan.z,
        },
      });
      this.titans = this.titans.filter((t) => t.id !== titan.id);
    }

    events.push({
      targetId: scout.id,
      payload: {
        type: "titan:slash_confirm",
        damage,
        isNapeCrit,
        staggered: staggerSec > 0,
        killed,
      },
    });
    return events;
  }

  resetExpedition(): TitanOutgoingEvent[] {
    this.wave = 1;
    this.status = "ACTIVE";
    this.teamScore = 0;
    const events: TitanOutgoingEvent[] = [];
    for (const p of this.players.values()) {
      const sp = SCOUT_SPAWNS[p.slot % SCOUT_SPAWNS.length];
      p.x = sp.x;
      p.y = sp.y;
      p.z = sp.z;
      p.yaw = sp.yaw;
      p.hp = p.maxHp;
      p.alive = true;
      p.respawnTimer = 0;
      p.kills = 0;
      p.score = 0;
      events.push({ targetId: p.id, payload: { type: "titan:restarted", spawn: sp } });
    }
    this.spawnWave(1);
    return events;
  }

  tick(dt: number): TitanOutgoingEvent[] {
    const events: TitanOutgoingEvent[] = [];
    if (this.status !== "ACTIVE") return events;

    const scoutList = Array.from(this.players.values());
    const livingScouts = scoutList.filter((s) => s.alive);

    for (const s of scoutList) {
      if (!s.alive) {
        s.respawnTimer -= dt;
        if (s.respawnTimer <= 0) {
          const sp = SCOUT_SPAWNS[s.slot % SCOUT_SPAWNS.length];
          s.x = sp.x;
          s.y = sp.y;
          s.z = sp.z;
          s.hp = s.maxHp;
          s.alive = true;
          s.respawnTimer = 0;
          events.push({ targetId: s.id, payload: { type: "scout:respawned", spawn: sp } });
        }
      }
    }

    for (const titan of this.titans) {
      if (livingScouts.length === 0) continue;
      let nearest = livingScouts[0];
      let bestDist = Math.hypot(nearest.x - titan.x, nearest.z - titan.z);
      for (let i = 1; i < livingScouts.length; i++) {
        const cand = livingScouts[i];
        const d = Math.hypot(cand.x - titan.x, cand.z - titan.z);
        if (d < bestDist) {
          nearest = cand;
          bestDist = d;
        }
      }

      const dx = nearest.x - titan.x;
      const dz = nearest.z - titan.z;
      const dHoriz = Math.max(0.01, Math.hypot(dx, dz));
      if (titan.staggerTimer > 0) {
        titan.staggerTimer = Math.max(0, titan.staggerTimer - dt);
        titan.telegraphTimer = 0;
        continue;
      }
      titan.yaw = Math.atan2(dx / dHoriz, dz / dHoriz);

      if (titan.telegraphTimer > 0) {
        titan.telegraphTimer -= dt;
        if (titan.telegraphTimer <= 0) {
          for (const s of livingScouts) {
            const sd = Math.hypot(s.x - titan.x, s.z - titan.z);
            if (sd < titan.bodyRadius * 2.15 && s.y < titan.height * 0.92) {
              const baseDmg =
                titan.variant === "colossal" ? 42 : titan.variant === "armored" ? 32 : 24;
              const resist =
                s.shifterForm === "armored"
                  ? 0.28
                  : s.shifterForm === "colossal"
                    ? 0.42
                    : s.shifterForm === "attack"
                      ? 0.55
                      : s.shifterForm === "jaw"
                        ? 0.65
                        : 1.0;
              const dmg = Math.max(4, Math.round(baseDmg * resist));
              s.hp = Math.max(0, s.hp - dmg);
              events.push({
                targetId: s.id,
                payload: { type: "scout:damaged", hp: Math.round(s.hp) },
              });
              if (s.hp <= 0) {
                s.alive = false;
                s.shifterForm = null;
                s.respawnTimer = 4.5;
              }
            }
          }
        }
      } else {
        if (dHoriz > titan.bodyRadius * 1.45) {
          const resolved = resolveTitanCityPush(
            titan.x + (dx / dHoriz) * titan.speed * dt,
            titan.z + (dz / dHoriz) * titan.speed * dt,
            titan.bodyRadius,
          );
          titan.x = resolved.x;
          titan.z = resolved.z;
        }
        titan.attackCooldown -= dt;
        if (
          titan.attackCooldown <= 0 &&
          dHoriz < titan.bodyRadius * 2.3 &&
          nearest.y < titan.height * 0.95
        ) {
          titan.telegraphTimer = 0.85;
          titan.attackCooldown = titan.variant === "abnormal" ? 2.4 : 3.2;
        }
      }
    }

    if (this.titans.length === 0) {
      if (this.wave < this.maxWaves) {
        this.wave += 1;
        this.teamScore += 350;
        this.spawnWave(this.wave);
        events.push({ payload: { type: "titan:wave_advanced", wave: this.wave } });
      } else {
        this.status = "VICTORY";
        this.teamScore += 1200;
      }
    }

    return events;
  }

  serializeSnapshot(): HostTitanSnapshot {
    return {
      type: "titan:snapshot",
      code: this.code,
      title: this.title,
      wave: this.wave,
      maxWaves: this.maxWaves,
      status: this.status,
      teamScore: this.teamScore,
      players: Array.from(this.players.values()).map((p) => ({
        id: p.id,
        name: p.name,
        color: p.color,
        x: Number(p.x.toFixed(2)),
        y: Number(p.y.toFixed(2)),
        z: Number(p.z.toFixed(2)),
        yaw: Number(p.yaw.toFixed(3)),
        hp: Math.round(p.hp),
        maxHp: p.maxHp,
        alive: p.alive,
        respawnTimer: Number(p.respawnTimer.toFixed(1)),
        kills: p.kills,
        score: p.score,
        shifterForm: p.shifterForm,
        hookLeft: p.hookLeft,
        hookRight: p.hookRight,
      })),
      titans: this.titans.map((t) => ({
        id: t.id,
        variant: t.variant,
        x: Number(t.x.toFixed(2)),
        z: Number(t.z.toFixed(2)),
        yaw: Number(t.yaw.toFixed(3)),
        hp: Math.round(t.hp),
        maxHp: t.maxHp,
        height: t.height,
        telegraphTimer: Number(t.telegraphTimer.toFixed(2)),
        staggerTimer: Number(t.staggerTimer.toFixed(2)),
      })),
    };
  }
}
