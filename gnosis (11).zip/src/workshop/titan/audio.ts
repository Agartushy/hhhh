export class OdmAudioEngine {
  private ctx: AudioContext | null = null;
  private muted = false;
  private volume = 0.82;
  private noiseBuf: AudioBuffer | null = null;
  private gasSource: AudioBufferSourceNode | null = null;
  private gasFilter: BiquadFilterNode | null = null;
  private gasGain: GainNode | null = null;

  public setMuted(muted: boolean) {
    this.muted = muted;
    if (muted && this.gasGain && this.ctx) {
      this.gasGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.04);
    }
  }

  public setVolume(v: number) {
    this.volume = Math.max(0, Math.min(1, v));
    if (this.volume <= 0.001 && this.gasGain && this.ctx) {
      this.gasGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.04);
    }
  }

  public initOnGesture() {
    if (typeof window === "undefined") return;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      this.ctx = new AudioCtx();

      const len = this.ctx.sampleRate * 2;
      const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < len; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      this.noiseBuf = buf;

      const src = this.ctx.createBufferSource();
      src.buffer = buf;
      src.loop = true;

      const filter = this.ctx.createBiquadFilter();
      filter.type = "bandpass";
      filter.frequency.value = 1450;
      filter.Q.value = 0.85;

      const gain = this.ctx.createGain();
      gain.gain.value = 0;

      src.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);
      src.start();

      this.gasSource = src;
      this.gasFilter = filter;
      this.gasGain = gain;
    }
    if (this.ctx.state === "suspended") {
      this.ctx.resume().catch(() => {});
    }
  }

  public updateGasIntensity(intensity: number) {
    if (!this.ctx || !this.gasGain || !this.gasFilter) return;
    const now = this.ctx.currentTime;
    if (this.muted || this.volume <= 0.001) {
      this.gasGain.gain.setTargetAtTime(0, now, 0.05);
      return;
    }
    const clamped = Math.max(0, Math.min(1, intensity));
    this.gasGain.gain.setTargetAtTime(clamped * 0.2 * this.volume, now, 0.04);
    this.gasFilter.frequency.setTargetAtTime(950 + clamped * 2050, now, 0.05);
  }

  public playGrappleLaunch() {
    if (this.muted || this.volume <= 0.001 || !this.ctx) return;
    const now = this.ctx.currentTime;
    const v = this.volume;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = "triangle";
    osc.frequency.setValueAtTime(1240, now);
    osc.frequency.exponentialRampToValueAtTime(360, now + 0.085);
    gain.gain.setValueAtTime(0.15 * v, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.11);

    const clink = this.ctx.createOscillator();
    const cg = this.ctx.createGain();
    clink.type = "sine";
    clink.frequency.setValueAtTime(2280, now + 0.045);
    clink.frequency.exponentialRampToValueAtTime(1480, now + 0.12);
    cg.gain.setValueAtTime(0.09 * v, now + 0.045);
    cg.gain.exponentialRampToValueAtTime(0.001, now + 0.13);
    clink.connect(cg);
    cg.connect(this.ctx.destination);
    clink.start(now + 0.045);
    clink.stop(now + 0.14);
  }

  public playHookRelease() {
    if (this.muted || this.volume <= 0.001 || !this.ctx) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(520, now);
    osc.frequency.exponentialRampToValueAtTime(210, now + 0.06);
    g.gain.setValueAtTime(0.06 * this.volume, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.07);
    osc.connect(g);
    g.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.075);
  }

  public playGasDash() {
    if (this.muted || this.volume <= 0.001 || !this.ctx || !this.noiseBuf) return;
    const now = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    const filter = this.ctx.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.setValueAtTime(2500, now);
    filter.frequency.exponentialRampToValueAtTime(750, now + 0.24);
    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.25 * this.volume, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.ctx.destination);
    src.start(now);
    src.stop(now + 0.26);
  }

  public playBladeSlash(speedKmh: number) {
    if (this.muted || this.volume <= 0.001 || !this.ctx || !this.noiseBuf) return;
    const now = this.ctx.currentTime;
    const v = this.volume;
    const speedFactor = Math.min(1.65, 0.8 + speedKmh / 105);

    const ring = this.ctx.createOscillator();
    const rg = this.ctx.createGain();
    ring.type = "sawtooth";
    ring.frequency.setValueAtTime(950 * speedFactor, now);
    ring.frequency.exponentialRampToValueAtTime(310, now + 0.16);
    rg.gain.setValueAtTime(0.11 * v, now);
    rg.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
    ring.connect(rg);
    rg.connect(this.ctx.destination);
    ring.start(now);
    ring.stop(now + 0.19);

    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    const filter = this.ctx.createBiquadFilter();
    filter.type = "highpass";
    filter.frequency.value = 1250;
    const ng = this.ctx.createGain();
    ng.gain.setValueAtTime(0.18 * v, now);
    ng.gain.exponentialRampToValueAtTime(0.001, now + 0.14);
    src.connect(filter);
    filter.connect(ng);
    ng.connect(this.ctx.destination);
    src.start(now);
    src.stop(now + 0.15);
  }

  public playNapeHit(isCriticalKill: boolean) {
    if (this.muted || this.volume <= 0.001 || !this.ctx) return;
    const now = this.ctx.currentTime;
    const v = this.volume;

    const thud = this.ctx.createOscillator();
    const tg = this.ctx.createGain();
    thud.type = "sine";
    thud.frequency.setValueAtTime(isCriticalKill ? 250 : 190, now);
    thud.frequency.exponentialRampToValueAtTime(46, now + (isCriticalKill ? 0.34 : 0.16));
    tg.gain.setValueAtTime((isCriticalKill ? 0.32 : 0.2) * v, now);
    tg.gain.exponentialRampToValueAtTime(0.001, now + (isCriticalKill ? 0.36 : 0.18));
    thud.connect(tg);
    tg.connect(this.ctx.destination);
    thud.start(now);
    thud.stop(now + (isCriticalKill ? 0.37 : 0.19));

    if (isCriticalKill) {
      const chime = this.ctx.createOscillator();
      const cg = this.ctx.createGain();
      chime.type = "triangle";
      chime.frequency.setValueAtTime(880, now + 0.03);
      chime.frequency.setValueAtTime(1320, now + 0.1);
      cg.gain.setValueAtTime(0.15 * v, now + 0.03);
      cg.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
      chime.connect(cg);
      cg.connect(this.ctx.destination);
      chime.start(now + 0.03);
      chime.stop(now + 0.29);
    }
  }

  public playTitanTransformThunder() {
    if (this.muted || this.volume <= 0.001 || !this.ctx || !this.noiseBuf) return;
    const now = this.ctx.currentTime;
    const v = this.volume;

    // Electric sky lightning crackle
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    const filter = this.ctx.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.setValueAtTime(3400, now);
    filter.frequency.exponentialRampToValueAtTime(160, now + 0.85);
    const ng = this.ctx.createGain();
    ng.gain.setValueAtTime(0.42 * v, now);
    ng.gain.exponentialRampToValueAtTime(0.001, now + 0.9);
    src.connect(filter);
    filter.connect(ng);
    ng.connect(this.ctx.destination);
    src.start(now);
    src.stop(now + 0.92);

    // Massive Titan roar / sub-bass shockwave
    const sub = this.ctx.createOscillator();
    const sg = this.ctx.createGain();
    sub.type = "sawtooth";
    sub.frequency.setValueAtTime(145, now + 0.04);
    sub.frequency.exponentialRampToValueAtTime(42, now + 0.82);
    sg.gain.setValueAtTime(0.32 * v, now + 0.04);
    sg.gain.exponentialRampToValueAtTime(0.001, now + 0.85);
    sub.connect(sg);
    sg.connect(this.ctx.destination);
    sub.start(now + 0.04);
    sub.stop(now + 0.86);
  }

  public playTitanSmash() {
    if (this.muted || this.volume <= 0.001 || !this.ctx || !this.noiseBuf) return;
    const now = this.ctx.currentTime;
    const v = this.volume;

    const punch = this.ctx.createOscillator();
    const pg = this.ctx.createGain();
    punch.type = "triangle";
    punch.frequency.setValueAtTime(175, now);
    punch.frequency.exponentialRampToValueAtTime(34, now + 0.32);
    pg.gain.setValueAtTime(0.36 * v, now);
    pg.gain.exponentialRampToValueAtTime(0.001, now + 0.34);
    punch.connect(pg);
    pg.connect(this.ctx.destination);
    punch.start(now);
    punch.stop(now + 0.35);

    const crunch = this.ctx.createBufferSource();
    crunch.buffer = this.noiseBuf;
    const f = this.ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = 620;
    const cg = this.ctx.createGain();
    cg.gain.setValueAtTime(0.24 * v, now);
    cg.gain.exponentialRampToValueAtTime(0.001, now + 0.24);
    crunch.connect(f);
    f.connect(cg);
    cg.connect(this.ctx.destination);
    crunch.start(now);
    crunch.stop(now + 0.25);
  }

  public playThunderSpearFire() {
    if (this.muted || this.volume <= 0.001 || !this.ctx || !this.noiseBuf) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(680, now);
    osc.frequency.exponentialRampToValueAtTime(1450, now + 0.22);
    g.gain.setValueAtTime(0.14 * this.volume, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.24);
    osc.connect(g);
    g.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.25);
  }

  public playExplosion() {
    if (this.muted || this.volume <= 0.001 || !this.ctx || !this.noiseBuf) return;
    const now = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    const f = this.ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.setValueAtTime(1350, now);
    f.frequency.exponentialRampToValueAtTime(110, now + 0.55);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.38 * this.volume, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.58);
    src.connect(f);
    f.connect(g);
    g.connect(this.ctx.destination);
    src.start(now);
    src.stop(now + 0.6);
  }

  public playResupply() {
    if (this.muted || this.volume <= 0.001 || !this.ctx) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(520, now);
    osc.frequency.setValueAtTime(780, now + 0.08);
    g.gain.setValueAtTime(0.14 * this.volume, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.24);
    osc.connect(g);
    g.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.25);
  }

  public playDamageAlert() {
    if (this.muted || this.volume <= 0.001 || !this.ctx) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(160, now);
    osc.frequency.exponentialRampToValueAtTime(65, now + 0.24);
    g.gain.setValueAtTime(0.24 * this.volume, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.26);
    osc.connect(g);
    g.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.27);
  }

  public dispose() {
    try {
      this.gasSource?.stop();
    } catch {
      // Ignore
    }
    this.ctx?.close().catch(() => {});
    this.ctx = null;
    this.gasSource = null;
  }
}
