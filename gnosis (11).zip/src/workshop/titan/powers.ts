export type TitanPowerId = "attack" | "armored" | "jaw" | "colossal";

export interface TitanPowerSpec {
  id: TitanPowerId;
  name: string;
  title: string;
  eyeHeight: number;
  maxHp: number;
  speed: number;
  jumpVel: number;
  damageResist: number;
  punchDamage: number;
  punchRange: number;
  specialName: string;
  specialDesc: string;
  specialCooldown: number;
  durationSec: number;
  skinColor: number;
  accentColor: number;
}

export const TITAN_POWERS: TitanPowerSpec[] = [
  {
    id: "attack",
    name: "Attack Titan",
    title: "Berserk Hardening",
    eyeHeight: 11.2,
    maxHp: 320,
    speed: 24,
    jumpVel: 18,
    damageResist: 0.45,
    punchDamage: 145,
    punchRange: 14.5,
    specialName: "Hardened Crimson Uppercut",
    specialDesc: "Explosive crystal-knuckle lunge that shatters Armor & launches Titans.",
    specialCooldown: 4.5,
    durationSec: 28,
    skinColor: 0xd19f7e,
    accentColor: 0x6ce5ff,
  },
  {
    id: "armored",
    name: "Armored Titan",
    title: "Unbreakable Bastion",
    eyeHeight: 12.2,
    maxHp: 460,
    speed: 21,
    jumpVel: 15,
    damageResist: 0.72,
    punchDamage: 165,
    punchRange: 15.5,
    specialName: "Armored Bull Charge",
    specialDesc: "Unstoppable full-speed shoulder tackle plowing through every Titan in range.",
    specialCooldown: 5.0,
    durationSec: 30,
    skinColor: 0x9c6e58,
    accentColor: 0xe6dac4,
  },
  {
    id: "jaw",
    name: "Jaw Titan",
    title: "Hyper-Agile Predator",
    eyeHeight: 6.2,
    maxHp: 240,
    speed: 35,
    jumpVel: 25,
    damageResist: 0.35,
    punchDamage: 125,
    punchRange: 12.0,
    specialName: "Blitz Nape Rend",
    specialDesc: "High-velocity aerial pounce that tears straight through Titan napes (2.5s CD).",
    specialCooldown: 2.5,
    durationSec: 28,
    skinColor: 0xcfb6a0,
    accentColor: 0xf4eee4,
  },
  {
    id: "colossal",
    name: "Colossal Titan",
    title: "God of Destruction",
    eyeHeight: 19.5,
    maxHp: 620,
    speed: 17,
    jumpVel: 14,
    damageResist: 0.58,
    punchDamage: 240,
    punchRange: 21.0,
    specialName: "Scorching Steam Blast",
    specialDesc: "Transformation triggers a 36m nuke; Special erupts boiling steam AoE.",
    specialCooldown: 6.0,
    durationSec: 26,
    skinColor: 0xb53c2f,
    accentColor: 0xff8c38,
  },
];

export const TITAN_POWERS_BY_ID: Record<TitanPowerId, TitanPowerSpec> = {
  attack: TITAN_POWERS[0],
  armored: TITAN_POWERS[1],
  jaw: TITAN_POWERS[2],
  colossal: TITAN_POWERS[3],
};
