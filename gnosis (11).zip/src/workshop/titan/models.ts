import * as THREE from "three";
import { disposeSafeHierarchy, loadExternalModel } from "../assets/modelLoader";
import { CITY_BOXES, SUPPLY_STATIONS } from "./cityData";
import type { TitanPowerId } from "./powers";

export type TitanVariant = "pure" | "abnormal" | "armored" | "colossal";
export type TitanBladeFinish = "steel" | "obsidian" | "gold" | "crimson";

export interface TitanCosmeticOptions {
  cloakColorHex: string;
  scarfColorHex: string;
  bladeFinish: TitanBladeFinish;
  cableColorHex: string;
}

export const DEFAULT_TITAN_COSMETICS: TitanCosmeticOptions = {
  cloakColorHex: "#245439",
  scarfColorHex: "#8c1d18",
  bladeFinish: "steel",
  cableColorHex: "#73ffdb",
};

export const TITAN_CLOAK_PRESETS = [
  { id: "survey", name: "Survey Emerald", hex: "#245439" },
  { id: "garrison", name: "Garrison Ochre", hex: "#6e4e2a" },
  { id: "police", name: "Military Navy", hex: "#23364d" },
  { id: "night", name: "Night Ops Obsidian", hex: "#1b1d22" },
  { id: "crimson", name: "Marley Crimson", hex: "#5c1f24" },
];

export const TITAN_SCARF_PRESETS = [
  { id: "red", name: "Crimson Scarf", hex: "#8c1d18" },
  { id: "gold", name: "GNOSIS Gold", hex: "#c6a057" },
  { id: "ivory", name: "Paradis Ivory", hex: "#dfd5c2" },
  { id: "slate", name: "Storm Slate", hex: "#3c4b5c" },
  { id: "emerald", name: "Forest Silk", hex: "#2a6946" },
];

export const TITAN_BLADE_PRESETS: {
  id: TitanBladeFinish;
  label: string;
  color: number;
  emissive: number;
  metalness: number;
  roughness: number;
  guardColor: number;
}[] = [
  {
    id: "steel",
    label: "Ultrahard Steel",
    color: 0xe5edf6,
    emissive: 0x000000,
    metalness: 0.94,
    roughness: 0.14,
    guardColor: 0xb08d57,
  },
  {
    id: "obsidian",
    label: "Obsidian Edge",
    color: 0x1b222e,
    emissive: 0x164e63,
    metalness: 0.88,
    roughness: 0.18,
    guardColor: 0x38bdf8,
  },
  {
    id: "gold",
    label: "Imperial Gilded",
    color: 0xe8c468,
    emissive: 0x332200,
    metalness: 0.95,
    roughness: 0.16,
    guardColor: 0x7c5a20,
  },
  {
    id: "crimson",
    label: "Scarlet Damascus",
    color: 0x992028,
    emissive: 0x450a0a,
    metalness: 0.84,
    roughness: 0.2,
    guardColor: 0xf59e0b,
  },
];

export const TITAN_CABLE_PRESETS = [
  { id: "cyan", name: "Aether Cyan", hex: "#73ffdb" },
  { id: "white", name: "Braided Steel", hex: "#eef8ff" },
  { id: "amber", name: "Solar Gold", hex: "#ffd257" },
  { id: "rose", name: "Crimson Spark", hex: "#ff6b6b" },
];

export interface TitanModelRig {
  group: THREE.Group;
  torso: THREE.Group;
  head: THREE.Group;
  lowerJaw: THREE.Group;
  napeMesh: THREE.Mesh;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  hpBarGroup: THREE.Group;
  hpBarFill: THREE.Mesh;
  telegraphRing: THREE.Mesh;
  height: number;
  napeLocalY: number;
  napeLocalZ: number;
  bodyRadius: number;
}

export interface LocalScoutAvatarRig {
  group: THREE.Group;
  bodyGroup: THREE.Group;
  cloak: THREE.Mesh;
  head: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  leftBlade: THREE.Group;
  rightBlade: THREE.Group;
  leftHipAnchor: THREE.Object3D;
  rightHipAnchor: THREE.Object3D;
}

export interface LocalShifterAvatarRig {
  group: THREE.Group;
  torso: THREE.Group;
  head: THREE.Group;
  lowerJaw: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
}

export interface ScoutTeammateRig {
  group: THREE.Group;
  scoutMeshGroup: THREE.Group;
  shifterMeshGroup: THREE.Group;
  leftCable: THREE.Line;
  rightCable: THREE.Line;
}

export function disposeTitanHierarchy(root: THREE.Object3D) {
  root.traverse((obj) => {
    if (obj instanceof THREE.Mesh || obj instanceof THREE.Line) {
      obj.geometry.dispose();
      const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
      for (const m of mats) {
        if (m && typeof m.dispose === "function") m.dispose();
      }
    }
  });
}

function makeTimberFacadeTexture(): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = "#d4c7b0";
  ctx.fillRect(0, 0, 256, 256);

  for (let i = 0; i < 750; i++) {
    ctx.fillStyle = i % 2 === 0 ? "rgba(70,56,42,0.065)" : "rgba(255,250,240,0.09)";
    ctx.fillRect(Math.random() * 256, Math.random() * 256, 4, 4);
  }

  ctx.fillStyle = "#483321";
  ctx.fillRect(0, 0, 256, 14);
  ctx.fillRect(0, 122, 256, 12);
  ctx.fillRect(0, 242, 256, 14);
  ctx.fillRect(0, 0, 14, 256);
  ctx.fillRect(122, 0, 12, 256);
  ctx.fillRect(242, 0, 14, 256);

  ctx.strokeStyle = "#483321";
  ctx.lineWidth = 8;
  ctx.beginPath();
  ctx.moveTo(12, 126);
  ctx.lineTo(124, 14);
  ctx.moveTo(244, 126);
  ctx.lineTo(132, 14);
  ctx.stroke();

  for (const wx of [34, 152]) {
    for (const wy of [34, 154]) {
      ctx.fillStyle = "#2b2016";
      ctx.fillRect(wx - 4, wy - 4, 68, 68);
      ctx.fillStyle = "#f2c982";
      ctx.fillRect(wx + 2, wy + 2, 26, 26);
      ctx.fillRect(wx + 32, wy + 2, 26, 26);
      ctx.fillRect(wx + 2, wy + 32, 26, 26);
      ctx.fillRect(wx + 32, wy + 32, 26, 26);
    }
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  return tex;
}

function makeSlateRoofTexture(): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 128;
  c.height = 128;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = "#8a3a2f";
  ctx.fillRect(0, 0, 128, 128);
  for (let y = 0; y < 128; y += 16) {
    ctx.fillStyle = "rgba(25, 10, 8, 0.25)";
    ctx.fillRect(0, y + 13, 128, 3);
    const shift = ((y / 16) % 2) * 8;
    for (let x = -8; x < 128; x += 16) {
      ctx.fillStyle = (x + y) % 32 === 0 ? "rgba(255,220,190,0.08)" : "rgba(0,0,0,0.08)";
      ctx.fillRect(x + shift, y, 14, 13);
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(3, 3);
  return tex;
}

function makeCobbleTexture(): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = "#564d42";
  ctx.fillRect(0, 0, 256, 256);
  for (let y = 0; y < 256; y += 16) {
    const offset = ((y / 16) % 2) * 12;
    for (let x = -12; x < 256; x += 24) {
      const shade = 74 + Math.floor(Math.random() * 28);
      ctx.fillStyle = `rgb(${shade + 8}, ${shade}, ${shade - 9})`;
      ctx.fillRect(x + offset + 1, y + 1, 21, 13);
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(68, 68);
  return tex;
}

export function buildWalledDistrictScene(scene: THREE.Scene) {
  const disposables: { dispose: () => void }[] = [];
  const asyncGroups: THREE.Group[] = [];
  let sceneDisposed = false;

  const cobbleTex = makeCobbleTexture();
  const facadeTex = makeTimberFacadeTexture();
  const roofTex = makeSlateRoofTexture();
  disposables.push(cobbleTex, facadeTex, roofTex);

  const groundGeo = new THREE.PlaneGeometry(460, 460);
  const groundMat = new THREE.MeshStandardMaterial({
    map: cobbleTex,
    roughness: 0.9,
    metalness: 0.05,
  });
  const ground = new THREE.Mesh(groundGeo, groundMat);
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  scene.add(ground);
  disposables.push(groundGeo, groundMat);

  // Outer grass expanse & distant mountain silhouettes beyond Wall Rose
  const outerPlaneGeo = new THREE.RingGeometry(226, 560, 32);
  outerPlaneGeo.rotateX(-Math.PI / 2);
  const outerPlaneMat = new THREE.MeshStandardMaterial({ color: 0x415238, roughness: 0.95 });
  const outerPlane = new THREE.Mesh(outerPlaneGeo, outerPlaneMat);
  outerPlane.position.y = -0.15;
  scene.add(outerPlane);
  disposables.push(outerPlaneGeo, outerPlaneMat);

  const stoneMat = new THREE.MeshStandardMaterial({
    color: 0x736a60,
    roughness: 0.88,
    metalness: 0.08,
  });
  const parapetMat = new THREE.MeshStandardMaterial({
    color: 0x574f46,
    roughness: 0.9,
  });
  const bannerMat = new THREE.MeshStandardMaterial({
    color: 0x224c3b,
    roughness: 0.75,
  });
  disposables.push(stoneMat, parapetMat, bannerMat);

  for (const box of CITY_BOXES) {
    if (box.kind === "wall") {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(box.w, box.h, box.d), stoneMat);
      mesh.position.set(box.x, box.y, box.z);
      mesh.receiveShadow = true;
      scene.add(mesh);

      const battlementTop = new THREE.Mesh(
        new THREE.BoxGeometry(box.w + 1.8, 3.0, box.d + 1.8),
        parapetMat,
      );
      battlementTop.position.set(box.x, box.y + box.h * 0.5 + 1.5, box.z);
      scene.add(battlementTop);

      const isNS = box.w > box.d;
      const span = isNS ? box.w : box.d;
      for (let off = -span * 0.44; off <= span * 0.44; off += 46) {
        const rib = new THREE.Mesh(
          new THREE.BoxGeometry(isNS ? 6.5 : 17.5, box.h, isNS ? 17.5 : 6.5),
          parapetMat,
        );
        rib.position.set(isNS ? off : box.x, box.y, isNS ? box.z : off);
        scene.add(rib);
        disposables.push(rib.geometry);
      }

      disposables.push(mesh.geometry, battlementTop.geometry);
    } else {
      const texClone = facadeTex.clone();
      texClone.needsUpdate = true;
      texClone.repeat.set(
        Math.max(1, Math.round(box.w / 10)),
        Math.max(1, Math.round(box.h / 10)),
      );
      const wallMat = new THREE.MeshStandardMaterial({
        map: texClone,
        color: box.wallColor,
        roughness: 0.84,
      });
      const body = new THREE.Mesh(new THREE.BoxGeometry(box.w, box.h, box.d), wallMat);
      body.position.set(box.x, box.y, box.z);
      body.castShadow = true;
      body.receiveShadow = true;
      scene.add(body);

      const roofMat = new THREE.MeshStandardMaterial({
        map: roofTex,
        color: box.roofColor,
        roughness: 0.68,
      });
      const roofDeck = new THREE.Mesh(
        new THREE.BoxGeometry(box.w + 1.2, 0.9, box.d + 1.2),
        roofMat,
      );
      roofDeck.position.set(box.x, box.y + box.h * 0.5 - 0.35, box.z);
      roofDeck.receiveShadow = true;
      scene.add(roofDeck);

      if (box.kind === "house") {
        const ridge = new THREE.Mesh(
          new THREE.ConeGeometry(Math.min(box.w, box.d) * 0.45, 4.2, 4),
          roofMat,
        );
        ridge.rotation.y = Math.PI / 4;
        ridge.position.set(box.x, box.y + box.h * 0.5 + 2.1, box.z);
        scene.add(ridge);
        disposables.push(ridge.geometry);
      } else if (box.kind === "tower") {
        const cupola = new THREE.Mesh(
          new THREE.ConeGeometry(box.w * 0.68, 6.4, 4),
          roofMat,
        );
        cupola.rotation.y = Math.PI / 4;
        cupola.position.set(box.x, box.y + box.h * 0.5 + 3.2, box.z);
        scene.add(cupola);
        const banner = new THREE.Mesh(new THREE.BoxGeometry(2.4, 7.2, 0.25), bannerMat);
        banner.position.set(box.x, box.y + box.h * 0.25, box.z + box.d * 0.5 + 0.18);
        scene.add(banner);
        disposables.push(cupola.geometry, banner.geometry);
      } else if (box.kind === "spire" && box.id === "spire-top") {
        const needle = new THREE.Mesh(new THREE.ConeGeometry(5.6, 16, 4), roofMat);
        needle.rotation.y = Math.PI / 4;
        needle.position.set(box.x, box.y + box.h * 0.5 + 8, box.z);
        scene.add(needle);
        disposables.push(needle.geometry);
      }

      disposables.push(texClone, wallMat, body.geometry, roofMat, roofDeck.geometry);
    }
  }

  // Avenue Trees & Warm Dusk Lantern Posts across Inner + Outer District
  const trunkMat = new THREE.MeshStandardMaterial({ color: 0x4b3523, roughness: 0.9 });
  const leafMat = new THREE.MeshStandardMaterial({ color: 0x355a36, roughness: 0.85 });
  const lanternPostMat = new THREE.MeshStandardMaterial({
    color: 0x2a2623,
    metalness: 0.6,
    roughness: 0.4,
  });
  const lanternGlowMat = new THREE.MeshBasicMaterial({ color: 0xffd07a });
  disposables.push(trunkMat, leafMat, lanternPostMat, lanternGlowMat);

  const decoCoords: [number, number][] = [
    [-16, -44], [16, -44], [-16, 44], [16, 44],
    [-44, -16], [-44, 16], [44, -16], [44, 16],
    [-82, -16], [82, -16], [-82, 16], [82, 16],
    [-16, -132], [16, -132], [-16, 132], [16, 132],
    [-132, -16], [-132, 16], [132, -16], [132, 16],
  ];
  const placeDistrictAsset = (
    url: string,
    targetSize: number,
    x: number,
    y: number,
    z: number,
    rotY = 0,
    hideOnLoad?: THREE.Object3D[],
  ) => {
    loadExternalModel(url, { targetSize, groundAtZero: true })
      .then((asset) => {
        if (!asset) return;
        if (sceneDisposed) {
          disposeSafeHierarchy(asset);
          return;
        }
        asset.position.set(x, y, z);
        asset.rotation.y = rotY;
        if (hideOnLoad) {
          for (const h of hideOnLoad) h.visible = false;
        }
        scene.add(asset);
        asyncGroups.push(asset);
      })
      .catch(() => {});
  };

  for (const [dx, dz] of decoCoords) {
    const post = new THREE.Mesh(
      new THREE.CylinderGeometry(0.15, 0.22, 5.4, 6),
      lanternPostMat,
    );
    post.position.set(dx, 2.7, dz);
    const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.35, 8, 8), lanternGlowMat);
    bulb.position.set(dx, 5.5, dz);
    scene.add(post, bulb);
    disposables.push(post.geometry, bulb.geometry);
    placeDistrictAsset("/assets/models/props/street_lamp.glb", 6.0, dx, 0, dz, 0, [post, bulb]);
  }

  const treeCoords: [number, number][] = [
    [-18, -82], [18, -82], [-86, -46], [86, -46], [-86, 46], [86, 46],
    [-118, -118], [118, -118], [-118, 118], [118, 118],
    [-22, -158], [22, -158], [-22, 158], [22, 158],
  ];
  for (let i = 0; i < treeCoords.length; i++) {
    const [tx, tz] = treeCoords[i];
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.62, 4.6, 7), trunkMat);
    trunk.position.set(tx, 2.3, tz);
    const crown = new THREE.Mesh(new THREE.DodecahedronGeometry(3.1, 0), leafMat);
    crown.position.set(tx, 5.9, tz);
    scene.add(trunk, crown);
    disposables.push(trunk.geometry, crown.geometry);
    placeDistrictAsset(
      i % 2 === 0 ? "/assets/models/props/tree_oak.glb" : "/assets/models/props/tree_pine.glb",
      9.5,
      tx,
      0,
      tz,
      i * 0.85,
      [trunk, crown],
    );
  }

  // Supply Depots + Downloaded 3D Supply Crates & Barrels
  const crateMat = new THREE.MeshStandardMaterial({
    color: 0x24594c,
    roughness: 0.55,
    metalness: 0.3,
  });
  const beaconMat = new THREE.MeshBasicMaterial({
    color: 0x57f2c8,
    transparent: true,
    opacity: 0.45,
  });
  disposables.push(crateMat, beaconMat);

  for (const sup of SUPPLY_STATIONS) {
    const crate = new THREE.Mesh(new THREE.BoxGeometry(2.8, 1.4, 1.9), crateMat);
    crate.position.set(sup.x, sup.y + 0.7, sup.z);
    scene.add(crate);

    const ring = new THREE.Mesh(new THREE.TorusGeometry(2.1, 0.09, 8, 28), beaconMat);
    ring.rotation.x = Math.PI / 2;
    ring.position.set(sup.x, sup.y + 0.14, sup.z);
    scene.add(ring);

    const beam = new THREE.Mesh(
      new THREE.CylinderGeometry(0.16, 0.46, 22, 10, 1, true),
      beaconMat,
    );
    beam.position.set(sup.x, sup.y + 11.2, sup.z);
    scene.add(beam);

    disposables.push(crate.geometry, ring.geometry, beam.geometry);

    placeDistrictAsset("/assets/models/props/wooden_crate.glb", 2.9, sup.x, sup.y, sup.z, 0.3, [crate]);
    placeDistrictAsset("/assets/models/props/barrel.glb", 1.4, sup.x + 2.1, sup.y, sup.z - 0.8, 0);
  }

  // Downloaded 3D District Avenue Roads, Highway Signs, Central Obelisk & Parked Vehicles
  const roadTileSize = 18;
  for (let n = -9; n <= 9; n++) {
    const coord = n * roadTileSize;
    if (n === 0) {
      placeDistrictAsset("/assets/models/roads/road-crossroad.glb", roadTileSize, 0, 0.03, 0, 0);
    } else {
      placeDistrictAsset("/assets/models/roads/road-straight.glb", roadTileSize, 0, 0.03, coord, 0);
      placeDistrictAsset("/assets/models/roads/road-straight.glb", roadTileSize, coord, 0.03, 0, Math.PI / 2);
    }
  }
  placeDistrictAsset("/assets/models/roads/road-bend.glb", roadTileSize, -90, 0.03, -90, 0);
  placeDistrictAsset("/assets/models/roads/road-bend.glb", roadTileSize, 90, 0.03, 90, Math.PI);
  placeDistrictAsset("/assets/models/roads/sign-highway-wide.glb", 7.5, -13, 0, -56, Math.PI / 2);
  placeDistrictAsset("/assets/models/roads/sign-highway-wide.glb", 7.5, 13, 0, 56, -Math.PI / 2);
  placeDistrictAsset("/assets/models/props/statue_obelisk.glb", 11.5, 22, 0, -22, Math.PI * 0.25);

  // Garrison Scout Regiment Camps & District Boulevard Cars
  placeDistrictAsset("/assets/models/racing/kit/decoration-tents.glb", 11, -30, 0, 148, 0);
  placeDistrictAsset("/assets/models/racing/pitsGarage.glb", 14, 34, 0, -148, Math.PI);
  placeDistrictAsset("/assets/models/cars/sedan.glb", 4.6, -7.2, 0, 28, 0.08);
  placeDistrictAsset("/assets/models/cars/suv-luxury.glb", 4.8, 7.4, 0, -34, Math.PI - 0.12);
  placeDistrictAsset("/assets/models/cars/sedan-sports.glb", 4.5, -42, 0, -7.2, Math.PI / 2);
  placeDistrictAsset("/assets/models/cars/hatchback-sports.glb", 4.3, 44, 0, 7.2, -Math.PI / 2);

  // Outer District Distant Horizon Citadel Towers (outside Wall Rose)
  placeDistrictAsset("/assets/models/racing/city/skyscraper-a.glb", 64, -270, 0, -260, 0.2);
  placeDistrictAsset("/assets/models/racing/city/skyscraper-b.glb", 72, 275, 0, -255, -0.35);

  return {
    dispose: () => {
      sceneDisposed = true;
      for (const grp of asyncGroups) {
        scene.remove(grp);
        disposeSafeHierarchy(grp);
      }
      for (const d of disposables) d.dispose();
    },
  };
}

interface TitanHeadStyle {
  scale: number;
  skinColor: number;
  muscleColor: number;
  hairColor: number;
  irisColor: number;
  scleraGlow?: boolean;
  armoredPlates?: boolean;
  jawMask?: boolean;
  exposedMuscleSkull?: boolean;
  lopsidedGrin?: boolean;
  pointedEars?: boolean;
  hairless?: boolean;
}

function buildDetailedTitanHead(style: TitanHeadStyle): {
  head: THREE.Group;
  lowerJaw: THREE.Group;
} {
  const s = style.scale;
  const skinMat = new THREE.MeshStandardMaterial({
    color: style.exposedMuscleSkull ? 0x9e2c22 : style.skinColor,
    roughness: style.exposedMuscleSkull ? 0.56 : 0.76,
  });
  const shadeMat = new THREE.MeshStandardMaterial({
    color: style.muscleColor,
    roughness: 0.72,
  });
  const plateMat = new THREE.MeshStandardMaterial({
    color: 0xe6dac5,
    roughness: 0.34,
    metalness: 0.25,
  });
  const hairMat = new THREE.MeshStandardMaterial({
    color: style.hairColor,
    roughness: 0.92,
  });
  const socketMat = new THREE.MeshBasicMaterial({ color: 0x160908 });
  const scleraMat = style.scleraGlow
    ? new THREE.MeshBasicMaterial({ color: 0xffe8b0 })
    : new THREE.MeshStandardMaterial({ color: 0xf7efe4, roughness: 0.3 });
  const irisMat = new THREE.MeshBasicMaterial({ color: style.irisColor });
  const pupilMat = new THREE.MeshBasicMaterial({ color: 0x090505 });
  const mouthCavityMat = new THREE.MeshBasicMaterial({ color: 0x2a0707 });
  const toothMat = new THREE.MeshStandardMaterial({ color: 0xf4eee0, roughness: 0.25 });

  const head = new THREE.Group();

  // Upper cranium + cheekbones
  const cranium = new THREE.Mesh(
    new THREE.BoxGeometry(1.42 * s, 1.15 * s, 1.54 * s),
    style.armoredPlates ? plateMat : skinMat,
  );
  cranium.position.set(0, 0.28 * s, -0.02 * s);
  head.add(cranium);

  // Heavy furrowed brow ridge
  const browL = new THREE.Mesh(
    new THREE.BoxGeometry(0.62 * s, 0.2 * s, 0.32 * s),
    style.armoredPlates ? plateMat : shadeMat,
  );
  browL.position.set(-0.34 * s, 0.36 * s, 0.74 * s);
  browL.rotation.z = -0.18;
  const browR = new THREE.Mesh(
    new THREE.BoxGeometry(0.62 * s, 0.2 * s, 0.32 * s),
    style.armoredPlates ? plateMat : shadeMat,
  );
  browR.position.set(0.34 * s, 0.36 * s, 0.74 * s);
  browR.rotation.z = 0.18;
  head.add(browL, browR);

  // Deep dark orbital eye sockets
  const socketL = new THREE.Mesh(new THREE.BoxGeometry(0.42 * s, 0.28 * s, 0.18 * s), socketMat);
  socketL.position.set(-0.35 * s, 0.18 * s, 0.71 * s);
  const socketR = new THREE.Mesh(new THREE.BoxGeometry(0.42 * s, 0.28 * s, 0.18 * s), socketMat);
  socketR.position.set(0.35 * s, 0.18 * s, 0.71 * s);
  head.add(socketL, socketR);

  // Unblinking staring eyeballs + colored iris + pinpoint pupil
  const eyeGeo = new THREE.SphereGeometry(0.145 * s, 10, 10);
  const irisGeo = new THREE.SphereGeometry(0.088 * s, 8, 8);
  const pupilGeo = new THREE.SphereGeometry(0.044 * s, 6, 6);
  for (const side of [-1, 1]) {
    const ex = side * 0.34 * s;
    const ey = 0.17 * s;
    const eyeball = new THREE.Mesh(eyeGeo, scleraMat);
    eyeball.position.set(ex, ey, 0.73 * s);
    eyeball.scale.set(1.15, 0.88, 0.65);

    const iris = new THREE.Mesh(irisGeo, irisMat);
    iris.position.set(ex, ey, 0.81 * s);
    iris.scale.set(1.0, 1.0, 0.5);

    const pupil = new THREE.Mesh(pupilGeo, pupilMat);
    pupil.position.set(ex, ey, 0.84 * s);
    pupil.scale.set(1.0, 1.0, 0.45);
    head.add(eyeball, iris, pupil);
  }

  // Prominent nose bridge & nostrils
  const nose = new THREE.Mesh(
    new THREE.ConeGeometry(0.16 * s, 0.42 * s, 4),
    style.armoredPlates ? plateMat : skinMat,
  );
  nose.rotation.x = Math.PI * 0.42;
  nose.rotation.y = Math.PI * 0.25;
  nose.position.set(0, -0.02 * s, 0.85 * s);
  head.add(nose);

  // Cheekbone plates + exposed tendon sinews flanking mouth (iconic AOT look)
  for (const side of [-1, 1]) {
    const cheek = new THREE.Mesh(
      new THREE.BoxGeometry(0.44 * s, 0.38 * s, 0.38 * s),
      style.armoredPlates || style.jawMask ? plateMat : skinMat,
    );
    cheek.position.set(side * 0.56 * s, -0.06 * s, 0.63 * s);
    head.add(cheek);

    const sinew = new THREE.Mesh(new THREE.BoxGeometry(0.14 * s, 0.52 * s, 0.24 * s), shadeMat);
    sinew.position.set(side * 0.56 * s, -0.34 * s, 0.66 * s);
    sinew.rotation.z = side * -0.14;
    head.add(sinew);

    // Titan ears
    const ear = new THREE.Mesh(
      style.pointedEars
        ? new THREE.ConeGeometry(0.14 * s, 0.52 * s, 4)
        : new THREE.BoxGeometry(0.16 * s, 0.34 * s, 0.22 * s),
      skinMat,
    );
    if (style.pointedEars) {
      ear.rotation.z = side * -1.15;
      ear.rotation.y = side * -0.3;
    }
    ear.position.set(side * 0.78 * s, 0.2 * s, -0.02 * s);
    head.add(ear);
  }

  // Upper gum & Dark Mouth Cavity + Individual Upper Teeth
  const upperMouthBack = new THREE.Mesh(
    new THREE.BoxGeometry(0.88 * s, 0.34 * s, 0.3 * s),
    mouthCavityMat,
  );
  upperMouthBack.position.set(0, -0.32 * s, 0.66 * s);
  head.add(upperMouthBack);

  const toothW = style.jawMask ? 0.13 * s : 0.1 * s;
  for (let ti = -2; ti <= 2; ti++) {
    const uTooth = new THREE.Mesh(
      style.jawMask
        ? new THREE.ConeGeometry(toothW * 0.55, 0.18 * s, 4)
        : new THREE.BoxGeometry(toothW, 0.13 * s, 0.09 * s),
      toothMat,
    );
    if (style.jawMask) uTooth.rotation.x = Math.PI;
    uTooth.position.set(ti * 0.14 * s, -0.22 * s, 0.79 * s);
    head.add(uTooth);
  }

  // Hinged Lower Jaw with Individual Bottom Teeth + Chin
  const lowerJaw = new THREE.Group();
  lowerJaw.position.set(0, -0.36 * s, 0.15 * s);
  if (style.lopsidedGrin) lowerJaw.rotation.z = 0.08;

  const jawBlock = new THREE.Mesh(
    new THREE.BoxGeometry(1.06 * s, 0.38 * s, 1.18 * s),
    style.armoredPlates || style.jawMask ? plateMat : skinMat,
  );
  jawBlock.position.set(0, -0.24 * s, 0.12 * s);
  lowerJaw.add(jawBlock);

  const lowerGum = new THREE.Mesh(
    new THREE.BoxGeometry(0.82 * s, 0.14 * s, 0.22 * s),
    mouthCavityMat,
  );
  lowerGum.position.set(0, -0.08 * s, 0.58 * s);
  lowerJaw.add(lowerGum);

  for (let ti = -2; ti <= 2; ti++) {
    const lTooth = new THREE.Mesh(
      style.jawMask
        ? new THREE.ConeGeometry(toothW * 0.55, 0.17 * s, 4)
        : new THREE.BoxGeometry(toothW, 0.12 * s, 0.09 * s),
      toothMat,
    );
    lTooth.position.set(ti * 0.14 * s, -0.02 * s, 0.64 * s);
    lowerJaw.add(lTooth);
  }
  head.add(lowerJaw);

  // Tousled Titan Hair locks (unless hairless Colossal)
  if (!style.hairless) {
    const hairTop = new THREE.Mesh(new THREE.BoxGeometry(1.56 * s, 0.45 * s, 1.66 * s), hairMat);
    hairTop.position.set(0, 0.82 * s, -0.06 * s);
    const hairBack = new THREE.Mesh(new THREE.BoxGeometry(1.52 * s, 0.9 * s, 0.42 * s), hairMat);
    hairBack.position.set(0, 0.36 * s, -0.78 * s);
    const bangsL = new THREE.Mesh(new THREE.BoxGeometry(0.45 * s, 0.36 * s, 0.28 * s), hairMat);
    bangsL.position.set(-0.46 * s, 0.62 * s, 0.72 * s);
    bangsL.rotation.z = 0.22;
    const bangsR = new THREE.Mesh(new THREE.BoxGeometry(0.48 * s, 0.34 * s, 0.28 * s), hairMat);
    bangsR.position.set(0.45 * s, 0.64 * s, 0.72 * s);
    bangsR.rotation.z = -0.18;
    head.add(hairTop, hairBack, bangsL, bangsR);
  }

  return { head, lowerJaw };
}

export function buildTitanRig(variant: TitanVariant): TitanModelRig {
  const height =
    variant === "colossal"
      ? 23
      : variant === "armored"
        ? 15.5
        : variant === "abnormal"
          ? 11.5
          : 8.5;
  const s = height / 10;

  const skinColor =
    variant === "colossal"
      ? 0xb53c2f
      : variant === "armored"
        ? 0x9c6e58
        : variant === "abnormal"
          ? 0xd6a584
          : 0xdfb292;
  const muscleColor = variant === "colossal" ? 0x87251c : 0xc18a6c;
  const hairColor =
    variant === "colossal" ? 0x611c17 : variant === "armored" ? 0xe4dcd0 : 0x2c2019;

  const skinMat = new THREE.MeshStandardMaterial({
    color: skinColor,
    roughness: variant === "colossal" ? 0.6 : 0.78,
  });
  const muscleShadeMat = new THREE.MeshStandardMaterial({
    color: muscleColor,
    roughness: 0.72,
  });
  const armorMat = new THREE.MeshStandardMaterial({
    color: 0xd9cbb6,
    roughness: 0.38,
    metalness: 0.32,
  });
  const napeMat = new THREE.MeshBasicMaterial({ color: 0xff3b2f });

  const group = new THREE.Group();
  const torso = new THREE.Group();
  torso.position.set(0, 4.7 * s, 0);
  group.add(torso);

  const chest = new THREE.Mesh(new THREE.BoxGeometry(3.05 * s, 2.9 * s, 1.65 * s), skinMat);
  chest.position.set(0, 1.55 * s, 0);
  chest.castShadow = true;
  torso.add(chest);

  const abs = new THREE.Mesh(new THREE.BoxGeometry(2.2 * s, 1.6 * s, 1.32 * s), muscleShadeMat);
  abs.position.set(0, -0.35 * s, 0.04 * s);
  torso.add(abs);

  const traps = new THREE.Mesh(new THREE.BoxGeometry(3.5 * s, 0.95 * s, 1.55 * s), skinMat);
  traps.position.set(0, 2.65 * s, -0.04 * s);
  torso.add(traps);

  if (variant === "armored" || variant === "colossal") {
    const chestPlate = new THREE.Mesh(
      new THREE.BoxGeometry(3.2 * s, 2.3 * s, 1.82 * s),
      variant === "armored" ? armorMat : new THREE.MeshBasicMaterial({ color: 0xff7038 }),
    );
    chestPlate.position.set(0, 1.6 * s, 0.08 * s);
    torso.add(chestPlate);

    if (variant === "armored") {
      const shoulderL = new THREE.Mesh(new THREE.BoxGeometry(1.3 * s, 1.2 * s, 1.5 * s), armorMat);
      shoulderL.position.set(-2.0 * s, 2.75 * s, 0);
      const shoulderR = new THREE.Mesh(new THREE.BoxGeometry(1.3 * s, 1.2 * s, 1.5 * s), armorMat);
      shoulderR.position.set(2.0 * s, 2.75 * s, 0);
      torso.add(shoulderL, shoulderR);
    }
  }

  // Detailed Sculpted AOT Titan Head + Animated Jaw
  const { head, lowerJaw } = buildDetailedTitanHead({
    scale: s,
    skinColor,
    muscleColor,
    hairColor,
    irisColor:
      variant === "colossal"
        ? 0xffb830
        : variant === "armored"
          ? 0xffd269
          : variant === "abnormal"
            ? 0xff3b2f
            : 0x70563c,
    scleraGlow: variant === "colossal" || variant === "armored",
    armoredPlates: variant === "armored",
    exposedMuscleSkull: variant === "colossal",
    lopsidedGrin: variant === "abnormal",
    pointedEars: variant === "abnormal",
    hairless: variant === "colossal",
  });
  head.position.set(0, 3.65 * s, 0.14 * s);
  torso.add(head);

  // CRITICAL WEAK POINT: Glowing Crimson Nape on upper back of neck
  const napeLocalY = 7.95 * s;
  const napeLocalZ = -0.95 * s;
  const napeMesh = new THREE.Mesh(new THREE.BoxGeometry(1.42 * s, 1.52 * s, 0.58 * s), napeMat);
  napeMesh.position.set(0, 3.25 * s, -0.95 * s);
  torso.add(napeMesh);

  // Arms
  const leftArm = new THREE.Group();
  leftArm.position.set(-2.05 * s, 2.7 * s, 0);
  const rightArm = new THREE.Group();
  rightArm.position.set(2.05 * s, 2.7 * s, 0);
  torso.add(leftArm, rightArm);

  for (const arm of [leftArm, rightArm]) {
    const upper = new THREE.Mesh(new THREE.BoxGeometry(1.0 * s, 2.45 * s, 1.0 * s), skinMat);
    upper.position.set(0, -1.0 * s, 0);
    const fore = new THREE.Mesh(new THREE.BoxGeometry(0.92 * s, 2.35 * s, 0.92 * s), muscleShadeMat);
    fore.position.set(0, -3.1 * s, 0.28 * s);
    const fist = new THREE.Mesh(
      new THREE.BoxGeometry(1.05 * s, 0.95 * s, 1.05 * s),
      variant === "armored" ? armorMat : skinMat,
    );
    fist.position.set(0, -4.45 * s, 0.35 * s);
    arm.add(upper, fore, fist);
  }

  // Legs
  const leftLeg = new THREE.Group();
  leftLeg.position.set(-0.85 * s, 4.3 * s, 0);
  const rightLeg = new THREE.Group();
  rightLeg.position.set(0.85 * s, 4.3 * s, 0);
  group.add(leftLeg, rightLeg);

  for (const leg of [leftLeg, rightLeg]) {
    const thigh = new THREE.Mesh(new THREE.BoxGeometry(1.18 * s, 2.35 * s, 1.2 * s), skinMat);
    thigh.position.set(0, -1.0 * s, 0);
    const shin = new THREE.Mesh(
      new THREE.BoxGeometry(0.98 * s, 2.35 * s, 1.08 * s),
      variant === "armored" ? armorMat : muscleShadeMat,
    );
    shin.position.set(0, -3.1 * s, 0);
    leg.add(thigh, shin);
  }

  // Billboarded Overhead HP bar
  const hpBarGroup = new THREE.Group();
  hpBarGroup.position.set(0, height + 1.3 * s, 0);
  const hpBg = new THREE.Mesh(
    new THREE.PlaneGeometry(3.4 * s, 0.36 * s),
    new THREE.MeshBasicMaterial({ color: 0x18120e, side: THREE.DoubleSide }),
  );
  const hpBarFill = new THREE.Mesh(
    new THREE.PlaneGeometry(3.26 * s, 0.24 * s),
    new THREE.MeshBasicMaterial({ color: 0xe64b3b, side: THREE.DoubleSide }),
  );
  hpBarFill.position.set(0, 0, 0.04 * s);
  hpBarGroup.add(hpBg, hpBarFill);
  group.add(hpBarGroup);

  const telegraphRing = new THREE.Mesh(
    new THREE.RingGeometry(2.6 * s, 3.35 * s, 28),
    new THREE.MeshBasicMaterial({
      color: 0xff4636,
      transparent: true,
      opacity: 0,
      side: THREE.DoubleSide,
    }),
  );
  telegraphRing.rotation.x = -Math.PI / 2;
  telegraphRing.position.set(0, 0.14, 0);
  group.add(telegraphRing);

  return {
    group,
    torso,
    head,
    lowerJaw,
    napeMesh,
    leftArm,
    rightArm,
    leftLeg,
    rightLeg,
    hpBarGroup,
    hpBarFill,
    telegraphRing,
    height,
    napeLocalY,
    napeLocalZ,
    bodyRadius: 1.9 * s,
  };
}

export function buildLocalScoutAvatar(cosmetics: TitanCosmeticOptions = DEFAULT_TITAN_COSMETICS): LocalScoutAvatarRig {
  const group = new THREE.Group();
  const bodyGroup = new THREE.Group();
  group.add(bodyGroup);

  const bladeSpec = TITAN_BLADE_PRESETS.find((b) => b.id === cosmetics.bladeFinish) || TITAN_BLADE_PRESETS[0];
  const cloakMat = new THREE.MeshStandardMaterial({
    color: cosmetics.cloakColorHex,
    roughness: 0.78,
    side: THREE.DoubleSide,
  });
  const scarfMat = new THREE.MeshStandardMaterial({
    color: cosmetics.scarfColorHex,
    roughness: 0.74,
  });
  const jacketMat = new THREE.MeshStandardMaterial({ color: 0x7c573b, roughness: 0.72 });
  const pantsMat = new THREE.MeshStandardMaterial({ color: 0xe6decb, roughness: 0.8 });
  const bootMat = new THREE.MeshStandardMaterial({ color: 0x2d2118, roughness: 0.65 });
  const skinMat = new THREE.MeshStandardMaterial({ color: 0xe5c19c, roughness: 0.7 });
  const hairMat = new THREE.MeshStandardMaterial({ color: 0x1e1a18, roughness: 0.85 });
  const metalMat = new THREE.MeshStandardMaterial({ color: 0xaeb8c4, metalness: 0.86, roughness: 0.22 });
  const steelMat = new THREE.MeshStandardMaterial({
    color: bladeSpec.color,
    emissive: bladeSpec.emissive,
    metalness: bladeSpec.metalness,
    roughness: bladeSpec.roughness,
  });

  // Torso + Scout Jacket + Customizable Cloak & Scarf
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.72, 0.32), jacketMat);
  torso.position.set(0, 1.18, 0);
  torso.castShadow = true;
  bodyGroup.add(torso);

  const shoulders = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.24, 0.38), cloakMat);
  shoulders.position.set(0, 1.44, 0.02);
  bodyGroup.add(shoulders);

  const scarf = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.14, 0.42), scarfMat);
  scarf.position.set(0, 1.54, 0.01);
  bodyGroup.add(scarf);

  const cloak = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.82, 0.08), cloakMat);
  cloak.position.set(0, 1.12, 0.21);
  bodyGroup.add(cloak);

  // ODM Gas Gear Pack + Twin Hip Scabbards & Grapple Launchers
  const gasPack = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.34, 0.22), metalMat);
  gasPack.position.set(0, 0.82, 0.22);
  bodyGroup.add(gasPack);

  const leftHipAnchor = new THREE.Object3D();
  leftHipAnchor.position.set(-0.38, 0.84, 0.04);
  const rightHipAnchor = new THREE.Object3D();
  rightHipAnchor.position.set(0.38, 0.84, 0.04);
  bodyGroup.add(leftHipAnchor, rightHipAnchor);

  const scabbardL = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.24, 0.82), metalMat);
  scabbardL.position.set(-0.38, 0.84, 0.04);
  scabbardL.rotation.x = 0.22;
  const scabbardR = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.24, 0.82), metalMat);
  scabbardR.position.set(0.38, 0.84, 0.04);
  scabbardR.rotation.x = 0.22;
  bodyGroup.add(scabbardL, scabbardR);

  // Head + Hair
  const head = new THREE.Group();
  head.position.set(0, 1.72, 0);
  const skull = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.4, 0.38), skinMat);
  const hairTop = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.22, 0.42), hairMat);
  hairTop.position.set(0, 0.14, 0.01);
  head.add(skull, hairTop);
  bodyGroup.add(head);

  // Articulated Arms + Ultrahard Steel Twin Blades
  const buildArm = (side: -1 | 1) => {
    const arm = new THREE.Group();
    arm.position.set(side * 0.37, 1.44, 0);
    const sleeve = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.56, 0.18), jacketMat);
    sleeve.position.set(0, -0.24, 0);
    const hand = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.14, 0.14), skinMat);
    hand.position.set(0, -0.54, 0);

    const bladeGroup = new THREE.Group();
    bladeGroup.position.set(0, -0.54, -0.06);
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.06, 0.18), bootMat);
    const steel = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.07, 0.82), steelMat);
    steel.position.set(0, 0, -0.45);
    bladeGroup.add(grip, steel);

    arm.add(sleeve, hand, bladeGroup);
    bodyGroup.add(arm);
    return { arm, bladeGroup };
  };

  const { arm: leftArm, bladeGroup: leftBlade } = buildArm(-1);
  const { arm: rightArm, bladeGroup: rightBlade } = buildArm(1);

  // Articulated Legs
  const buildLeg = (side: -1 | 1) => {
    const leg = new THREE.Group();
    leg.position.set(side * 0.15, 0.82, 0);
    const thigh = new THREE.Mesh(new THREE.BoxGeometry(0.21, 0.44, 0.22), pantsMat);
    thigh.position.set(0, -0.22, 0);
    const boot = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.42, 0.25), bootMat);
    boot.position.set(0, -0.62, -0.02);
    leg.add(thigh, boot);
    bodyGroup.add(leg);
    return leg;
  };
  const leftLeg = buildLeg(-1);
  const rightLeg = buildLeg(1);

  return {
    group,
    bodyGroup,
    cloak,
    head,
    leftArm,
    rightArm,
    leftLeg,
    rightLeg,
    leftBlade,
    rightBlade,
    leftHipAnchor,
    rightHipAnchor,
  };
}

export function buildLocalShifterRig(powerId: TitanPowerId): LocalShifterAvatarRig {
  const height =
    powerId === "colossal" ? 21.5 : powerId === "armored" ? 13.8 : powerId === "jaw" ? 7.2 : 12.6;
  const s = height / 10;

  const skinColor =
    powerId === "colossal"
      ? 0xb53c2f
      : powerId === "armored"
        ? 0x9c6e58
        : powerId === "jaw"
          ? 0xcfb6a0
          : 0xd19f7e;
  const muscleColor = powerId === "colossal" ? 0x87251c : 0xb37f63;
  const accentColor =
    powerId === "colossal"
      ? 0xff8c38
      : powerId === "armored"
        ? 0xe6dac4
        : powerId === "jaw"
          ? 0xf4eee4
          : 0x6ce5ff;

  const skinMat = new THREE.MeshStandardMaterial({ color: skinColor, roughness: 0.68 });
  const muscleMat = new THREE.MeshStandardMaterial({ color: muscleColor, roughness: 0.72 });
  const accentMat = new THREE.MeshStandardMaterial({
    color: accentColor,
    roughness: 0.34,
    metalness: powerId === "attack" ? 0.45 : 0.22,
  });

  const group = new THREE.Group();
  const torso = new THREE.Group();
  torso.position.set(0, 4.7 * s, 0);
  group.add(torso);

  const chest = new THREE.Mesh(new THREE.BoxGeometry(3.0 * s, 2.9 * s, 1.65 * s), skinMat);
  chest.position.set(0, 1.55 * s, 0);
  chest.castShadow = true;
  const abs = new THREE.Mesh(new THREE.BoxGeometry(2.2 * s, 1.6 * s, 1.3 * s), muscleMat);
  abs.position.set(0, -0.35 * s, 0.04 * s);
  torso.add(chest, abs);

  if (powerId === "armored") {
    const chestArmor = new THREE.Mesh(new THREE.BoxGeometry(3.22 * s, 2.35 * s, 1.82 * s), accentMat);
    chestArmor.position.set(0, 1.6 * s, 0.06 * s);
    torso.add(chestArmor);
  } else if (powerId === "colossal") {
    const ribs = new THREE.Mesh(
      new THREE.BoxGeometry(3.15 * s, 2.2 * s, 1.75 * s),
      new THREE.MeshBasicMaterial({ color: 0xff7038 }),
    );
    ribs.position.set(0, 1.5 * s, 0.05 * s);
    torso.add(ribs);
  }

  // Note: Player Shifter faces -Z (away from camera), matching Scout orientation!
  const { head, lowerJaw } = buildDetailedTitanHead({
    scale: s,
    skinColor,
    muscleColor,
    hairColor: powerId === "armored" ? 0xe6dac4 : powerId === "jaw" ? 0xc29e70 : 0x221814,
    irisColor:
      powerId === "attack"
        ? 0x56ff98
        : powerId === "armored"
          ? 0xffd269
          : powerId === "jaw"
            ? 0xffa83b
            : 0xffd54f,
    scleraGlow: true,
    armoredPlates: powerId === "armored",
    jawMask: powerId === "jaw",
    exposedMuscleSkull: powerId === "colossal",
    pointedEars: powerId === "attack" || powerId === "jaw",
    hairless: powerId === "colossal",
  });
  head.rotation.y = Math.PI;
  head.position.set(0, 3.65 * s, -0.14 * s);
  torso.add(head);

  const leftArm = new THREE.Group();
  leftArm.position.set(-2.05 * s, 2.7 * s, 0);
  const rightArm = new THREE.Group();
  rightArm.position.set(2.05 * s, 2.7 * s, 0);
  torso.add(leftArm, rightArm);

  for (const arm of [leftArm, rightArm]) {
    const upper = new THREE.Mesh(new THREE.BoxGeometry(1.0 * s, 2.4 * s, 1.0 * s), skinMat);
    upper.position.set(0, -1.0 * s, 0);
    const fore = new THREE.Mesh(new THREE.BoxGeometry(0.92 * s, 2.3 * s, 0.92 * s), muscleMat);
    fore.position.set(0, -3.05 * s, -0.24 * s);
    const fist = new THREE.Mesh(new THREE.BoxGeometry(1.08 * s, 0.96 * s, 1.08 * s), accentMat);
    fist.position.set(0, -4.4 * s, -0.32 * s);
    arm.add(upper, fore, fist);
  }

  const leftLeg = new THREE.Group();
  leftLeg.position.set(-0.85 * s, 4.3 * s, 0);
  const rightLeg = new THREE.Group();
  rightLeg.position.set(0.85 * s, 4.3 * s, 0);
  group.add(leftLeg, rightLeg);

  for (const leg of [leftLeg, rightLeg]) {
    const thigh = new THREE.Mesh(new THREE.BoxGeometry(1.18 * s, 2.35 * s, 1.2 * s), skinMat);
    thigh.position.set(0, -1.0 * s, 0);
    const shin = new THREE.Mesh(new THREE.BoxGeometry(0.98 * s, 2.35 * s, 1.08 * s), muscleMat);
    shin.position.set(0, -3.1 * s, 0);
    leg.add(thigh, shin);
  }

  return { group, torso, head, lowerJaw, leftArm, rightArm, leftLeg, rightLeg };
}

export function buildOdmBladeViewmodels(cosmetics: TitanCosmeticOptions = DEFAULT_TITAN_COSMETICS) {
  const bladeSpec = TITAN_BLADE_PRESETS.find((b) => b.id === cosmetics.bladeFinish) || TITAN_BLADE_PRESETS[0];
  const root = new THREE.Group();
  const bladeMat = new THREE.MeshStandardMaterial({
    color: bladeSpec.color,
    emissive: bladeSpec.emissive,
    metalness: bladeSpec.metalness,
    roughness: bladeSpec.roughness,
  });
  const handleMat = new THREE.MeshStandardMaterial({
    color: 0x2a2f36,
    metalness: 0.65,
    roughness: 0.45,
  });
  const accentMat = new THREE.MeshStandardMaterial({
    color: bladeSpec.guardColor,
    metalness: 0.82,
    roughness: 0.28,
  });

  const makeSingleBlade = (side: -1 | 1) => {
    const g = new THREE.Group();
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.036, 0.14, 0.05), handleMat);
    const guard = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.03, 0.1), accentMat);
    guard.position.set(0, 0.06, -0.02);

    const steel = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.048, 0.74), bladeMat);
    steel.position.set(0, 0.065, -0.4);

    const tip = new THREE.Mesh(new THREE.BoxGeometry(0.011, 0.036, 0.11), bladeMat);
    tip.position.set(0, 0.068, -0.78);
    tip.rotation.x = 0.24;

    g.add(grip, guard, steel, tip);
    g.position.set(side * 0.34, -0.24, -0.34);
    g.rotation.set(0.15, side * 0.24, side * -0.35);
    return g;
  };

  const leftBlade = makeSingleBlade(-1);
  const rightBlade = makeSingleBlade(1);
  root.add(leftBlade, rightBlade);
  return { root, leftBlade, rightBlade };
}

export function buildTitanFirstPersonArms(powerId: TitanPowerId) {
  const root = new THREE.Group();
  const skinColor =
    powerId === "colossal"
      ? 0xb53c2f
      : powerId === "armored"
        ? 0x9c6e58
        : powerId === "jaw"
          ? 0xcfb6a0
          : 0xd19f7e;
  const accentColor =
    powerId === "colossal"
      ? 0xff8c38
      : powerId === "armored"
        ? 0xe6dac4
        : powerId === "jaw"
          ? 0xf4eee4
          : 0x6ce5ff;

  const armMat = new THREE.MeshStandardMaterial({ color: skinColor, roughness: 0.65 });
  const accentMat = new THREE.MeshStandardMaterial({
    color: accentColor,
    roughness: powerId === "attack" ? 0.25 : 0.4,
    metalness: powerId === "attack" ? 0.55 : 0.2,
    emissive: powerId === "colossal" ? new THREE.Color(0x551806) : new THREE.Color(0x000000),
  });

  const makeArm = (side: -1 | 1) => {
    const g = new THREE.Group();
    const forearm = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.28, 0.85), armMat);
    forearm.position.set(0, 0, -0.4);
    const knuckle = new THREE.Mesh(
      new THREE.BoxGeometry(0.3, 0.32, powerId === "jaw" ? 0.42 : 0.34),
      accentMat,
    );
    knuckle.position.set(0, 0.02, -0.88);
    g.add(forearm, knuckle);

    if (powerId === "jaw") {
      for (const cx of [-0.09, 0, 0.09]) {
        const claw = new THREE.Mesh(new THREE.ConeGeometry(0.038, 0.34, 4), accentMat);
        claw.rotation.x = -Math.PI / 2;
        claw.position.set(cx, 0.02, -1.16);
        g.add(claw);
      }
    }

    g.position.set(side * 0.58, -0.44, -0.38);
    g.rotation.set(0.14, side * -0.18, 0);
    return g;
  };

  const leftArm = makeArm(-1);
  const rightArm = makeArm(1);
  root.add(leftArm, rightArm);
  return { root, leftArm, rightArm };
}

export function buildScoutTeammateRig(cloakColorHex: string): ScoutTeammateRig {
  const group = new THREE.Group();
  const scoutMeshGroup = new THREE.Group();
  const shifterMeshGroup = new THREE.Group();

  const coatMat = new THREE.MeshStandardMaterial({ color: 0x2d4e38, roughness: 0.8 });
  const bodyMat = new THREE.MeshStandardMaterial({ color: cloakColorHex, roughness: 0.65 });
  const metalMat = new THREE.MeshStandardMaterial({
    color: 0x9aa3ad,
    metalness: 0.85,
    roughness: 0.25,
  });

  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.88, 0.4), bodyMat);
  torso.position.y = 1.25;
  const cloak = new THREE.Mesh(new THREE.BoxGeometry(0.84, 0.76, 0.48), coatMat);
  cloak.position.set(0, 1.32, 0.08);
  const head = new THREE.Mesh(
    new THREE.BoxGeometry(0.42, 0.44, 0.42),
    new THREE.MeshStandardMaterial({ color: 0xe4c19e, roughness: 0.7 }),
  );
  head.position.y = 1.92;
  const legs = new THREE.Mesh(
    new THREE.BoxGeometry(0.5, 0.82, 0.32),
    new THREE.MeshStandardMaterial({ color: 0xe5ddc8, roughness: 0.8 }),
  );
  legs.position.y = 0.41;
  const scabbardL = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.28, 0.86), metalMat);
  scabbardL.position.set(-0.44, 0.92, -0.08);
  const scabbardR = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.28, 0.86), metalMat);
  scabbardR.position.set(0.44, 0.92, -0.08);
  scoutMeshGroup.add(torso, cloak, head, legs, scabbardL, scabbardR);

  // Detailed Teammate Shifter Avatar
  const titanSkinMat = new THREE.MeshStandardMaterial({ color: 0xd19f7e, roughness: 0.7 });
  const tTorso = new THREE.Mesh(new THREE.BoxGeometry(3.6, 5.2, 2.2), titanSkinMat);
  tTorso.position.y = 7.4;
  const tLegs = new THREE.Mesh(new THREE.BoxGeometry(2.8, 4.8, 1.8), titanSkinMat);
  tLegs.position.y = 2.4;
  const { head: tHead } = buildDetailedTitanHead({
    scale: 1.25,
    skinColor: 0xd19f7e,
    muscleColor: 0xb37f63,
    hairColor: 0x221814,
    irisColor: 0x67ff9c,
    scleraGlow: true,
    pointedEars: true,
  });
  tHead.rotation.y = Math.PI;
  tHead.position.set(0, 11.1, 0);
  shifterMeshGroup.add(tTorso, tLegs, tHead);
  shifterMeshGroup.visible = false;

  group.add(scoutMeshGroup, shifterMeshGroup);

  const cableMat = new THREE.LineBasicMaterial({
    color: 0xd9e8f5,
    transparent: true,
    opacity: 0.85,
  });
  const leftCable = new THREE.Line(
    new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]),
    cableMat,
  );
  const rightCable = new THREE.Line(
    new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]),
    cableMat,
  );
  leftCable.visible = false;
  rightCable.visible = false;

  return { group, scoutMeshGroup, shifterMeshGroup, leftCable, rightCable };
}
