export interface CityBox {
  id: string;
  x: number;
  y: number;
  z: number;
  w: number;
  h: number;
  d: number;
  kind: "house" | "tower" | "wall" | "spire";
  roofColor: number;
  wallColor: number;
}

export interface SupplyStation {
  id: string;
  x: number;
  y: number;
  z: number;
  label: string;
}

export interface TitanSpawnPoint {
  x: number;
  z: number;
}

export const DISTRICT_HALF = 210;

// Towering outer fortress walls (420m x 420m arena) + Shiganshina-inspired multi-ring district & central spire
export const CITY_BOXES: CityBox[] = [
  // 4 Outer Rose Fortress Walls (64m high, thick stone ramparts)
  { id: "wall-n", x: 0, y: 32, z: -210, w: 436, h: 64, d: 14, kind: "wall", roofColor: 0x5d574f, wallColor: 0x736c63 },
  { id: "wall-s", x: 0, y: 32, z: 210, w: 436, h: 64, d: 14, kind: "wall", roofColor: 0x5d574f, wallColor: 0x736c63 },
  { id: "wall-w", x: -210, y: 32, z: 0, w: 14, h: 64, d: 406, kind: "wall", roofColor: 0x5d574f, wallColor: 0x736c63 },
  { id: "wall-e", x: 210, y: 32, z: 0, w: 14, h: 64, d: 406, kind: "wall", roofColor: 0x5d574f, wallColor: 0x736c63 },

  // Central Bell Tower Spire (Prime high-altitude ODM slingshot anchor)
  { id: "spire-base", x: 0, y: 21, z: 0, w: 14, h: 42, d: 14, kind: "spire", roofColor: 0x7c342b, wallColor: 0x9b8e7c },
  { id: "spire-top", x: 0, y: 52, z: 0, w: 8, h: 20, d: 8, kind: "spire", roofColor: 0x61261f, wallColor: 0x897c6b },

  // Inner Plaza Quarter Buildings (clear wide avenues between them for Titan movement)
  { id: "b-nw1", x: -32, y: 9.5, z: -30, w: 16, h: 19, d: 16, kind: "house", roofColor: 0x8b3a2e, wallColor: 0xc9bca6 },
  { id: "b-nw2", x: -64, y: 12.5, z: -26, w: 18, h: 25, d: 16, kind: "house", roofColor: 0x6f3229, wallColor: 0xbfb29c },
  { id: "b-nw3", x: -28, y: 11.5, z: -64, w: 18, h: 23, d: 18, kind: "house", roofColor: 0x7d362c, wallColor: 0xc6b9a3 },
  { id: "b-nw4", x: -72, y: 16, z: -68, w: 16, h: 32, d: 16, kind: "tower", roofColor: 0x5a312c, wallColor: 0xb0a38e },
  { id: "b-nw5", x: -102, y: 11, z: -36, w: 18, h: 22, d: 20, kind: "house", roofColor: 0x8b3a2e, wallColor: 0xc9bca6 },
  { id: "b-nw6", x: -52, y: 9, z: -98, w: 20, h: 18, d: 16, kind: "house", roofColor: 0x6f3229, wallColor: 0xc2b59f },

  // Northeast Inner Quarter
  { id: "b-ne1", x: 32, y: 10, z: -32, w: 16, h: 20, d: 15, kind: "house", roofColor: 0x7f362c, wallColor: 0xc8bba4 },
  { id: "b-ne2", x: 64, y: 14, z: -30, w: 16, h: 28, d: 18, kind: "tower", roofColor: 0x5b302a, wallColor: 0xb7aa95 },
  { id: "b-ne3", x: 30, y: 11.5, z: -66, w: 18, h: 23, d: 16, kind: "house", roofColor: 0x8b3a2e, wallColor: 0xcbc0ab },
  { id: "b-ne4", x: 74, y: 10.5, z: -72, w: 20, h: 21, d: 18, kind: "house", roofColor: 0x723229, wallColor: 0xc0b39d },
  { id: "b-ne5", x: 102, y: 15, z: -24, w: 16, h: 30, d: 18, kind: "tower", roofColor: 0x5d2e27, wallColor: 0xb4a792 },
  { id: "b-ne6", x: 52, y: 9.5, z: -100, w: 18, h: 19, d: 16, kind: "house", roofColor: 0x893b30, wallColor: 0xc4b7a1 },

  // Southwest Inner Quarter
  { id: "b-sw1", x: -32, y: 10.5, z: 32, w: 16, h: 21, d: 18, kind: "house", roofColor: 0x84382d, wallColor: 0xc6b9a2 },
  { id: "b-sw2", x: -66, y: 14, z: 32, w: 18, h: 28, d: 16, kind: "tower", roofColor: 0x5c2f28, wallColor: 0xb8ab96 },
  { id: "b-sw3", x: -28, y: 9.5, z: 68, w: 18, h: 19, d: 17, kind: "house", roofColor: 0x75332a, wallColor: 0xc8bba4 },
  { id: "b-sw4", x: -74, y: 11.5, z: 72, w: 20, h: 23, d: 18, kind: "house", roofColor: 0x8b3a2e, wallColor: 0xc0b39d },
  { id: "b-sw5", x: -102, y: 10.5, z: 40, w: 16, h: 21, d: 18, kind: "house", roofColor: 0x6f3229, wallColor: 0xc5b8a2 },
  { id: "b-sw6", x: -52, y: 14.5, z: 98, w: 16, h: 29, d: 16, kind: "tower", roofColor: 0x592d27, wallColor: 0xb2a590 },

  // Southeast Inner Quarter
  { id: "b-se1", x: 34, y: 10, z: 32, w: 18, h: 20, d: 16, kind: "house", roofColor: 0x7b352b, wallColor: 0xc9bca6 },
  { id: "b-se2", x: 66, y: 12.5, z: 36, w: 16, h: 25, d: 18, kind: "house", roofColor: 0x883a2e, wallColor: 0xc0b39d },
  { id: "b-se3", x: 30, y: 13.5, z: 68, w: 16, h: 27, d: 16, kind: "tower", roofColor: 0x5e3029, wallColor: 0xb5a893 },
  { id: "b-se4", x: 74, y: 10.5, z: 74, w: 20, h: 21, d: 18, kind: "house", roofColor: 0x733229, wallColor: 0xc4b7a1 },
  { id: "b-se5", x: 102, y: 11.5, z: 28, w: 16, h: 23, d: 18, kind: "house", roofColor: 0x8b3a2e, wallColor: 0xc8bba4 },
  { id: "b-se6", x: 52, y: 9.5, z: 98, w: 20, h: 19, d: 16, kind: "house", roofColor: 0x6e3128, wallColor: 0xc1b49e },

  // Outer District Ring (125m..178m) — Expanded Shiganshina Wards & Citadel Towers
  { id: "o-nw1", x: -138, y: 13, z: -136, w: 22, h: 26, d: 22, kind: "tower", roofColor: 0x532a24, wallColor: 0xaa9c87 },
  { id: "o-nw2", x: -158, y: 10, z: -76, w: 22, h: 20, d: 20, kind: "house", roofColor: 0x84382d, wallColor: 0xc5b8a2 },
  { id: "o-nw3", x: -84, y: 11, z: -152, w: 22, h: 22, d: 18, kind: "house", roofColor: 0x723229, wallColor: 0xc0b39d },
  { id: "o-nw4", x: -164, y: 12, z: -18, w: 18, h: 24, d: 22, kind: "house", roofColor: 0x6d3027, wallColor: 0xbdb09a },

  { id: "o-ne1", x: 138, y: 13, z: -136, w: 22, h: 26, d: 22, kind: "tower", roofColor: 0x532a24, wallColor: 0xaa9c87 },
  { id: "o-ne2", x: 158, y: 10.5, z: -78, w: 22, h: 21, d: 20, kind: "house", roofColor: 0x7f362c, wallColor: 0xc7baa4 },
  { id: "o-ne3", x: 84, y: 11, z: -152, w: 22, h: 22, d: 18, kind: "house", roofColor: 0x8a3a2e, wallColor: 0xc3b6a0 },
  { id: "o-ne4", x: 164, y: 14, z: -22, w: 18, h: 28, d: 20, kind: "tower", roofColor: 0x5b302a, wallColor: 0xb2a590 },

  { id: "o-sw1", x: -138, y: 13, z: 136, w: 22, h: 26, d: 22, kind: "tower", roofColor: 0x532a24, wallColor: 0xaa9c87 },
  { id: "o-sw2", x: -158, y: 10.5, z: 82, w: 22, h: 21, d: 20, kind: "house", roofColor: 0x75332a, wallColor: 0xc6b9a2 },
  { id: "o-sw3", x: -84, y: 10, z: 152, w: 22, h: 20, d: 18, kind: "house", roofColor: 0x893a2e, wallColor: 0xc8bba4 },
  { id: "o-sw4", x: -164, y: 11, z: 24, w: 18, h: 22, d: 22, kind: "house", roofColor: 0x6f3229, wallColor: 0xc1b49e },

  { id: "o-se1", x: 138, y: 13, z: 136, w: 22, h: 26, d: 22, kind: "tower", roofColor: 0x532a24, wallColor: 0xaa9c87 },
  { id: "o-se2", x: 158, y: 11, z: 82, w: 22, h: 22, d: 20, kind: "house", roofColor: 0x85392d, wallColor: 0xc4b7a1 },
  { id: "o-se3", x: 84, y: 12.5, z: 152, w: 22, h: 25, d: 18, kind: "house", roofColor: 0x713128, wallColor: 0xbdb09a },
  { id: "o-se4", x: 164, y: 11.5, z: 26, w: 18, h: 23, d: 22, kind: "house", roofColor: 0x8b3a2e, wallColor: 0xc6b9a2 },

  // Inner Plaza Gate Watchtowers
  { id: "watch-n", x: 0, y: 17, z: -108, w: 12, h: 34, d: 12, kind: "tower", roofColor: 0x55302a, wallColor: 0x9b8e7b },
  { id: "watch-s", x: 0, y: 17, z: 108, w: 12, h: 34, d: 12, kind: "tower", roofColor: 0x55302a, wallColor: 0x9b8e7b },
  { id: "watch-w", x: -108, y: 17, z: 0, w: 12, h: 34, d: 12, kind: "tower", roofColor: 0x55302a, wallColor: 0x9b8e7b },
  { id: "watch-e", x: 108, y: 17, z: 0, w: 12, h: 34, d: 12, kind: "tower", roofColor: 0x55302a, wallColor: 0x9b8e7b },

  // Outer Wall Gate Bastions (Massive vertical boost towers near outer perimeter)
  { id: "gate-n", x: 0, y: 21, z: -182, w: 16, h: 42, d: 16, kind: "tower", roofColor: 0x4b2a24, wallColor: 0x8f8270 },
  { id: "gate-s", x: 0, y: 21, z: 182, w: 16, h: 42, d: 16, kind: "tower", roofColor: 0x4b2a24, wallColor: 0x8f8270 },
  { id: "gate-w", x: -182, y: 21, z: 0, w: 16, h: 42, d: 16, kind: "tower", roofColor: 0x4b2a24, wallColor: 0x8f8270 },
  { id: "gate-e", x: 182, y: 21, z: 0, w: 16, h: 42, d: 16, kind: "tower", roofColor: 0x4b2a24, wallColor: 0x8f8270 },
];

export const SUPPLY_STATIONS: SupplyStation[] = [
  { id: "sup-nw", x: -32, y: 19.0, z: -30, label: "NW Rooftop Depot" },
  { id: "sup-se", x: 34, y: 20.0, z: 32, label: "SE Rooftop Depot" },
  { id: "sup-n", x: 0, y: 0, z: -56, label: "North Avenue Cart" },
  { id: "sup-s", x: 0, y: 0, z: 56, label: "South Plaza Cart" },
  { id: "sup-w", x: -56, y: 0, z: 0, label: "West Avenue Cart" },
  { id: "sup-e", x: 56, y: 0, z: 0, label: "East Avenue Cart" },
  { id: "sup-onw", x: -138, y: 26.0, z: -136, label: "NW Citadel Roof Depot" },
  { id: "sup-ose", x: 138, y: 26.0, z: 136, label: "SE Citadel Roof Depot" },
];

export const SCOUT_SPAWNS = [
  { x: 0, y: 34.1, z: 108, yaw: 0 },
  { x: -14, y: 0, z: 84, yaw: 0 },
  { x: 14, y: 0, z: 84, yaw: 0 },
  { x: 0, y: 42.1, z: 182, yaw: 0 },
];

export const TITAN_SPAWN_POINTS: TitanSpawnPoint[] = [
  { x: 0, z: -144 },
  { x: -96, z: -96 },
  { x: 96, z: -96 },
  { x: -144, z: 0 },
  { x: 144, z: 0 },
  { x: -96, z: 96 },
  { x: 96, z: 96 },
  { x: 0, z: -76 },
  { x: -52, z: -52 },
  { x: 52, z: -52 },
];

export interface CityRaycastHit {
  dist: number;
  x: number;
  y: number;
  z: number;
  nx: number;
  ny: number;
  nz: number;
  boxId: string | "ground";
}

export function raycastCityObstacles(
  ox: number,
  oy: number,
  oz: number,
  dx: number,
  dy: number,
  dz: number,
  maxDist: number,
): CityRaycastHit | null {
  let bestT = maxDist;
  let bestHit: CityRaycastHit | null = null;

  // Ground plane y = 0
  if (dy < -1e-5 && oy > 0.05) {
    const tGround = -oy / dy;
    if (tGround > 0.3 && tGround < bestT) {
      bestT = tGround;
      bestHit = {
        dist: tGround,
        x: ox + dx * tGround,
        y: 0,
        z: oz + dz * tGround,
        nx: 0,
        ny: 1,
        nz: 0,
        boxId: "ground",
      };
    }
  }

  for (const box of CITY_BOXES) {
    const minX = box.x - box.w * 0.5;
    const maxX = box.x + box.w * 0.5;
    const minY = box.y - box.h * 0.5;
    const maxY = box.y + box.h * 0.5;
    const minZ = box.z - box.d * 0.5;
    const maxZ = box.z + box.d * 0.5;

    let tMin = 0;
    let tMax = bestT;
    let hitNx = 0;
    let hitNy = 0;
    let hitNz = 0;

    // X slab
    if (Math.abs(dx) < 1e-8) {
      if (ox < minX || ox > maxX) continue;
    } else {
      const inv = 1 / dx;
      let t1 = (minX - ox) * inv;
      let t2 = (maxX - ox) * inv;
      let n = -1;
      if (t1 > t2) {
        const tmp = t1;
        t1 = t2;
        t2 = tmp;
        n = 1;
      }
      if (t1 > tMin) {
        tMin = t1;
        hitNx = n;
        hitNy = 0;
        hitNz = 0;
      }
      tMax = Math.min(tMax, t2);
      if (tMin > tMax) continue;
    }

    // Y slab
    if (Math.abs(dy) < 1e-8) {
      if (oy < minY || oy > maxY) continue;
    } else {
      const inv = 1 / dy;
      let t1 = (minY - oy) * inv;
      let t2 = (maxY - oy) * inv;
      let n = -1;
      if (t1 > t2) {
        const tmp = t1;
        t1 = t2;
        t2 = tmp;
        n = 1;
      }
      if (t1 > tMin) {
        tMin = t1;
        hitNx = 0;
        hitNy = n;
        hitNz = 0;
      }
      tMax = Math.min(tMax, t2);
      if (tMin > tMax) continue;
    }

    // Z slab
    if (Math.abs(dz) < 1e-8) {
      if (oz < minZ || oz > maxZ) continue;
    } else {
      const inv = 1 / dz;
      let t1 = (minZ - oz) * inv;
      let t2 = (maxZ - oz) * inv;
      let n = -1;
      if (t1 > t2) {
        const tmp = t1;
        t1 = t2;
        t2 = tmp;
        n = 1;
      }
      if (t1 > tMin) {
        tMin = t1;
        hitNx = 0;
        hitNy = 0;
        hitNz = n;
      }
      tMax = Math.min(tMax, t2);
      if (tMin > tMax) continue;
    }

    if (tMin > 0.35 && tMin < bestT) {
      bestT = tMin;
      bestHit = {
        dist: tMin,
        x: ox + dx * tMin,
        y: oy + dy * tMin,
        z: oz + dz * tMin,
        nx: hitNx,
        ny: hitNy,
        nz: hitNz,
        boxId: box.id,
      };
    }
  }

  return bestHit;
}

export function resolvePlayerCityCollision(
  x: number,
  y: number,
  z: number,
  vy: number,
  radius: number,
  playerHeight: number,
): { x: number; y: number; z: number; vy: number; grounded: boolean } {
  let px = Math.max(-201.5, Math.min(201.5, x));
  let py = y;
  let pz = Math.max(-201.5, Math.min(201.5, z));
  let pvy = vy;
  let grounded = false;

  if (py <= 0) {
    py = 0;
    if (pvy < 0) pvy = 0;
    grounded = true;
  }

  for (const box of CITY_BOXES) {
    if (box.kind === "wall") continue;
    const minX = box.x - box.w * 0.5;
    const maxX = box.x + box.w * 0.5;
    const minY = box.y - box.h * 0.5;
    const maxY = box.y + box.h * 0.5;
    const minZ = box.z - box.d * 0.5;
    const maxZ = box.z + box.d * 0.5;

    // Quick vertical overlap check
    if (py + playerHeight <= minY + 0.05) continue;

    // Rooftop landing check when horizontally near/inside footprint
    const inFootprint =
      px >= minX - radius * 0.72 &&
      px <= maxX + radius * 0.72 &&
      pz >= minZ - radius * 0.72 &&
      pz <= maxZ + radius * 0.72;

    if (inFootprint && py >= maxY - 1.35 && py <= maxY + 0.35 && pvy <= 0.5) {
      py = maxY;
      pvy = 0;
      grounded = true;
      continue;
    }

    if (py >= maxY - 0.15) continue;

    // Horizontal push-out from building walls
    const closestX = Math.max(minX, Math.min(px, maxX));
    const closestZ = Math.max(minZ, Math.min(pz, maxZ));
    const dx = px - closestX;
    const dz = pz - closestZ;
    const distSq = dx * dx + dz * dz;
    if (distSq < radius * radius) {
      const dist = Math.sqrt(distSq);
      if (dist > 0.0001) {
        const push = radius - dist;
        px += (dx / dist) * push;
        pz += (dz / dist) * push;
      } else {
        const penLeft = Math.abs(px - minX);
        const penRight = Math.abs(maxX - px);
        const penTop = Math.abs(pz - minZ);
        const penBot = Math.abs(maxZ - pz);
        const minPen = Math.min(penLeft, penRight, penTop, penBot);
        if (minPen === penLeft) px = minX - radius;
        else if (minPen === penRight) px = maxX + radius;
        else if (minPen === penTop) pz = minZ - radius;
        else pz = maxZ + radius;
      }
    }
  }

  return { x: px, y: py, z: pz, vy: pvy, grounded };
}

export function resolveTitanCityPush(
  x: number,
  z: number,
  radius: number,
): { x: number; z: number } {
  let tx = Math.max(-197, Math.min(197, x));
  let tz = Math.max(-197, Math.min(197, z));

  for (const box of CITY_BOXES) {
    if (box.kind === "wall") continue;
    const minX = box.x - box.w * 0.5;
    const maxX = box.x + box.w * 0.5;
    const minZ = box.z - box.d * 0.5;
    const maxZ = box.z + box.d * 0.5;
    const cx = Math.max(minX, Math.min(tx, maxX));
    const cz = Math.max(minZ, Math.min(tz, maxZ));
    const dx = tx - cx;
    const dz = tz - cz;
    const dSq = dx * dx + dz * dz;
    if (dSq < radius * radius) {
      const d = Math.sqrt(dSq);
      if (d > 0.001) {
        const push = radius - d;
        tx += (dx / d) * push;
        tz += (dz / d) * push;
      } else {
        tx = minX - radius;
      }
    }
  }
  return { x: tx, z: tz };
}
