export interface SoundtrackItem {
  id: string;
  title: string;
  artist?: string;
  url: string;
  isCustom?: boolean;
}

export type WorkshopAudioGameTheme = "shooter" | "racing" | "strategy" | "titan";

export const GAME_SOUNDTRACK_PLAYLIST: SoundtrackItem[] = [
  {
    id: "lovers",
    title: "Lovers on the Sun",
    artist: "David Guetta ft. Sam Martin",
    url: "/assets/aistudio/Lovers_on_the_Sun__feat._Sam_Martin__-_David_Guetta_c426b995.m4a",
  },
  {
    id: "heart",
    title: "Nothing Breaks Like a Heart",
    artist: "Mark Ronson ft. Miley Cyrus",
    url: "/assets/aistudio/Nothing_Breaks_Like_a_Heart__feat._Miley_Cyrus__-_Mark_Ronso_56a7a985.m4a",
  },
  {
    id: "nevada2",
    title: "Nevada 2.0",
    artist: "GNOSIS Workshop OST",
    url: "/assets/aistudio/nevada2.0_f9589c48.mp3",
  },
  {
    id: "nevada",
    title: "Nevada",
    artist: "GNOSIS Workshop OST",
    url: "/assets/aistudio/nevada_33dd1c8c.mp3",
  },
];

export const GAME_SOUNDTRACK_URL = GAME_SOUNDTRACK_PLAYLIST[0].url;

const THEME_DEFAULT_ID: Record<WorkshopAudioGameTheme, string> = {
  racing: "lovers",
  shooter: "nevada2",
  strategy: "heart",
  titan: "nevada",
};

const customSessionTracks: SoundtrackItem[] = [];
const activePlayers = new Set<GameSoundtrackPlayer>();
const trackChangeListeners = new Set<() => void>();
let notifyScheduled = false;

function scheduleNotifyTrackListeners() {
  if (notifyScheduled) return;
  notifyScheduled = true;
  queueMicrotask(() => {
    notifyScheduled = false;
    for (const listener of trackChangeListeners) {
      try {
        listener();
      } catch {
        // Ignore UI subscriber errors
      }
    }
  });
}

export function getSharedPlaylist(): SoundtrackItem[] {
  return [...GAME_SOUNDTRACK_PLAYLIST, ...customSessionTracks];
}

export function getActiveSoundtrackItem(): SoundtrackItem {
  const first = activePlayers.values().next().value as GameSoundtrackPlayer | undefined;
  if (first) return first.getCurrentTrack();
  const list = getSharedPlaylist();
  return list[0] || GAME_SOUNDTRACK_PLAYLIST[0];
}

export function getActiveSoundtrackTitle(): string {
  return getActiveSoundtrackItem().title;
}

export function subscribeSoundtrackMeta(listener: () => void): () => void {
  trackChangeListeners.add(listener);
  return () => {
    trackChangeListeners.delete(listener);
  };
}

export function cycleActiveSoundtrack(): string {
  let latestTitle = getActiveSoundtrackTitle();
  for (const player of activePlayers) {
    latestTitle = player.nextTrack();
  }
  scheduleNotifyTrackListeners();
  return latestTitle;
}

export function selectActiveSoundtrackByUrl(url: string): string {
  const list = getSharedPlaylist();
  const item = list.find((t) => t.url === url);
  if (!item) return getActiveSoundtrackTitle();
  for (const player of activePlayers) {
    player.selectTrackItem(item);
  }
  scheduleNotifyTrackListeners();
  return item.title;
}

export function setActiveSoundtrackVolume(volume: number) {
  for (const player of activePlayers) {
    player.setVolume(volume);
  }
}

export function registerSessionTrackFile(file: File): string {
  const url = URL.createObjectURL(file);
  const title = file.name.replace(/\.[^/.]+$/, "") || "Custom Track";
  const item: SoundtrackItem = {
    id: `custom-${Date.now()}`,
    title,
    artist: "Local Upload",
    url,
    isCustom: true,
  };
  customSessionTracks.push(item);

  for (const player of activePlayers) {
    player.selectTrackItem(item);
  }
  scheduleNotifyTrackListeners();
  return title;
}

/**
 * Shared HTMLAudio soundtrack controller for GNOSIS Workshop games.
 * Ensures zero overlapping tracks across views, supports all 4 bundled OST/licensed tracks
 * + custom local file uploads, volume scaling, mute/toggle, and clean teardown.
 */
export class GameSoundtrackPlayer {
  private audio: HTMLAudioElement | null = null;
  private tracks: SoundtrackItem[] = getSharedPlaylist();
  private trackIndex = 0;
  private musicEnabled = true;
  private globalMuted = false;
  private wantedPlaying = false;
  private baseVolume: number;

  constructor(baseVolume = 0.36, theme?: WorkshopAudioGameTheme) {
    this.baseVolume = Math.max(0, Math.min(1, baseVolume));
    if (customSessionTracks.length > 0) {
      this.trackIndex = this.tracks.length - 1;
    } else if (theme) {
      const targetId = THEME_DEFAULT_ID[theme];
      const idx = this.tracks.findIndex((t) => t.id === targetId);
      if (idx >= 0) this.trackIndex = idx;
    }
  }

  attach() {
    // Pause any lingering players so two games/menus never overlap audio
    for (const other of activePlayers) {
      if (other !== this) {
        other.pause();
      }
    }
    if (!activePlayers.has(this)) {
      activePlayers.add(this);
      scheduleNotifyTrackListeners();
    }
  }

  getCurrentTrack(): SoundtrackItem {
    return this.tracks[this.trackIndex] || GAME_SOUNDTRACK_PLAYLIST[0];
  }

  getTrackTitle(): string {
    return this.getCurrentTrack().title;
  }

  getTrackCount(): number {
    return this.tracks.length;
  }

  private ensureElement(): HTMLAudioElement | null {
    if (typeof window === "undefined" || typeof Audio === "undefined") return null;
    if (!this.audio) {
      const current = this.tracks[this.trackIndex] || GAME_SOUNDTRACK_PLAYLIST[0];
      const el = new Audio(current.url);
      el.loop = this.tracks.length === 1;
      el.preload = "auto";
      el.volume = this.baseVolume;
      el.addEventListener("ended", () => {
        if (this.tracks.length > 1) {
          this.nextTrack();
        }
      });
      this.audio = el;
    }
    return this.audio;
  }

  private syncState() {
    const el = this.audio;
    if (!el) return;
    el.loop = this.tracks.length === 1;
    el.muted = this.globalMuted || !this.musicEnabled || this.baseVolume <= 0.001;
    el.volume = Math.max(0, Math.min(1, this.baseVolume));
    if (this.wantedPlaying && this.musicEnabled && !this.globalMuted && this.baseVolume > 0.001) {
      // Ensure no sibling player stays playing
      for (const other of activePlayers) {
        if (other !== this) other.pause();
      }
      if (el.paused) {
        const p = el.play();
        if (p && typeof p.catch === "function") {
          p.catch(() => {
            // Autoplay blocked until next user interaction
          });
        }
      }
    } else if (!el.paused) {
      el.pause();
    }
  }

  startOnGesture() {
    this.attach();
    this.wantedPlaying = true;
    this.ensureElement();
    this.syncState();
  }

  setVolume(volume: number) {
    this.baseVolume = Math.max(0, Math.min(1, volume));
    this.syncState();
  }

  nextTrack(): string {
    this.attach();
    this.tracks = getSharedPlaylist();
    if (this.tracks.length > 0) {
      this.trackIndex = (this.trackIndex + 1) % this.tracks.length;
    }
    const el = this.ensureElement();
    if (el) {
      const next = this.tracks[this.trackIndex];
      if (next) {
        el.src = next.url;
        el.currentTime = 0;
        if (this.wantedPlaying && this.musicEnabled && !this.globalMuted) {
          el.play().catch(() => {});
        }
      }
    }
    scheduleNotifyTrackListeners();
    return this.getTrackTitle();
  }

  selectTrackItem(item: SoundtrackItem): string {
    this.attach();
    this.tracks = getSharedPlaylist();
    const idx = this.tracks.findIndex((t) => t.url === item.url || t.id === item.id);
    this.trackIndex = idx >= 0 ? idx : this.tracks.length - 1;
    this.wantedPlaying = true;
    const el = this.ensureElement();
    if (el) {
      if (el.src !== new URL(item.url, window.location.href).href) {
        el.src = item.url;
        el.currentTime = 0;
      }
      this.syncState();
    }
    scheduleNotifyTrackListeners();
    return this.getTrackTitle();
  }

  selectTrackByUrl(url: string): string {
    this.tracks = getSharedPlaylist();
    const found = this.tracks.find((t) => t.url === url);
    if (!found) return this.getTrackTitle();
    return this.selectTrackItem(found);
  }

  addCustomTrackFile(file: File): string {
    return registerSessionTrackFile(file);
  }

  setMusicEnabled(enabled: boolean) {
    this.musicEnabled = enabled;
    if (enabled && !this.globalMuted) {
      this.attach();
      this.wantedPlaying = true;
      this.ensureElement();
    }
    this.syncState();
  }

  setMuted(muted: boolean) {
    this.globalMuted = muted;
    this.syncState();
  }

  pause() {
    this.wantedPlaying = false;
    this.syncState();
  }

  dispose() {
    activePlayers.delete(this);
    this.wantedPlaying = false;
    if (this.audio) {
      try {
        this.audio.pause();
        this.audio.removeAttribute("src");
        this.audio.load();
      } catch {
        // Ignore cleanup errors
      }
      this.audio = null;
    }
    scheduleNotifyTrackListeners();
  }
}
