import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Hoi4AudioEngine } from "./hoi4/audio";
import { LocalStrategyCampaign } from "./hoi4/localEngine";
import type {
  StrategyPublicRoom,
  StrategyScenario,
  StrategySnapshot,
} from "./hoi4/types";
import {
  COUNTRIES_BY_ID,
  FEATURED_COUNTRY_IDS,
  NATIONAL_FOCUSES,
  REGION_INFO,
  TECH_ITEMS,
  TERRAIN_INFO,
  UNIT_TEMPLATES,
  WORLD_COUNTRY_SPECS,
  type EquipmentType,
  type RegionId,
  type UnitTemplateId,
} from "./hoi4/worldData";
import {
  findCountryAtWorldPoint,
  WORLD_COUNTRIES,
  WORLD_COUNTRIES_BY_ID,
  WORLD_MAP_H,
  WORLD_MAP_W,
} from "./hoi4/worldGeo";
import {
  createWorkshopLobbyClient,
  openWorkshopRoom,
  type NetworkConnectionState,
  type WorkshopLobbyClient,
  type WorkshopRoomSummary,
  type WorkshopRoomTransport,
} from "./net/gameNetwork";
import { Hoi4RoomHost, type Hoi4OutgoingEvent } from "./hoi4/multiplayerEngine";
import {
  GameSoundtrackPlayer,
  getSharedPlaylist,
  registerSessionTrackFile,
  selectActiveSoundtrackByUrl,
  subscribeSoundtrackMeta,
} from "./soundtrack";
import {
  resetWorkshopSettings,
  updateWorkshopSettings,
  useWorkshopSettings,
} from "./sharedSettings";
import cardWorldImg from "../assets/images/card_world_command_1795263403926.jpg";

type MapMode = "political" | "region" | "resources" | "diplomacy";
type DrawerTab = "focus" | "economy" | "recruit" | "tech" | "diplomacy" | "world" | null;
type StrategyLobbyTab = "theater" | "dossier" | "settings";

export function Hoi4StrategyGame({
  isFullscreen,
  onToggleFullscreen,
  onExit,
}: {
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  onExit: () => void;
}) {
  const lobbyClientRef = useRef<WorkshopLobbyClient | null>(null);
  const roomTransportRef = useRef<WorkshopRoomTransport | null>(null);
  const hostEngineRef = useRef<Hoi4RoomHost | null>(null);
  const hostTickTimerRef = useRef<number | null>(null);
  const joinTimeoutRef = useRef<number | null>(null);
  const lastMetaSyncAtRef = useRef(0);
  const applyHoi4MessageRef = useRef<(msg: Record<string, unknown>) => void>(() => {});
  const soloEngineRef = useRef<LocalStrategyCampaign | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const settings = useWorkshopSettings();
  const [audioEngine] = useState(() => new Hoi4AudioEngine());
  const [musicPlayer] = useState(() => new GameSoundtrackPlayer(settings.musicVolume, "strategy"));
  const audioRef = useRef<Hoi4AudioEngine>(audioEngine);
  const musicRef = useRef<GameSoundtrackPlayer>(musicPlayer);

  const [wsState, setWsState] = useState<NetworkConnectionState>("probing");
  const [wsDetail, setWsDetail] = useState<string | null>(null);
  const [wsLatency, setWsLatency] = useState<number | null>(null);
  const [wsError, setWsError] = useState<string | null>(null);
  const [publicRooms, setPublicRooms] = useState<StrategyPublicRoom[]>([]);

  // Lobby & Start Setup
  const [lobbyTab, setLobbyTab] = useState<StrategyLobbyTab>("theater");
  const [playlistItems, setPlaylistItems] = useState(() => getSharedPlaylist());
  const [commanderName, setCommanderName] = useState(
    () => sessionStorage.getItem("gnosis-strategy-name") || "Marshal-01",
  );
  const [roomTitle, setRoomTitle] = useState("Global Multipolar Theater");
  const [scenario, setScenario] = useState<StrategyScenario>("multipolar");
  const [chosenStartIso, setChosenStartIso] = useState<string>("840");
  const [lobbySearch, setLobbySearch] = useState("");
  const [regionFilter, setRegionFilter] = useState<"all" | RegionId>("all");
  const [joinCode, setJoinCode] = useState("");

  // Active Game State
  const [snapshot, setSnapshot] = useState<StrategySnapshot | null>(null);
  const [localPlayerId, setLocalPlayerId] = useState("");
  const [mapMode, setMapMode] = useState<MapMode>("political");
  const [activeDrawer, setActiveDrawer] = useState<DrawerTab>("focus");
  const [selectedIsoId, setSelectedIsoId] = useState<string | null>("840");
  const [hoveredIsoId, setHoveredIsoId] = useState<string | null>(null);
  const [hoverScreenPos, setHoverScreenPos] = useState<{ x: number; y: number } | null>(null);
  const [selectedDivisionIds, setSelectedDivisionIds] = useState<string[]>([]);
  const [orderClickMode, setOrderClickMode] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [chatInput, setChatInput] = useState("");
  const [worldSearch, setWorldSearch] = useState("");
  const muted = settings.muted;
  const musicOn = settings.musicEnabled;

  // Camera Pan & Zoom in 1600x820 Equirectangular World Space
  const camRef = useRef({ x: WORLD_MAP_W / 2, y: WORLD_MAP_H / 2, zoom: 0.72 });
  const dragRef = useRef({
    active: false,
    moved: false,
    startX: 0,
    startY: 0,
    camX: WORLD_MAP_W / 2,
    camY: WORLD_MAP_H / 2,
  });

  const snapRef = useRef<StrategySnapshot | null>(null);
  snapRef.current = snapshot;
  const selectedDivRef = useRef<string[]>(selectedDivisionIds);
  selectedDivRef.current = selectedDivisionIds;
  const selectedIsoRef = useRef<string | null>(selectedIsoId);
  selectedIsoRef.current = selectedIsoId;
  const hoveredIsoRef = useRef<string | null>(hoveredIsoId);
  hoveredIsoRef.current = hoveredIsoId;
  const mapModeRef = useRef<MapMode>(mapMode);
  mapModeRef.current = mapMode;

  useEffect(() => {
    audioRef.current.setMuted(muted);
    audioRef.current.setVolume(settings.sfxVolume);
    musicRef.current.setVolume(settings.musicVolume);
    musicRef.current.setMuted(muted);
    musicRef.current.setMusicEnabled(musicOn);
  }, [muted, musicOn, settings.musicVolume, settings.sfxVolume]);

  useEffect(() => {
    return subscribeSoundtrackMeta(() => setPlaylistItems(getSharedPlaylist()));
  }, []);

  const stopHostSimulation = useCallback(() => {
    if (hostTickTimerRef.current !== null) {
      window.clearInterval(hostTickTimerRef.current);
      hostTickTimerRef.current = null;
    }
    hostEngineRef.current = null;
  }, []);

  const clearJoinTimeout = useCallback(() => {
    if (joinTimeoutRef.current !== null) {
      window.clearTimeout(joinTimeoutRef.current);
      joinTimeoutRef.current = null;
    }
  }, []);

  applyHoi4MessageRef.current = (msg: Record<string, unknown>) => {
    if (msg.type === "error") {
      clearJoinTimeout();
      setWsError(String(msg.message || "Grand Strategy theater error."));
      return;
    }
    if (msg.type === "hoi4:joined") {
      clearJoinTimeout();
      soloEngineRef.current = null;
      const snap = msg.snapshot as StrategySnapshot;
      const pid = String(msg.playerId);
      setLocalPlayerId(pid);
      setSnapshot(snap);
      const nid = typeof msg.nationId === "string" ? msg.nationId : null;
      if (nid) {
        setSelectedIsoId(nid);
        const geo = WORLD_COUNTRIES_BY_ID[nid];
        if (geo) camRef.current = { x: geo.x, y: geo.y, zoom: 2.2 };
      }
      setSelectedDivisionIds([]);
      setWsError(null);
      return;
    }
    if (msg.type === "hoi4:snapshot") {
      if (soloEngineRef.current) return;
      setSnapshot(msg as unknown as StrategySnapshot);
    }
  };

  const broadcastHostSnapshot = useCallback((host: Hoi4RoomHost, syncMeta = false) => {
    const transport = roomTransportRef.current;
    if (!transport || !transport.getIsHost()) return;
    const snap = host.serializeSnapshot();
    const packet = { ...snap, type: "hoi4:snapshot" };
    applyHoi4MessageRef.current(packet);
    transport.send(packet);
    if (syncMeta) {
      lastMetaSyncAtRef.current = performance.now();
      void transport.updateRoomMeta(host.getRoomSummaryMeta());
    }
  }, []);

  const dispatchHostEvents = useCallback((events: Hoi4OutgoingEvent[]) => {
    const transport = roomTransportRef.current;
    if (!transport) return;
    const localId = transport.localPlayerId;
    for (const ev of events) {
      if (ev.targetId) {
        if (ev.targetId === localId) {
          applyHoi4MessageRef.current(ev.payload);
        } else {
          transport.send(ev.payload, ev.targetId);
        }
      } else {
        applyHoi4MessageRef.current(ev.payload);
        transport.send(ev.payload);
      }
    }
  }, []);

  const startHostSimulation = useCallback(() => {
    if (hostTickTimerRef.current !== null) {
      window.clearInterval(hostTickTimerRef.current);
    }
    hostTickTimerRef.current = window.setInterval(() => {
      const host = hostEngineRef.current;
      const transport = roomTransportRef.current;
      if (!host || !transport || !transport.getIsHost()) return;

      const advanced = host.tick();
      const now = performance.now();
      const shouldMeta = now - lastMetaSyncAtRef.current >= 3500;
      if (advanced) {
        broadcastHostSnapshot(host, shouldMeta);
      } else if (shouldMeta) {
        lastMetaSyncAtRef.current = now;
        void transport.updateRoomMeta(host.getRoomSummaryMeta());
      }
    }, 360);
  }, [broadcastHostSnapshot]);

  // Connect Supabase Realtime lobby discovery for Grand Strategy rooms
  useEffect(() => {
    const lobby = createWorkshopLobbyClient({
      channel: "hoi4",
      onStateChange: (state, detail) => {
        setWsState(state);
        setWsDetail(detail ?? null);
        if (state === "connected") setWsError(null);
      },
      onRoomsChange: (rooms: WorkshopRoomSummary[]) => {
        setPublicRooms(
          rooms.map((r) => ({
            code: r.code,
            title: r.title,
            scenario: (r.scenario === "flashpoint" ? "flashpoint" : "multipolar") as StrategyScenario,
            players: r.players,
            maxPlayers: r.maxPlayers,
            dateStr: r.dateStr || "1936-01-01",
            speed: 3,
            paused: false,
            worldTension: r.worldTension ?? 12,
          })),
        );
      },
      onLatency: (rtt) => setWsLatency(rtt),
    });

    musicRef.current.attach();
    lobbyClientRef.current = lobby;
    lobby.connect();

    return () => {
      clearJoinTimeout();
      stopHostSimulation();
      void roomTransportRef.current?.leave();
      roomTransportRef.current = null;
      void lobby.disconnect();
      lobbyClientRef.current = null;
      audioRef.current.dispose();
      musicRef.current.dispose();
    };
  }, [clearJoinTimeout, stopHostSimulation]);

  // Solo Campaign local simulation loop
  useEffect(() => {
    const timer = window.setInterval(() => {
      const solo = soloEngineRef.current;
      if (!solo) return;
      const snap = solo.tick(1);
      setSnapshot(snap);
    }, 280);
    return () => window.clearInterval(timer);
  }, []);

  // Unified command dispatcher (routes to Solo engine, Host engine, OR Supabase Realtime guest broadcast)
  const dispatchCommand = useCallback(
    (payload: Record<string, unknown>) => {
      const solo = soloEngineRef.current;
      if (solo) {
        const res = solo.dispatch(payload);
        if (res.error) setWsError(res.error);
        else setWsError(null);
        setSnapshot(res.snapshot);
        return;
      }
      const transport = roomTransportRef.current;
      if (!transport) return;
      if (transport.getIsHost() && hostEngineRef.current) {
        const host = hostEngineRef.current;
        const res = host.dispatchCommand(transport.localPlayerId, payload);
        if (res.error) setWsError(res.error);
        else setWsError(null);
        if (res.changed) {
          broadcastHostSnapshot(host, false);
        }
        return;
      }
      transport.send(payload);
    },
    [broadcastHostSnapshot],
  );

  const launchSoloCampaign = useCallback(
    (startIso = chosenStartIso) => {
      audioRef.current.initOnGesture();
      musicRef.current.startOnGesture();
      clearJoinTimeout();
      stopHostSimulation();
      if (roomTransportRef.current) {
        void roomTransportRef.current.leave();
        roomTransportRef.current = null;
      }
      sessionStorage.setItem("gnosis-strategy-name", commanderName);
      const engine = new LocalStrategyCampaign(commanderName, startIso, scenario);
      soloEngineRef.current = engine;
      setLocalPlayerId(engine.getPlayerId());
      setSnapshot(engine.getSnapshot());
      setSelectedIsoId(startIso);
      const geo = WORLD_COUNTRIES_BY_ID[startIso];
      if (geo) camRef.current = { x: geo.x, y: geo.y, zoom: 2.1 };
      setSelectedDivisionIds([]);
      setWsError(null);
    },
    [chosenStartIso, clearJoinTimeout, commanderName, scenario, stopHostSimulation],
  );

  const openOnlineTheater = async (action: "create" | "join", code?: string) => {
    audioRef.current.initOnGesture();
    musicRef.current.startOnGesture();
    audioRef.current.playClick();
    const cleanName = commanderName.trim() || "Marshal-01";
    sessionStorage.setItem("gnosis-strategy-name", cleanName);
    setWsError(null);
    clearJoinTimeout();
    stopHostSimulation();
    soloEngineRef.current = null;
    await roomTransportRef.current?.leave();
    roomTransportRef.current = null;

    const { session, error } = await openWorkshopRoom({
      channel: "hoi4",
      mode: action,
      code,
      playerName: cleanName,
      maxPlayers: 12,
      initialMeta: {
        title: roomTitle.trim() || "Global Multipolar Theater",
        scenario,
        dateStr: "1936-01-01",
        worldTension: scenario === "flashpoint" ? 32 : 12,
      },
      joinHelloPayload: { nationId: chosenStartIso },
      onStatusChange: (st, detail) => {
        if (st === "offline" && detail) setWsError(detail);
      },
      onLatency: (rtt) => setWsLatency(rtt),
      onPeersChange: (peers, _hostId, isHostNow) => {
        const curSnap = snapRef.current;
        if (isHostNow && !hostEngineRef.current && curSnap?.mode === "multiplayer") {
          hostEngineRef.current = Hoi4RoomHost.fromSnapshot(curSnap);
          startHostSimulation();
        }
        const host = hostEngineRef.current;
        if (host && isHostNow && peers.some((p) => p.playerId === roomTransportRef.current?.localPlayerId)) {
          const presentIds = new Set(peers.map((p) => p.playerId));
          let removedAny = false;
          for (const pl of Array.from(host.state.players.values())) {
            if (!presentIds.has(pl.id)) {
              host.removeCommander(pl.id);
              removedAny = true;
            }
          }
          if (removedAny) broadcastHostSnapshot(host, true);
        }
      },
      onMessage: (msg) => {
        const transport = roomTransportRef.current;
        if (transport?.getIsHost() && hostEngineRef.current) {
          const host = hostEngineRef.current;
          const sid = msg.senderId;
          if (msg.type === "peer:hello") {
            const added = host.addCommander(
              sid,
              String(msg.playerName || "Marshal"),
              typeof msg.nationId === "string" ? msg.nationId : undefined,
            );
            if (!added.ok) {
              transport.send({ type: "error", message: added.error || "Theater is full." }, sid);
              return;
            }
            dispatchHostEvents(added.events);
            broadcastHostSnapshot(host, true);
            return;
          }
          if (msg.type === "peer:left") {
            host.removeCommander(sid);
            broadcastHostSnapshot(host, true);
            return;
          }
          if (typeof msg.type === "string" && !msg.type.startsWith("hoi4:")) {
            const res = host.dispatchCommand(sid, msg);
            if (res.error) {
              transport.send({ type: "error", message: res.error }, sid);
            } else if (res.changed) {
              broadcastHostSnapshot(host, false);
            }
            return;
          }
        }
        applyHoi4MessageRef.current(msg);
      },
    });

    if (error || !session) {
      setWsError(error || "Unable to open Supabase multiplayer theater.");
      return;
    }

    roomTransportRef.current = session;

    if (action === "create") {
      const host = new Hoi4RoomHost(session.code, roomTitle, scenario);
      hostEngineRef.current = host;
      const added = host.addCommander(session.localPlayerId, cleanName, chosenStartIso);
      dispatchHostEvents(added.events);
      broadcastHostSnapshot(host, true);
      startHostSimulation();
    } else {
      joinTimeoutRef.current = window.setTimeout(() => {
        if (!snapRef.current && roomTransportRef.current === session) {
          setWsError(
            `Theater "${session.code}" host did not respond (session may have ended).`,
          );
          const ghost = session.getPeers().length <= 1;
          void session.leave(ghost);
          roomTransportRef.current = null;
          void lobbyClientRef.current?.refreshRooms();
        }
      }, 4500);
    }
  };

  const handleCreateOnlineRoom = () => {
    void openOnlineTheater("create");
  };

  const handleJoinOnlineRoom = (code: string) => {
    const clean = code.trim().toUpperCase();
    if (!clean) return;
    void openOnlineTheater("join", clean);
  };

  const handleLeaveCampaign = () => {
    clearJoinTimeout();
    stopHostSimulation();
    if (soloEngineRef.current) {
      soloEngineRef.current = null;
    }
    if (roomTransportRef.current) {
      void roomTransportRef.current.leave();
      roomTransportRef.current = null;
    }
    setSnapshot(null);
    setSelectedDivisionIds([]);
    setOrderClickMode(false);
    setWsError(null);
    void lobbyClientRef.current?.refreshRooms();
  };

  const localPlayer = useMemo(
    () => snapshot?.players.find((p) => p.id === localPlayerId) || null,
    [snapshot, localPlayerId],
  );
  const myIsoId: string | null = localPlayer?.nationId || null;
  const myNation = myIsoId && snapshot ? snapshot.countries[myIsoId] : null;
  const myNationSpec = myIsoId ? COUNTRIES_BY_ID[myIsoId] : null;

  // Clean up dead selected divisions
  useEffect(() => {
    if (!snapshot) return;
    const liveIds = new Set(snapshot.divisions.map((d) => d.id));
    setSelectedDivisionIds((prev) => {
      const next = prev.filter((id) => liveIds.has(id));
      return next.length === prev.length ? prev : next;
    });
  }, [snapshot]);

  // Keyboard shortcuts
  useEffect(() => {
    if (!snapshot) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (
        document.activeElement &&
        ["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement.tagName)
      ) {
        return;
      }
      if (e.code === "Space") {
        e.preventDefault();
        dispatchCommand({ type: "toggle_pause" });
      } else if (e.key === "1") setActiveDrawer((d) => (d === "focus" ? null : "focus"));
      else if (e.key === "2") setActiveDrawer((d) => (d === "economy" ? null : "economy"));
      else if (e.key === "3") setActiveDrawer((d) => (d === "recruit" ? null : "recruit"));
      else if (e.key === "4") setActiveDrawer((d) => (d === "tech" ? null : "tech"));
      else if (e.key === "5") setActiveDrawer((d) => (d === "diplomacy" ? null : "diplomacy"));
      else if (e.key === "6") setActiveDrawer((d) => (d === "world" ? null : "world"));
      else if (e.key === "Escape") {
        setSelectedDivisionIds([]);
        setOrderClickMode(false);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [snapshot, dispatchCommand]);

  const screenToWorld = useCallback((clientX: number, clientY: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return { wx: WORLD_MAP_W / 2, wy: WORLD_MAP_H / 2 };
    const rect = canvas.getBoundingClientRect();
    const sx = clientX - rect.left;
    const sy = clientY - rect.top;
    const cam = camRef.current;
    const wx = (sx - rect.width / 2) / cam.zoom + cam.x;
    const wy = (sy - rect.height / 2) / cam.zoom + cam.y;
    return { wx, wy };
  }, []);

  const focusRegion = useCallback((region: RegionId | "world") => {
    if (region === "world") {
      camRef.current = { x: WORLD_MAP_W / 2, y: WORLD_MAP_H / 2, zoom: 0.72 };
    } else {
      const r = REGION_INFO[region];
      camRef.current = { x: r.focusX, y: r.focusY, zoom: r.focusZoom };
    }
  }, []);

  // High-DPI Interactive World Map Canvas Renderer (Natural Earth 176 Countries)
  useEffect(() => {
    if (!snapshot) return;
    let rafId = 0;

    const renderMap = () => {
      const canvas = canvasRef.current;
      const wrap = wrapRef.current;
      const snap = snapRef.current;
      if (!canvas || !wrap || !snap) {
        rafId = requestAnimationFrame(renderMap);
        return;
      }

      const dpr = Math.min(2, window.devicePixelRatio || 1);
      const w = wrap.clientWidth || 800;
      const h = wrap.clientHeight || 540;
      if (canvas.width !== Math.floor(w * dpr) || canvas.height !== Math.floor(h * dpr)) {
        canvas.width = Math.floor(w * dpr);
        canvas.height = Math.floor(h * dpr);
      }

      const ctx = canvas.getContext("2d");
      if (!ctx) {
        rafId = requestAnimationFrame(renderMap);
        return;
      }

      const cam = camRef.current;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      // Deep Bathymetric Ocean Backdrop
      const oceanGrad = ctx.createLinearGradient(0, 0, 0, h);
      oceanGrad.addColorStop(0, "#091522");
      oceanGrad.addColorStop(0.5, "#0d2033");
      oceanGrad.addColorStop(1, "#08121d");
      ctx.fillStyle = oceanGrad;
      ctx.fillRect(0, 0, w, h);

      ctx.save();
      ctx.translate(w / 2, h / 2);
      ctx.scale(cam.zoom, cam.zoom);
      ctx.translate(-cam.x, -cam.y);

      // Map Bounds & Geographic Graticule (Lat/Lon lines)
      ctx.strokeStyle = "rgba(130, 175, 220, 0.08)";
      ctx.lineWidth = 1 / cam.zoom;
      for (let lon = -180; lon <= 180; lon += 30) {
        const x = ((lon + 180) / 360) * WORLD_MAP_W;
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, WORLD_MAP_H);
        ctx.stroke();
      }
      for (let lat = -60; lat <= 80; lat += 20) {
        const y = ((83 - lat) / 141) * WORLD_MAP_H;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(WORLD_MAP_W, y);
        ctx.stroke();
      }

      // Strategic Sea-Lane Shipping & Expedition Corridors
      ctx.save();
      ctx.strokeStyle = "rgba(138, 198, 255, 0.24)";
      ctx.lineWidth = 1.1 / cam.zoom;
      ctx.setLineDash([4 / cam.zoom, 4 / cam.zoom]);
      const drawnSea = new Set<string>();
      for (const c of WORLD_COUNTRIES) {
        for (const nbIso of c.seaNeighbors) {
          const key = c.isoId < nbIso ? `${c.isoId}-${nbIso}` : `${nbIso}-${c.isoId}`;
          if (drawnSea.has(key)) continue;
          drawnSea.add(key);
          const nb = WORLD_COUNTRIES_BY_ID[nbIso];
          if (!nb || Math.abs(c.x - nb.x) > WORLD_MAP_W * 0.6) continue;
          ctx.beginPath();
          ctx.moveTo(c.x, c.y);
          ctx.lineTo(nb.x, nb.y);
          ctx.stroke();
        }
      }
      ctx.restore();

      const selIso = selectedIsoRef.current;
      const hovIso = hoveredIsoRef.current;
      const mode = mapModeRef.current;
      const focusNation = selIso || myIsoId;
      const focusNatState = focusNation ? snap.countries[focusNation] : null;

      // Render All 176 Real Natural Earth Countries
      for (const geo of WORLD_COUNTRIES) {
        const cState = snap.countries[geo.isoId];
        const cSpec = COUNTRIES_BY_ID[geo.isoId];
        if (!cState || !cSpec) continue;

        const ctrlSpec = COUNTRIES_BY_ID[cState.controllerIso] || cSpec;

        let fillColor = ctrlSpec.color;
        if (mode === "region") {
          fillColor = REGION_INFO[cSpec.region].color;
        } else if (mode === "resources") {
          const resTotal =
            cSpec.resources.steel + cSpec.resources.oil + cSpec.resources.rare + cSpec.resources.grain;
          if (resTotal >= 100) fillColor = "#d99b38";
          else if (resTotal >= 65) fillColor = "#8ca84d";
          else if (resTotal >= 35) fillColor = "#4e7d63";
          else fillColor = "#344652";
        } else if (mode === "diplomacy" && focusNatState) {
          if (cState.controllerIso === focusNatState.isoId) fillColor = "#38915c";
          else if (focusNatState.atWarWith.includes(cState.controllerIso)) fillColor = "#b53c3c";
          else if (focusNatState.allies.includes(cState.controllerIso)) fillColor = "#4b9be8";
          else if (focusNatState.tradePactsWith.includes(cState.controllerIso)) fillColor = "#a89247";
          else fillColor = "#333a45";
        }

        const isSelected = selIso === geo.isoId;
        const isHovered = hovIso === geo.isoId;
        const isMyNation = myIsoId && cState.controllerIso === myIsoId;

        ctx.beginPath();
        for (const poly of geo.polygons) {
          for (const ring of poly.rings) {
            if (ring.length < 3) continue;
            ctx.moveTo(ring[0][0], ring[0][1]);
            for (let k = 1; k < ring.length; k++) {
              ctx.lineTo(ring[k][0], ring[k][1]);
            }
            ctx.closePath();
          }
        }

        ctx.fillStyle = fillColor;
        ctx.globalAlpha = isSelected ? 0.96 : isHovered ? 0.9 : 0.82;
        ctx.fill();
        ctx.globalAlpha = 1;

        ctx.strokeStyle = isSelected
          ? "#ffd875"
          : isHovered
            ? "#ffffff"
            : isMyNation
              ? "#e0be6e"
              : "#101822";
        ctx.lineWidth = (isSelected ? 2.1 : isHovered ? 1.4 : isMyNation ? 1.15 : 0.65) / cam.zoom;
        ctx.stroke();

        // Country Labels & Capitals when featured or sufficiently zoomed in
        const showLabel = cam.zoom >= 1.55 || cSpec.featured || isSelected || isHovered;
        if (showLabel) {
          ctx.fillStyle = isSelected ? "#ffe79e" : "#f4ecdc";
          ctx.font = `${cSpec.featured ? "700" : "500"} ${Math.max(4.5, 9.5 / Math.sqrt(cam.zoom))}px "JetBrains Mono", monospace`;
          ctx.textAlign = "center";
          ctx.fillText(cSpec.shortName, geo.x, geo.y - 5 / cam.zoom);

          if (cSpec.featured || isSelected) {
            ctx.fillStyle = cState.controllerIso === geo.isoId ? "#f7d469" : "#ff6352";
            ctx.beginPath();
            ctx.arc(geo.x, geo.y, 2.8 / cam.zoom, 0, Math.PI * 2);
            ctx.fill();
          }
        }
      }

      // Draw Movement Arrows for Moving Divisions
      for (const div of snap.divisions) {
        if (!div.targetProvinceId) continue;
        const fromG = WORLD_COUNTRIES_BY_ID[div.provinceId];
        const toG = WORLD_COUNTRIES_BY_ID[div.targetProvinceId];
        if (!fromG || !toG || Math.abs(fromG.x - toG.x) > WORLD_MAP_W * 0.6) continue;
        const ownerState = snap.countries[div.owner];
        const destState = snap.countries[div.targetProvinceId];
        const isAttack = Boolean(ownerState && destState && ownerState.atWarWith.includes(destState.controllerIso));

        ctx.save();
        ctx.strokeStyle = isAttack ? "#ff5247" : "#6ce094";
        ctx.lineWidth = 2.2 / cam.zoom;
        ctx.setLineDash([5 / cam.zoom, 3 / cam.zoom]);
        ctx.beginPath();
        ctx.moveTo(fromG.x, fromG.y);
        ctx.lineTo(toG.x, toG.y);
        ctx.stroke();
        ctx.restore();
      }

      // Group Division Stacks by Country
      const stacks = new Map<string, { owner: string; count: number; ids: string[]; moving: boolean; battle: boolean }[]>();
      for (const div of snap.divisions) {
        let arr = stacks.get(div.provinceId);
        if (!arr) {
          arr = [];
          stacks.set(div.provinceId, arr);
        }
        let g = arr.find((x) => x.owner === div.owner);
        if (!g) {
          g = { owner: div.owner, count: 0, ids: [], moving: false, battle: false };
          arr.push(g);
        }
        g.count += 1;
        g.ids.push(div.id);
        if (div.targetProvinceId) g.moving = true;
        if (div.inBattle) g.battle = true;
      }

      const selSet = new Set(selectedDivRef.current);
      for (const [isoId, ownerStacks] of stacks.entries()) {
        const geo = WORLD_COUNTRIES_BY_ID[isoId];
        if (!geo) continue;

        ownerStacks.forEach((st, idx) => {
          const anySel = st.ids.some((id) => selSet.has(id));
          const cSpec = COUNTRIES_BY_ID[st.owner];
          const isPlayerOwned = st.owner === myIsoId;
          // Show at world zoom only if player-owned, selected, in battle, or zoomed in
          if (!isPlayerOwned && !anySel && !st.battle && cam.zoom < 1.35 && !cSpec?.featured) {
            return;
          }

          const bx = geo.x + idx * (16 / cam.zoom);
          const by = geo.y + 8 / cam.zoom;
          const bw = 20 / cam.zoom;
          const bh = 12 / cam.zoom;

          ctx.fillStyle = cSpec?.color || "#4b5563";
          ctx.fillRect(bx - bw / 2, by - bh / 2, bw, bh);
          ctx.strokeStyle = anySel ? "#ffd84d" : st.battle ? "#ff5247" : "#f4ebdd";
          ctx.lineWidth = (anySel ? 2.0 : 1.0) / cam.zoom;
          ctx.strokeRect(bx - bw / 2, by - bh / 2, bw, bh);

          ctx.fillStyle = "#ffffff";
          ctx.font = `700 ${Math.max(5, 8.5 / cam.zoom)}px "JetBrains Mono", monospace`;
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.fillText(String(st.count), bx, by);
        });
      }

      // Draw Active Battles
      for (const bat of snap.battles) {
        const geo = WORLD_COUNTRIES_BY_ID[bat.provinceId];
        if (!geo) continue;
        const r = 10 / cam.zoom;
        ctx.fillStyle = bat.progress >= 55 ? "#267d47" : "#9c2d25";
        ctx.beginPath();
        ctx.arc(geo.x, geo.y - 12 / cam.zoom, r, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "#ffe082";
        ctx.lineWidth = 1.6 / cam.zoom;
        ctx.stroke();

        ctx.fillStyle = "#ffffff";
        ctx.font = `700 ${8 / cam.zoom}px "JetBrains Mono", monospace`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(`${bat.progress}%`, geo.x, geo.y - 12 / cam.zoom);
      }

      ctx.restore();
      rafId = requestAnimationFrame(renderMap);
    };

    rafId = requestAnimationFrame(renderMap);
    return () => cancelAnimationFrame(rafId);
  }, [snapshot, myIsoId]);

  const handleCanvasWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const sx = e.clientX - rect.left;
    const sy = e.clientY - rect.top;
    const cam = camRef.current;
    const wxBefore = (sx - rect.width / 2) / cam.zoom + cam.x;
    const wyBefore = (sy - rect.height / 2) / cam.zoom + cam.y;
    const factor = e.deltaY < 0 ? 1.16 : 0.86;
    const nextZoom = Math.max(0.55, Math.min(7.5, cam.zoom * factor));
    cam.zoom = nextZoom;
    cam.x = wxBefore - (sx - rect.width / 2) / nextZoom;
    cam.y = wyBefore - (sy - rect.height / 2) / nextZoom;
  };

  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (e.button === 2) return;
    dragRef.current = {
      active: true,
      moved: false,
      startX: e.clientX,
      startY: e.clientY,
      camX: camRef.current.x,
      camY: camRef.current.y,
    };
  };

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const { wx, wy } = screenToWorld(e.clientX, e.clientY);
    const hit = findCountryAtWorldPoint(wx, wy);
    setHoveredIsoId(hit ? hit.isoId : null);
    if (hit) {
      const rect = canvasRef.current?.getBoundingClientRect();
      if (rect) {
        setHoverScreenPos({ x: e.clientX - rect.left, y: e.clientY - rect.top });
      }
    } else {
      setHoverScreenPos(null);
    }

    if (!dragRef.current.active) return;
    const dx = e.clientX - dragRef.current.startX;
    const dy = e.clientY - dragRef.current.startY;
    if (Math.hypot(dx, dy) > 5) dragRef.current.moved = true;
    camRef.current.x = dragRef.current.camX - dx / camRef.current.zoom;
    camRef.current.y = dragRef.current.camY - dy / camRef.current.zoom;
  };

  const handleCanvasMouseUp = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const wasMoved = dragRef.current.moved;
    dragRef.current.active = false;
    if (wasMoved || !snapshot) return;

    audioRef.current.initOnGesture();
    const { wx, wy } = screenToWorld(e.clientX, e.clientY);
    const hit = findCountryAtWorldPoint(wx, wy);
    if (!hit) return;

    if (e.button === 2 || (orderClickMode && selectedDivisionIds.length > 0)) {
      if (selectedDivisionIds.length > 0) {
        audioRef.current.playOrderMarch();
        dispatchCommand({
          type: "move_divisions",
          divisionIds: selectedDivisionIds,
          targetProvinceId: hit.isoId,
        });
        setOrderClickMode(false);
      }
      return;
    }

    audioRef.current.playClick();
    setSelectedIsoId(hit.isoId);

    if (myIsoId) {
      const myDivsHere = snapshot.divisions
        .filter((d) => d.owner === myIsoId && d.provinceId === hit.isoId)
        .map((d) => d.id);
      if (myDivsHere.length > 0) {
        setSelectedDivisionIds(myDivsHere);
      }
    }
  };

  const handleCanvasContextMenu = (e: React.MouseEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    if (!snapshot || selectedDivisionIds.length === 0) return;
    const { wx, wy } = screenToWorld(e.clientX, e.clientY);
    const hit = findCountryAtWorldPoint(wx, wy);
    if (!hit) return;
    audioRef.current.initOnGesture();
    audioRef.current.playOrderMarch();
    dispatchCommand({
      type: "move_divisions",
      divisionIds: selectedDivisionIds,
      targetProvinceId: hit.isoId,
    });
  };

  const selectedGeo = selectedIsoId ? WORLD_COUNTRIES_BY_ID[selectedIsoId] : null;
  const selectedSpec = selectedIsoId ? COUNTRIES_BY_ID[selectedIsoId] : null;
  const selectedState = selectedIsoId && snapshot ? snapshot.countries[selectedIsoId] : null;

  const selectedCountryDivs = useMemo(() => {
    if (!snapshot || !selectedIsoId) return [];
    return snapshot.divisions.filter((d) => d.provinceId === selectedIsoId);
  }, [snapshot, selectedIsoId]);

  const myDivisions = useMemo(() => {
    if (!snapshot || !myIsoId) return [];
    return snapshot.divisions.filter((d) => d.owner === myIsoId);
  }, [snapshot, myIsoId]);

  const filteredLobbyCountries = useMemo(() => {
    const q = lobbySearch.trim().toLowerCase();
    const base =
      regionFilter === "all"
        ? WORLD_COUNTRY_SPECS
        : WORLD_COUNTRY_SPECS.filter((c) => c.region === regionFilter);
    const list = q
      ? base.filter((c) => c.name.toLowerCase().includes(q) || c.shortName.toLowerCase().includes(q))
      : regionFilter === "all"
        ? base.filter((c) => c.featured)
        : base;
    return list.slice(0, 32);
  }, [lobbySearch, regionFilter]);

  const filteredWorldCountries = useMemo(() => {
    const q = worldSearch.trim().toLowerCase();
    const list = q
      ? WORLD_COUNTRY_SPECS.filter(
          (c) =>
            c.name.toLowerCase().includes(q) ||
            c.shortName.toLowerCase().includes(q) ||
            REGION_INFO[c.region].label.toLowerCase().includes(q),
        )
      : WORLD_COUNTRY_SPECS.filter((c) => c.featured);
    return list.slice(0, 36);
  }, [worldSearch]);

  const adjustProduction = (key: EquipmentType, delta: number) => {
    if (!myNation) return;
    const alloc = { ...myNation.productionAlloc };
    if (delta > 0) {
      const donor = (["infantry", "tanks", "artillery", "fighters"] as EquipmentType[]).find(
        (k) => k !== key && alloc[k] > 0,
      );
      if (!donor) return;
      alloc[donor] -= 1;
      alloc[key] += 1;
    } else if (delta < 0 && alloc[key] > 0) {
      const receiver: EquipmentType = key === "infantry" ? "tanks" : "infantry";
      alloc[key] -= 1;
      alloc[receiver] += 1;
    }
    dispatchCommand({ type: "set_production", alloc });
  };

  const statusBadgeLabel =
    wsState === "connected"
      ? `● SUPABASE REALTIME${wsLatency ? ` · ${wsLatency}ms` : ""}`
      : wsState === "probing" || wsState === "connecting" || wsState === "reconnecting"
        ? "◌ CONNECTING REALTIME..."
        : wsState === "unconfigured"
          ? "SOLO CAMPAIGN READY (SUPABASE NOT CONFIGURED)"
          : "SOLO READY · REALTIME OFFLINE";

  // =========================================================================
  // LOBBY SCREEN (3-TAB COMMAND HUB)
  // =========================================================================
  if (!snapshot) {
    const chosenSpec = COUNTRIES_BY_ID[chosenStartIso] || WORLD_COUNTRY_SPECS[0];
    const currentTrackUrl = musicRef.current.getCurrentTrack().url;
    return (
      <div className="gw-fps-lobby">
        <div className="gw-hero-deck theme-strategy">
          <img className="gw-hero-deck-bg" src={cardWorldImg} alt="" />
          <div className="gw-hero-deck-scrim" />
          <div className="gw-hero-deck-content">
            <span className="gw-hero-deck-kicker">Real-World Natural Earth 176-Nation Grand Strategy</span>
            <h3>GNOSIS World Command · Grand Strategy</h3>
            <p>
              Command any of <strong>176 countries</strong> on a real Natural Earth geographic map with
              accurate borders, strategic sea lanes, economies, resources, research, diplomacy, and military operations.
            </p>
          </div>
          <div className="gw-hero-deck-actions">
            <button
              type="button"
              className={`gw-btn ${musicOn && !muted ? "gw-btn-primary" : ""}`}
              onClick={() => {
                musicRef.current.startOnGesture();
                updateWorkshopSettings({ musicEnabled: !musicOn });
              }}
            >
              {musicOn ? "♪ Music On" : "♪ Music Off"}
            </button>
            <span className={`gw-ws-badge ${wsState === "connected" ? "connected" : ""}`}>
              {statusBadgeLabel}
            </span>
            {wsState !== "connected" && (
              <button
                type="button"
                className="gw-btn"
                onClick={() => {
                  setWsError(null);
                  lobbyClientRef.current?.connect();
                }}
              >
                Reconnect
              </button>
            )}
            <button type="button" className="gw-btn" onClick={onToggleFullscreen}>
              {isFullscreen ? "Exit Fullscreen" : "Fullscreen"}
            </button>
            <button type="button" className="gw-btn" onClick={onExit}>
              Leave
            </button>
          </div>
        </div>

        {/* 3-Tab Hub Navigation */}
        <div className="gw-menu-tabs" role="tablist" aria-label="World Command Lobby Tabs">
          {(
            [
              ["theater", "Command & Theater"],
              ["dossier", "Nation Dossier & Scenarios"],
              ["settings", "Audio & Controls"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={lobbyTab === id}
              className={`gw-menu-tab ${lobbyTab === id ? "active" : ""}`}
              onClick={() => {
                audioRef.current.initOnGesture();
                musicRef.current.startOnGesture();
                setLobbyTab(id);
              }}
            >
              {label}
            </button>
          ))}
        </div>

        {(wsError || (wsState !== "connected" && wsDetail)) && (
          <div className="gw-fps-error" style={{ borderColor: wsError ? "#9c4034" : "#80663e", background: wsError ? undefined : "rgba(128,102,62,0.14)", color: wsError ? undefined : "#e8d6b3" }}>
            <span>{wsError || wsDetail}</span>
            {wsError && (
              <button type="button" className="gw-btn" onClick={() => setWsError(null)}>
                Dismiss
              </button>
            )}
          </div>
        )}

        {lobbyTab === "theater" && (
          <div className="gw-fps-lobby-grid">
            <div className="gw-fps-panel">
              <h4>Launch Campaign · Select Sovereign State</h4>
              <label className="gw-fps-field">
                <span>Commander Name</span>
                <input
                  type="text"
                  maxLength={18}
                  value={commanderName}
                  onChange={(e) => setCommanderName(e.target.value)}
                />
              </label>

              <div className="gw-fps-field">
                <span>Strategic Scenario</span>
                <div className="gw-hoi4-scenario-row">
                  <button
                    type="button"
                    className={`gw-btn ${scenario === "multipolar" ? "gw-btn-primary" : ""}`}
                    onClick={() => setScenario("multipolar")}
                  >
                    Multipolar Balance (Economic Buildup)
                  </button>
                  <button
                    type="button"
                    className={`gw-btn ${scenario === "flashpoint" ? "gw-btn-primary" : ""}`}
                    onClick={() => setScenario("flashpoint")}
                  >
                    Flashpoint Crisis (Active Conflicts)
                  </button>
                </div>
              </div>

              <label className="gw-fps-field">
                <span>Search All 176 Countries ({chosenSpec.name} selected)</span>
                <input
                  type="text"
                  placeholder="Type any country name (e.g. Brazil, Germany, Japan, Nigeria)..."
                  value={lobbySearch}
                  onChange={(e) => setLobbySearch(e.target.value)}
                />
              </label>

              <div className="gw-filter-bar" role="group" aria-label="Filter nations by region">
                <button
                  type="button"
                  className={`gw-filter-btn ${regionFilter === "all" ? "active" : ""}`}
                  onClick={() => setRegionFilter("all")}
                >
                  Featured Powers
                </button>
                {(Object.keys(REGION_INFO) as RegionId[]).map((rid) => (
                  <button
                    key={rid}
                    type="button"
                    className={`gw-filter-btn ${regionFilter === rid ? "active" : ""}`}
                    onClick={() => setRegionFilter(rid)}
                  >
                    {REGION_INFO[rid].label}
                  </button>
                ))}
              </div>

              <div className="gw-hoi4-nation-grid" style={{ maxHeight: 240, overflowY: "auto" }}>
                {filteredLobbyCountries.map((c) => (
                  <button
                    key={c.isoId}
                    type="button"
                    className={`gw-car-option ${chosenStartIso === c.isoId ? "selected" : ""}`}
                    onClick={() => setChosenStartIso(c.isoId)}
                  >
                    <div className="gw-car-swatch-row">
                      <span className="gw-car-swatch" style={{ background: c.color }} />
                      <small>{c.shortName} · {REGION_INFO[c.region].label}</small>
                    </div>
                    <strong style={{ fontSize: 15 }}>{c.name}</strong>
                    <div className="gw-car-mini-specs">
                      <span>Ref Pop {c.refPopulationM}M</span>
                      <span>Fac {c.startCiv}/{c.startMil}</span>
                    </div>
                  </button>
                ))}
              </div>

              <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 4 }}>
                <button
                  type="button"
                  className="brass-button"
                  onClick={() => launchSoloCampaign(chosenStartIso)}
                >
                  Launch Solo World Campaign ({chosenSpec.shortName})
                </button>
              </div>
            </div>

            <div className="gw-fps-panel">
              <div className="gw-fps-panel-top">
                <h4>Online Multiplayer Theaters (12P Supabase Realtime)</h4>
                <button
                  type="button"
                  className="gw-btn"
                  disabled={wsState !== "connected"}
                  onClick={() => void lobbyClientRef.current?.refreshRooms()}
                >
                  Refresh
                </button>
              </div>

              <label className="gw-fps-field">
                <span>Multiplayer Theater Title</span>
                <input
                  type="text"
                  maxLength={32}
                  value={roomTitle}
                  onChange={(e) => setRoomTitle(e.target.value)}
                />
              </label>

              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                <button
                  type="button"
                  className="gw-btn gw-btn-primary"
                  disabled={wsState !== "connected"}
                  onClick={handleCreateOnlineRoom}
                >
                  Host Online Theater
                </button>
              </div>

              <div className="gw-fps-divider" />

              <div className="gw-fps-code-row">
                <input
                  type="text"
                  maxLength={8}
                  placeholder="THEATER CODE (E.G. W4K9)"
                  value={joinCode}
                  onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                />
                <button
                  type="button"
                  className="gw-btn gw-btn-primary"
                  disabled={wsState !== "connected" || !joinCode.trim()}
                  onClick={() => handleJoinOnlineRoom(joinCode)}
                >
                  Join Code
                </button>
              </div>

              {wsState !== "connected" ? (
                <div className="gw-fps-empty">
                  <p>Solo Campaign is ready immediately on any host</p>
                  <span>
                    Online Multiplayer uses Supabase Realtime (Presence &amp; Broadcast) with host-coordinated
                    state. Use <strong>Launch Solo World Campaign</strong> on the left to play the full
                    176-nation game immediately, or configure{" "}
                    <code>VITE_SUPABASE_URL</code> and <code>VITE_SUPABASE_ANON_KEY</code>.
                  </span>
                </div>
              ) : publicRooms.length === 0 ? (
                <div className="gw-fps-empty">
                  <p>No active multiplayer theaters yet</p>
                  <span>Host an online theater above and share its code for 12-player diplomacy &amp; war.</span>
                </div>
              ) : (
                <div className="gw-fps-room-list">
                  {publicRooms.map((r) => (
                    <div key={r.code} className="gw-fps-room-row">
                      <div>
                        <strong>{r.title}</strong>
                        <small>
                          {r.code} · {r.dateStr} · {r.players}/{r.maxPlayers} CMD · Tension {r.worldTension}%
                        </small>
                      </div>
                      <button
                        type="button"
                        className="gw-btn gw-btn-primary"
                        onClick={() => handleJoinOnlineRoom(r.code)}
                      >
                        Join
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {lobbyTab === "dossier" && (
          <div className="gw-fps-lobby-grid">
            <div className="gw-fps-panel">
              <div className="gw-fps-panel-top">
                <h4>Sovereign Intelligence Dossier</h4>
                <button
                  type="button"
                  className="brass-button"
                  onClick={() => launchSoloCampaign(chosenSpec.isoId)}
                >
                  Command {chosenSpec.shortName} →
                </button>
              </div>

              <div className="gw-weapon-dossier">
                <small>
                  ISO #{chosenSpec.isoId} · {REGION_INFO[chosenSpec.region].label.toUpperCase()} ·{" "}
                  {TERRAIN_INFO[chosenSpec.terrain].label.toUpperCase()}
                </small>
                <h4>
                  {chosenSpec.name} ({chosenSpec.shortName}) ·{" "}
                  <span>{chosenSpec.doctrine}</span>
                </h4>
                <p>
                  Capital: <b>{chosenSpec.capitalName}</b> · Geographic baseline reference population{" "}
                  <b>~{chosenSpec.refPopulationM}M</b>.
                </p>
                <div className="gw-stat-pills gw-tabular">
                  <div><span>Civ Factories</span><strong>{chosenSpec.startCiv}</strong></div>
                  <div><span>Mil Factories</span><strong>{chosenSpec.startMil}</strong></div>
                  <div><span>Infra Tier</span><strong>Lv {chosenSpec.startInfra}</strong></div>
                  <div><span>Victory Pts</span><strong>{chosenSpec.vp}</strong></div>
                </div>
                <div className="gw-resource-bars">
                  {(
                    [
                      ["Steel Stock", chosenSpec.resources.steel, 60],
                      ["Oil Output", chosenSpec.resources.oil, 60],
                      ["Rare Earths", chosenSpec.resources.rare, 45],
                      ["Grain Supply", chosenSpec.resources.grain, 70],
                    ] as const
                  ).map(([label, val, scaleMax]) => (
                    <div key={label} className="gw-resource-bar-row">
                      <div>
                        <span>{label}</span>
                        <b>{val}</b>
                      </div>
                      <div className="gw-resource-track">
                        <i style={{ width: `${Math.min(100, Math.round((val / scaleMax) * 100))}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="gw-fps-divider" />
              <h4>Scenario Rules Comparison</h4>
              <div className="gw-fps-two-cols">
                <button
                  type="button"
                  className={`gw-car-option ${scenario === "multipolar" ? "selected" : ""}`}
                  onClick={() => setScenario("multipolar")}
                >
                  <small>SCENARIO I</small>
                  <strong>Multipolar Balance</strong>
                  <span>Low initial World Tension (12%). Focus on industry, research trees, and trade pacts.</span>
                </button>
                <button
                  type="button"
                  className={`gw-car-option ${scenario === "flashpoint" ? "selected" : ""}`}
                  onClick={() => setScenario("flashpoint")}
                >
                  <small>SCENARIO II</small>
                  <strong>Flashpoint Crisis</strong>
                  <span>Elevated World Tension (32%) with active border conflicts and urgent alliance decisions.</span>
                </button>
              </div>
            </div>

            <div className="gw-fps-panel">
              <h4>Featured Major Powers ({FEATURED_COUNTRY_IDS.length})</h4>
              <div className="gw-hoi4-nation-grid" style={{ maxHeight: 420, overflowY: "auto" }}>
                {FEATURED_COUNTRY_IDS.map((isoId) => {
                  const c = COUNTRIES_BY_ID[isoId];
                  if (!c) return null;
                  return (
                    <button
                      key={c.isoId}
                      type="button"
                      className={`gw-car-option ${chosenStartIso === c.isoId ? "selected" : ""}`}
                      onClick={() => setChosenStartIso(c.isoId)}
                    >
                      <div className="gw-car-swatch-row">
                        <span className="gw-car-swatch" style={{ background: c.color }} />
                        <small>{c.doctrine}</small>
                      </div>
                      <strong style={{ fontSize: 15 }}>{c.name}</strong>
                      <div className="gw-car-mini-specs">
                        <span>Capital: {c.capitalName}</span>
                        <span>Ind: {c.startCiv}/{c.startMil}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {lobbyTab === "settings" && (
          <div className="gw-fps-lobby-grid">
            <div className="gw-fps-panel">
              <div className="gw-fps-panel-top">
                <h4>Theater Soundtrack &amp; Audio</h4>
                <button type="button" className="gw-btn" onClick={resetWorkshopSettings}>
                  Reset Defaults
                </button>
              </div>

              <div className="gw-playlist-box">
                <small>ACTIVE COMMAND SOUNDTRACK</small>
                <select
                  value={currentTrackUrl}
                  onChange={(e) => {
                    musicRef.current.startOnGesture();
                    selectActiveSoundtrackByUrl(e.target.value);
                  }}
                >
                  {playlistItems.map((track) => (
                    <option key={track.id} value={track.url}>
                      {track.title} {track.artist ? `— ${track.artist}` : ""}
                    </option>
                  ))}
                </select>
                <label className="gw-btn" style={{ marginTop: 8, cursor: "pointer", display: "inline-block" }}>
                  + Upload Local Track
                  <input
                    type="file"
                    accept="audio/*,.mp3,.m4a,.wav,.ogg"
                    hidden
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) registerSessionTrackFile(f);
                    }}
                  />
                </label>
              </div>

              <label className="gw-fps-field">
                <span>Music Volume: {Math.round(settings.musicVolume * 100)}%</span>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={Math.round(settings.musicVolume * 100)}
                  onChange={(e) => {
                    musicRef.current.startOnGesture();
                    updateWorkshopSettings({ musicVolume: Number(e.target.value) / 100 });
                  }}
                />
              </label>

              <label className="gw-fps-field">
                <span>War Horn &amp; UI SFX Volume: {Math.round(settings.sfxVolume * 100)}%</span>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={Math.round(settings.sfxVolume * 100)}
                  onChange={(e) => updateWorkshopSettings({ sfxVolume: Number(e.target.value) / 100 })}
                />
              </label>

              <div className="gw-pill-grid">
                <button
                  type="button"
                  className={`gw-btn ${musicOn && !muted ? "gw-btn-primary" : ""}`}
                  onClick={() => updateWorkshopSettings({ musicEnabled: !musicOn })}
                >
                  {musicOn ? "♪ Music Enabled" : "♪ Music Off"}
                </button>
                <button
                  type="button"
                  className={`gw-btn ${muted ? "" : "gw-btn-primary"}`}
                  onClick={() => updateWorkshopSettings({ muted: !muted })}
                >
                  {muted ? "All Audio Muted" : "Master Audio Active"}
                </button>
              </div>
            </div>

            <div className="gw-fps-panel">
              <h4>Situation Room Controls</h4>
              <div className="gw-controls-grid">
                <div><b>Drag Map</b><span>Pan Natural Earth</span></div>
                <div><b>Mouse Wheel</b><span>Zoom In / Out</span></div>
                <div><b>Left-Click</b><span>Inspect Country / Select Div</span></div>
                <div><b>Right-Click</b><span>March Selected Divisions</span></div>
                <div><b>1–5x Buttons</b><span>Simulation Speed</span></div>
                <div><b>Dock Tabs 1–6</b><span>Focus / Econ / Mil / Tech</span></div>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Active Strategic Event for my nation
  const myPendingEvent = myIsoId
    ? snapshot.pendingEvents.find((ev) => ev.targetIsoId === myIsoId) || null
    : null;
  const hovGeo = hoveredIsoId ? WORLD_COUNTRIES_BY_ID[hoveredIsoId] : null;
  const hovSpec = hoveredIsoId ? COUNTRIES_BY_ID[hoveredIsoId] : null;
  const hovState = hoveredIsoId ? snapshot.countries[hoveredIsoId] : null;

  return (
    <div className="gw-hoi4-stage">
      {/* TOP GRAND STRATEGY COMMAND BAR */}
      <div className="gw-hoi4-topbar">
        <div className="gw-hoi4-nation-badge">
          <span
            className="gw-car-swatch"
            style={{ background: myNationSpec?.color || "#8c7b65" }}
          />
          <div>
            <strong>{myNationSpec ? myNationSpec.name : "Observer"}</strong>
            <small>
              {myNationSpec?.doctrine || "Select a State"} ·{" "}
              {snapshot.mode === "solo" ? "SOLO CAMPAIGN" : `ROOM ${snapshot.code}`}
            </small>
          </div>
          {snapshot.mode === "multiplayer" && (
            <button
              type="button"
              className="gw-fps-copy-btn"
              onClick={() => {
                navigator.clipboard?.writeText(snapshot.code);
                setCopiedCode(true);
                window.setTimeout(() => setCopiedCode(false), 1600);
              }}
            >
              {copiedCode ? "Copied" : snapshot.code}
            </button>
          )}
        </div>

        {myNation && (
          <div className="gw-hoi4-metrics">
            <div>
              <small>TREASURY</small>
              <b>
                ${myNation.treasury}B ({myNation.dailyBudgetDelta >= 0 ? "+" : ""}
                {myNation.dailyBudgetDelta}/d)
              </b>
            </div>
            <div>
              <small>POL. POWER</small>
              <b>{myNation.pp}</b>
            </div>
            <div>
              <small>MANPOWER</small>
              <b>{Math.round(myNation.manpower / 1000)}k</b>
            </div>
            <div>
              <small>CIV / MIL</small>
              <b>
                {myNation.civCount} / {myNation.milCount}
              </b>
            </div>
            <div>
              <small>INFRA</small>
              <b>Tier {myNation.infrastructure}/5</b>
            </div>
            <div>
              <small>RESOURCES (S/O/R/G)</small>
              <b>
                {myNation.resources.steel}/{myNation.resources.oil}/{myNation.resources.rare}/
                {myNation.resources.grain}
              </b>
            </div>
            <div>
              <small>STABILITY</small>
              <b>{myNation.stability}%</b>
            </div>
            <div>
              <small>TENSION</small>
              <b style={{ color: snapshot.worldTension >= 60 ? "#ff8878" : "#f2cf7e" }}>
                {snapshot.worldTension}%
              </b>
            </div>
          </div>
        )}

        <div className="gw-hoi4-clock-bar">
          <span className="gw-hoi4-date">{snapshot.dateStr}</span>
          <button
            type="button"
            className={`gw-btn ${snapshot.paused ? "gw-btn-primary" : ""}`}
            onClick={() => dispatchCommand({ type: "toggle_pause" })}
          >
            {snapshot.paused ? "Resume" : "Pause"}
          </button>
          {[1, 2, 3, 4, 5].map((sp) => (
            <button
              key={sp}
              type="button"
              className={`gw-btn ${snapshot.speed === sp && !snapshot.paused ? "gw-btn-primary" : ""}`}
              onClick={() => dispatchCommand({ type: "set_speed", speed: sp })}
            >
              {sp}x
            </button>
          ))}
          <button
            type="button"
            className="gw-btn"
            onClick={() => updateWorkshopSettings({ muted: !muted })}
          >
            {muted ? "Unmute" : "Mute"}
          </button>
          <button
            type="button"
            className="gw-btn"
            onClick={() => {
              musicRef.current.startOnGesture();
              updateWorkshopSettings({ musicEnabled: !musicOn });
            }}
          >
            {musicOn ? "Music On" : "Music Off"}
          </button>
          <button type="button" className="gw-btn" onClick={handleLeaveCampaign}>
            Exit Campaign
          </button>
        </div>
      </div>

      {wsError && (
        <div className="gw-fps-error" style={{ margin: "6px 10px 0" }}>
          <span>{wsError}</span>
          <button type="button" className="gw-btn" onClick={() => setWsError(null)}>
            OK
          </button>
        </div>
      )}

      {/* MAIN BODY */}
      <div className="gw-hoi4-body">
        {/* LEFT STRATEGY DOCK */}
        <aside className="gw-hoi4-dock" aria-label="Grand Strategy Controls">
          <button
            type="button"
            className={`gw-hoi4-dock-btn ${activeDrawer === "focus" ? "active" : ""}`}
            onClick={() => setActiveDrawer((d) => (d === "focus" ? null : "focus"))}
          >
            1 · Focuses
          </button>
          <button
            type="button"
            className={`gw-hoi4-dock-btn ${activeDrawer === "economy" ? "active" : ""}`}
            onClick={() => setActiveDrawer((d) => (d === "economy" ? null : "economy"))}
          >
            2 · Economy
          </button>
          <button
            type="button"
            className={`gw-hoi4-dock-btn ${activeDrawer === "recruit" ? "active" : ""}`}
            onClick={() => setActiveDrawer((d) => (d === "recruit" ? null : "recruit"))}
          >
            3 · Military ({myDivisions.length})
          </button>
          <button
            type="button"
            className={`gw-hoi4-dock-btn ${activeDrawer === "tech" ? "active" : ""}`}
            onClick={() => setActiveDrawer((d) => (d === "tech" ? null : "tech"))}
          >
            4 · Research
          </button>
          <button
            type="button"
            className={`gw-hoi4-dock-btn ${activeDrawer === "diplomacy" ? "active" : ""}`}
            onClick={() => setActiveDrawer((d) => (d === "diplomacy" ? null : "diplomacy"))}
          >
            5 · Diplomacy
          </button>
          <button
            type="button"
            className={`gw-hoi4-dock-btn ${activeDrawer === "world" ? "active" : ""}`}
            onClick={() => setActiveDrawer((d) => (d === "world" ? null : "world"))}
          >
            6 · 176 Nations
          </button>

          <div className="gw-hoi4-dock-sep" />

          {(["political", "region", "resources", "diplomacy"] as MapMode[]).map((mm) => (
            <button
              key={mm}
              type="button"
              className={`gw-hoi4-dock-btn ${mapMode === mm ? "active" : ""}`}
              onClick={() => setMapMode(mm)}
            >
              Map: {mm.slice(0, 4).toUpperCase()}
            </button>
          ))}
        </aside>

        {/* SLIDE-OUT STRATEGY DRAWER */}
        {activeDrawer && myNation && myNationSpec && (
          <section className="gw-hoi4-drawer">
            <div className="gw-hoi4-drawer-head">
              <strong>
                {activeDrawer === "focus"
                  ? "National Focuses"
                  : activeDrawer === "economy"
                    ? "Economy & Construction"
                    : activeDrawer === "recruit"
                      ? "Armed Forces & Deploy"
                      : activeDrawer === "tech"
                        ? "Research & Technology"
                        : activeDrawer === "diplomacy"
                          ? "Foreign Diplomacy"
                          : "World Country Index (176)"}
              </strong>
              <button type="button" className="gw-btn" onClick={() => setActiveDrawer(null)}>
                ✕
              </button>
            </div>

            {activeDrawer === "focus" && (
              <div className="gw-hoi4-drawer-list">
                {myNation.activeFocusId && (
                  <div className="gw-hoi4-active-card">
                    <small>ACTIVE FOCUS</small>
                    <strong>
                      {NATIONAL_FOCUSES.find((f) => f.id === myNation.activeFocusId)?.name}
                    </strong>
                    <div className="gw-hoi4-progress">
                      <i
                        style={{
                          width: `${Math.min(
                            100,
                            (myNation.focusProgressDays /
                              (NATIONAL_FOCUSES.find((f) => f.id === myNation.activeFocusId)?.days || 10)) *
                              100,
                          )}%`,
                        }}
                      />
                    </div>
                  </div>
                )}
                {NATIONAL_FOCUSES.map((f) => {
                  const done = myNation.completedFocuses.includes(f.id);
                  const active = myNation.activeFocusId === f.id;
                  const unlocked =
                    !f.requires || f.requires.every((r) => myNation.completedFocuses.includes(r));
                  return (
                    <div
                      key={f.id}
                      className={`gw-hoi4-item ${done ? "done" : ""} ${!unlocked ? "locked" : ""}`}
                    >
                      <small>
                        {f.branch.toUpperCase()} · {f.days} DAYS
                      </small>
                      <strong>{f.name}</strong>
                      <p>{f.summary}</p>
                      {done ? (
                        <span className="gw-hoi4-status-tag">COMPLETED</span>
                      ) : active ? (
                        <span className="gw-hoi4-status-tag">IN PROGRESS</span>
                      ) : (
                        <button
                          type="button"
                          className="gw-btn gw-btn-primary"
                          disabled={!unlocked}
                          onClick={() => dispatchCommand({ type: "start_focus", focusId: f.id })}
                        >
                          {unlocked ? "Activate Focus" : "Requires Prior Focus"}
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {activeDrawer === "economy" && (
              <div className="gw-hoi4-drawer-list">
                <div className="gw-hoi4-item">
                  <small>NATIONAL BUDGET &amp; RESOURCES (SIMULATION)</small>
                  <strong>
                    Treasury: ${myNation.treasury}B ({myNation.dailyBudgetDelta >= 0 ? "+" : ""}
                    {myNation.dailyBudgetDelta}B/day)
                  </strong>
                  <p>
                    Steel {myNation.resources.steel} · Oil {myNation.resources.oil} · Rare Earths{" "}
                    {myNation.resources.rare} · Grain {myNation.resources.grain}
                  </p>
                </div>

                <div className="gw-hoi4-item">
                  <small>MILITARY PRODUCTION LINES ({myNation.milCount} MIL FACTORIES)</small>
                  {(["infantry", "tanks", "artillery", "fighters"] as EquipmentType[]).map((k) => (
                    <div key={k} className="gw-hoi4-prod-row">
                      <span>
                        {k.toUpperCase()} (Stock: {myNation.equipment[k]})
                      </span>
                      <div className="gw-hoi4-prod-ctrl">
                        <button
                          type="button"
                          className="gw-btn"
                          onClick={() => adjustProduction(k, -1)}
                        >
                          -
                        </button>
                        <b>{myNation.productionAlloc[k]}</b>
                        <button
                          type="button"
                          className="gw-btn"
                          onClick={() => adjustProduction(k, 1)}
                        >
                          +
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="gw-hoi4-item">
                  <small>
                    INFRASTRUCTURE &amp; PROJECTS ({selectedSpec ? selectedSpec.name : myNationSpec.name})
                  </small>
                  <div className="gw-hoi4-build-btns">
                    {(
                      [
                        { kind: "civ", label: "+Civ Fac ($70B)" },
                        { kind: "mil", label: "+Mil Fac ($65B)" },
                        { kind: "infra", label: "+Infra ($55B)" },
                        { kind: "fort", label: "+Fort ($40B)" },
                      ] as const
                    ).map((b) => (
                      <button
                        key={b.kind}
                        type="button"
                        className="gw-btn"
                        disabled={!selectedState || selectedState.controllerIso !== myIsoId}
                        onClick={() =>
                          dispatchCommand({
                            type: "queue_construction",
                            provinceId: selectedState?.isoId || myIsoId,
                            kind: b.kind,
                          })
                        }
                      >
                        {b.label}
                      </button>
                    ))}
                  </div>
                </div>

                {myNation.constructionQueue.map((c) => (
                  <div key={c.id} className="gw-hoi4-active-card">
                    <small>
                      {c.kind.toUpperCase()} · {COUNTRIES_BY_ID[c.provinceId]?.name}
                    </small>
                    <div className="gw-hoi4-progress">
                      <i style={{ width: `${Math.min(100, (c.progress / c.cost) * 100)}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeDrawer === "recruit" && (
              <div className="gw-hoi4-drawer-list">
                {(["infantry", "armor", "motorized", "mountaineer"] as UnitTemplateId[]).map(
                  (tid) => {
                    const tpl = UNIT_TEMPLATES[tid];
                    return (
                      <div key={tid} className="gw-hoi4-item">
                        <small>
                          {tpl.shortTag} · ${tpl.treasuryCost}B · {tpl.trainDays}D
                        </small>
                        <strong>{tpl.name}</strong>
                        <p>
                          Atk {tpl.softAttack} · Def {tpl.defense} · Spd {tpl.speed}x · Gear:{" "}
                          {tpl.infEqCost} Inf, {tpl.tankCost} Tank, {tpl.artilleryCost} Arty
                        </p>
                        <button
                          type="button"
                          className="gw-btn gw-btn-primary"
                          onClick={() =>
                            dispatchCommand({
                              type: "recruit_division",
                              templateId: tid,
                              deployProvinceId:
                                selectedState?.controllerIso === myIsoId ? selectedState.isoId : myIsoId,
                            })
                          }
                        >
                          Deploy Division
                        </button>
                      </div>
                    );
                  },
                )}
                {myNation.trainingQueue.map((tr) => (
                  <div key={tr.id} className="gw-hoi4-active-card">
                    <small>
                      TRAINING {UNIT_TEMPLATES[tr.templateId].shortTag} →{" "}
                      {COUNTRIES_BY_ID[tr.deployProvinceId]?.shortName}
                    </small>
                    <div className="gw-hoi4-progress">
                      <i style={{ width: `${Math.min(100, (tr.progressDays / tr.totalDays) * 100)}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeDrawer === "tech" && (
              <div className="gw-hoi4-drawer-list">
                {myNation.activeTechId && (
                  <div className="gw-hoi4-active-card">
                    <small>RESEARCHING</small>
                    <strong>{TECH_ITEMS.find((t) => t.id === myNation.activeTechId)?.name}</strong>
                    <div className="gw-hoi4-progress">
                      <i
                        style={{
                          width: `${Math.min(
                            100,
                            (myNation.techProgressDays /
                              (TECH_ITEMS.find((t) => t.id === myNation.activeTechId)?.days || 10)) *
                              100,
                          )}%`,
                        }}
                      />
                    </div>
                  </div>
                )}
                {TECH_ITEMS.map((t) => {
                  const done = myNation.completedTechs.includes(t.id);
                  const active = myNation.activeTechId === t.id;
                  return (
                    <div key={t.id} className={`gw-hoi4-item ${done ? "done" : ""}`}>
                      <small>
                        {t.category.toUpperCase()} · {t.days} DAYS
                      </small>
                      <strong>{t.name}</strong>
                      <p>{t.summary}</p>
                      {done ? (
                        <span className="gw-hoi4-status-tag">RESEARCHED</span>
                      ) : active ? (
                        <span className="gw-hoi4-status-tag">IN PROGRESS</span>
                      ) : (
                        <button
                          type="button"
                          className="gw-btn gw-btn-primary"
                          onClick={() => dispatchCommand({ type: "start_tech", techId: t.id })}
                        >
                          Research
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {activeDrawer === "diplomacy" && (
              <div className="gw-hoi4-drawer-list">
                {WORLD_COUNTRY_SPECS.filter(
                  (c) =>
                    c.isoId !== myIsoId &&
                    !snapshot.countries[c.isoId]?.capitulated &&
                    (c.featured ||
                      c.isoId === selectedIsoId ||
                      myNation.atWarWith.includes(c.isoId) ||
                      myNation.allies.includes(c.isoId) ||
                      myNation.tradePactsWith.includes(c.isoId)),
                ).map((c) => {
                  const st = snapshot.countries[c.isoId];
                  const atWar = myNation.atWarWith.includes(c.isoId);
                  const allied = myNation.allies.includes(c.isoId);
                  const trading = myNation.tradePactsWith.includes(c.isoId);
                  const pendingIn = myNation.incomingAllyProposals.includes(c.isoId);
                  return (
                    <div key={c.isoId} className="gw-hoi4-item">
                      <div className="gw-hoi4-dip-head">
                        <span className="gw-car-swatch" style={{ background: c.color }} />
                        <div>
                          <strong>{c.name}</strong>
                          <small>
                            {st?.controllerName ? `Player: ${st.controllerName}` : "AI Sovereign"} ·{" "}
                            {c.shortName}
                          </small>
                        </div>
                      </div>
                      <div className="gw-hoi4-dip-actions">
                        {atWar ? (
                          <>
                            <span className="gw-hoi4-war-pill">AT WAR</span>
                            <button
                              type="button"
                              className="gw-btn"
                              onClick={() =>
                                dispatchCommand({
                                  type: "diplomacy_action",
                                  targetNationId: c.isoId,
                                  action: "offer_peace",
                                })
                              }
                            >
                              Ceasefire (35 PP)
                            </button>
                          </>
                        ) : allied ? (
                          <>
                            <span className="gw-hoi4-ally-pill">ALLY</span>
                            <button
                              type="button"
                              className="gw-btn"
                              onClick={() =>
                                dispatchCommand({
                                  type: "diplomacy_action",
                                  targetNationId: c.isoId,
                                  action: "lend_lease",
                                })
                              }
                            >
                              Send Aid
                            </button>
                          </>
                        ) : pendingIn ? (
                          <button
                            type="button"
                            className="gw-btn gw-btn-primary"
                            onClick={() =>
                              dispatchCommand({
                                type: "diplomacy_action",
                                targetNationId: c.isoId,
                                action: "accept_ally",
                              })
                            }
                          >
                            Accept Alliance
                          </button>
                        ) : (
                          <>
                            {!trading && (
                              <button
                                type="button"
                                className="gw-btn"
                                onClick={() =>
                                  dispatchCommand({
                                    type: "diplomacy_action",
                                    targetNationId: c.isoId,
                                    action: "trade_pact",
                                  })
                                }
                              >
                                Trade (10 PP)
                              </button>
                            )}
                            <button
                              type="button"
                              className="gw-btn"
                              onClick={() =>
                                dispatchCommand({
                                  type: "diplomacy_action",
                                  targetNationId: c.isoId,
                                  action: "propose_ally",
                                })
                              }
                            >
                              Alliance
                            </button>
                            <button
                              type="button"
                              className="gw-btn gw-btn-danger"
                              onClick={() => {
                                audioRef.current.playWarHorn();
                                dispatchCommand({
                                  type: "diplomacy_action",
                                  targetNationId: c.isoId,
                                  action: "declare_war",
                                });
                              }}
                            >
                              War (15 PP)
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {activeDrawer === "world" && (
              <div className="gw-hoi4-drawer-list">
                <label className="gw-fps-field">
                  <span>Filter 176 Sovereign Countries</span>
                  <input
                    type="text"
                    placeholder="Search country, region, or ISO..."
                    value={worldSearch}
                    onChange={(e) => setWorldSearch(e.target.value)}
                  />
                </label>
                {filteredWorldCountries.map((c) => {
                  const st = snapshot.countries[c.isoId];
                  const geo = WORLD_COUNTRIES_BY_ID[c.isoId];
                  return (
                    <div key={c.isoId} className="gw-hoi4-item">
                      <div className="gw-hoi4-dip-head">
                        <span className="gw-car-swatch" style={{ background: c.color }} />
                        <div>
                          <strong>{c.name}</strong>
                          <small>
                            {REGION_INFO[c.region].label} · Ref Pop {c.refPopulationM}M
                          </small>
                        </div>
                      </div>
                      <div className="gw-hoi4-dip-actions">
                        <button
                          type="button"
                          className="gw-btn"
                          onClick={() => {
                            setSelectedIsoId(c.isoId);
                            if (geo) camRef.current = { x: geo.x, y: geo.y, zoom: 2.6 };
                          }}
                        >
                          Locate on Map
                        </button>
                        {!st?.capitulated && c.isoId !== myIsoId && !st?.controllerPlayerId && (
                          <button
                            type="button"
                            className="gw-btn gw-btn-primary"
                            onClick={() => {
                              dispatchCommand({ type: "select_nation", nationId: c.isoId });
                              setSelectedIsoId(c.isoId);
                            }}
                          >
                            Command
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>
        )}

        {/* INTERACTIVE NATURAL EARTH WORLD MAP */}
        <div ref={wrapRef} className="gw-hoi4-map-wrap">
          <canvas
            ref={canvasRef}
            className="gw-hoi4-canvas"
            onWheel={handleCanvasWheel}
            onMouseDown={handleCanvasMouseDown}
            onMouseMove={handleCanvasMouseMove}
            onMouseUp={handleCanvasMouseUp}
            onMouseLeave={() => {
              setHoveredIsoId(null);
              setHoverScreenPos(null);
              dragRef.current.active = false;
            }}
            onContextMenu={handleCanvasContextMenu}
          />

          {/* Region Quick Focus & Zoom Controls */}
          <div className="gw-hoi4-map-tools" style={{ flexWrap: "wrap", maxWidth: "74%" }}>
            <button type="button" className="gw-btn" onClick={() => focusRegion("world")}>
              World
            </button>
            <button type="button" className="gw-btn" onClick={() => focusRegion("europe")}>
              Europe
            </button>
            <button type="button" className="gw-btn" onClick={() => focusRegion("north-america")}>
              N. America
            </button>
            <button type="button" className="gw-btn" onClick={() => focusRegion("south-america")}>
              S. America
            </button>
            <button type="button" className="gw-btn" onClick={() => focusRegion("middle-east")}>
              Mid East
            </button>
            <button type="button" className="gw-btn" onClick={() => focusRegion("africa")}>
              Africa
            </button>
            <button type="button" className="gw-btn" onClick={() => focusRegion("asia")}>
              Asia
            </button>
            <button
              type="button"
              className="gw-btn"
              onClick={() => {
                camRef.current.zoom = Math.min(7.5, camRef.current.zoom * 1.3);
              }}
            >
              Zoom +
            </button>
            <button
              type="button"
              className="gw-btn"
              onClick={() => {
                camRef.current.zoom = Math.max(0.55, camRef.current.zoom * 0.78);
              }}
            >
              Zoom -
            </button>
          </div>

          {/* Country Hover Tooltip */}
          {hovGeo && hovSpec && hovState && hoverScreenPos && (
            <div
              style={{
                position: "absolute",
                left: Math.min(hoverScreenPos.x + 14, 520),
                top: Math.max(50, hoverScreenPos.y - 16),
                zIndex: 8,
                pointerEvents: "none",
                background: "rgba(15, 12, 9, 0.94)",
                border: "1px solid #8a6c44",
                padding: "6px 9px",
                font: '11px "JetBrains Mono", monospace',
                color: "#efe4cf",
                minWidth: 185,
              }}
            >
              <div style={{ fontWeight: 700, color: "#ffd875" }}>
                {hovSpec.name} ({hovSpec.shortName})
              </div>
              <div>
                Region: {REGION_INFO[hovSpec.region].label} · {TERRAIN_INFO[hovSpec.terrain].label}
              </div>
              <div>
                Control: {COUNTRIES_BY_ID[hovState.controllerIso]?.name || hovState.controllerIso}
              </div>
              <div>
                Ref Pop: {hovSpec.refPopulationM}M · Divisions:{" "}
                {snapshot.divisions.filter((d) => d.provinceId === hovGeo.isoId).length}
              </div>
            </div>
          )}

          {/* Selected Division Command Bar */}
          {selectedDivisionIds.length > 0 && (
            <div className="gw-hoi4-army-bar">
              <span>{selectedDivisionIds.length} Division(s) Selected</span>
              <button
                type="button"
                className={`gw-btn ${orderClickMode ? "gw-btn-primary" : ""}`}
                onClick={() => setOrderClickMode((v) => !v)}
              >
                {orderClickMode ? "Click Destination Country..." : "Click-to-Move / Right-Click"}
              </button>
              <button
                type="button"
                className="gw-btn"
                onClick={() => dispatchCommand({ type: "halt_divisions", divisionIds: selectedDivisionIds })}
              >
                Halt
              </button>
              <button type="button" className="gw-btn" onClick={() => setSelectedDivisionIds([])}>
                Clear
              </button>
            </div>
          )}
        </div>

        {/* RIGHT INSPECTOR + STRATEGIC FEED */}
        <aside className="gw-hoi4-right">
          <div className="gw-hoi4-inspector">
            <small>COUNTRY INSPECTOR</small>
            {selectedGeo && selectedSpec && selectedState ? (
              <>
                <h4>
                  {selectedSpec.name} ({selectedSpec.shortName})
                </h4>
                <div className="gw-hoi4-prov-meta">
                  <span style={{ color: "#d1b273", fontWeight: 600 }}>
                    Reference Baseline (Geographic)
                  </span>
                  <span>
                    Capital: <b>{selectedSpec.capitalName}</b> · ISO #{selectedSpec.isoId}
                  </span>
                  <span>
                    Region: <b>{REGION_INFO[selectedSpec.region].label}</b> · Ref. Pop:{" "}
                    <b>~{selectedSpec.refPopulationM}M</b>
                  </span>
                  <span style={{ color: "#8fb7d8", fontWeight: 600, marginTop: 4 }}>
                    Campaign Simulation State
                  </span>
                  <span>
                    Controller:{" "}
                    <b>
                      {COUNTRIES_BY_ID[selectedState.controllerIso]?.name ||
                        selectedState.controllerIso}
                    </b>
                  </span>
                  <span>
                    Terrain: <b>{TERRAIN_INFO[selectedSpec.terrain].label}</b> · Infra Tier{" "}
                    <b>{selectedState.infrastructure}/5</b> · Fort {selectedState.fortLevel}
                  </span>
                  <span>
                    Treasury: <b>${selectedState.treasury}B</b> · Factories: Civ{" "}
                    <b>{selectedState.civCount}</b> / Mil <b>{selectedState.milCount}</b>
                  </span>
                  <span>
                    Resources: Steel {selectedSpec.resources.steel} · Oil {selectedSpec.resources.oil}{" "}
                    · Rare {selectedSpec.resources.rare} · Grain {selectedSpec.resources.grain}
                  </span>
                  <span>
                    Supply:{" "}
                    <b style={{ color: selectedState.supplied ? "#7ce89e" : "#ff8d7d" }}>
                      {selectedState.supplied ? "Supplied" : "Out of Supply"}
                    </b>{" "}
                    · Neighbors: {selectedGeo.landNeighbors.length} land,{" "}
                    {selectedGeo.seaNeighbors.length} sea
                  </span>
                </div>

                {selectedSpec.isoId !== myIsoId &&
                  !selectedState.capitulated &&
                  !selectedState.controllerPlayerId && (
                    <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 4 }}>
                      <button
                        type="button"
                        className="gw-btn gw-btn-primary"
                        onClick={() =>
                          dispatchCommand({ type: "select_nation", nationId: selectedSpec.isoId })
                        }
                      >
                        Assume Command ({selectedSpec.shortName})
                      </button>
                      {myNation &&
                        !myNation.atWarWith.includes(selectedSpec.isoId) && (
                          <button
                            type="button"
                            className="gw-btn gw-btn-danger"
                            onClick={() => {
                              audioRef.current.playWarHorn();
                              dispatchCommand({
                                type: "diplomacy_action",
                                targetNationId: selectedSpec.isoId,
                                action: "declare_war",
                              });
                            }}
                          >
                            Declare War
                          </button>
                        )}
                    </div>
                  )}

                {snapshot.battles
                  .filter((b) => b.provinceId === selectedSpec.isoId)
                  .map((b) => (
                    <div key={b.id} className="gw-hoi4-battle-box">
                      <strong>
                        Active Battle ({COUNTRIES_BY_ID[b.attackerNation]?.shortName} vs{" "}
                        {COUNTRIES_BY_ID[b.defenderNation]?.shortName})
                      </strong>
                      <div className="gw-hoi4-progress">
                        <i style={{ width: `${b.progress}%` }} />
                      </div>
                      <small>
                        Progress {b.progress}% · {b.attackerCount} vs {b.defenderCount} divs
                      </small>
                    </div>
                  ))}

                <div className="gw-hoi4-div-list">
                  {selectedCountryDivs.slice(0, 6).map((d) => (
                    <div key={d.id} className="gw-hoi4-div-row">
                      <span>
                        {d.name} ({COUNTRIES_BY_ID[d.owner]?.shortName})
                      </span>
                      <small>
                        HP {d.hp} · Org {d.org}/{d.maxOrg}{" "}
                        {d.targetProvinceId
                          ? `→ ${COUNTRIES_BY_ID[d.targetProvinceId]?.shortName} (${d.moveProgress}%)`
                          : ""}
                      </small>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <p style={{ fontSize: 12, color: "#b6a690" }}>
                Click any country on the Natural Earth world map to inspect geography, demographics,
                economy, and military units. Right-click moves selected divisions.
              </p>
            )}
          </div>

          <div className="gw-hoi4-events">
            <small>DISPATCH LOG &amp; DIPLOMACY ({snapshot.players.length} CMD)</small>
            <div className="gw-hoi4-event-list">
              {snapshot.events.map((ev) => (
                <div key={ev.id} className={`gw-hoi4-ev ${ev.tone}`}>
                  <span>[{ev.dateStr}]</span> {ev.text}
                </div>
              ))}
            </div>
            <form
              className="gw-hoi4-chat-form"
              onSubmit={(e) => {
                e.preventDefault();
                if (!chatInput.trim()) return;
                dispatchCommand({ type: "chat_message", text: chatInput });
                setChatInput("");
              }}
            >
              <input
                type="text"
                placeholder="Strategic log / team chat..."
                maxLength={140}
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
              />
              <button type="submit" className="gw-btn">
                Send
              </button>
            </form>
          </div>
        </aside>
      </div>

      {/* INTERACTIVE STRATEGIC EVENT MODAL */}
      {myPendingEvent && !snapshot.winnerNationId && (
        <div className="gw-race-overlay">
          <div className="gw-race-modal" style={{ textAlign: "left" }}>
            <small style={{ font: '700 10.5px "JetBrains Mono"', color: "#d1b273" }}>
              CABINET DECISION BRIEF · {COUNTRIES_BY_ID[myPendingEvent.targetIsoId]?.name.toUpperCase()}
            </small>
            <h3 style={{ fontSize: 28 }}>{myPendingEvent.title}</h3>
            <p>{myPendingEvent.description}</p>
            <div style={{ display: "flex", flexDirection: "column", gap: 8, marginTop: 6 }}>
              {myPendingEvent.choices.map((ch) => (
                <button
                  key={ch.id}
                  type="button"
                  className="gw-car-option"
                  onClick={() => {
                    audioRef.current.playChime();
                    dispatchCommand({
                      type: "event_choice",
                      uid: myPendingEvent.uid,
                      choiceId: ch.id,
                    });
                  }}
                >
                  <strong style={{ fontSize: 16 }}>{ch.label}</strong>
                  <small>{ch.summary}</small>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* VICTORY OVERLAY */}
      {snapshot.winnerNationId && (
        <div className="gw-race-overlay">
          <div className="gw-race-modal">
            <p className="eyebrow">Campaign Concluded</p>
            <h3>{COUNTRIES_BY_ID[snapshot.winnerNationId]?.name} Victorious</h3>
            <p>{snapshot.winnerReason}</p>
            <div className="gw-race-modal-actions">
              <button type="button" className="brass-button" onClick={handleLeaveCampaign}>
                Return to Theater Lobby
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
