import { useState } from "react";
import { GameProtocol } from "../GameProtocol";
import cardChessImg from "../assets/images/card_chess_protocol_1795263403254.jpg";
import cardShooterImg from "../assets/images/card_coop_shooter_1795184669798.jpg";
import cardRacingImg from "../assets/images/card_gnosis_racing_1795182391860.jpg";
import cardTitanImg from "../assets/images/card_titan_assault_1795263403128.jpg";
import cardWorldImg from "../assets/images/card_world_command_1795263403926.jpg";
import { GamePlayer, type WorkshopGameDefinition } from "./GamePlayer";

const WORKSHOP_GAMES: WorkshopGameDefinition[] = [
  {
    id: "coop-shooter",
    name: "GNOSIS Strike · Tactical Arenas",
    gameType: "Competitive Team PvP 3D FPS",
    runtimeLabel: "4 Maps (Mansion) · 14 Skins · 6 Knives · 3D Weapons",
    description:
      "Round-based 3D tactical shooter featuring CS-inspired Estate: Mansion, 3D firearm & knife collections with 14 PBR skins, interactive 3D Armory preview, operative armor studio, and Supabase Realtime.",
    coverArt: cardShooterImg,
    ctaLabel: "Open Operations Hub →",
  },
  {
    id: "gnosis-racing",
    name: "GNOSIS Racing",
    gameType: "Co-op 3D Grand Circuit Racer",
    runtimeLabel: "4 Circuits · 8 3D Cars · Track Kit · Tuning Lab",
    description:
      "Race solo or form a 4-driver Co-op Squad across 4 multi-elevation 3D circuits with viaduct bridges, 8 distinct 3D vehicles, interactive Paint & Livery Studio, live Tuning Lab, and 120Hz physics.",
    coverArt: cardRacingImg,
    ctaLabel: "Enter Racing Paddock →",
  },
  {
    id: "titan-assault",
    name: "Titan Assault: ODM Revolution",
    gameType: "3D ODM Grapple & Titan Slayer",
    runtimeLabel: "Solo & 4P Co-op · Walled District Roads · Shifters",
    description:
      "Vertical 3D ODM combat across a bustling walled district with paved avenues, street lamps, garrison camps, Scout uniform studio, dual grappling cables, Thunder Spears, and 4 Titan Shifter forms.",
    coverArt: cardTitanImg,
    ctaLabel: "Launch ODM Expedition →",
  },
  {
    id: "hoi4-strategy",
    name: "GNOSIS World Command · Grand Strategy",
    gameType: "176-Nation Natural Earth Grand Strategy",
    runtimeLabel: "Solo Campaign & 12P Supabase Theater",
    description:
      "Real-world Natural Earth 176-country grand strategy simulation. Command any sovereign nation, develop industry & infrastructure, manage strategic resources, conduct diplomacy, research tech, and maneuver divisions.",
    coverArt: cardWorldImg,
    ctaLabel: "Enter Situation Room →",
  },
  {
    id: "classic-protocol",
    name: "Chess & Classic Protocol VII",
    gameType: "Board, Arcade & Online Collection (13 Games)",
    runtimeLabel: "Chess AI / Online · Co-op Vault · Classics",
    description:
      "Full-rules Chess (vs AI, Local & 2P Online), Aether Vault Co-op, Connect Four, Tic-Tac-Toe, Minesweeper, 2048, Snake, Pong, Clockwork Ascent, and Sandboxed Imported Web Games.",
    coverArt: cardChessImg,
    ctaLabel: "Open Chess & Classics →",
  },
];

function CardCover({ game }: { game: WorkshopGameDefinition }) {
  const [failed, setFailed] = useState(false);

  if (!failed && game.coverArt) {
    return (
      <img
        src={game.coverArt}
        alt={game.name}
        loading="lazy"
        referrerPolicy="no-referrer"
        className="gw-card-img"
        onError={() => setFailed(true)}
      />
    );
  }

  return (
    <div className="gw-card-fallback" aria-hidden="true">
      <span className="gw-fallback-glyph">◈</span>
      <small>{game.gameType}</small>
    </div>
  );
}

export function WorkshopHub({
  onReturnToNormalGnosis,
}: {
  onReturnToNormalGnosis: () => void;
}) {
  const [activeGame, setActiveGame] = useState<WorkshopGameDefinition | null>(null);
  const [showClassicProtocol, setShowClassicProtocol] = useState(false);
  const [spotlightId, setSpotlightId] = useState<WorkshopGameDefinition["id"]>("coop-shooter");

  if (showClassicProtocol) {
    return <GameProtocol onExit={() => setShowClassicProtocol(false)} />;
  }

  if (activeGame) {
    return (
      <main className="gw-workshop-root">
        <GamePlayer game={activeGame} onBack={() => setActiveGame(null)} />
      </main>
    );
  }

  const launchCard = (game: WorkshopGameDefinition) => {
    if (game.id === "classic-protocol") {
      setShowClassicProtocol(true);
    } else {
      setActiveGame(game);
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const spotlight = WORKSHOP_GAMES.find((g) => g.id === spotlightId) || WORKSHOP_GAMES[0];

  return (
    <main className="gw-workshop-root gw-secret-reveal">
      <div className="gw-mast">
        <div>
          <p className="eyebrow" style={{ marginBottom: 4 }}>
            Protocol VII Unlocked · Secret Chamber
          </p>
          <h1>GNOSIS Hidden Workshop</h1>
          <p className="gw-mast-sub">
            Select a chamber below or preview modes in the Featured Spotlight. All 3D arenas, roads,
            weapons, vehicles, soundtracks, and Supabase Realtime lobbies are ready.
          </p>
        </div>

        <div className="gw-mast-actions">
          <button
            type="button"
            className="gw-btn gw-btn-primary"
            onClick={() => setShowClassicProtocol(true)}
          >
            Chess &amp; Classic Games (13)
          </button>
          <button
            type="button"
            className="gw-btn"
            onClick={onReturnToNormalGnosis}
          >
            ← Return to Normal GNOSIS
          </button>
        </div>
      </div>

      {/* Featured Interactive Game Spotlight */}
      <section className="gw-hub-spotlight" aria-label="Featured Game Spotlight">
        <div className="gw-hub-spotlight-media">
          <img
            src={spotlight.coverArt}
            alt={spotlight.name}
            referrerPolicy="no-referrer"
          />
          <div className="gw-hub-spotlight-scrim" />
        </div>
        <div className="gw-hub-spotlight-body">
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <div className="gw-hub-switcher" role="tablist" aria-label="Quick chamber spotlight">
              {WORKSHOP_GAMES.map((g) => (
                <button
                  key={g.id}
                  type="button"
                  role="tab"
                  aria-selected={spotlight.id === g.id}
                  className={`gw-hub-switch-btn ${spotlight.id === g.id ? "active" : ""}`}
                  onClick={() => setSpotlightId(g.id)}
                >
                  {g.name.split(" · ")[0].replace("GNOSIS ", "")}
                </button>
              ))}
            </div>
            <div className="gw-card-kicker">
              <span>{spotlight.gameType}</span>
              <span aria-hidden="true">·</span>
              <span>{spotlight.runtimeLabel}</span>
            </div>
            <h2>{spotlight.name}</h2>
            <p>{spotlight.description}</p>
          </div>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
            <button
              type="button"
              className="brass-button"
              onClick={() => launchCard(spotlight)}
            >
              {spotlight.ctaLabel}
            </button>
          </div>
        </div>
      </section>

      <section className="gw-three-grid" aria-label="Hidden Workshop Game Selection">
        {WORKSHOP_GAMES.map((game) => (
          <article
            key={game.id}
            className="gw-hero-card"
            onMouseEnter={() => setSpotlightId(game.id)}
          >
            <button
              type="button"
              className="gw-hero-media"
              onClick={() => launchCard(game)}
              aria-label={`Play ${game.name}`}
            >
              <CardCover game={game} />
            </button>

            <div className="gw-hero-body">
              <div className="gw-card-kicker">
                <span>{game.gameType}</span>
                <span aria-hidden="true">·</span>
                <span>{game.runtimeLabel}</span>
              </div>

              <h2>{game.name}</h2>
              <p>{game.description}</p>

              <div className="gw-hero-actions">
                <button
                  type="button"
                  className="brass-button"
                  onClick={() => launchCard(game)}
                >
                  {game.ctaLabel}
                </button>
              </div>
            </div>
          </article>
        ))}
      </section>
    </main>
  );
}
