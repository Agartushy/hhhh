import { useSyncExternalStore } from "react";

export type WorkshopGraphicsQuality = "low" | "medium" | "high";

export interface WorkshopKeybinds {
  forward: string;
  backward: string;
  left: string;
  right: string;
  sprint: string;
  crouch: string;
  jump: string;
  reload: string;
  interact: string;
  inspect: string;
  loadout: string;
}

export interface WorkshopSettings {
  musicVolume: number; // 0..1
  sfxVolume: number; // 0..1
  muted: boolean;
  musicEnabled: boolean;
  graphicsQuality: WorkshopGraphicsQuality;
  mouseSensitivity: number; // 0.3..3.0 multiplier
  fov: number; // 65..100
  preferredTrackUrl: string | null;
  keybinds: WorkshopKeybinds;
}

const STORAGE_KEY = "gnosis-workshop-settings-v1";

export const DEFAULT_WORKSHOP_SETTINGS: WorkshopSettings = {
  musicVolume: 0.38,
  sfxVolume: 0.82,
  muted: false,
  musicEnabled: true,
  graphicsQuality: "high",
  mouseSensitivity: 1.0,
  fov: 74,
  preferredTrackUrl: null,
  keybinds: {
    forward: "W",
    backward: "S",
    left: "A",
    right: "D",
    sprint: "Shift",
    crouch: "C",
    jump: "Space",
    reload: "R",
    interact: "E",
    inspect: "F",
    loadout: "B",
  },
};

function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}

function loadSettingsFromStorage(): WorkshopSettings {
  if (typeof window === "undefined") return { ...DEFAULT_WORKSHOP_SETTINGS };
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return { ...DEFAULT_WORKSHOP_SETTINGS };
    const parsed = JSON.parse(raw) as Partial<WorkshopSettings>;
    return {
      musicVolume:
        typeof parsed.musicVolume === "number"
          ? clamp(parsed.musicVolume, 0, 1)
          : DEFAULT_WORKSHOP_SETTINGS.musicVolume,
      sfxVolume:
        typeof parsed.sfxVolume === "number"
          ? clamp(parsed.sfxVolume, 0, 1)
          : DEFAULT_WORKSHOP_SETTINGS.sfxVolume,
      muted: typeof parsed.muted === "boolean" ? parsed.muted : DEFAULT_WORKSHOP_SETTINGS.muted,
      musicEnabled:
        typeof parsed.musicEnabled === "boolean"
          ? parsed.musicEnabled
          : DEFAULT_WORKSHOP_SETTINGS.musicEnabled,
      graphicsQuality:
        parsed.graphicsQuality === "low" ||
        parsed.graphicsQuality === "medium" ||
        parsed.graphicsQuality === "high"
          ? parsed.graphicsQuality
          : DEFAULT_WORKSHOP_SETTINGS.graphicsQuality,
      mouseSensitivity:
        typeof parsed.mouseSensitivity === "number"
          ? clamp(parsed.mouseSensitivity, 0.25, 3.0)
          : DEFAULT_WORKSHOP_SETTINGS.mouseSensitivity,
      fov: typeof parsed.fov === "number" ? clamp(parsed.fov, 60, 105) : DEFAULT_WORKSHOP_SETTINGS.fov,
      preferredTrackUrl:
        typeof parsed.preferredTrackUrl === "string" || parsed.preferredTrackUrl === null
          ? parsed.preferredTrackUrl
          : null,
      keybinds: {
        ...DEFAULT_WORKSHOP_SETTINGS.keybinds,
        ...(parsed.keybinds && typeof parsed.keybinds === "object" ? parsed.keybinds : {}),
      },
    };
  } catch {
    return { ...DEFAULT_WORKSHOP_SETTINGS };
  }
}

let currentSettings: WorkshopSettings = loadSettingsFromStorage();
const listeners = new Set<() => void>();

function saveAndNotify() {
  if (typeof window !== "undefined") {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(currentSettings));
    } catch {
      // Ignore storage quota errors
    }
  }
  for (const l of listeners) {
    try {
      l();
    } catch {
      // Ignore subscriber errors
    }
  }
}

export function getWorkshopSettings(): WorkshopSettings {
  return currentSettings;
}

export function updateWorkshopSettings(patch: Partial<WorkshopSettings>) {
  currentSettings = {
    ...currentSettings,
    ...patch,
    musicVolume:
      patch.musicVolume !== undefined
        ? clamp(patch.musicVolume, 0, 1)
        : currentSettings.musicVolume,
    sfxVolume:
      patch.sfxVolume !== undefined ? clamp(patch.sfxVolume, 0, 1) : currentSettings.sfxVolume,
    mouseSensitivity:
      patch.mouseSensitivity !== undefined
        ? clamp(patch.mouseSensitivity, 0.25, 3.0)
        : currentSettings.mouseSensitivity,
    fov: patch.fov !== undefined ? clamp(patch.fov, 60, 105) : currentSettings.fov,
    keybinds: patch.keybinds
      ? { ...currentSettings.keybinds, ...patch.keybinds }
      : currentSettings.keybinds,
  };
  saveAndNotify();
}

export function resetWorkshopSettings() {
  currentSettings = {
    ...DEFAULT_WORKSHOP_SETTINGS,
    keybinds: { ...DEFAULT_WORKSHOP_SETTINGS.keybinds },
  };
  saveAndNotify();
}

function subscribe(listener: () => void): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function useWorkshopSettings(): WorkshopSettings {
  return useSyncExternalStore(subscribe, getWorkshopSettings, getWorkshopSettings);
}
