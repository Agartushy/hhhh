import type { RealtimeChannel } from "@supabase/supabase-js";
import {
  getLocalPlayerId,
  getSupabaseClient,
  isSupabaseConfigured,
} from "../../supabaseClient";

export { isSupabaseConfigured };

export type WorkshopChannel = "shooter" | "racing" | "titan" | "hoi4";

export type NetworkConnectionState =
  | "probing"
  | "connecting"
  | "connected"
  | "reconnecting"
  | "offline"
  | "unconfigured";

export interface WorkshopRoomSummary {
  code: string;
  gameKey: string;
  title: string;
  hostId: string;
  hostName: string;
  players: number;
  maxPlayers: number;
  mode?: string;
  round?: number;
  phase?: string;
  wave?: number;
  status?: string;
  scenario?: string;
  dateStr?: string;
  worldTension?: number;
  elapsedTime?: number;
  updatedAt: string;
}

export interface WorkshopPeer {
  playerId: string;
  playerName: string;
  joinedAt: number;
  onlineAt: string;
}

export interface WorkshopEnvelope {
  type: string;
  senderId: string;
  targetId?: string;
  [key: string]: unknown;
}

const CHANNEL_PREFIX: Record<WorkshopChannel, string> = {
  shooter: "F",
  racing: "R",
  titan: "T",
  hoi4: "W",
};

const GAME_KEYS: Record<WorkshopChannel, string> = {
  shooter: "ws-shooter",
  racing: "ws-racing",
  titan: "ws-titan",
  hoi4: "ws-hoi4",
};

const STALE_ROOM_MS = 4 * 60 * 1000;

export function getWorkshopGameKey(channel: WorkshopChannel): string {
  return GAME_KEYS[channel];
}

export function generateWorkshopCode(channel: WorkshopChannel): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = CHANNEL_PREFIX[channel];
  for (let i = 0; i < 4; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}

function mapRoomRow(row: Record<string, unknown>): WorkshopRoomSummary | null {
  const code = typeof row.code === "string" ? row.code : "";
  const gameKey = typeof row.game_id === "string" ? row.game_id : "";
  if (!code || !gameKey) return null;
  const state = (row.state && typeof row.state === "object"
    ? row.state
    : {}) as Record<string, unknown>;
  const updatedAt =
    typeof row.updated_at === "string" ? row.updated_at : new Date().toISOString();

  return {
    code,
    gameKey,
    title:
      typeof state.title === "string" && state.title.trim()
        ? state.title.trim()
        : `Room ${code}`,
    hostId: typeof row.host_id === "string" ? row.host_id : "",
    hostName: typeof row.host_name === "string" ? row.host_name : "Host",
    players: typeof state.players === "number" ? state.players : 1,
    maxPlayers: typeof state.maxPlayers === "number" ? state.maxPlayers : 8,
    mode: typeof state.mode === "string" ? state.mode : undefined,
    round: typeof state.round === "number" ? state.round : undefined,
    phase: typeof state.phase === "string" ? state.phase : undefined,
    wave: typeof state.wave === "number" ? state.wave : undefined,
    status: typeof state.status === "string" ? state.status : undefined,
    scenario: typeof state.scenario === "string" ? state.scenario : undefined,
    dateStr: typeof state.dateStr === "string" ? state.dateStr : undefined,
    worldTension: typeof state.worldTension === "number" ? state.worldTension : undefined,
    elapsedTime: typeof state.elapsedTime === "number" ? state.elapsedTime : undefined,
    updatedAt,
  };
}

export interface WorkshopLobbyClient {
  connect: () => void;
  refreshRooms: () => Promise<void>;
  disconnect: () => Promise<void>;
  isConnected: () => boolean;
}

/**
 * Event-driven Supabase lobby discovery for Workshop games.
 * Fetches once on subscribe and updates live via Postgres Changes (no interval DB polling).
 */
export function createWorkshopLobbyClient(params: {
  channel: WorkshopChannel;
  onStateChange: (state: NetworkConnectionState, detail?: string | null) => void;
  onRoomsChange: (rooms: WorkshopRoomSummary[]) => void;
  onLatency?: (rttMs: number) => void;
}): WorkshopLobbyClient {
  const gameKey = getWorkshopGameKey(params.channel);
  let lobbyChannel: RealtimeChannel | null = null;
  let disposed = false;
  let connected = false;
  let refreshDebounce: number | null = null;

  const refreshRooms = async () => {
    const sb = getSupabaseClient();
    if (!sb || disposed) return;

    const cutoffIso = new Date(Date.now() - STALE_ROOM_MS).toISOString();
    const startMs = performance.now();
    const { data, error } = await sb
      .from("game_rooms")
      .select("code, game_id, status, host_id, host_name, state, updated_at")
      .eq("game_id", gameKey)
      .neq("status", "closed")
      .gte("updated_at", cutoffIso)
      .order("updated_at", { ascending: false })
      .limit(20);

    if (disposed) return;

    if (error) {
      params.onStateChange(
        "offline",
        `Supabase room query failed: ${error.message}. Ensure migration 001_game_rooms.sql has been applied.`,
      );
      return;
    }

    params.onLatency?.(Math.max(1, Math.round(performance.now() - startMs)));

    const list: WorkshopRoomSummary[] = [];
    for (const row of data || []) {
      const mapped = mapRoomRow(row as Record<string, unknown>);
      if (mapped && mapped.players > 0) list.push(mapped);
    }
    params.onRoomsChange(list);
  };

  const connect = () => {
    if (disposed) return;
    if (!isSupabaseConfigured) {
      connected = false;
      params.onStateChange(
        "unconfigured",
        "Supabase credentials (VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY) are not configured in this environment. Solo modes run locally without a server.",
      );
      return;
    }

    const sb = getSupabaseClient();
    if (!sb) {
      connected = false;
      params.onStateChange("unconfigured", "Supabase client unavailable.");
      return;
    }

    if (lobbyChannel) {
      void sb.removeChannel(lobbyChannel);
      lobbyChannel = null;
    }

    connected = false;
    params.onStateChange("connecting", null);

    const ch = sb.channel(`gnosis-workshop-lobby:${gameKey}:${Math.random().toString(36).slice(2, 7)}`);
    lobbyChannel = ch;

    ch.on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: "game_rooms",
        filter: `game_id=eq.${gameKey}`,
      },
      () => {
        if (disposed) return;
        if (refreshDebounce !== null) window.clearTimeout(refreshDebounce);
        refreshDebounce = window.setTimeout(() => {
          void refreshRooms();
        }, 220);
      },
    ).subscribe((status, err) => {
      if (disposed || lobbyChannel !== ch) return;
      if (status === "SUBSCRIBED") {
        connected = true;
        params.onStateChange("connected", null);
        void refreshRooms();
      } else if (status === "TIMED_OUT" || status === "CHANNEL_ERROR") {
        connected = false;
        params.onStateChange(
          "offline",
          err?.message
            ? `Supabase Realtime connection failed: ${err.message}`
            : "Supabase Realtime lobby channel error. Check network or Realtime settings and click Reconnect.",
        );
      } else if (status === "CLOSED") {
        connected = false;
        params.onStateChange("offline", "Supabase Realtime channel closed.");
      }
    });
  };

  const disconnect = async () => {
    disposed = true;
    connected = false;
    if (refreshDebounce !== null) {
      window.clearTimeout(refreshDebounce);
      refreshDebounce = null;
    }
    const sb = getSupabaseClient();
    if (sb && lobbyChannel) {
      const ch = lobbyChannel;
      lobbyChannel = null;
      try {
        await sb.removeChannel(ch);
      } catch {
        // Ignore cleanup failure
      }
    }
  };

  return {
    connect,
    refreshRooms,
    disconnect,
    isConnected: () => connected,
  };
}

export interface WorkshopRoomTransport {
  code: string;
  localPlayerId: string;
  localPlayerName: string;
  getIsHost: () => boolean;
  getPeers: () => WorkshopPeer[];
  send: (payload: Record<string, unknown>, targetId?: string) => void;
  updateRoomMeta: (meta: Record<string, unknown>) => Promise<void>;
  leave: (forceCloseRoom?: boolean) => Promise<void>;
}

export async function openWorkshopRoom(params: {
  channel: WorkshopChannel;
  mode: "create" | "join";
  code?: string;
  playerName: string;
  initialMeta?: Record<string, unknown>;
  maxPlayers: number;
  joinHelloPayload?: Record<string, unknown>;
  onMessage: (msg: WorkshopEnvelope) => void;
  onPeersChange: (peers: WorkshopPeer[], hostId: string, isHost: boolean) => void;
  onStatusChange: (status: NetworkConnectionState, detail?: string | null) => void;
  onLatency?: (rttMs: number) => void;
}): Promise<{ session?: WorkshopRoomTransport; error?: string }> {
  if (!isSupabaseConfigured) {
    return {
      error: "Supabase is not configured. Add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to use online rooms.",
    };
  }
  const sb = getSupabaseClient();
  if (!sb) {
    return { error: "Supabase client could not be initialized." };
  }

  const gameKey = getWorkshopGameKey(params.channel);
  const localPlayerId = getLocalPlayerId();
  const cleanName = params.playerName.trim().slice(0, 18) || "Operative";
  let roomCode = (params.code || "").trim().toUpperCase();
  let dbHostId = localPlayerId;
  let latestMeta: Record<string, unknown> = { ...(params.initialMeta || {}) };

  if (params.mode === "create") {
    let created = false;
    let lastErr = "";
    for (let attempt = 0; attempt < 4; attempt++) {
      roomCode = generateWorkshopCode(params.channel);
      const { error } = await sb.from("game_rooms").insert({
        code: roomCode,
        game_id: gameKey,
        status: "playing",
        host_id: localPlayerId,
        host_name: cleanName,
        turn: "live",
        state: {
          ...latestMeta,
          players: 1,
          maxPlayers: params.maxPlayers,
        },
      });
      if (!error) {
        created = true;
        break;
      }
      lastErr = error.message;
    }
    if (!created) {
      return {
        error: `Failed to create room in Supabase: ${lastErr}. Ensure migration 001_game_rooms.sql has been run.`,
      };
    }
  } else {
    if (!roomCode) return { error: "Enter a room code to join." };
    const { data, error } = await sb
      .from("game_rooms")
      .select("code, game_id, status, host_id, host_name, state, updated_at")
      .eq("code", roomCode)
      .eq("game_id", gameKey)
      .maybeSingle();

    if (error) {
      return { error: `Room lookup failed: ${error.message}` };
    }
    if (!data) {
      return { error: `No active room found with code "${roomCode}".` };
    }
    if (data.status === "closed") {
      return { error: `Room "${roomCode}" has already closed.` };
    }
    const updatedMs = Date.parse(String(data.updated_at || ""));
    if (Number.isFinite(updatedMs) && Date.now() - updatedMs > STALE_ROOM_MS) {
      return { error: `Room "${roomCode}" has expired due to inactivity.` };
    }
    const st = (data.state && typeof data.state === "object"
      ? data.state
      : {}) as Record<string, unknown>;
    const curPlayers = typeof st.players === "number" ? st.players : 1;
    const cap = typeof st.maxPlayers === "number" ? st.maxPlayers : params.maxPlayers;
    if (curPlayers >= cap && data.host_id !== localPlayerId) {
      return { error: `Room "${roomCode}" is full (${curPlayers}/${cap}).` };
    }
    dbHostId = String(data.host_id || localPlayerId);
    latestMeta = st;
  }

  let closed = false;
  let hasSyncedPresence = false;
  let isHost = params.mode === "create" || dbHostId === localPlayerId;
  let peers: WorkshopPeer[] = [];
  const joinedAt = Date.now();
  let heartbeatTimer: number | null = null;
  let pingTimer: number | null = null;

  const rtChannel = sb.channel(`gnosis-workshop:${gameKey}:${roomCode}`, {
    config: {
      presence: { key: localPlayerId },
      broadcast: { self: false, ack: false },
    },
  });

  const sendRaw = (payload: Record<string, unknown>, targetId?: string) => {
    if (closed) return;
    const envelope: WorkshopEnvelope = {
      ...payload,
      type: String(payload.type || "event"),
      senderId: localPlayerId,
      ...(targetId ? { targetId } : {}),
    };
    void rtChannel.send({
      type: "broadcast",
      event: "ws:msg",
      payload: envelope,
    });
  };

  const updateRoomMeta = async (meta: Record<string, unknown>) => {
    if (closed) return;
    latestMeta = { ...latestMeta, ...meta };
    try {
      await sb
        .from("game_rooms")
        .update({
          state: latestMeta,
          host_id: dbHostId,
        })
        .eq("code", roomCode)
        .eq("game_id", gameKey);
    } catch {
      // Best-effort metadata heartbeat
    }
  };

  const onUnload = () => {
    if (!closed) {
      try {
        void rtChannel.untrack();
      } catch {
        // Ignore
      }
    }
  };
  window.addEventListener("beforeunload", onUnload);

  const leave = async (forceCloseRoom = false) => {
    if (closed) return;
    closed = true;
    window.removeEventListener("beforeunload", onUnload);
    if (heartbeatTimer !== null) {
      window.clearInterval(heartbeatTimer);
      heartbeatTimer = null;
    }
    if (pingTimer !== null) {
      window.clearInterval(pingTimer);
      pingTimer = null;
    }

    sendRaw({ type: "peer:left", playerId: localPlayerId, playerName: cleanName });

    try {
      const otherPeers = peers.filter((p) => p.playerId !== localPlayerId);
      if (forceCloseRoom || (otherPeers.length === 0 && (isHost || hasSyncedPresence))) {
        await sb
          .from("game_rooms")
          .update({ status: "closed", state: { ...latestMeta, players: 0 } })
          .eq("code", roomCode)
          .eq("game_id", gameKey);
      } else if (isHost && otherPeers.length > 0) {
        const nextHost = otherPeers[0];
        await sb
          .from("game_rooms")
          .update({
            host_id: nextHost.playerId,
            host_name: nextHost.playerName,
            state: { ...latestMeta, players: otherPeers.length },
          })
          .eq("code", roomCode)
          .eq("game_id", gameKey);
      }
    } catch {
      // Best-effort cleanup
    }

    try {
      await rtChannel.untrack();
    } catch {
      // Ignore
    }
    try {
      await sb.removeChannel(rtChannel);
    } catch {
      // Ignore
    }
  };

  rtChannel
    .on("broadcast", { event: "ws:msg" }, ({ payload }) => {
      if (closed || !payload || typeof payload !== "object") return;
      const msg = payload as WorkshopEnvelope;
      if (msg.senderId === localPlayerId) return;
      if (msg.targetId && msg.targetId !== localPlayerId) return;

      if (msg.type === "net:ping" && typeof msg.ts === "number") {
        sendRaw({ type: "net:pong", ts: msg.ts }, msg.senderId);
        return;
      }
      if (msg.type === "net:pong" && typeof msg.ts === "number") {
        params.onLatency?.(Math.max(1, Date.now() - msg.ts));
        return;
      }

      params.onMessage(msg);
    })
    .on("presence", { event: "sync" }, () => {
      if (closed) return;
      hasSyncedPresence = true;
      const stateMap = rtChannel.presenceState<WorkshopPeer>();
      const list: WorkshopPeer[] = [];
      for (const entries of Object.values(stateMap)) {
        for (const entry of entries) {
          if (entry && typeof entry.playerId === "string") {
            list.push(entry);
          }
        }
      }
      list.sort((a, b) =>
        a.joinedAt !== b.joinedAt
          ? a.joinedAt - b.joinedAt
          : a.playerId.localeCompare(b.playerId),
      );
      peers = list;

      if (list.length > 0) {
        const dbHostStillHere = list.some((p) => p.playerId === dbHostId);
        const electedHost = dbHostStillHere ? dbHostId : list[0].playerId;
        const becameHost = !isHost && electedHost === localPlayerId;
        dbHostId = electedHost;
        isHost = electedHost === localPlayerId;

        if (becameHost && list.length > 1) {
          void sb
            .from("game_rooms")
            .update({
              host_id: localPlayerId,
              host_name: cleanName,
            })
            .eq("code", roomCode)
            .eq("game_id", gameKey);
        }
        params.onPeersChange(list, electedHost, isHost);
      } else {
        params.onPeersChange([], dbHostId, isHost);
      }
    });

  const subscribedOk = await new Promise<boolean>((resolve) => {
    let settled = false;
    const timeout = window.setTimeout(() => {
      if (!settled) {
        settled = true;
        resolve(false);
      }
    }, 6500);

    rtChannel.subscribe(async (status, err) => {
      if (closed) return;
      if (status === "SUBSCRIBED") {
        try {
          await rtChannel.track({
            playerId: localPlayerId,
            playerName: cleanName,
            joinedAt,
            onlineAt: new Date().toISOString(),
          } satisfies WorkshopPeer);
        } catch {
          // Presence track failed
        }
        params.onStatusChange("connected", null);
        if (!settled) {
          settled = true;
          window.clearTimeout(timeout);
          resolve(true);
        }
      } else if (status === "CHANNEL_ERROR" || status === "TIMED_OUT") {
        params.onStatusChange(
          "offline",
          err?.message || "Failed to subscribe to Supabase Realtime room channel.",
        );
        if (!settled) {
          settled = true;
          window.clearTimeout(timeout);
          resolve(false);
        }
      } else if (status === "CLOSED") {
        params.onStatusChange("offline", "Room Realtime channel closed.");
      }
    });
  });

  if (!subscribedOk) {
    await leave(params.mode === "create");
    return {
      error: "Could not establish Supabase Realtime connection for this room.",
    };
  }

  heartbeatTimer = window.setInterval(() => {
    if (closed || !isHost) return;
    void updateRoomMeta(latestMeta);
  }, 30_000);

  pingTimer = window.setInterval(() => {
    if (closed || isHost || !dbHostId) return;
    sendRaw({ type: "net:ping", ts: Date.now() }, dbHostId);
  }, 5000);

  if (params.mode === "join") {
    sendRaw({
      type: "peer:hello",
      playerId: localPlayerId,
      playerName: cleanName,
      ...(params.joinHelloPayload || {}),
    });
  }

  return {
    session: {
      code: roomCode,
      localPlayerId,
      localPlayerName: cleanName,
      getIsHost: () => isHost,
      getPeers: () => peers,
      send: sendRaw,
      updateRoomMeta,
      leave: async (forceCloseRoom = false) => {
        await leave(forceCloseRoom);
      },
    },
  };
}
