import { Suspense, lazy, useCallback, useEffect, useRef, useState } from "react";
import {
  cycleActiveSoundtrack,
  getActiveSoundtrackItem,
  getActiveSoundtrackTitle,
  getSharedPlaylist,
  registerSessionTrackFile,
  selectActiveSoundtrackByUrl,
  setActiveSoundtrackVolume,
  subscribeSoundtrackMeta,
} from "./soundtrack";
import { updateWorkshopSettings, useWorkshopSettings } from "./sharedSettings";

const CoopShooterGame = lazy(() =>
  import("./CoopShooterGame").then((m) => ({ default: m.CoopShooterGame })),
);
const GnosisRacingGame = lazy(() =>
  import("./GnosisRacingGame").then((m) => ({ default: m.GnosisRacingGame })),
);
const Hoi4StrategyGame = lazy(() =>
  import("./Hoi4StrategyGame").then((m) => ({ default: m.Hoi4StrategyGame })),
);
const TitanAssaultGame = lazy(() =>
  import("./TitanAssaultGame").then((m) => ({ default: m.TitanAssaultGame })),
);

export type WorkshopGameId =
  | "gnosis-racing"
  | "coop-shooter"
  | "titan-assault"
  | "hoi4-strategy"
  | "classic-protocol";

export interface WorkshopGameDefinition {
  id: WorkshopGameId;
  name: string;
  gameType: string;
  runtimeLabel: string;
  description: string;
  coverArt: string;
  ctaLabel: string;
}

export function GamePlayer({
  game,
  onBack,
}: {
  game: WorkshopGameDefinition;
  onBack: () => void;
}) {
  const playerRootRef = useRef<HTMLElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const settings = useWorkshopSettings();
  const [trackTitle, setTrackTitle] = useState(() => getActiveSoundtrackTitle());
  const [activeTrackUrl, setActiveTrackUrl] = useState(() => getActiveSoundtrackItem().url);
  const [playlist, setPlaylist] = useState(() => getSharedPlaylist());

  useEffect(() => {
    const syncTrack = () => {
      setTrackTitle(getActiveSoundtrackTitle());
      setActiveTrackUrl(getActiveSoundtrackItem().url);
      setPlaylist(getSharedPlaylist());
    };
    syncTrack();
    return subscribeSoundtrackMeta(syncTrack);
  }, [game.id]);

  useEffect(() => {
    setActiveSoundtrackVolume(settings.muted ? 0 : settings.musicVolume);
  }, [settings.musicVolume, settings.muted]);

  useEffect(() => {
    const onFullscreenChange = () => {
      if (!document.fullscreenElement) {
        setIsFullscreen(false);
      }
    };
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isFullscreen && !document.fullscreenElement) {
        setIsFullscreen(false);
      }
    };
    document.addEventListener("fullscreenchange", onFullscreenChange);
    window.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("fullscreenchange", onFullscreenChange);
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [isFullscreen]);

  const toggleFullscreen = useCallback(async () => {
    const el = playerRootRef.current;
    if (!el) return;
    if (!isFullscreen) {
      setIsFullscreen(true);
      try {
        if (el.requestFullscreen) {
          await el.requestFullscreen();
        }
      } catch {
        // Fallback CSS fullscreen overlay remains active
      }
    } else {
      setIsFullscreen(false);
      try {
        if (document.fullscreenElement && document.exitFullscreen) {
          await document.exitFullscreen();
        }
      } catch {
        // Ignore
      }
    }
  }, [isFullscreen]);

  const handleExit = useCallback(async () => {
    if (document.pointerLockElement) {
      document.exitPointerLock?.();
    }
    if (document.fullscreenElement && document.exitFullscreen) {
      try {
        await document.exitFullscreen();
      } catch {
        // Ignore
      }
    }
    setIsFullscreen(false);
    onBack();
  }, [onBack]);

  return (
    <section
      ref={playerRootRef}
      className={`gw-player-page ${isFullscreen ? "is-fullscreen" : ""}`}
      aria-label={`Playing ${game.name}`}
    >
      <div className="gw-player-header">
        <div className="gw-player-left">
          <button type="button" className="gw-btn" onClick={handleExit}>
            ← Back to Workshop
          </button>
          <div className="gw-player-titleblock">
            <div className="gw-player-meta">
              <span>{game.gameType}</span>
              <span aria-hidden="true">·</span>
              <span>{game.runtimeLabel}</span>
            </div>
            <h2>{game.name}</h2>
          </div>
        </div>

        <div className="gw-player-actions" style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
          <select
            aria-label="Soundtrack track selector"
            className="gw-track-select"
            value={activeTrackUrl}
            onChange={(e) => {
              const nextUrl = e.target.value;
              const title = selectActiveSoundtrackByUrl(nextUrl);
              setTrackTitle(title);
              setActiveTrackUrl(nextUrl);
              updateWorkshopSettings({ preferredTrackUrl: nextUrl, musicEnabled: true });
            }}
          >
            {playlist.map((t) => (
              <option key={t.id} value={t.url}>
                ♪ {t.title}
              </option>
            ))}
          </select>
          <button
            type="button"
            className="gw-btn"
            title={`Next track (Current: ${trackTitle})`}
            onClick={() => {
              const title = cycleActiveSoundtrack();
              setTrackTitle(title);
              setActiveTrackUrl(getActiveSoundtrackItem().url);
            }}
          >
            Next Track ⏭
          </button>
          <label
            className="gw-vol-inline"
            title="Master music volume"
            style={{ display: "inline-flex", alignItems: "center", gap: 6, fontSize: 12 }}
          >
            <span>{settings.muted ? "Muted" : "Vol"}</span>
            <input
              type="range"
              min={0}
              max={100}
              value={Math.round(settings.musicVolume * 100)}
              onChange={(e) =>
                updateWorkshopSettings({
                  musicVolume: Number(e.target.value) / 100,
                  muted: false,
                })
              }
              style={{ width: 68 }}
            />
          </label>
          <button
            type="button"
            className={`gw-btn ${settings.muted ? "danger" : ""}`}
            title="Toggle global audio mute"
            onClick={() => updateWorkshopSettings({ muted: !settings.muted })}
          >
            {settings.muted ? "Unmute" : "Mute"}
          </button>
          <button
            type="button"
            className="gw-btn"
            title="Add an MP3/M4A track to the session playlist"
            onClick={() => fileInputRef.current?.click()}
          >
            + Song
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="audio/*,.mp3,.m4a,.wav,.ogg"
            style={{ display: "none" }}
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                setTrackTitle(registerSessionTrackFile(file));
                setActiveTrackUrl(getActiveSoundtrackItem().url);
                setPlaylist(getSharedPlaylist());
                e.target.value = "";
              }
            }}
          />
          <button
            type="button"
            className={`gw-btn ${isFullscreen ? "active" : "gw-btn-primary"}`}
            onClick={toggleFullscreen}
          >
            {isFullscreen ? "Exit Fullscreen" : "Fullscreen"}
          </button>
        </div>
      </div>

      <div className="gw-player-stage">
        <Suspense
          fallback={
            <div className="gw-fps-empty" style={{ margin: "auto", maxWidth: 420 }}>
              <p>Loading {game.name}…</p>
              <small>Initializing game simulation and WebGL/canvas resources.</small>
            </div>
          }
        >
          {game.id === "gnosis-racing" && (
            <GnosisRacingGame
              isFullscreen={isFullscreen}
              onToggleFullscreen={toggleFullscreen}
              onExit={handleExit}
            />
          )}
          {game.id === "coop-shooter" && (
            <CoopShooterGame
              isFullscreen={isFullscreen}
              onToggleFullscreen={toggleFullscreen}
              onExit={handleExit}
            />
          )}
          {game.id === "titan-assault" && (
            <TitanAssaultGame
              isFullscreen={isFullscreen}
              onToggleFullscreen={toggleFullscreen}
              onExit={handleExit}
            />
          )}
          {game.id === "hoi4-strategy" && (
            <Hoi4StrategyGame
              isFullscreen={isFullscreen}
              onToggleFullscreen={toggleFullscreen}
              onExit={handleExit}
            />
          )}
        </Suspense>
      </div>
    </section>
  );
}
