import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import { disposeSafeHierarchy } from "./assets/modelLoader";
import {
  buildTrackWorld,
  findClosestTrackPoint,
  getTrackDef,
  TRACK_CATALOG,
} from "./racing/trackAndWorld";
import type { MyCarEntry } from "./racing/myCars";
import {
  buildVehicleRig,
  WORKSHOP_VEHICLES,
  type CarRig,
  type CarVisualOptions,
} from "./racing/vehicles";
import { createLoadedCarWithPhysics } from "./racing/physics";
import {
  applyTuningPreset,
  loadTrackRecords,
  saveTrackRecord,
  TUNING_PRESETS,
  updateRacingCustomization,
  updateRacingTuning,
  useRacingCustomization,
  type RacingTrackId,
  type TrackBestRecord,
  type TuningPresetId,
} from "./racing/customization";
import { CarGlbThumbnail, GaragePreview3D } from "./racing/GaragePreview3D";
import {
  GAME_SOUNDTRACK_PLAYLIST,
  GameSoundtrackPlayer,
  getSharedPlaylist,
  registerSessionTrackFile,
  selectActiveSoundtrackByUrl,
  subscribeSoundtrackMeta,
} from "./soundtrack";
import {
  updateWorkshopSettings,
  useWorkshopSettings,
  type WorkshopGraphicsQuality,
} from "./sharedSettings";
import {
  createWorkshopLobbyClient,
  openWorkshopRoom,
  type NetworkConnectionState,
  type WorkshopLobbyClient,
  type WorkshopRoomSummary,
  type WorkshopRoomTransport,
} from "./net/gameNetwork";
import {
  RacingRoomHost,
  type HostRacingSnapshot,
  type RacingOutgoingEvent,
} from "./racing/racingHostEngine";
import cardRacingImg from "../assets/images/card_gnosis_racing_1795182391860.jpg";

type GraphicsQuality = WorkshopGraphicsQuality;
type CameraViewMode = "chase" | "close" | "hood";
type RaceStatus = "GARAGE" | "RACING" | "PAUSED" | "FINISHED";
type GarageMenuTab = "play" | "garage" | "tuning" | "settings";

interface PublicRacingRoomInfo {
  code: string;
  title: string;
  players: number;
  maxPlayers: number;
  status: "ACTIVE" | "FINISHED";
  elapsedTime: number;
}

interface NetRacer {
  id: string;
  name: string;
  color: string;
  slot: number;
  vehicleId: string;
  x: number;
  y: number;
  z: number;
  yaw: number;
  steer: number;
  wheelSpin: number;
  speedKmh: number;
  topSpeedKmh: number;
  lap: number;
  progressNorm: number;
  drafting: boolean;
  finished: boolean;
  finishTime: number | null;
  bestLap: number | null;
  score: number;
}

interface NetRival {
  id: string;
  name: string;
  vehicleId: string;
  s: number;
  speed: number;
  laneOffset: number;
  lap: number;
  wheelSpin: number;
}

interface RacingSnapshot {
  type: "racing:snapshot";
  code: string;
  title: string;
  trackId?: RacingTrackId;
  status: "ACTIVE" | "FINISHED";
  elapsedTime: number;
  teamScore: number;
  totalLaps: number;
  squadLapsCompleted: number;
  squadTargetLaps: number;
  players: NetRacer[];
  rivals: NetRival[];
}

interface RaceSummary {
  totalTime: number;
  bestLap: number | null;
  topSpeedKmh: number;
  vehicleName: string;
  trackName: string;
}

const _camDesiredPos = new THREE.Vector3();
const _camLookTarget = new THREE.Vector3();
const _sunOffset = new THREE.Vector3(48, 76, 36);

function formatRaceTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  const ms = Math.floor((seconds % 1) * 100);
  return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}.${String(ms).padStart(2, "0")}`;
}

function detectSoftwareWebGL(): boolean {
  try {
    const probe = document.createElement("canvas");
    const gl = probe.getContext("webgl2") || probe.getContext("webgl");
    if (!gl) return true;
    const ext = gl.getExtension("WEBGL_debug_renderer_info");
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param) || "");
    gl.getExtension("WEBGL_lose_context")?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

function disposeObjectResources(root: THREE.Object3D) {
  root.traverse((obj) => {
    obj.userData.disposed = true;
  });
  disposeSafeHierarchy(root);
}

function createRacerNameplate(name: string, colorHex: string): THREE.Sprite {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 64;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = "rgba(18, 13, 9, 0.84)";
  ctx.fillRect(6, 10, 244, 44);
  ctx.strokeStyle = colorHex;
  ctx.lineWidth = 3;
  ctx.strokeRect(6, 10, 244, 44);
  ctx.fillStyle = "#f4ebdd";
  ctx.font = "bold 23px monospace";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(name.slice(0, 14), 128, 33);

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true }));
  sprite.position.set(0, 2.35, 0);
  sprite.scale.set(2.8, 0.7, 1);
  return sprite;
}

class RacingAudioEngine {
  private ctx: AudioContext | null = null;
  private engineOsc: OscillatorNode | null = null;
  private engineGain: GainNode | null = null;
  private skidFilter: BiquadFilterNode | null = null;
  private skidGain: GainNode | null = null;
  private muted = false;
  private volume = 0.82;

  initOnGesture() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") this.ctx.resume().catch(() => {});
      return;
    }
    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      this.ctx = ctx;

      const osc = ctx.createOscillator();
      osc.type = "sawtooth";
      osc.frequency.value = 55;
      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.value = 260;
      const gain = ctx.createGain();
      gain.gain.value = 0;
      osc.connect(filter).connect(gain).connect(ctx.destination);
      osc.start();
      this.engineOsc = osc;
      this.engineGain = gain;

      const bufSize = ctx.sampleRate;
      const noiseBuf = ctx.createBuffer(1, bufSize, ctx.sampleRate);
      const data = noiseBuf.getChannelData(0);
      for (let i = 0; i < bufSize; i++) data[i] = Math.random() * 2 - 1;
      const noise = ctx.createBufferSource();
      noise.buffer = noiseBuf;
      noise.loop = true;
      const bp = ctx.createBiquadFilter();
      bp.type = "bandpass";
      bp.frequency.value = 1150;
      bp.Q.value = 3.2;
      const sGain = ctx.createGain();
      sGain.gain.value = 0;
      noise.connect(bp).connect(sGain).connect(ctx.destination);
      noise.start();
      this.skidFilter = bp;
      this.skidGain = sGain;
    } catch {
      // Blocked by browser policy
    }
  }

  setVolume(v: number) {
    this.volume = Math.max(0, Math.min(1, v));
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (m) this.silence();
  }

  silence() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    if (this.engineGain) this.engineGain.gain.setTargetAtTime(0, t, 0.04);
    if (this.skidGain) this.skidGain.gain.setTargetAtTime(0, t, 0.04);
  }

  update(rpmRatio: number, throttle: number, driftIntensity: number, paused: boolean, pitchBias = 1) {
    if (!this.ctx || this.muted || paused || this.volume <= 0.001) {
      this.silence();
      return;
    }
    const t = this.ctx.currentTime;
    if (this.engineOsc && this.engineGain) {
      const freq = (46 + rpmRatio * 155) * pitchBias;
      this.engineOsc.frequency.setTargetAtTime(freq, t, 0.04);
      const vol = (0.02 + throttle * 0.024 + rpmRatio * 0.018) * this.volume;
      this.engineGain.gain.setTargetAtTime(vol, t, 0.05);
    }
    if (this.skidGain && this.skidFilter) {
      const sv = THREE.MathUtils.clamp(driftIntensity, 0, 1) * 0.045 * this.volume;
      this.skidGain.gain.setTargetAtTime(sv, t, 0.03);
      this.skidFilter.frequency.setTargetAtTime(950 + driftIntensity * 450, t, 0.05);
    }
  }

  playBump(strength: number) {
    if (!this.ctx || this.muted || this.volume <= 0.001) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = "triangle";
      osc.frequency.setValueAtTime(115, t);
      osc.frequency.exponentialRampToValueAtTime(38, t + 0.16);
      gain.gain.setValueAtTime(
        THREE.MathUtils.clamp(strength * 0.14, 0.03, 0.18) * this.volume,
        t,
      );
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
      osc.connect(gain).connect(this.ctx.destination);
      osc.start(t);
      osc.stop(t + 0.19);
    } catch {
      // Ignore
    }
  }

  dispose() {
    this.silence();
    try {
      this.engineOsc?.stop();
      if (this.ctx && this.ctx.state !== "closed") {
        this.ctx.close().catch(() => {});
      }
    } catch {
      // Ignore
    }
    this.ctx = null;
  }
}

export function GnosisRacingGame({
  isFullscreen,
  onToggleFullscreen,
  onExit,
}: {
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  onExit: () => void;
}) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const minimapRef = useRef<HTMLCanvasElement | null>(null);

  const speedTextRef = useRef<HTMLElement | null>(null);
  const gearTextRef = useRef<HTMLElement | null>(null);
  const rpmBarRef = useRef<HTMLDivElement | null>(null);
  const lapTextRef = useRef<HTMLElement | null>(null);
  const lapTimeTextRef = useRef<HTMLElement | null>(null);
  const bestLapTextRef = useRef<HTMLElement | null>(null);
  const surfaceTextRef = useRef<HTMLElement | null>(null);

  const settings = useWorkshopSettings();
  const custom = useRacingCustomization();

  const selectedVehicle: MyCarEntry = useMemo(
    () => WORKSHOP_VEHICLES.find((v) => v.id === custom.vehicleId) || WORKSHOP_VEHICLES[0],
    [custom.vehicleId],
  );
  const selectedTrackDef = useMemo(() => getTrackDef(custom.trackId), [custom.trackId]);

  const visualOptions: CarVisualOptions = useMemo(() => {
    return {
      useCustomColors: custom.useCustomColors,
      paintHex: custom.useCustomColors ? custom.paintHex : undefined,
      accentHex: custom.useCustomColors ? custom.accentHex : undefined,
      rimHex: custom.useCustomColors ? custom.rimHex : undefined,
      finish: custom.finish,
      livery: custom.livery,
      rimStyle: custom.rimStyle,
      raceNumber: custom.raceNumber,
      rideHeightOffset: custom.tuning.rideHeightOffset,
    };
  }, [custom]);

  const [menuTab, setMenuTab] = useState<GarageMenuTab>("play");
  const [raceSessionKey, setRaceSessionKey] = useState(0);
  const [activeTrackId, setActiveTrackId] = useState<RacingTrackId>(custom.trackId);
  const [cameraView, setCameraView] = useState<CameraViewMode>("chase");
  const [raceStatus, setRaceStatus] = useState<RaceStatus>("GARAGE");
  const [hudExpanded, setHudExpanded] = useState(true);
  const [contextLost, setContextLost] = useState(false);
  const [missingAssetAlert, setMissingAssetAlert] = useState<string | null>(null);
  const [summary, setSummary] = useState<RaceSummary | null>(null);
  const [draftingActive, setDraftingActive] = useState(false);
  const [trackRecords, setTrackRecords] = useState<Record<string, TrackBestRecord>>(() =>
    loadTrackRecords(),
  );
  const [playlistVersion, setPlaylistVersion] = useState(0);

  // Co-op Racing Supabase Realtime State
  const [wsStatus, setWsStatus] = useState<NetworkConnectionState>("probing");
  const [wsDetail, setWsDetail] = useState<string | null>(null);
  const [wsError, setWsError] = useState<string | null>(null);
  const [wsLatency, setWsLatency] = useState<number | null>(null);
  const [driverName, setDriverName] = useState(
    () => sessionStorage.getItem("gnosis-racer-name") || "ApexPilot-01",
  );
  const [coopRoomTitle, setCoopRoomTitle] = useState("GNOSIS Squad GP");
  const [joinCodeInput, setJoinCodeInput] = useState("");
  const [publicRooms, setPublicRooms] = useState<PublicRacingRoomInfo[]>([]);
  const [coopRoomCode, setCoopRoomCode] = useState<string | null>(null);
  const [localRacerId, setLocalRacerId] = useState<string>("");
  const [coopSnapshot, setCoopSnapshot] = useState<RacingSnapshot | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);

  const quality = settings.graphicsQuality;
  const muted = settings.muted;
  const musicOn = settings.musicEnabled;

  const qualityRef = useRef<GraphicsQuality>(quality);
  const cameraViewRef = useRef<CameraViewMode>(cameraView);
  const statusRef = useRef<RaceStatus>(raceStatus);
  const fovRef = useRef<number>(settings.fov);
  const tuningRef = useRef(custom.tuning);
  const visualRef = useRef(visualOptions);

  const [audioEngine] = useState(() => new RacingAudioEngine());
  const [musicPlayer] = useState(() => new GameSoundtrackPlayer(settings.musicVolume, "racing"));
  const audioRef = useRef<RacingAudioEngine>(audioEngine);
  const musicRef = useRef<GameSoundtrackPlayer>(musicPlayer);
  const lobbyClientRef = useRef<WorkshopLobbyClient | null>(null);
  const roomTransportRef = useRef<WorkshopRoomTransport | null>(null);
  const hostEngineRef = useRef<RacingRoomHost | null>(null);
  const hostTickTimerRef = useRef<number | null>(null);
  const joinTimeoutRef = useRef<number | null>(null);
  const lastMetaSyncAtRef = useRef(0);
  const applyRacingMessageRef = useRef<(msg: Record<string, unknown>) => void>(() => {});
  const coopSnapshotRef = useRef<RacingSnapshot | null>(null);
  const coopRoomCodeRef = useRef<string | null>(null);
  const localRacerIdRef = useRef<string>("");
  const pendingGridSpawnRef = useRef<{ x: number; y: number; z: number; yaw: number } | null>(null);

  const actionsRef = useRef<{
    resetCar: () => void;
    restartRace: () => void;
    applyQuality: (q: GraphicsQuality) => void;
  } | null>(null);

  useEffect(() => {
    tuningRef.current = custom.tuning;
  }, [custom.tuning]);

  useEffect(() => {
    visualRef.current = visualOptions;
  }, [visualOptions]);

  useEffect(() => {
    fovRef.current = settings.fov;
  }, [settings.fov]);

  useEffect(() => {
    qualityRef.current = quality;
    actionsRef.current?.applyQuality(quality);
  }, [quality]);

  useEffect(() => {
    cameraViewRef.current = cameraView;
  }, [cameraView]);

  useEffect(() => {
    statusRef.current = raceStatus;
    if (raceStatus !== "RACING") {
      audioRef.current.silence();
    }
  }, [raceStatus]);

  useEffect(() => {
    audioRef.current.setMuted(muted);
    audioRef.current.setVolume(settings.sfxVolume);
    musicRef.current.setMuted(muted);
    musicRef.current.setVolume(settings.musicVolume);
    musicRef.current.setMusicEnabled(musicOn);
  }, [muted, musicOn, settings.sfxVolume, settings.musicVolume]);

  useEffect(() => {
    return subscribeSoundtrackMeta(() => setPlaylistVersion((v) => v + 1));
  }, []);

  const stopHostSimulation = useCallback(() => {
    if (hostTickTimerRef.current !== null) {
      window.clearInterval(hostTickTimerRef.current);
      hostTickTimerRef.current = null;
    }
    hostEngineRef.current = null;
  }, []);

  const clearJoinTimeout = useCallback(() => {
    if (joinTimeoutRef.current !== null) {
      window.clearTimeout(joinTimeoutRef.current);
      joinTimeoutRef.current = null;
    }
  }, []);

  applyRacingMessageRef.current = (msg: Record<string, unknown>) => {
    if (msg.type === "error") {
      clearJoinTimeout();
      setWsError(String(msg.message || "Co-op Racing room error"));
      return;
    }
    if (msg.type === "racing:joined") {
      clearJoinTimeout();
      const snap = msg.snapshot as RacingSnapshot;
      const pid = String(msg.playerId);
      const spawn = msg.spawn as { x: number; y: number; z: number; yaw: number };
      const joinedTrack: RacingTrackId = snap.trackId || "alpine-grand";
      localRacerIdRef.current = pid;
      coopRoomCodeRef.current = snap.code;
      coopSnapshotRef.current = snap;
      pendingGridSpawnRef.current = spawn;
      setActiveTrackId(joinedTrack);
      setLocalRacerId(pid);
      setCoopRoomCode(snap.code);
      setCoopSnapshot(snap);
      setSummary(null);
      setRaceSessionKey((k) => k + 1);
      setRaceStatus("RACING");
      return;
    }
    if (msg.type === "racing:snapshot") {
      const snap = msg as unknown as RacingSnapshot;
      coopSnapshotRef.current = snap;
      setCoopSnapshot(snap);
      if (snap.status === "FINISHED" && statusRef.current === "RACING") {
        setRaceStatus("FINISHED");
      }
      return;
    }
    if (msg.type === "racing:restarted") {
      const spawn = msg.spawn as { x: number; y: number; z: number; yaw: number };
      pendingGridSpawnRef.current = spawn;
      setSummary(null);
      setRaceSessionKey((k) => k + 1);
      setRaceStatus("RACING");
    }
  };

  const dispatchHostEvents = useCallback((events: RacingOutgoingEvent[]) => {
    const transport = roomTransportRef.current;
    if (!transport) return;
    const localId = transport.localPlayerId;
    for (const ev of events) {
      if (ev.targetId) {
        if (ev.targetId === localId) {
          applyRacingMessageRef.current(ev.payload);
        } else {
          transport.send(ev.payload, ev.targetId);
        }
      } else {
        applyRacingMessageRef.current(ev.payload);
        transport.send(ev.payload);
      }
    }
  }, []);

  const startHostSimulation = useCallback(() => {
    if (hostTickTimerRef.current !== null) {
      window.clearInterval(hostTickTimerRef.current);
    }
    let lastTick = performance.now();
    hostTickTimerRef.current = window.setInterval(() => {
      const host = hostEngineRef.current;
      const transport = roomTransportRef.current;
      if (!host || !transport || !transport.getIsHost()) return;

      const now = performance.now();
      const dt = Math.min(0.15, Math.max(0.016, (now - lastTick) / 1000));
      lastTick = now;

      host.tick(dt);
      const snap = host.serializeSnapshot();
      applyRacingMessageRef.current(snap as unknown as Record<string, unknown>);
      transport.send(snap as unknown as Record<string, unknown>);

      if (now - lastMetaSyncAtRef.current >= 2500) {
        lastMetaSyncAtRef.current = now;
        void transport.updateRoomMeta({
          title: host.title,
          status: host.status,
          elapsedTime: Math.round(host.elapsedTime),
          players: host.players.size,
          maxPlayers: 4,
        });
      }
    }, 70);
  }, []);

  const sendAction = useCallback(
    (payload: Record<string, unknown>) => {
      const transport = roomTransportRef.current;
      if (!transport) return;
      if (transport.getIsHost() && hostEngineRef.current) {
        const host = hostEngineRef.current;
        const pid = transport.localPlayerId;
        if (payload.type === "racer:state") {
          host.handleRacerState(pid, payload);
        } else if (payload.type === "restart_race") {
          dispatchHostEvents(host.resetRace());
        }
        return;
      }
      transport.send(payload);
    },
    [dispatchHostEvents],
  );

  const connectRacingLobby = useCallback(() => {
    setWsError(null);
    lobbyClientRef.current?.connect();
  }, []);

  useEffect(() => {
    const lobby = createWorkshopLobbyClient({
      channel: "racing",
      onStateChange: (state, detail) => {
        setWsStatus(state);
        setWsDetail(detail ?? null);
        if (state === "connected") setWsError(null);
        else if (state === "offline" && detail) setWsError(detail);
      },
      onRoomsChange: (rooms: WorkshopRoomSummary[]) => {
        setPublicRooms(
          rooms.map((r) => ({
            code: r.code,
            title: r.title,
            players: r.players,
            maxPlayers: r.maxPlayers,
            status: r.status === "FINISHED" ? "FINISHED" : "ACTIVE",
            elapsedTime: r.elapsedTime ?? 0,
          })),
        );
      },
      onLatency: (rtt) => setWsLatency(rtt),
    });

    lobbyClientRef.current = lobby;
    lobby.connect();

    return () => {
      clearJoinTimeout();
      stopHostSimulation();
      void roomTransportRef.current?.leave();
      roomTransportRef.current = null;
      void lobby.disconnect();
      lobbyClientRef.current = null;
    };
  }, [clearJoinTimeout, stopHostSimulation]);

  const startSoloRace = useCallback(() => {
    audioRef.current.initOnGesture();
    musicRef.current.startOnGesture();
    clearJoinTimeout();
    stopHostSimulation();
    if (roomTransportRef.current) {
      void roomTransportRef.current.leave();
      roomTransportRef.current = null;
    }
    coopRoomCodeRef.current = null;
    coopSnapshotRef.current = null;
    localRacerIdRef.current = "";
    pendingGridSpawnRef.current = null;
    setActiveTrackId(custom.trackId);
    setCoopRoomCode(null);
    setCoopSnapshot(null);
    setLocalRacerId("");
    setMissingAssetAlert(null);
    setSummary(null);
    setRaceSessionKey((k) => k + 1);
    setRaceStatus("RACING");
  }, [clearJoinTimeout, custom.trackId, stopHostSimulation]);

  const openCoopRaceSession = useCallback(
    async (action: "create" | "join", code?: string) => {
      audioRef.current.initOnGesture();
      musicRef.current.startOnGesture();
      const cleanName = driverName.trim() || "ApexPilot-01";
      sessionStorage.setItem("gnosis-racer-name", cleanName);
      setWsError(null);
      clearJoinTimeout();
      stopHostSimulation();
      await roomTransportRef.current?.leave();
      roomTransportRef.current = null;

      const { session, error } = await openWorkshopRoom({
        channel: "racing",
        mode: action,
        code,
        playerName: cleanName,
        maxPlayers: 4,
        initialMeta: {
          title: coopRoomTitle.trim() || "GNOSIS Squad GP",
          status: "ACTIVE",
          elapsedTime: 0,
        },
        joinHelloPayload: { vehicleId: selectedVehicle.id },
        onStatusChange: (st, detail) => {
          if (st === "offline" && detail) setWsError(detail);
        },
        onLatency: (rtt) => setWsLatency(rtt),
        onPeersChange: (peers, _hostId, isHostNow) => {
          if (isHostNow && !hostEngineRef.current && coopSnapshotRef.current) {
            hostEngineRef.current = RacingRoomHost.fromSnapshot(
              coopSnapshotRef.current as unknown as HostRacingSnapshot,
            );
            startHostSimulation();
          }
          const host = hostEngineRef.current;
          if (host && isHostNow && peers.some((p) => p.playerId === roomTransportRef.current?.localPlayerId)) {
            const presentIds = new Set(peers.map((p) => p.playerId));
            const evs: RacingOutgoingEvent[] = [];
            for (const p of Array.from(host.players.values())) {
              if (!presentIds.has(p.id)) evs.push(...host.removeRacer(p.id));
            }
            if (evs.length > 0) dispatchHostEvents(evs);
          }
        },
        onMessage: (msg) => {
          const transport = roomTransportRef.current;
          if (transport?.getIsHost() && hostEngineRef.current) {
            const host = hostEngineRef.current;
            const sid = msg.senderId;
            if (msg.type === "peer:hello") {
              const vid =
                typeof msg.vehicleId === "string" && msg.vehicleId
                  ? msg.vehicleId
                  : "meridian-gt";
              const added = host.addRacer(sid, String(msg.playerName || "Driver"), vid);
              if (!added.ok) {
                transport.send({ type: "error", message: added.error || "Race room full." }, sid);
                return;
              }
              dispatchHostEvents(added.events);
              const snap = host.serializeSnapshot();
              applyRacingMessageRef.current(snap as unknown as Record<string, unknown>);
              transport.send(snap as unknown as Record<string, unknown>);
              return;
            }
            if (msg.type === "peer:left") {
              dispatchHostEvents(host.removeRacer(sid));
              return;
            }
            if (msg.type === "racer:state") {
              host.handleRacerState(sid, msg);
              return;
            }
            if (msg.type === "restart_race") {
              dispatchHostEvents(host.resetRace());
              return;
            }
          }
          applyRacingMessageRef.current(msg);
        },
      });

      if (error || !session) {
        setWsError(error || "Unable to open Supabase racing room.");
        return;
      }

      roomTransportRef.current = session;

      if (action === "create") {
        const host = new RacingRoomHost(session.code, coopRoomTitle, custom.trackId);
        hostEngineRef.current = host;
        const added = host.addRacer(session.localPlayerId, cleanName, selectedVehicle.id);
        dispatchHostEvents(added.events);
        startHostSimulation();
      } else {
        joinTimeoutRef.current = window.setTimeout(() => {
          if (!coopRoomCodeRef.current && roomTransportRef.current === session) {
            setWsError(
              `Race room "${session.code}" host did not respond (room may have closed).`,
            );
            const ghost = session.getPeers().length <= 1;
            void session.leave(ghost);
            roomTransportRef.current = null;
            void lobbyClientRef.current?.refreshRooms();
          }
        }, 4500);
      }
    },
    [
      clearJoinTimeout,
      coopRoomTitle,
      custom.trackId,
      dispatchHostEvents,
      driverName,
      selectedVehicle.id,
      startHostSimulation,
      stopHostSimulation,
    ],
  );

  const createCoopRaceRoom = useCallback(() => {
    void openCoopRaceSession("create");
  }, [openCoopRaceSession]);

  const joinCoopRaceRoom = useCallback(
    (code: string) => {
      const clean = code.trim().toUpperCase();
      if (!clean) {
        setWsError("Enter a race room code to join.");
        return;
      }
      void openCoopRaceSession("join", clean);
    },
    [openCoopRaceSession],
  );

  const returnToGarage = useCallback(() => {
    audioRef.current.silence();
    clearJoinTimeout();
    stopHostSimulation();
    if (roomTransportRef.current) {
      void roomTransportRef.current.leave();
      roomTransportRef.current = null;
    }
    coopRoomCodeRef.current = null;
    coopSnapshotRef.current = null;
    localRacerIdRef.current = "";
    pendingGridSpawnRef.current = null;
    setCoopRoomCode(null);
    setCoopSnapshot(null);
    setLocalRacerId("");
    setSummary(null);
    setDraftingActive(false);
    setRaceStatus("GARAGE");
    void lobbyClientRef.current?.refreshRooms();
  }, [clearJoinTimeout, stopHostSimulation]);

  // Mount Three.js circuit only when active in race
  useEffect(() => {
    if (raceStatus === "GARAGE") return;
    const container = mountRef.current;
    if (!container) return;

    const vehicle = selectedVehicle;
    const trackDef = getTrackDef(activeTrackId);
    const isSoftwareGl = detectSoftwareWebGL();
    const width = container.clientWidth || 1024;
    const height = container.clientHeight || 620;

    const scene = new THREE.Scene();
    const horizonColor = new THREE.Color(trackDef.fogHex);
    scene.background = horizonColor;
    scene.fog = new THREE.FogExp2(trackDef.fogHex, trackDef.fogDensity);

    const camera = new THREE.PerspectiveCamera(62, width / height, 0.25, 1150);

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: "high-performance",
    });
    renderer.setSize(width, height);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = activeTrackId === "neon-metropolis" ? 1.18 : 1.08;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.domElement.style.display = "block";
    renderer.domElement.style.width = "100%";
    renderer.domElement.style.height = "100%";
    renderer.domElement.tabIndex = 0;
    renderer.domElement.style.outline = "none";
    container.appendChild(renderer.domElement);
    (document.activeElement as HTMLElement | null)?.blur?.();
    renderer.domElement.focus({ preventScroll: true });

    const applyQuality = (q: GraphicsQuality) => {
      if (isSoftwareGl) {
        renderer.setPixelRatio(1);
        renderer.shadowMap.enabled = false;
        scene.fog = new THREE.FogExp2(trackDef.fogHex, trackDef.fogDensity * 1.25);
        return;
      }
      if (q === "low") {
        renderer.setPixelRatio(1);
        renderer.shadowMap.enabled = false;
        scene.fog = new THREE.FogExp2(trackDef.fogHex, trackDef.fogDensity * 1.35);
      } else if (q === "medium") {
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.35));
        renderer.shadowMap.enabled = true;
        scene.fog = new THREE.FogExp2(trackDef.fogHex, trackDef.fogDensity * 1.1);
      } else {
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        renderer.shadowMap.enabled = true;
        scene.fog = new THREE.FogExp2(trackDef.fogHex, trackDef.fogDensity);
      }
    };
    applyQuality(qualityRef.current);

    const pmrem = new THREE.PMREMGenerator(renderer);
    const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;
    pmrem.dispose();

    const hemiLight = new THREE.HemisphereLight(trackDef.hemiSkyHex, trackDef.hemiGroundHex, 0.78);
    scene.add(hemiLight);

    const sunLight = new THREE.DirectionalLight(trackDef.sunHex, trackDef.sunIntensity);
    sunLight.castShadow = !isSoftwareGl;
    sunLight.shadow.mapSize.set(1024, 1024);
    sunLight.shadow.camera.near = 5;
    sunLight.shadow.camera.far = 220;
    const dShadow = 54;
    sunLight.shadow.camera.left = -dShadow;
    sunLight.shadow.camera.right = dShadow;
    sunLight.shadow.camera.top = dShadow;
    sunLight.shadow.camera.bottom = -dShadow;
    sunLight.shadow.bias = -0.0006;
    sunLight.shadow.normalBias = 0.025;
    scene.add(sunLight);
    scene.add(sunLight.target);

    const rimLight = new THREE.DirectionalLight(0x9bb8d9, 0.45);
    rimLight.position.set(-90, 45, -110);
    scene.add(rimLight);

    const skyCanvas = document.createElement("canvas");
    skyCanvas.width = 4;
    skyCanvas.height = 256;
    const sCtx = skyCanvas.getContext("2d")!;
    const skyGrad = sCtx.createLinearGradient(0, 0, 0, 256);
    skyGrad.addColorStop(0, trackDef.skyTopHex);
    skyGrad.addColorStop(0.45, trackDef.skyMidHex);
    skyGrad.addColorStop(1, trackDef.skyBottomHex);
    sCtx.fillStyle = skyGrad;
    sCtx.fillRect(0, 0, 4, 256);
    const skyTex = new THREE.CanvasTexture(skyCanvas);
    skyTex.colorSpace = THREE.SRGBColorSpace;
    const skyGeo = new THREE.SphereGeometry(860, 24, 16);
    const skyMat = new THREE.MeshBasicMaterial({ map: skyTex, side: THREE.BackSide, fog: false });
    const skyDome = new THREE.Mesh(skyGeo, skyMat);
    scene.add(skyDome);

    const world = buildTrackWorld(
      scene,
      renderer.capabilities.getMaxAnisotropy(),
      activeTrackId,
    );

    const startSample = world.samples[0];
    const startYaw = Math.atan2(startSample.tangent.x, startSample.tangent.z);
    const initGrid = pendingGridSpawnRef.current || {
      x: startSample.pos.x - startSample.right.x * 3.8,
      y: startSample.pos.y,
      z: startSample.pos.z - startSample.right.z * 3.8,
      yaw: startYaw,
    };
    pendingGridSpawnRef.current = null;

    setMissingAssetAlert(null);
    const playerBundle = createLoadedCarWithPhysics(vehicle, {
      customVisual: visualRef.current,
      spawn: initGrid,
      onMissingAsset: (_url, reason) => {
        setMissingAssetAlert(reason);
      },
    });
    const playerRig = playerBundle.rig;
    const carPhysics = playerBundle.physics;
    const rivalSpec1 = WORKSHOP_VEHICLES.find((v) => v.id === "apex-v12") || WORKSHOP_VEHICLES[1];
    const rivalSpec2 = WORKSHOP_VEHICLES.find((v) => v.id === "alpine-rally") || WORKSHOP_VEHICLES[4];
    const rivalRig1 = buildVehicleRig(rivalSpec1);
    const rivalRig2 = buildVehicleRig(rivalSpec2);
    scene.add(playerRig.group, rivalRig1.group, rivalRig2.group);

    const teammateMeshes = new Map<
      string,
      { rig: CarRig; nameplate: THREE.Sprite; vehicleId: string; color: string; x: number; y: number; z: number }
    >();

    const smokeCount = 42;
    const smokeGeo = new THREE.SphereGeometry(0.32, 8, 8);
    const smokeMat = new THREE.MeshBasicMaterial({
      color: 0xd8d2c7,
      transparent: true,
      opacity: 0.45,
      depthWrite: false,
    });
    const smokeMeshes: { mesh: THREE.Mesh; life: number; vx: number; vy: number; vz: number }[] = [];
    for (let i = 0; i < smokeCount; i++) {
      const m = new THREE.Mesh(smokeGeo, smokeMat);
      m.visible = false;
      scene.add(m);
      smokeMeshes.push({ mesh: m, life: 0, vx: 0, vy: 0, vz: 0 });
    }
    let smokeCursor = 0;
    let smokeAccum = 0;

    const phys = {
      x: initGrid.x,
      y: initGrid.y,
      z: initGrid.z,
      vx: 0,
      vz: 0,
      yaw: initGrid.yaw,
      yawRate: 0,
      steer: 0,
      wheelSpin: 0,
      pitch: 0,
      roll: 0,
      trackIdx: 0,
      gear: "N",
      rpmRatio: 0.12,
      lap: 1,
      sectorMask: 0,
      lapTime: 0,
      totalTime: 0,
      bestLap: null as number | null,
      topSpeedKmh: 0,
      cameraShake: 0,
      surface: "ASPHALT" as "ASPHALT" | "SHOULDER" | "DRIFT" | "OFF-TRACK",
      finishedLocal: false,
      finishTimeLocal: null as number | null,
      drafting: false,
    };

    const rivals = [
      { s: 20, speed: 24, baseSpeed: 40, laneOffset: 5.2, x: 0, y: 0, z: 0, yaw: startYaw, wheelSpin: 0, rig: rivalRig1, wr: rivalSpec1.wheelRadius },
      { s: 44, speed: 22, baseSpeed: 36, laneOffset: -5.2, x: 0, y: 0, z: 0, yaw: startYaw, wheelSpin: 0, rig: rivalRig2, wr: rivalSpec2.wheelRadius },
    ];

    const resetCarToNearestTrack = () => {
      const closest = findClosestTrackPoint(world.samples, phys.x, phys.z, phys.trackIdx);
      const ryaw = Math.atan2(closest.sample.tangent.x, closest.sample.tangent.z);
      carPhysics.reset(closest.sample.pos.x, closest.elevation, closest.sample.pos.z, ryaw);
      phys.x = closest.sample.pos.x;
      phys.z = closest.sample.pos.z;
      phys.y = closest.elevation;
      phys.vx = 0;
      phys.vz = 0;
      phys.yaw = ryaw;
      phys.yawRate = 0;
      phys.steer = 0;
      phys.pitch = 0;
      phys.roll = 0;
      phys.cameraShake = 0;
    };

    const restartFullRace = () => {
      if (coopRoomCodeRef.current) {
        sendAction({ type: "restart_race" });
        return;
      }
      const rx = startSample.pos.x - startSample.right.x * 3.8;
      const rz = startSample.pos.z - startSample.right.z * 3.8;
      carPhysics.reset(rx, startSample.pos.y, rz, startYaw);
      phys.x = rx;
      phys.z = rz;
      phys.y = startSample.pos.y;
      phys.vx = 0;
      phys.vz = 0;
      phys.yaw = startYaw;
      phys.yawRate = 0;
      phys.steer = 0;
      phys.wheelSpin = 0;
      phys.pitch = 0;
      phys.roll = 0;
      phys.trackIdx = 0;
      phys.lap = 1;
      phys.sectorMask = 0;
      phys.lapTime = 0;
      phys.totalTime = 0;
      phys.bestLap = null;
      phys.topSpeedKmh = 0;
      phys.cameraShake = 0;
      phys.finishedLocal = false;
      phys.finishTimeLocal = null;

      rivals[0].s = 20;
      rivals[1].s = 44;
      setSummary(null);
      setRaceStatus("RACING");
    };

    actionsRef.current = {
      resetCar: resetCarToNearestTrack,
      restartRace: restartFullRace,
      applyQuality,
    };

    camera.position.set(
      phys.x - Math.sin(phys.yaw) * 9.5,
      phys.y + 3.8,
      phys.z - Math.cos(phys.yaw) * 9.5,
    );
    camera.lookAt(phys.x, phys.y + 1.0, phys.z);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    const keys: Record<string, boolean> = {};
    const clearKeys = () => {
      for (const prop of Object.keys(keys)) delete keys[prop];
    };
    const isInputFocused = (target: EventTarget | null) =>
      target instanceof HTMLInputElement ||
      target instanceof HTMLTextAreaElement ||
      target instanceof HTMLSelectElement;

    const onKeyDown = (e: KeyboardEvent) => {
      if (isInputFocused(e.target)) return;
      if (
        ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Space"].includes(e.code) ||
        ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", " "].includes(e.key)
      ) {
        e.preventDefault();
      }
      audioRef.current.initOnGesture();
      musicRef.current.startOnGesture();

      const k = e.key.toLowerCase();
      keys[k] = true;
      if (e.code) keys[e.code] = true;

      if (!e.repeat) {
        if (k === "r" || e.code === "KeyR") {
          resetCarToNearestTrack();
        } else if (k === "p" || e.code === "KeyP" || e.key === "Escape" || e.code === "Escape") {
          setRaceStatus((prev) =>
            prev === "FINISHED" || prev === "GARAGE" ? prev : prev === "PAUSED" ? "RACING" : "PAUSED",
          );
        } else if (k === "c" || e.code === "KeyC") {
          setCameraView((v) => (v === "chase" ? "close" : v === "close" ? "hood" : "chase"));
        } else if (k === "h" || e.code === "KeyH") {
          setHudExpanded((v) => !v);
        }
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      keys[e.key.toLowerCase()] = false;
      if (e.code) keys[e.code] = false;
    };
    const onCanvasMouseDown = () => {
      audioRef.current.initOnGesture();
      musicRef.current.startOnGesture();
      (document.activeElement as HTMLElement | null)?.blur?.();
      renderer.domElement.focus({ preventScroll: true });
    };
    window.addEventListener("keydown", onKeyDown, { capture: true, passive: false });
    window.addEventListener("keyup", onKeyUp, { capture: true });
    window.addEventListener("blur", clearKeys);
    renderer.domElement.addEventListener("mousedown", onCanvasMouseDown);

    const onResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      if (w <= 0 || h <= 0) return;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    const resizeObserver = new ResizeObserver(onResize);
    resizeObserver.observe(container);
    window.addEventListener("resize", onResize);

    const onContextLost = (e: Event) => {
      e.preventDefault();
      setContextLost(true);
    };
    const onContextRestored = () => {
      setContextLost(false);
    };
    renderer.domElement.addEventListener("webglcontextlost", onContextLost);
    renderer.domElement.addEventListener("webglcontextrestored", onContextRestored);

    let minX = Infinity,
      maxX = -Infinity,
      minZ = Infinity,
      maxZ = -Infinity;
    for (const s of world.samples) {
      if (s.pos.x < minX) minX = s.pos.x;
      if (s.pos.x > maxX) maxX = s.pos.x;
      if (s.pos.z < minZ) minZ = s.pos.z;
      if (s.pos.z > maxZ) maxZ = s.pos.z;
    }
    const mapPad = 32;
    const mapSpan = Math.max(maxX - minX, maxZ - minZ) + mapPad * 2;

    const drawMinimap = () => {
      const mc = minimapRef.current;
      if (!mc) return;
      const mctx = mc.getContext("2d");
      if (!mctx) return;
      const W = mc.width;
      const H = mc.height;
      mctx.clearRect(0, 0, W, H);

      const toMapX = (wx: number) => ((wx - minX + mapPad) / mapSpan) * W;
      const toMapY = (wz: number) => ((wz - minZ + mapPad) / mapSpan) * H;

      mctx.strokeStyle = "rgba(218, 198, 160, 0.45)";
      mctx.lineWidth = 4;
      mctx.beginPath();
      for (let i = 0; i < world.samples.length; i += 3) {
        const pt = world.samples[i].pos;
        const mx = toMapX(pt.x);
        const my = toMapY(pt.z);
        if (i === 0) mctx.moveTo(mx, my);
        else mctx.lineTo(mx, my);
      }
      mctx.closePath();
      mctx.stroke();

      mctx.fillStyle = "#f4ebdd";
      mctx.fillRect(toMapX(startSample.pos.x) - 3, toMapY(startSample.pos.z) - 3, 6, 6);

      mctx.fillStyle = "#67a4df";
      for (const rv of rivals) {
        mctx.beginPath();
        mctx.arc(toMapX(rv.x), toMapY(rv.z), 3.1, 0, Math.PI * 2);
        mctx.fill();
      }

      for (const tm of teammateMeshes.values()) {
        mctx.fillStyle = tm.color;
        mctx.beginPath();
        mctx.arc(toMapX(tm.x), toMapY(tm.z), 4.1, 0, Math.PI * 2);
        mctx.fill();
      }

      mctx.fillStyle = "#f5a623";
      mctx.beginPath();
      mctx.arc(toMapX(phys.x), toMapY(phys.z), 4.9, 0, Math.PI * 2);
      mctx.fill();
      mctx.strokeStyle = "#17110c";
      mctx.lineWidth = 1.5;
      mctx.stroke();
    };

    const TOTAL_LAPS = 3;
    const pitchAudioBias = vehicle.massKg < 960 ? 1.16 : vehicle.massKg > 1550 ? 0.82 : 1.0;

    let lastDraftState = false;

    const stepPhysics = (dt: number) => {
      const tune = tuningRef.current;
      const accelInput =
        !phys.finishedLocal && (keys["w"] || keys["KeyW"] || keys["arrowup"] || keys["ArrowUp"]) ? 1 : 0;
      const brakeInput =
        !phys.finishedLocal && (keys["s"] || keys["KeyS"] || keys["arrowdown"] || keys["ArrowDown"]) ? 1 : 0;
      const leftInput =
        !phys.finishedLocal && (keys["a"] || keys["KeyA"] || keys["arrowleft"] || keys["ArrowLeft"]) ? 1 : 0;
      const rightInput =
        !phys.finishedLocal && (keys["d"] || keys["KeyD"] || keys["arrowright"] || keys["ArrowRight"]) ? 1 : 0;
      const handbrake = !phys.finishedLocal && Boolean(keys[" "] || keys["Space"]);
      const steerInput = leftInput - rightInput;

      const fx = Math.sin(phys.yaw);
      const fz = Math.cos(phys.yaw);

      let draftingNow = false;
      if (carPhysics.getSnapshot().vLong > 9 && teammateMeshes.size > 0) {
        for (const tm of teammateMeshes.values()) {
          const toMateX = tm.x - phys.x;
          const toMateZ = tm.z - phys.z;
          const d = Math.hypot(toMateX, toMateZ);
          if (d >= 3.5 && d <= 24) {
            const dot = (toMateX / d) * fx + (toMateZ / d) * fz;
            if (dot > 0.72) {
              draftingNow = true;
              break;
            }
          }
        }
      }
      phys.drafting = draftingNow;
      if (draftingNow !== lastDraftState) {
        lastDraftState = draftingNow;
        setDraftingActive(draftingNow);
      }

      const closest = findClosestTrackPoint(world.samples, phys.x, phys.z, phys.trackIdx);
      phys.trackIdx = closest.index;

      const cSnap = carPhysics.step(
        dt,
        { throttle: accelInput, brake: brakeInput, steer: steerInput, handbrake },
        {
          closestTrack: closest,
          roadHalfWidth: world.roadHalfWidth,
          barrierHalfWidth: world.barrierHalfWidth,
          tuning: tune,
          drafting: draftingNow,
        },
      );

      phys.x = cSnap.x;
      phys.y = cSnap.y;
      phys.z = cSnap.z;
      phys.vx = cSnap.vx;
      phys.vz = cSnap.vz;
      phys.yaw = cSnap.yaw;
      phys.yawRate = cSnap.yawRate;
      phys.steer = cSnap.steer;
      phys.wheelSpin = cSnap.wheelSpin;
      phys.pitch = cSnap.pitch;
      phys.roll = cSnap.roll;
      phys.surface = cSnap.surface;

      const nextClosest = findClosestTrackPoint(world.samples, phys.x, phys.z, phys.trackIdx);
      phys.trackIdx = nextClosest.index;

      const barrierImpactSpeed = carPhysics.resolveBarrierCollision(nextClosest, world.barrierHalfWidth);
      if (barrierImpactSpeed > 0) {
        phys.x = carPhysics.chassisBody.position.x;
        phys.z = carPhysics.chassisBody.position.z;
        phys.vx = carPhysics.chassisBody.velocity.x;
        phys.vz = carPhysics.chassisBody.velocity.z;
        if (barrierImpactSpeed > 3.5) {
          phys.cameraShake = Math.min(0.45, barrierImpactSpeed * 0.024);
          audioRef.current.playBump(barrierImpactSpeed / 18);
        }
      }

      for (const py of world.pylons) {
        if (py.hitCooldown > 0) py.hitCooldown -= dt;
        const dx = phys.x - py.x;
        const dz = phys.z - py.z;
        const dist = Math.hypot(dx, dz);
        if (dist < 1.35 + py.radius && dist > 0.001 && py.hitCooldown <= 0) {
          py.hitCooldown = 0.8;
          const nx = dx / dist;
          const nz = dz / dist;
          carPhysics.applyBodyImpulseCorrection(0, 0, nx * 2.0, nz * 2.0, 0.92);
          phys.vx = carPhysics.chassisBody.velocity.x;
          phys.vz = carPhysics.chassisBody.velocity.z;
          py.mesh.rotation.x = 0.65;
          py.mesh.rotation.z = -0.4;
          audioRef.current.playBump(0.42);
        } else if (py.hitCooldown <= 0) {
          py.mesh.rotation.x = THREE.MathUtils.damp(py.mesh.rotation.x, 0, 5, dt);
          py.mesh.rotation.z = THREE.MathUtils.damp(py.mesh.rotation.z, 0, 5, dt);
        }
      }

      const netSnap = coopSnapshotRef.current;
      for (let ri = 0; ri < rivals.length; ri++) {
        const rv = rivals[ri];
        const netRv = netSnap?.rivals?.[ri];
        if (coopRoomCodeRef.current && netRv) {
          rv.s += (netRv.s - rv.s) * Math.min(1, 14 * dt);
          if (Math.abs(netRv.s - rv.s) > world.totalLength * 0.5) {
            rv.s = netRv.s;
          }
          rv.speed = netRv.speed;
          rv.wheelSpin += (rv.speed / rv.wr) * dt;
        } else {
          const rClosest = findClosestTrackPoint(world.samples, rv.x, rv.z);
          const targetRivalSpeed = rClosest.sample.curvature > 0.045 ? rv.baseSpeed * 0.64 : rv.baseSpeed;
          rv.speed = THREE.MathUtils.damp(rv.speed, targetRivalSpeed, 2.2, dt);
          rv.s = (rv.s + rv.speed * dt) % world.totalLength;
          rv.wheelSpin += (rv.speed / rv.wr) * dt;
        }
        const rNorm = (rv.s % world.totalLength) / world.totalLength;
        const rPos = world.curve.getPointAt(rNorm);
        const rTan = world.curve.getTangentAt(rNorm);
        const rRightX = -rTan.z;
        const rRightZ = rTan.x;
        rv.x = rPos.x + rRightX * rv.laneOffset;
        rv.y = rPos.y;
        rv.z = rPos.z + rRightZ * rv.laneOffset;
        rv.yaw = Math.atan2(rTan.x, rTan.z);

        const cdx = phys.x - rv.x;
        const cdz = phys.z - rv.z;
        const cDist = Math.hypot(cdx, cdz);
        const minCarDist = 2.75;
        if (cDist < minCarDist && cDist > 0.001) {
          const nx = cdx / cDist;
          const nz = cdz / cDist;
          const overlap = minCarDist - cDist;
          carPhysics.applyBodyImpulseCorrection(nx * overlap, nz * overlap, nx * 7.2, nz * 7.2, 1.0);
          phys.x = carPhysics.chassisBody.position.x;
          phys.z = carPhysics.chassisBody.position.z;
          phys.vx = carPhysics.chassisBody.velocity.x;
          phys.vz = carPhysics.chassisBody.velocity.z;
          phys.cameraShake = 0.28;
          audioRef.current.playBump(0.78);
        }
      }

      for (const tm of teammateMeshes.values()) {
        const tdx = phys.x - tm.x;
        const tdz = phys.z - tm.z;
        const tDist = Math.hypot(tdx, tdz);
        if (tDist < 2.65 && tDist > 0.001) {
          const nx = tdx / tDist;
          const nz = tdz / tDist;
          carPhysics.applyBodyImpulseCorrection(
            nx * (2.65 - tDist) * 0.65,
            nz * (2.65 - tDist) * 0.65,
            nx * 2.5,
            nz * 2.5,
            1.0,
          );
          phys.x = carPhysics.chassisBody.position.x;
          phys.z = carPhysics.chassisBody.position.z;
          phys.vx = carPhysics.chassisBody.velocity.x;
          phys.vz = carPhysics.chassisBody.velocity.z;
        }
      }

      for (const bm of playerRig.brakeMaterials) {
        bm.emissiveIntensity = cSnap.isBraking ? 3.2 : 0.65;
      }

      const vLong = cSnap.vLong;
      const vLat = cSnap.vLat;
      const speed = cSnap.speedMs;
      const absKmh = Math.abs(vLong) * 3.6;
      if (absKmh > phys.topSpeedKmh) phys.topSpeedKmh = absKmh;
      if (vLong < -0.5) {
        phys.gear = "R";
        phys.rpmRatio = THREE.MathUtils.clamp(0.2 + absKmh / 65, 0.18, 0.95);
      } else if (absKmh < 2 && accelInput === 0) {
        phys.gear = "N";
        phys.rpmRatio = 0.14;
      } else {
        const gearIdx =
          absKmh < 36 ? 1 : absKmh < 74 ? 2 : absKmh < 118 ? 3 : absKmh < 166 ? 4 : absKmh < 216 ? 5 : 6;
        phys.gear = String(gearIdx);
        const thresholds = [0, 36, 74, 118, 166, 216, 305];
        const low = thresholds[gearIdx - 1];
        const high = thresholds[gearIdx];
        phys.rpmRatio = THREE.MathUtils.clamp(0.25 + ((absKmh - low) / (high - low)) * 0.72, 0.2, 0.98);
      }

      const slipMag = Math.abs(vLat);
      const isDrifting = cSnap.isDrifting;
      const nfx = Math.sin(phys.yaw);
      const nfz = Math.cos(phys.yaw);
      const nrx = -nfz;
      const nrz = nfx;

      if (isDrifting || (!cSnap.onAsphalt && speed > 6)) {
        smokeAccum += dt;
        if (smokeAccum > 0.032) {
          smokeAccum = 0;
          const p = smokeMeshes[smokeCursor];
          smokeCursor = (smokeCursor + 1) % smokeCount;
          p.life = 0.68;
          p.mesh.visible = true;
          const sideOffset = smokeCursor % 2 === 0 ? -0.95 : 0.95;
          p.mesh.position.set(
            phys.x - nfx * 1.48 + nrx * sideOffset,
            phys.y + 0.22,
            phys.z - nfz * 1.48 + nrz * sideOffset,
          );
          p.mesh.scale.setScalar(0.72);
          p.vx = THREE.MathUtils.randFloat(-0.8, 0.8);
          p.vy = THREE.MathUtils.randFloat(0.75, 1.5);
          p.vz = THREE.MathUtils.randFloat(-0.8, 0.8);
        }
      }

      if (!phys.finishedLocal) {
        phys.lapTime += dt;
        phys.totalTime += dt;
        const sector = Math.floor((nextClosest.index / world.samples.length) * 8);
        phys.sectorMask |= 1 << sector;

        const passedMostTrack = (phys.sectorMask & 0b01111100) === 0b01111100;
        if (sector === 0 && passedMostTrack && vLong > 2) {
          const finishedLapTime = phys.lapTime;
          if (phys.bestLap === null || finishedLapTime < phys.bestLap) {
            phys.bestLap = finishedLapTime;
          }
          phys.lapTime = 0;
          phys.sectorMask = 1;
          if (phys.lap >= TOTAL_LAPS) {
            phys.finishedLocal = true;
            phys.finishTimeLocal = phys.totalTime;
            const topRounded = Math.round(phys.topSpeedKmh);
            setTrackRecords(
              saveTrackRecord(
                activeTrackId,
                phys.bestLap,
                phys.totalTime,
                topRounded,
                vehicle.name,
              ),
            );
            setSummary({
              totalTime: phys.totalTime,
              bestLap: phys.bestLap,
              topSpeedKmh: topRounded,
              vehicleName: vehicle.name,
              trackName: trackDef.name,
            });
            if (!coopRoomCodeRef.current) {
              setRaceStatus("FINISHED");
            }
          } else {
            phys.lap += 1;
          }
        }
      }

      const driftAudio = isDrifting ? THREE.MathUtils.clamp(slipMag / 10, 0.15, 1) : 0;
      audioRef.current.update(phys.rpmRatio, accelInput, driftAudio, false, pitchAudioBias);
    };

    const clock = new THREE.Clock();
    let frameId = 0;
    let disposed = false;
    let physAccum = 0;
    let lastNetSend = 0;
    const FIXED_DT = 1 / 120;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync ? gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0) : null;
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    const tick = () => {
      if (disposed) return;
      const dt = Math.min(clock.getDelta(), 0.05);
      const nowMs = performance.now();

      if (statusRef.current === "RACING") {
        physAccum += dt;
        while (physAccum >= FIXED_DT) {
          stepPhysics(FIXED_DT);
          physAccum -= FIXED_DT;
        }
      }

      const snap = coopSnapshotRef.current;
      const activeMates = new Set<string>();
      if (coopRoomCodeRef.current && snap) {
        const netBlend = 1 - Math.exp(-16 * dt);
        for (const p of snap.players) {
          if (p.id === localRacerIdRef.current) continue;
          activeMates.add(p.id);
          let entry = teammateMeshes.get(p.id);
          if (!entry || entry.vehicleId !== p.vehicleId) {
            if (entry) {
              scene.remove(entry.rig.group);
              disposeObjectResources(entry.rig.group);
            }
            const mateSpec = WORKSHOP_VEHICLES.find((v) => v.id === p.vehicleId) || WORKSHOP_VEHICLES[0];
            const rig = buildVehicleRig(mateSpec);
            const nameplate = createRacerNameplate(p.name, p.color);
            rig.group.add(nameplate);
            rig.group.position.set(p.x, p.y, p.z);
            rig.group.rotation.y = p.yaw;
            scene.add(rig.group);
            entry = { rig, nameplate, vehicleId: p.vehicleId, color: p.color, x: p.x, y: p.y, z: p.z };
            teammateMeshes.set(p.id, entry);
          }
          entry.rig.group.position.lerp(new THREE.Vector3(p.x, p.y, p.z), netBlend);
          entry.x = entry.rig.group.position.x;
          entry.y = entry.rig.group.position.y;
          entry.z = entry.rig.group.position.z;
          let dyaw = p.yaw - entry.rig.group.rotation.y;
          while (dyaw > Math.PI) dyaw -= Math.PI * 2;
          while (dyaw < -Math.PI) dyaw += Math.PI * 2;
          entry.rig.group.rotation.y += dyaw * netBlend;
          entry.rig.flSteer.rotation.y = p.steer;
          entry.rig.frSteer.rotation.y = p.steer;
          for (const wMesh of entry.rig.wheels) wMesh.rotation.x = p.wheelSpin;
        }
      }
      for (const [id, entry] of teammateMeshes.entries()) {
        if (!activeMates.has(id)) {
          scene.remove(entry.rig.group);
          disposeObjectResources(entry.rig.group);
          teammateMeshes.delete(id);
        }
      }

      if (coopRoomCodeRef.current && nowMs - lastNetSend >= 60) {
        lastNetSend = nowMs;
        const speedKmhNow = Math.round(Math.hypot(phys.vx, phys.vz) * 3.6);
        sendAction({
          type: "racer:state",
          vehicleId: vehicle.id,
          x: phys.x,
          y: phys.y,
          z: phys.z,
          yaw: phys.yaw,
          steer: phys.steer,
          wheelSpin: phys.wheelSpin,
          speedKmh: speedKmhNow,
          lap: phys.lap,
          progressNorm: phys.trackIdx / world.samples.length,
          bestLap: phys.bestLap,
          drafting: phys.drafting,
          finished: phys.finishedLocal,
          finishTime: phys.finishTimeLocal,
        });
      }

      for (const p of smokeMeshes) {
        if (p.life > 0) {
          p.life -= dt;
          if (p.life <= 0) {
            p.mesh.visible = false;
          } else {
            p.mesh.position.x += p.vx * dt;
            p.mesh.position.y += p.vy * dt;
            p.mesh.position.z += p.vz * dt;
            const s = 0.72 + (0.68 - p.life) * 2.2;
            p.mesh.scale.setScalar(s);
          }
        }
      }

      const closestNow = findClosestTrackPoint(world.samples, phys.x, phys.z, phys.trackIdx);
      carPhysics.syncToRig(playerRig, closestNow);

      for (const rv of rivals) {
        rv.rig.group.position.set(rv.x, rv.y, rv.z);
        rv.rig.group.rotation.y = rv.yaw;
        for (const w of rv.rig.wheels) w.rotation.x = rv.wheelSpin;
      }

      sunLight.position.set(phys.x + _sunOffset.x, phys.y + _sunOffset.y, phys.z + _sunOffset.z);
      sunLight.target.position.set(phys.x, phys.y, phys.z);
      sunLight.target.updateMatrixWorld();

      const fx = Math.sin(phys.yaw);
      const fz = Math.cos(phys.yaw);
      const viewMode = cameraViewRef.current;
      const speed = Math.hypot(phys.vx, phys.vz);

      if (viewMode === "hood") {
        _camDesiredPos.set(phys.x + fx * 0.45, phys.y + 1.52 + vehicle.rideHeight, phys.z + fz * 0.45);
        _camLookTarget.set(phys.x + fx * 24, phys.y + 1.35 + vehicle.rideHeight, phys.z + fz * 24);
        camera.position.lerp(_camDesiredPos, 1 - Math.exp(-30 * dt));
      } else {
        const backDist = viewMode === "close" ? 6.5 : 9.4;
        const heightOffset = viewMode === "close" ? 2.5 : 3.6;
        phys.cameraShake = THREE.MathUtils.damp(phys.cameraShake, 0, 9, dt);
        const shakeX = phys.cameraShake > 0.01 ? (Math.random() - 0.5) * phys.cameraShake : 0;
        const shakeY = phys.cameraShake > 0.01 ? (Math.random() - 0.5) * phys.cameraShake : 0;

        _camDesiredPos.set(
          phys.x - fx * backDist + shakeX,
          phys.y + heightOffset + shakeY,
          phys.z - fz * backDist,
        );
        _camLookTarget.set(phys.x + fx * 12, phys.y + 1.2, phys.z + fz * 12);
        camera.position.lerp(_camDesiredPos, 1 - Math.exp(-7.5 * dt));
      }
      camera.lookAt(_camLookTarget);

      const baseFov = THREE.MathUtils.clamp(fovRef.current - 12, 54, 78);
      const targetFov = THREE.MathUtils.clamp(baseFov + speed * 0.34 + (phys.drafting ? 4 : 0), baseFov, baseFov + 24);
      if (Math.abs(camera.fov - targetFov) > 0.05) {
        camera.fov = THREE.MathUtils.damp(camera.fov, targetFov, 5, dt);
        camera.updateProjectionMatrix();
      }

      const kmh = Math.round(speed * 3.6);
      if (speedTextRef.current) speedTextRef.current.textContent = String(kmh);
      if (gearTextRef.current) gearTextRef.current.textContent = phys.gear;
      if (rpmBarRef.current) rpmBarRef.current.style.width = `${Math.round(phys.rpmRatio * 100)}%`;
      if (lapTextRef.current) lapTextRef.current.textContent = `${phys.lap} / ${TOTAL_LAPS}`;
      if (lapTimeTextRef.current) lapTimeTextRef.current.textContent = formatRaceTime(phys.lapTime);
      if (bestLapTextRef.current) {
        bestLapTextRef.current.textContent =
          phys.bestLap !== null ? formatRaceTime(phys.bestLap) : "--:--.--";
      }
      if (surfaceTextRef.current) surfaceTextRef.current.textContent = phys.surface;

      drawMinimap();
      renderer.render(scene, camera);

      if (isSoftwareGl) afterDraw(tick);
      else frameId = requestAnimationFrame(tick);
    };

    if (isSoftwareGl) afterDraw(tick);
    else frameId = requestAnimationFrame(tick);

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      window.clearTimeout(frameId);
      window.removeEventListener("keydown", onKeyDown, { capture: true });
      window.removeEventListener("keyup", onKeyUp, { capture: true });
      window.removeEventListener("blur", clearKeys);
      renderer.domElement.removeEventListener("mousedown", onCanvasMouseDown);
      window.removeEventListener("resize", onResize);
      resizeObserver.disconnect();
      renderer.domElement.removeEventListener("webglcontextlost", onContextLost);
      renderer.domElement.removeEventListener("webglcontextrestored", onContextRestored);

      playerBundle.dispose();
      disposeObjectResources(playerRig.group);
      disposeObjectResources(rivalRig1.group);
      disposeObjectResources(rivalRig2.group);
      for (const entry of teammateMeshes.values()) disposeObjectResources(entry.rig.group);
      teammateMeshes.clear();

      audioRef.current.silence();
      world.dispose();
      skyGeo.dispose();
      skyMat.dispose();
      skyTex.dispose();
      smokeGeo.dispose();
      smokeMat.dispose();
      envTex.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
      actionsRef.current = null;
    };
  }, [raceStatus === "GARAGE", raceSessionKey, selectedVehicle, activeTrackId, sendAction]);

  useEffect(() => {
    const engine = audioRef.current;
    const music = musicRef.current;
    music.attach();
    return () => {
      engine.dispose();
      music.dispose();
    };
  }, []);

  const cycleQuality = useCallback(() => {
    const next = quality === "high" ? "medium" : quality === "medium" ? "low" : "high";
    updateWorkshopSettings({ graphicsQuality: next });
  }, [quality]);

  const cycleCamera = useCallback(() => {
    setCameraView((v) => (v === "chase" ? "close" : v === "close" ? "hood" : "chase"));
  }, []);

  const playlistItems = useMemo(() => getSharedPlaylist(), [playlistVersion]);
  const currentTrackUrl = musicPlayer.getCurrentTrack().url || GAME_SOUNDTRACK_PLAYLIST[0].url;

  if (raceStatus === "GARAGE") {
    return (
      <div className="gw-garage-root">
        {/* Motorsport Hero Deck */}
        <div className="gw-hero-deck theme-racing">
          <img className="gw-hero-deck-bg" src={cardRacingImg} alt="" />
          <div className="gw-hero-deck-scrim" />
          <div className="gw-hero-deck-content">
            <span className="gw-hero-deck-kicker">GNOSIS Motorsport Division · 120Hz Physics</span>
            <h3>GNOSIS Grand Circuit</h3>
            <p>
              Inspect all {WORKSHOP_VEHICLES.length} predefined 3D GLB vehicles in interactive OrbitControls, race across {TRACK_CATALOG.length}{" "}
              architectural circuits with grandstands, bridges &amp; chicanes, or join 4-driver co-op slipstream rooms.
            </p>
          </div>
          <div className="gw-hero-deck-actions">
            <button
              type="button"
              className={`gw-btn ${musicOn && !muted ? "gw-btn-primary" : ""}`}
              onClick={() => {
                musicRef.current.startOnGesture();
                updateWorkshopSettings({ musicEnabled: !musicOn });
              }}
            >
              {musicOn && !muted ? "♪ Music On" : "♪ Music Off"}
            </button>
            <span className="gw-chip-pill">
              {selectedVehicle.name} · {selectedTrackDef.name}
            </span>
            <button type="button" className="brass-button" onClick={startSoloRace}>
              Start Race →
            </button>
          </div>
        </div>

        {/* Top Sim-Racer Tab Bar */}
        <div className="gw-menu-topbar">
          <div className="gw-menu-brand">
            <small>ACTIVE CHASSIS &amp; TRACK</small>
            <strong>{selectedVehicle.name}</strong>
          </div>

          <div className="gw-menu-tabs" role="tablist" aria-label="Racing Menu Sections">
            {(
              [
                ["play", "Race & Tracks"],
                ["garage", "3D GLB Showroom"],
                ["tuning", "Tuning Lab"],
                ["settings", "Audio & Settings"],
              ] as [GarageMenuTab, string][]
            ).map(([tabId, label]) => (
              <button
                key={tabId}
                type="button"
                role="tab"
                aria-selected={menuTab === tabId}
                className={`gw-menu-tab ${menuTab === tabId ? "active" : ""}`}
                onClick={() => setMenuTab(tabId)}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="gw-menu-quick-actions">
            <span className="gw-chip-pill gw-tabular">
              {selectedTrackDef.difficulty} · {selectedTrackDef.lengthLabel}
            </span>
          </div>
        </div>

        {/* TAB 1: RACE & TRACKS */}
        {menuTab === "play" && (
          <div className="gw-garage-main">
            <div className="gw-garage-stage">
              <div className="gw-garage-stage-head">
                <div>
                  <small>SELECT CIRCUIT ({TRACK_CATALOG.length} 3D TRACKS)</small>
                  <h3>{selectedTrackDef.name}</h3>
                </div>
                <span className="gw-garage-weight">
                  {selectedTrackDef.difficulty} · {selectedTrackDef.lengthLabel}
                </span>
              </div>

              <div className="gw-map-grid">
                {TRACK_CATALOG.map((tr) => {
                  const active = tr.id === custom.trackId;
                  const rec = trackRecords[tr.id];
                  return (
                    <button
                      key={tr.id}
                      type="button"
                      className={`gw-map-card ${active ? "selected" : ""}`}
                      onClick={() => updateRacingCustomization({ trackId: tr.id })}
                    >
                      <div className="gw-map-card-top">
                        <svg viewBox="0 0 160 120" className="gw-track-svg" aria-hidden="true">
                          <path
                            d={tr.svgPath}
                            fill="none"
                            stroke={active ? "#d1b273" : "#7d6b56"}
                            strokeWidth="6"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                        <span className="gw-map-diff">{tr.difficulty}</span>
                      </div>
                      <strong>{tr.name}</strong>
                      <small>{tr.surfaceLabel}</small>
                      <p>{tr.subtitle}</p>
                      {rec ? (
                        <div className="gw-map-record gw-tabular">
                          Best Lap: <b>{formatRaceTime(rec.bestLapSec)}</b> ·{" "}
                          {rec.topSpeedKmh} km/h
                        </div>
                      ) : (
                        <div className="gw-map-record">No lap record set yet</div>
                      )}
                    </button>
                  );
                })}
              </div>

              <div className="gw-garage-coop-box">
                <div className="gw-garage-coop-head">
                  <div>
                    <small>MULTIPLAYER CO-OP RACING · SQUAD SLIPSTREAM & SHARED LAPS</small>
                    <strong>Team up on {selectedTrackDef.name} (Up to 4 Drivers)</strong>
                  </div>
                  <span
                    className={`gw-ws-badge ${wsStatus === "connected" ? "connected" : wsStatus === "connecting" || wsStatus === "probing" || wsStatus === "reconnecting" ? "connecting" : "error"}`}
                  >
                    {wsStatus === "connected"
                      ? `● SUPABASE REALTIME${wsLatency !== null ? ` · ${wsLatency}ms` : ""}`
                      : wsStatus === "probing" || wsStatus === "connecting" || wsStatus === "reconnecting"
                        ? "◌ CONNECTING..."
                        : wsStatus === "unconfigured"
                          ? "◇ SOLO READY"
                          : "✕ OFFLINE"}
                  </span>
                </div>

                {(wsError || wsDetail) && (
                  <div className="gw-fps-error" style={{ marginBottom: 8 }}>
                    <span>{wsError || wsDetail}</span>
                    <button type="button" className="gw-btn" onClick={connectRacingLobby}>
                      Reconnect
                    </button>
                  </div>
                )}

                <div className="gw-garage-coop-inputs">
                  <input
                    type="text"
                    value={driverName}
                    maxLength={18}
                    onChange={(e) => setDriverName(e.target.value)}
                    placeholder="Driver callsign…"
                    aria-label="Driver callsign"
                  />
                  <input
                    type="text"
                    value={coopRoomTitle}
                    maxLength={32}
                    onChange={(e) => setCoopRoomTitle(e.target.value)}
                    placeholder="Co-op room name…"
                    aria-label="Co-op room name"
                  />
                  <button
                    type="button"
                    className="brass-button"
                    disabled={wsStatus !== "connected"}
                    onClick={createCoopRaceRoom}
                  >
                    Create Co-op Room & Race →
                  </button>
                </div>

                <div className="gw-garage-coop-join">
                  <div className="gw-fps-code-row">
                    <input
                      type="text"
                      value={joinCodeInput}
                      maxLength={8}
                      onChange={(e) => setJoinCodeInput(e.target.value.toUpperCase())}
                      placeholder="Join code (e.g. R7K2M)"
                      onKeyDown={(e) => e.key === "Enter" && joinCoopRaceRoom(joinCodeInput)}
                    />
                    <button
                      type="button"
                      className="gw-btn gw-btn-primary"
                      disabled={wsStatus !== "connected"}
                      onClick={() => joinCoopRaceRoom(joinCodeInput)}
                    >
                      Join Room
                    </button>
                    <button type="button" className="gw-btn gw-btn-primary" onClick={startSoloRace}>
                      Solo Time Trial →
                    </button>
                  </div>

                  {publicRooms.length > 0 && (
                    <div className="gw-garage-live-rooms">
                      {publicRooms.map((r) => (
                        <button
                          key={r.code}
                          type="button"
                          className="gw-garage-room-pill"
                          disabled={r.players >= r.maxPlayers}
                          onClick={() => joinCoopRaceRoom(r.code)}
                        >
                          <span>
                            <b>{r.code}</b> · {r.title}
                          </span>
                          <small>
                            {r.players}/{r.maxPlayers} Drivers →
                          </small>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="gw-garage-roster" aria-label="Predefined vehicle roster">
              <div className="gw-garage-roster-head">
                <small>8 PREDEFINED SLOTS · public/assets/models/my-cars/</small>
                <button type="button" className="gw-btn" onClick={() => setMenuTab("garage")}>
                  Open 3D Showroom →
                </button>
              </div>
              <div className="gw-garage-cards">
                {WORKSHOP_VEHICLES.map((car) => {
                  const selected = car.id === selectedVehicle.id;
                  return (
                    <button
                      key={car.id}
                      type="button"
                      className={`gw-car-option ${selected ? "selected" : ""}`}
                      onClick={() => updateRacingCustomization({ vehicleId: car.id })}
                    >
                      <CarGlbThumbnail vehicle={car} />
                      <div className="gw-car-swatch-row">
                        <span
                          className="gw-car-swatch"
                          style={{
                            background: `#${car.bodyColor.toString(16).padStart(6, "0")}`,
                            borderColor: `#${car.accentColor.toString(16).padStart(6, "0")}`,
                          }}
                        />
                        <small>{car.thumbnailLabel}</small>
                      </div>
                      <strong>{car.name}</strong>
                      <div className="gw-car-mini-specs gw-tabular">
                        <span>SPD {car.ratings.speed}</span>
                        <span>HDL {car.ratings.handling}</span>
                        <span>DRF {car.ratings.drift}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: 3D GLB SHOWROOM */}
        {menuTab === "garage" && (
          <div className="gw-garage-main">
            <div className="gw-garage-stage">
              <div className="gw-garage-stage-head">
                <div>
                  <small>
                    {selectedVehicle.thumbnailLabel} · {selectedVehicle.category}
                  </small>
                  <h3>{selectedVehicle.name}</h3>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                  <span className="gw-garage-weight gw-tabular">{selectedVehicle.ratings.weightKgLabel}</span>
                  <button type="button" className="brass-button" onClick={startSoloRace}>
                    Start Race →
                  </button>
                </div>
              </div>

              <GaragePreview3D vehicle={selectedVehicle} />

              <p className="gw-garage-tagline">{selectedVehicle.tagline}</p>

              <div className="gw-garage-stats">
                {[
                  ["Top Speed", selectedVehicle.ratings.speed],
                  ["Acceleration", selectedVehicle.ratings.accel],
                  ["Handling", selectedVehicle.ratings.handling],
                  ["Tire Grip", selectedVehicle.ratings.grip],
                  ["Drift Control", selectedVehicle.ratings.drift],
                ].map(([label, val]) => (
                  <div key={String(label)} className="gw-garage-stat">
                    <div className="gw-garage-stat-row">
                      <span>{label}</span>
                      <b className="gw-tabular">{val}</b>
                    </div>
                    <div className="gw-garage-bar">
                      <i style={{ width: `${val}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="gw-garage-roster">
              <div className="gw-custom-section">
                <div className="gw-custom-head">
                  <small>1. SELECT VEHICLE ({WORKSHOP_VEHICLES.length} PREDEFINED SLOTS)</small>
                </div>
                <div className="gw-garage-cards">
                  {WORKSHOP_VEHICLES.map((car) => (
                    <button
                      key={car.id}
                      type="button"
                      className={`gw-car-option ${car.id === selectedVehicle.id ? "selected" : ""}`}
                      onClick={() => updateRacingCustomization({ vehicleId: car.id })}
                    >
                      <CarGlbThumbnail vehicle={car} />
                      <strong>{car.name}</strong>
                      <small>{car.thumbnailLabel}</small>
                    </button>
                  ))}
                </div>
              </div>

              <div className="gw-custom-section">
                <div className="gw-custom-head">
                  <small>2. GLB ASSET FILE MAPPING</small>
                </div>
                <div
                  style={{
                    display: "grid",
                    gap: 6,
                    fontSize: 12,
                    color: "#cfc0aa",
                    lineHeight: 1.5,
                  }}
                >
                  <div>
                    <span style={{ color: "#9c8d77" }}>Slot File: </span>
                    <code>public{selectedVehicle.modelPath}</code>
                  </div>
                  <div>
                    <span style={{ color: "#9c8d77" }}>Loader: </span>
                    Three.js <code>GLTFLoader</code> (original materials, textures &amp; geometry preserved)
                  </div>
                  <div style={{ color: "#9c8d77", fontSize: 11.5 }}>
                    Drop your 8 downloaded <code>.glb</code> files as{" "}
                    <code>car-1.glb</code> through <code>car-8.glb</code> inside{" "}
                    <code>public/assets/models/my-cars/</code>.
                  </div>
                </div>
              </div>

              <div className="gw-custom-section">
                <div className="gw-custom-head">
                  <small>3. CHASSIS &amp; POWERTRAIN PARAMETERS</small>
                  <button
                    type="button"
                    className="gw-btn"
                    onClick={() => setMenuTab("tuning")}
                  >
                    Open Tuning Lab →
                  </button>
                </div>
                <div className="gw-controls-grid">
                  <div>
                    <b>{selectedVehicle.massKg} kg</b>
                    <span>Curb Mass</span>
                  </div>
                  <div>
                    <b>{Math.round(selectedVehicle.topSpeedMs * 3.6)} km/h</b>
                    <span>Max Velocity</span>
                  </div>
                  <div>
                    <b>{(selectedVehicle.engineForceN / 1000).toFixed(1)} kN</b>
                    <span>Peak Drive Force</span>
                  </div>
                  <div>
                    <b>{selectedVehicle.baseGrip.toFixed(2)}x</b>
                    <span>Base Lateral Grip</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: TUNING LAB */}
        {menuTab === "tuning" && (
          <div className="gw-tune-panel">
            <div className="gw-custom-section">
              <div className="gw-custom-head">
                <div>
                  <small>SETUP PRESETS</small>
                  <h3>{TUNING_PRESETS[custom.tuning.presetId].label}</h3>
                </div>
                <button
                  type="button"
                  className="gw-btn"
                  onClick={() => applyTuningPreset("balanced")}
                >
                  Restore Balanced Default
                </button>
              </div>
              <div className="gw-preset-grid">
                {(Object.keys(TUNING_PRESETS) as TuningPresetId[]).map((pid) => {
                  const preset = TUNING_PRESETS[pid];
                  return (
                    <button
                      key={pid}
                      type="button"
                      className={`gw-car-option ${custom.tuning.presetId === pid ? "selected" : ""}`}
                      onClick={() => applyTuningPreset(pid)}
                    >
                      <strong>{preset.label}</strong>
                      <small>{preset.summary}</small>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="gw-tune-grid">
              {[
                {
                  label: "Steering Sensitivity",
                  val: `${Math.round(custom.tuning.steeringGain * 100)}%`,
                  min: 0.75,
                  max: 1.35,
                  step: 0.05,
                  raw: custom.tuning.steeringGain,
                  onChange: (n: number) => updateRacingTuning({ steeringGain: n }),
                },
                {
                  label: "Tire Lateral Grip",
                  val: `${Math.round(custom.tuning.tireGripMult * 100)}%`,
                  min: 0.75,
                  max: 1.3,
                  step: 0.05,
                  raw: custom.tuning.tireGripMult,
                  onChange: (n: number) => updateRacingTuning({ tireGripMult: n }),
                },
                {
                  label: "Powertrain Boost",
                  val: `${Math.round(custom.tuning.accelBoostMult * 100)}%`,
                  min: 0.85,
                  max: 1.25,
                  step: 0.05,
                  raw: custom.tuning.accelBoostMult,
                  onChange: (n: number) => updateRacingTuning({ accelBoostMult: n }),
                },
                {
                  label: "Top Speed Gear Trim",
                  val: `${Math.round(custom.tuning.topSpeedTrim * 100)}%`,
                  min: 0.9,
                  max: 1.12,
                  step: 0.02,
                  raw: custom.tuning.topSpeedTrim,
                  onChange: (n: number) => updateRacingTuning({ topSpeedTrim: n }),
                },
                {
                  label: "Brake Hydraulic Pressure",
                  val: `${Math.round(custom.tuning.brakePowerMult * 100)}%`,
                  min: 0.8,
                  max: 1.35,
                  step: 0.05,
                  raw: custom.tuning.brakePowerMult,
                  onChange: (n: number) => updateRacingTuning({ brakePowerMult: n }),
                },
                {
                  label: "Differential Yaw Lock",
                  val: `${Math.round(custom.tuning.diffLockYaw * 100)}%`,
                  min: 0.75,
                  max: 1.4,
                  step: 0.05,
                  raw: custom.tuning.diffLockYaw,
                  onChange: (n: number) => updateRacingTuning({ diffLockYaw: n }),
                },
                {
                  label: "Suspension Stiffness",
                  val: `${Math.round(custom.tuning.suspensionStiffness * 100)}%`,
                  min: 0.7,
                  max: 1.4,
                  step: 0.05,
                  raw: custom.tuning.suspensionStiffness,
                  onChange: (n: number) => updateRacingTuning({ suspensionStiffness: n }),
                },
                {
                  label: "Chassis Ride Height",
                  val: `${custom.tuning.rideHeightOffset >= 0 ? "+" : ""}${Math.round(custom.tuning.rideHeightOffset * 100)} cm`,
                  min: -0.06,
                  max: 0.12,
                  step: 0.01,
                  raw: custom.tuning.rideHeightOffset,
                  onChange: (n: number) => updateRacingTuning({ rideHeightOffset: n }),
                },
              ].map((slider) => (
                <label key={slider.label} className="gw-slider-card">
                  <div className="gw-garage-stat-row">
                    <span>{slider.label}</span>
                    <b>{slider.val}</b>
                  </div>
                  <input
                    type="range"
                    min={slider.min}
                    max={slider.max}
                    step={slider.step}
                    value={slider.raw}
                    onChange={(e) => slider.onChange(Number(e.target.value))}
                  />
                </label>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: AUDIO, GRAPHICS & RECORDS */}
        {menuTab === "settings" && (
          <div className="gw-settings-grid">
            <div className="gw-custom-section">
              <small>AUDIO & SOUNDTRACK STUDIO</small>
              <div className="gw-slider-card">
                <div className="gw-garage-stat-row">
                  <span>Music Volume</span>
                  <b>{Math.round(settings.musicVolume * 100)}%</b>
                </div>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.02}
                  value={settings.musicVolume}
                  onChange={(e) => {
                    musicRef.current.startOnGesture();
                    updateWorkshopSettings({ musicVolume: Number(e.target.value) });
                  }}
                />
              </div>

              <div className="gw-slider-card">
                <div className="gw-garage-stat-row">
                  <span>Engine & Tire SFX Volume</span>
                  <b>{Math.round(settings.sfxVolume * 100)}%</b>
                </div>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.02}
                  value={settings.sfxVolume}
                  onChange={(e) => updateWorkshopSettings({ sfxVolume: Number(e.target.value) })}
                />
              </div>

              <div className="gw-pill-grid" style={{ marginTop: 8 }}>
                <button
                  type="button"
                  className={`gw-btn ${musicOn && !muted ? "gw-btn-primary" : ""}`}
                  onClick={() => {
                    musicRef.current.startOnGesture();
                    updateWorkshopSettings({ musicEnabled: !musicOn });
                  }}
                >
                  {musicOn ? "♪ Music Enabled" : "♪ Music Off"}
                </button>
                <button
                  type="button"
                  className={`gw-btn ${muted ? "" : "gw-btn-primary"}`}
                  onClick={() => updateWorkshopSettings({ muted: !muted })}
                >
                  {muted ? "All Audio Muted" : "Master Audio Active"}
                </button>
              </div>

              <div className="gw-playlist-box" style={{ marginTop: 12 }}>
                <small>ACTIVE SOUNDTRACK SELECTION</small>
                <select
                  value={currentTrackUrl}
                  onChange={(e) => {
                    musicRef.current.startOnGesture();
                    selectActiveSoundtrackByUrl(e.target.value);
                  }}
                >
                  {playlistItems.map((track) => (
                    <option key={track.id} value={track.url}>
                      {track.title} {track.artist ? `— ${track.artist}` : ""}
                    </option>
                  ))}
                </select>
                <label className="gw-btn" style={{ marginTop: 8, cursor: "pointer", display: "inline-block" }}>
                  + Add Local Audio Track
                  <input
                    type="file"
                    accept="audio/*,.mp3,.m4a,.wav,.ogg"
                    hidden
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) registerSessionTrackFile(f);
                    }}
                  />
                </label>
              </div>
            </div>

            <div className="gw-custom-section">
              <small>GRAPHICS, CAMERA & CONTROLS</small>
              <div className="gw-pill-grid">
                {(["low", "medium", "high"] as GraphicsQuality[]).map((q) => (
                  <button
                    key={q}
                    type="button"
                    className={`gw-btn ${quality === q ? "gw-btn-primary" : ""}`}
                    onClick={() => updateWorkshopSettings({ graphicsQuality: q })}
                  >
                    Quality: {q.toUpperCase()}
                  </button>
                ))}
              </div>
              <div className="gw-pill-grid" style={{ marginTop: 8 }}>
                {(["chase", "close", "hood"] as CameraViewMode[]).map((cam) => (
                  <button
                    key={cam}
                    type="button"
                    className={`gw-btn ${cameraView === cam ? "gw-btn-primary" : ""}`}
                    onClick={() => setCameraView(cam)}
                  >
                    Cam: {cam.toUpperCase()}
                  </button>
                ))}
              </div>

              <div className="gw-slider-card" style={{ marginTop: 10 }}>
                <div className="gw-garage-stat-row">
                  <span>Camera Base FOV</span>
                  <b>{settings.fov}°</b>
                </div>
                <input
                  type="range"
                  min={60}
                  max={100}
                  step={1}
                  value={settings.fov}
                  onChange={(e) => updateWorkshopSettings({ fov: Number(e.target.value) })}
                />
              </div>

              <div className="gw-controls-grid" style={{ marginTop: 12 }}>
                <div><b>W / ↑</b><span>Throttle</span></div>
                <div><b>S / ↓</b><span>Brake / Reverse</span></div>
                <div><b>A / D / ← / →</b><span>Steer</span></div>
                <div><b>Space</b><span>Handbrake Drift</span></div>
                <div><b>R</b><span>Reset onto Track</span></div>
                <div><b>C</b><span>Cycle Camera</span></div>
                <div><b>H</b><span>Toggle Bottom Dock</span></div>
                <div><b>P / Esc</b><span>Pause Menu</span></div>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="gw-race-root">
      <div
        ref={mountRef}
        className="gw-race-canvas-mount"
        onClick={() => {
          audioRef.current.initOnGesture();
          musicRef.current.startOnGesture();
        }}
      />

      <div className="gw-race-hud-tl">
        <div className="gw-race-stat-row">
          <div>
            <small>LAP</small>
            <strong ref={lapTextRef} className="tabular-nums">
              1 / 3
            </strong>
          </div>
          <div>
            <small>TIME</small>
            <strong ref={lapTimeTextRef} className="tabular-nums">
              00:00.00
            </strong>
          </div>
          <div>
            <small>BEST</small>
            <strong ref={bestLapTextRef} className="tabular-nums">
              --:--.--
            </strong>
          </div>
        </div>

        <div className="gw-race-speed-cluster">
          <div className="gw-race-speed-num">
            <span ref={speedTextRef} className="tabular-nums">
              0
            </span>
            <small>KM/H</small>
          </div>
          <div className="gw-race-gear-box">
            <small>GEAR</small>
            <strong ref={gearTextRef}>N</strong>
          </div>
          <div className="gw-race-surface-box">
            <small>{getTrackDef(activeTrackId).name.toUpperCase()}</small>
            <strong ref={surfaceTextRef}>ASPHALT</strong>
          </div>
        </div>

        <div className="gw-race-rpm-track" aria-hidden="true">
          <div ref={rpmBarRef} className="gw-race-rpm-fill" style={{ width: "14%" }} />
        </div>

        {draftingActive && (
          <div className="gw-race-draft-badge">⚡ CO-OP SLIPSTREAM DRAFT ACTIVE (+12% PACE)</div>
        )}
      </div>

      {coopRoomCode && coopSnapshot && (
        <div className="gw-race-squad-hud">
          <div className="gw-fps-room-chip">
            <span>
              CO-OP GP <b>{coopRoomCode}</b> · SCORE <b>{coopSnapshot.teamScore}</b>
            </span>
            <button
              type="button"
              className="gw-fps-copy-btn"
              onClick={() => {
                navigator.clipboard?.writeText(coopRoomCode);
                setCopiedCode(true);
                window.setTimeout(() => setCopiedCode(false), 1200);
              }}
            >
              {copiedCode ? "Copied ✓" : "Copy Code"}
            </button>
          </div>
          <div className="gw-race-squad-card">
            <small>
              SQUAD LAPS: {coopSnapshot.squadLapsCompleted} / {coopSnapshot.squadTargetLaps}
            </small>
            {coopSnapshot.players.map((p) => (
              <div key={p.id} className="gw-fps-squad-row">
                <span className="sq-dot" style={{ background: p.color }} />
                <b>
                  {p.name}
                  {p.id === localRacerId ? " (YOU)" : ""}
                </b>
                <span>{p.finished ? "FINISHED" : `L${p.lap}/3 · ${p.speedKmh}km/h`}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="gw-race-minimap-box" aria-hidden="true">
        <canvas ref={minimapRef} width={140} height={140} />
      </div>

      {missingAssetAlert && !contextLost && (
        <div
          role="alert"
          style={{
            position: "absolute",
            top: 16,
            left: "50%",
            transform: "translateX(-50%)",
            zIndex: 18,
            maxWidth: 520,
            padding: "10px 14px",
            background: "rgba(24, 17, 11, 0.94)",
            border: "1px solid #c9a867",
            color: "#f3e5c7",
            fontSize: 12.5,
            display: "flex",
            alignItems: "center",
            gap: 12,
          }}
        >
          <div style={{ flex: 1, lineHeight: 1.45 }}>
            <strong>Missing Vehicle GLB ({selectedVehicle.fileName}):</strong> {missingAssetAlert}
          </div>
          <button type="button" className="gw-btn gw-btn-primary" onClick={returnToGarage}>
            Garage
          </button>
        </div>
      )}

      {contextLost && (
        <div className="gw-race-overlay" role="alert">
          <div className="gw-race-modal">
            <p className="eyebrow">WebGL Context Suspended</p>
            <h3>Graphics Context Interrupted</h3>
            <p>Your browser suspended the 3D WebGL context. Exit or return to Garage.</p>
            <div className="gw-race-modal-actions">
              <button type="button" className="brass-button" onClick={returnToGarage}>
                Return to Garage
              </button>
              <button type="button" className="gw-btn" onClick={onExit}>
                Back to Workshop
              </button>
            </div>
          </div>
        </div>
      )}

      {raceStatus === "PAUSED" && !contextLost && (
        <div className="gw-race-overlay">
          <div className="gw-race-modal">
            <p className="eyebrow">
              {coopRoomCode ? `Co-op Room ${coopRoomCode}` : getTrackDef(activeTrackId).name} ·{" "}
              {selectedVehicle.name}
            </p>
            <h3>Race Paused</h3>
            <p>
              <strong>W / ↑</strong> Accelerate · <strong>S / ↓</strong> Brake/Reverse ·{" "}
              <strong>A / D</strong> Steer · <strong>Space</strong> Drift · <strong>R</strong>{" "}
              Reset · <strong>C</strong> Camera
            </p>

            <div className="gw-pause-sliders">
              <label>
                <span>Music ({Math.round(settings.musicVolume * 100)}%)</span>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={settings.musicVolume}
                  onChange={(e) => updateWorkshopSettings({ musicVolume: Number(e.target.value) })}
                />
              </label>
              <label>
                <span>Engine SFX ({Math.round(settings.sfxVolume * 100)}%)</span>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={settings.sfxVolume}
                  onChange={(e) => updateWorkshopSettings({ sfxVolume: Number(e.target.value) })}
                />
              </label>
            </div>

            <div className="gw-race-modal-actions">
              <button
                type="button"
                className="brass-button"
                onClick={() => setRaceStatus("RACING")}
              >
                Resume Race
              </button>
              <button type="button" className="gw-btn" onClick={returnToGarage}>
                Garage & Track Menu
              </button>
              <button
                type="button"
                className="gw-btn"
                onClick={() => actionsRef.current?.restartRace()}
              >
                {coopRoomCode ? "Restart Squad Race" : "Restart Session"}
              </button>
              <button type="button" className="gw-btn" onClick={onExit}>
                Exit to Workshop
              </button>
            </div>
          </div>
        </div>
      )}

      {(raceStatus === "FINISHED" || (coopRoomCode && summary && raceStatus === "RACING")) &&
        !contextLost && (
          <div className="gw-race-overlay">
            <div className="gw-race-modal">
              <p className="eyebrow">
                {coopRoomCode
                  ? `Co-op GP ${coopRoomCode} · Team Score ${coopSnapshot?.teamScore ?? 0}`
                  : `Checkered Flag · ${summary?.trackName ?? getTrackDef(activeTrackId).name}`}
              </p>
              <h3>
                {coopRoomCode && coopSnapshot?.status !== "FINISHED"
                  ? "Finished! Waiting on Squadmates…"
                  : "Session Complete"}
              </h3>

              {summary && (
                <div className="gw-race-summary-grid">
                  <div>
                    <small>Total Time</small>
                    <strong className="tabular-nums">{formatRaceTime(summary.totalTime)}</strong>
                  </div>
                  <div>
                    <small>Best Lap</small>
                    <strong className="tabular-nums">
                      {summary.bestLap ? formatRaceTime(summary.bestLap) : "--:--.--"}
                    </strong>
                  </div>
                  <div>
                    <small>Top Speed</small>
                    <strong className="tabular-nums">{summary.topSpeedKmh} KM/H</strong>
                  </div>
                </div>
              )}

              {coopRoomCode && coopSnapshot && (
                <div className="gw-race-coop-leaderboard">
                  {coopSnapshot.players.map((p) => (
                    <div key={p.id} className="gw-fps-squad-row">
                      <span className="sq-dot" style={{ background: p.color }} />
                      <b>{p.name}</b>
                      <span>
                        {p.finishTime !== null
                          ? `${formatRaceTime(p.finishTime)} · ${p.score} pts`
                          : `Lap ${p.lap}/3 (${Math.round(p.progressNorm * 100)}%)`}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              <div className="gw-race-modal-actions">
                <button
                  type="button"
                  className="brass-button"
                  onClick={() => actionsRef.current?.restartRace()}
                >
                  {coopRoomCode ? "Restart Squad Race" : "Race Again"}
                </button>
                <button type="button" className="gw-btn" onClick={returnToGarage}>
                  Select Another Car / Track
                </button>
                <button type="button" className="gw-btn" onClick={onExit}>
                  Back to Workshop
                </button>
              </div>
            </div>
          </div>
        )}

      <div className="gw-race-dock-wrap">
        <button
          type="button"
          className="gw-race-dock-toggle"
          onClick={() => setHudExpanded((v) => !v)}
        >
          {hudExpanded ? "Hide Controls (H) ▾" : "Show Controls (H) ▴"}
        </button>

        {hudExpanded && (
          <div className="gw-race-dock">
            <div className="gw-race-controls-hint">
              <span>
                <b>WASD/↑↓</b> Drive
              </span>
              <span>
                <b>Space</b> Drift
              </span>
              <span>
                <b>R</b> Reset
              </span>
              <span>
                <b>C</b> Cam ({cameraView})
              </span>
              <span>
                <b>P</b> Pause
              </span>
            </div>

            <div className="gw-race-dock-buttons">
              <button
                type="button"
                className="gw-btn"
                onClick={() => actionsRef.current?.resetCar()}
              >
                Reset Car
              </button>
              <button type="button" className="gw-btn" onClick={returnToGarage}>
                Garage
              </button>
              <button type="button" className="gw-btn" onClick={cycleCamera}>
                Cam
              </button>
              <button type="button" className="gw-btn" onClick={cycleQuality}>
                Q: {quality.toUpperCase()}
              </button>
              <button
                type="button"
                className={`gw-btn ${musicOn && !muted ? "gw-btn-primary" : ""}`}
                onClick={() => {
                  musicRef.current.startOnGesture();
                  updateWorkshopSettings({ musicEnabled: !musicOn });
                }}
              >
                {musicOn ? "♪ Music" : "Music Off"}
              </button>
              <button
                type="button"
                className={`gw-btn ${muted ? "" : "gw-btn-primary"}`}
                onClick={() => updateWorkshopSettings({ muted: !muted })}
              >
                {muted ? "Muted" : "SFX"}
              </button>
              <button type="button" className="gw-btn" onClick={onToggleFullscreen}>
                {isFullscreen ? "Exit FS" : "Fullscreen"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
