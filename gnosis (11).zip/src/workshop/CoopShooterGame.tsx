import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import {
  createWorkshopLobbyClient,
  openWorkshopRoom,
  type NetworkConnectionState,
  type WorkshopLobbyClient,
  type WorkshopRoomSummary,
  type WorkshopRoomTransport,
} from "./net/gameNetwork";
import {
  ARMOR_REFILL_PRICE,
  ShooterRoomHost,
  type HostShooterSnapshot,
  type ShooterOutgoingEvent,
} from "./shooter/shooterHostEngine";
import { ShooterAudioEngine } from "./shooter/audio";
import { disposeSafeHierarchy } from "./assets/modelLoader";
import {
  FPS_MAP_LIST,
  getFpsMapDef,
  getMapCallout,
  raycastArenaObstacles,
  resolveCircleBoxCollisions,
  type FpsMapId,
} from "./shooter/mapData";
import {
  buildArenaScene,
  buildFirstPersonWeapon,
  buildOperativeModel,
  type BlockyCharacterRig,
  type DetailedWeaponBundle,
} from "./shooter/models";
import {
  applySkinToAllWeapons,
  KNIFE_LIST,
  KNIVES_BY_ID,
  setEquippedKnife,
  setWeaponSkin,
  TRIM_PALETTE,
  updateOperativeCustomization,
  useFpsCosmetics,
  VISOR_PALETTE,
  WEAPON_SKINS,
  WEAPON_SKINS_BY_ID,
} from "./shooter/cosmetics";
import {
  BUYABLE_WEAPON_LIST,
  WEAPON_CATEGORIES,
  WEAPON_LIST,
  WEAPONS_BY_ID,
  type WeaponCollectionCategory,
  type WeaponId,
} from "./shooter/weapons";
import { WeaponPreview3D } from "./shooter/WeaponPreview3D";
import cardShooterImg from "../assets/images/card_coop_shooter_1795184669798.jpg";
import {
  GameSoundtrackPlayer,
  getSharedPlaylist,
  selectActiveSoundtrackByUrl,
} from "./soundtrack";
import {
  resetWorkshopSettings,
  updateWorkshopSettings,
  useWorkshopSettings,
} from "./sharedSettings";

export type ShooterTeam = "vanguard" | "syndicate";
export type ShooterMode = "DEFUSAL" | "TDM";
export type RoundPhase = "BUY_FREEZE" | "LIVE" | "ROUND_END" | "MATCH_END";
type FpsMenuTab = "play" | "armory" | "knives" | "operative" | "settings" | "profile";

interface PublicRoomInfo {
  code: string;
  title: string;
  mapId: FpsMapId;
  mode: ShooterMode;
  players: number;
  maxPlayers: number;
  round: number;
  phase: RoundPhase;
}

interface NetPlayer {
  id: string;
  name: string;
  team: ShooterTeam;
  color: string;
  isBot: boolean;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  crouching: boolean;
  weaponId: WeaponId;
  ownedWeapons?: WeaponId[];
  money?: number;
  hp: number;
  maxHp: number;
  armor: number;
  alive: boolean;
  respawnTimer: number;
  kills: number;
  deaths: number;
  assists: number;
  damageDealt: number;
  score: number;
}

interface RoomSnapshot {
  type: "room:snapshot";
  code: string;
  title: string;
  mapId: FpsMapId;
  mode: ShooterMode;
  fillBots: boolean;
  alphaBotCount: number;
  bravoBotCount: number;
  round: number;
  maxRounds: number;
  isPistolRound?: boolean;
  phase: RoundPhase;
  phaseTimer: number;
  vanguardRounds: number;
  syndicateRounds: number;
  vanguardKills: number;
  syndicateKills: number;
  roundWinnerTeam: ShooterTeam | null;
  winnerTeam: ShooterTeam | "draw" | null;
  winReason: string | null;
  bombPlanted: boolean;
  bombSiteId: "A" | "B" | null;
  bombX: number;
  bombY: number;
  bombZ: number;
  bombTimer: number;
  plantProgress: number;
  defuseProgress: number;
  players: NetPlayer[];
  pickups: { id: string; kind: "medkit" | "ammo"; active: boolean }[];
}

interface KillFeedEntry {
  id: number;
  killerName: string;
  killerTeam: ShooterTeam;
  victimName: string;
  victimTeam: ShooterTeam;
  weaponId: WeaponId;
  headshot: boolean;
  isKnife: boolean;
  wallbang: boolean;
  expiresAt: number;
}

interface AmmoState {
  mag: number;
  reserve: number;
}

interface FpsCareerStats {
  matchesPlayed: number;
  wins: number;
  kills: number;
  headshots: number;
  knifeKills: number;
  damageDealt: number;
}

const STATS_STORAGE_KEY = "gnosis-fps-stats-v1";

function loadFpsStats(): FpsCareerStats {
  if (typeof window === "undefined") {
    return { matchesPlayed: 0, wins: 0, kills: 0, headshots: 0, knifeKills: 0, damageDealt: 0 };
  }
  try {
    const raw = window.localStorage.getItem(STATS_STORAGE_KEY);
    if (!raw) return { matchesPlayed: 0, wins: 0, kills: 0, headshots: 0, knifeKills: 0, damageDealt: 0 };
    const p = JSON.parse(raw) as Partial<FpsCareerStats>;
    return {
      matchesPlayed: Number(p.matchesPlayed || 0),
      wins: Number(p.wins || 0),
      kills: Number(p.kills || 0),
      headshots: Number(p.headshots || 0),
      knifeKills: Number(p.knifeKills || 0),
      damageDealt: Number(p.damageDealt || 0),
    };
  } catch {
    return { matchesPlayed: 0, wins: 0, kills: 0, headshots: 0, knifeKills: 0, damageDealt: 0 };
  }
}

function saveFpsStats(stats: FpsCareerStats) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STATS_STORAGE_KEY, JSON.stringify(stats));
  } catch {
    // Ignore storage quota errors
  }
}

function makeInitialInventory(): Record<WeaponId, AmmoState> {
  return {
    starter_pistol: {
      mag: WEAPONS_BY_ID.starter_pistol.magSize,
      reserve: WEAPONS_BY_ID.starter_pistol.reserveMax,
    },
    carbine: { mag: WEAPONS_BY_ID.carbine.magSize, reserve: WEAPONS_BY_ID.carbine.reserveMax },
    smg: { mag: WEAPONS_BY_ID.smg.magSize, reserve: WEAPONS_BY_ID.smg.reserveMax },
    shotgun: { mag: WEAPONS_BY_ID.shotgun.magSize, reserve: WEAPONS_BY_ID.shotgun.reserveMax },
    pistol: { mag: WEAPONS_BY_ID.pistol.magSize, reserve: WEAPONS_BY_ID.pistol.reserveMax },
    sniper: { mag: WEAPONS_BY_ID.sniper.magSize, reserve: WEAPONS_BY_ID.sniper.reserveMax },
    knife: { mag: 0, reserve: 0 },
  };
}

function WeaponKillIcon({ id }: { id: WeaponId }) {
  if (id === "knife") {
    return (
      <svg viewBox="0 0 36 16" className="kf-weapon-svg" aria-hidden="true">
        <path d="M4 11 L13 11 L15 9 L31 5 L25 11 L14 13 L4 13 Z" fill="currentColor" />
      </svg>
    );
  }
  if (id === "starter_pistol" || id === "pistol") {
    return (
      <svg viewBox="0 0 36 16" className="kf-weapon-svg" aria-hidden="true">
        <path
          d={
            id === "pistol"
              ? "M6 4 H29 V7 H20 V14 H14 L15 8 H6 Z"
              : "M8 4 H26 V7 H18 V14 H13 L14 8 H8 Z"
          }
          fill="currentColor"
        />
      </svg>
    );
  }
  if (id === "smg") {
    return (
      <svg viewBox="0 0 40 16" className="kf-weapon-svg" aria-hidden="true">
        <path d="M5 5 H28 V8 H34 V6 H28 V4 H9 L6 10 H11 L12 8 H16 L17 14 H20 L19 8 H22 V12 H25 V8 H5 Z" fill="currentColor" />
      </svg>
    );
  }
  if (id === "shotgun") {
    return (
      <svg viewBox="0 0 44 16" className="kf-weapon-svg" aria-hidden="true">
        <path d="M2 10 L11 8 H39 V6 H12 L3 7 Z M17 8 H29 V10 H17 Z" fill="currentColor" />
      </svg>
    );
  }
  if (id === "sniper") {
    return (
      <svg viewBox="0 0 48 16" className="kf-weapon-svg" aria-hidden="true">
        <path d="M2 9 L12 8 H46 V6.5 H29 V4 H19 V6.5 H11 L3 7 Z M18 8 H23 V13 H18 Z" fill="currentColor" />
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 44 16" className="kf-weapon-svg" aria-hidden="true">
      <path d="M2 9 L11 8 H38 V6 H27 V4 H18 V6 H10 L3 7 Z M20 8 L23 14 H26 L23 8 Z" fill="currentColor" />
    </svg>
  );
}

function disposeHierarchy(root: THREE.Object3D) {
  root.traverse((obj) => {
    obj.userData.disposed = true;
  });
  disposeSafeHierarchy(root);
}

function formatTimer(sec: number): string {
  const s = Math.max(0, Math.ceil(sec));
  const m = Math.floor(s / 60);
  const rem = s % 60;
  return `${m}:${String(rem).padStart(2, "0")}`;
}

export function CoopShooterGame({
  isFullscreen,
  onToggleFullscreen,
  onExit,
}: {
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  onExit: () => void;
}) {
  const settings = useWorkshopSettings();
  const cosmetics = useFpsCosmetics();
  const playlist = getSharedPlaylist();

  const [netState, setNetState] = useState<NetworkConnectionState>("probing");
  const [netDetail, setNetDetail] = useState<string | null>(null);
  const [latencyMs, setLatencyMs] = useState<number | null>(null);
  const [wsError, setWsError] = useState<string | null>(null);

  // Menu Navigation & Collection State
  const [menuTab, setMenuTab] = useState<FpsMenuTab>("play");
  const [selectedMapId, setSelectedMapId] = useState<FpsMapId>("desert-outpost");
  const [armoryCategory, setArmoryCategory] = useState<WeaponCollectionCategory>("Rifles");
  const [previewWeaponId, setPreviewWeaponId] = useState<WeaponId>("carbine");
  const [previewAnim, setPreviewAnim] = useState<{ trigger: "idle" | "inspect" | "fire" | "reload"; seq: number }>({
    trigger: "idle",
    seq: 0,
  });
  const [previewTeam, setPreviewTeam] = useState<ShooterTeam>("vanguard");
  const [careerStats, setCareerStats] = useState<FpsCareerStats>(loadFpsStats);
  const [killFeedDurationSec, setKillFeedDurationSec] = useState<number>(() => {
    try {
      const saved = Number(window.localStorage.getItem("gnosis-fps-killfeed-sec") || "5.5");
      return Number.isFinite(saved) ? Math.max(3, Math.min(10, saved)) : 5.5;
    } catch {
      return 5.5;
    }
  });

  // Match Lobby Form
  const [publicRooms, setPublicRooms] = useState<PublicRoomInfo[]>([]);
  const [callsign, setCallsign] = useState(
    () => sessionStorage.getItem("gnosis-shooter-name") || "Operative-01",
  );
  const [newRoomTitle, setNewRoomTitle] = useState("Sirocco Citadel");
  const [selectedMode, setSelectedMode] = useState<ShooterMode>("DEFUSAL");
  const [selectedTeam, setSelectedTeam] = useState<ShooterTeam>("vanguard");
  const [alphaBots, setAlphaBots] = useState<number>(4);
  const [bravoBots, setBravoBots] = useState<number>(4);
  const [joinCodeInput, setJoinCodeInput] = useState("");

  // Active Match State
  const [inRoom, setInRoom] = useState(false);
  const [roomCode, setRoomCode] = useState("");
  const [roomTitle, setRoomTitle] = useState("");
  const [activeMapId, setActiveMapId] = useState<FpsMapId>("desert-outpost");
  const [localPlayerId, setLocalPlayerId] = useState("");
  const [myTeam, setMyTeam] = useState<ShooterTeam>("vanguard");
  const [snapshot, setSnapshot] = useState<RoomSnapshot | null>(null);
  const [spectateTargetId, setSpectateTargetId] = useState<string | null>(null);
  const [eventFeed, setEventFeed] = useState<{ id: number; text: string; tone?: string }[]>([]);
  const [killFeedEntries, setKillFeedEntries] = useState<KillFeedEntry[]>([]);
  const [shopNotice, setShopNotice] = useState<{ text: string; isError: boolean; stamp: number } | null>(null);
  const [pointerLocked, setPointerLocked] = useState(false);
  const [scoreboardOpen, setScoreboardOpen] = useState(false);
  const [loadoutOpen, setLoadoutOpen] = useState(false);
  const [pauseMenuOpen, setPauseMenuOpen] = useState(false);
  const [damageFlash, setDamageFlash] = useState(false);
  const [hitMarker, setHitMarker] = useState<{ headshot: boolean; damage: number; stamp: number } | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);
  const [calloutName, setCalloutName] = useState("ALPHA SPAWN COURTYARD");
  const [objectivePrompt, setObjectivePrompt] = useState<string | null>(null);

  // Weapon & HUD State
  const [activeWeapon, setActiveWeapon] = useState<WeaponId>("starter_pistol");
  const [inventory, setInventory] = useState<Record<WeaponId, AmmoState>>(makeInitialInventory);
  const [reloading, setReloading] = useState(false);
  const [isScopedSniper, setIsScopedSniper] = useState(false);

  const lobbyClientRef = useRef<WorkshopLobbyClient | null>(null);
  const roomTransportRef = useRef<WorkshopRoomTransport | null>(null);
  const hostEngineRef = useRef<ShooterRoomHost | null>(null);
  const hostTickTimerRef = useRef<number | null>(null);
  const joinTimeoutRef = useRef<number | null>(null);
  const lastMetaSyncAtRef = useRef(0);
  const applyShooterMessageRef = useRef<(msg: Record<string, unknown>) => void>(() => {});
  const [audioEngine] = useState(() => new ShooterAudioEngine());
  const [musicPlayer] = useState(() => new GameSoundtrackPlayer(settings.musicVolume, "shooter"));
  const audioRef = useRef<ShooterAudioEngine>(audioEngine);
  const musicRef = useRef<GameSoundtrackPlayer>(musicPlayer);
  const mountRef = useRef<HTMLDivElement | null>(null);
  const minimapCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const snapshotRef = useRef<RoomSnapshot | null>(null);
  const localPlayerIdRef = useRef("");
  const myTeamRef = useRef<ShooterTeam>("vanguard");
  const activeWeaponRef = useRef<WeaponId>("starter_pistol");
  const prevWeaponRef = useRef<WeaponId>("starter_pistol");
  const inventoryRef = useRef<Record<WeaponId, AmmoState>>(inventory);
  const reloadingRef = useRef(false);
  const reloadTimerRef = useRef<number | null>(null);
  const modalOpenRef = useRef(false);
  const settingsRef = useRef(settings);
  const cosmeticsRef = useRef(cosmetics);
  const killFeedDurationRef = useRef(killFeedDurationSec);
  const activeMapIdRef = useRef<FpsMapId>("desert-outpost");
  const inspectTimerRef = useRef(0);
  const meleeSwingTimerRef = useRef(0);
  const recordedMatchEndRef = useRef(false);
  const crosshairGapRef = useRef<HTMLDivElement | null>(null);
  const pendingSpawnRef = useRef<{ x: number; y: number; z: number; yaw: number } | null>(null);
  const spectateTargetIdRef = useRef<string | null>(null);
  const spectateOrbitRef = useRef<{ yaw: number; pitch: number }>({ yaw: 0, pitch: 0.24 });
  const tracerQueueRef = useRef<
    {
      origin: { x: number; y: number; z: number };
      ends: { x: number; y: number; z: number; hitWorld: boolean }[];
      shooterId: string;
    }[]
  >([]);

  useEffect(() => {
    inventoryRef.current = inventory;
  }, [inventory]);

  useEffect(() => {
    activeWeaponRef.current = activeWeapon;
  }, [activeWeapon]);

  useEffect(() => {
    modalOpenRef.current = loadoutOpen || pauseMenuOpen;
  }, [loadoutOpen, pauseMenuOpen]);

  useEffect(() => {
    myTeamRef.current = myTeam;
  }, [myTeam]);

  useEffect(() => {
    settingsRef.current = settings;
    audioRef.current.setMuted(settings.muted);
    audioRef.current.setVolume(settings.sfxVolume);
    musicRef.current.setMuted(settings.muted);
    musicRef.current.setVolume(settings.musicVolume);
    musicRef.current.setMusicEnabled(settings.musicEnabled);
  }, [settings]);

  useEffect(() => {
    cosmeticsRef.current = cosmetics;
  }, [cosmetics]);

  useEffect(() => {
    killFeedDurationRef.current = killFeedDurationSec;
    try {
      window.localStorage.setItem("gnosis-fps-killfeed-sec", String(killFeedDurationSec));
    } catch {
      // Ignore storage errors
    }
  }, [killFeedDurationSec]);

  useEffect(() => {
    if (!inRoom) return;
    const timer = window.setInterval(() => {
      const now = Date.now();
      setKillFeedEntries((prev) => {
        const filtered = prev.filter((item) => item.expiresAt > now);
        return filtered.length === prev.length ? prev : filtered;
      });
    }, 250);
    return () => window.clearInterval(timer);
  }, [inRoom]);

  const recordStatPatch = useCallback((updater: (prev: FpsCareerStats) => FpsCareerStats) => {
    setCareerStats((prev) => {
      const next = updater(prev);
      saveFpsStats(next);
      return next;
    });
  }, []);

  const pushFeed = useCallback((text: string, tone?: string) => {
    setEventFeed((prev) => [...prev.slice(-4), { id: Date.now() + Math.random(), text, tone }]);
  }, []);

  const stopHostSimulation = useCallback(() => {
    if (hostTickTimerRef.current !== null) {
      window.clearInterval(hostTickTimerRef.current);
      hostTickTimerRef.current = null;
    }
    hostEngineRef.current = null;
  }, []);

  const clearJoinTimeout = useCallback(() => {
    if (joinTimeoutRef.current !== null) {
      window.clearTimeout(joinTimeoutRef.current);
      joinTimeoutRef.current = null;
    }
  }, []);

  const getLivingSpectatePool = useCallback((snap: RoomSnapshot | null, selfId: string) => {
    if (!snap) return [];
    const alive = snap.players.filter((p) => p.alive && p.id !== selfId);
    const allyFirst = alive.filter((p) => p.team === myTeamRef.current);
    const enemyRest = alive.filter((p) => p.team !== myTeamRef.current);
    return [...allyFirst, ...enemyRest];
  }, []);

  const cycleSpectateTarget = useCallback(
    (dir: 1 | -1) => {
      const pool = getLivingSpectatePool(snapshotRef.current, localPlayerIdRef.current);
      if (pool.length === 0) {
        spectateTargetIdRef.current = null;
        setSpectateTargetId(null);
        return;
      }
      const curIdx = pool.findIndex((p) => p.id === spectateTargetIdRef.current);
      const nextIdx =
        curIdx === -1 ? 0 : (curIdx + dir + pool.length) % pool.length;
      const nextTarget = pool[nextIdx];
      spectateTargetIdRef.current = nextTarget.id;
      spectateOrbitRef.current.yaw = nextTarget.yaw;
      setSpectateTargetId(nextTarget.id);
    },
    [getLivingSpectatePool],
  );

  applyShooterMessageRef.current = (msg: Record<string, unknown>) => {
    if (msg.type === "error") {
      clearJoinTimeout();
      setWsError(String(msg.message || "Multiplayer match error."));
      return;
    }

    if (msg.type === "room:joined") {
      clearJoinTimeout();
      const snap = msg.snapshot as RoomSnapshot;
      const pid = String(msg.playerId);
      const team = (msg.team === "syndicate" ? "syndicate" : "vanguard") as ShooterTeam;
      const spawn = msg.spawn as { x: number; y: number; z: number; yaw: number };
      const mapId = getFpsMapDef(snap.mapId).id;

      localPlayerIdRef.current = pid;
      myTeamRef.current = team;
      snapshotRef.current = snap;
      pendingSpawnRef.current = spawn;
      activeMapIdRef.current = mapId;
      recordedMatchEndRef.current = false;
      spectateTargetIdRef.current = null;

      setLocalPlayerId(pid);
      setMyTeam(team);
      setRoomCode(snap.code);
      setRoomTitle(snap.title);
      setActiveMapId(mapId);
      setSnapshot(snap);
      setSpectateTargetId(null);
      setInventory(makeInitialInventory());
      setActiveWeapon("starter_pistol");
      activeWeaponRef.current = "starter_pistol";
      prevWeaponRef.current = "starter_pistol";
      setReloading(false);
      reloadingRef.current = false;
      setLoadoutOpen(false);
      setPauseMenuOpen(false);
      setShopNotice(null);
      setKillFeedEntries([]);
      setInRoom(true);
      recordStatPatch((st) => ({ ...st, matchesPlayed: st.matchesPlayed + 1 }));
      const teamLabel = team === "vanguard" ? "TEAM ALPHA" : "TEAM BRAVO";
      setEventFeed([
        {
          id: Date.now(),
          text: `Deployed to ${getFpsMapDef(mapId).name} [${snap.code}] · ${teamLabel}`,
          tone: team,
        },
      ]);
      return;
    }

    if (msg.type === "room:snapshot") {
      const snap = msg as unknown as RoomSnapshot;
      snapshotRef.current = snap;
      setSnapshot(snap);
      if (snap.mapId && snap.mapId !== activeMapIdRef.current) {
        activeMapIdRef.current = getFpsMapDef(snap.mapId).id;
        setActiveMapId(activeMapIdRef.current);
      }
      const me = snap.players.find((p) => p.id === localPlayerIdRef.current);
      if (me && me.team !== myTeamRef.current) {
        myTeamRef.current = me.team;
        setMyTeam(me.team);
      }
      if (me && Array.isArray(me.ownedWeapons) && me.ownedWeapons.length > 0) {
        if (!me.ownedWeapons.includes(activeWeaponRef.current)) {
          const fallbackWep = me.ownedWeapons.includes("pistol")
            ? "pistol"
            : me.ownedWeapons.includes("starter_pistol")
              ? "starter_pistol"
              : me.ownedWeapons[0];
          activeWeaponRef.current = fallbackWep;
          setActiveWeapon(fallbackWep);
        }
      }

      const roundLiveOrFreeze = snap.phase === "LIVE" || snap.phase === "BUY_FREEZE";
      if (me && !me.alive && roundLiveOrFreeze) {
        setIsScopedSniper(false);
        setLoadoutOpen(false);
        const pool = getLivingSpectatePool(snap, localPlayerIdRef.current);
        const stillAlive = pool.find((p) => p.id === spectateTargetIdRef.current);
        if (!stillAlive) {
          const fallback = pool[0] || null;
          spectateTargetIdRef.current = fallback ? fallback.id : null;
          if (fallback) spectateOrbitRef.current.yaw = fallback.yaw;
          setSpectateTargetId(fallback ? fallback.id : null);
        }
      } else if (spectateTargetIdRef.current !== null) {
        spectateTargetIdRef.current = null;
        setSpectateTargetId(null);
      }

      if (snap.phase === "ROUND_END" || snap.phase === "MATCH_END") {
        setLoadoutOpen(false);
        if (document.pointerLockElement) {
          document.exitPointerLock?.();
        }
      }

      if (snap.phase === "MATCH_END" && !recordedMatchEndRef.current) {
        recordedMatchEndRef.current = true;
        const won = snap.winnerTeam === myTeamRef.current;
        recordStatPatch((st) => ({
          ...st,
          wins: st.wins + (won ? 1 : 0),
          damageDealt: st.damageDealt + (me?.damageDealt || 0),
        }));
      }
      return;
    }

    if (msg.type === "player:joined") {
      const t = msg.team === "syndicate" ? "TEAM BRAVO" : "TEAM ALPHA";
      pushFeed(`${String(msg.playerName)} joined ${t}`);
      return;
    }

    if (msg.type === "player:left") {
      pushFeed(`${String(msg.playerName)} disconnected`);
      return;
    }

    if (msg.type === "player:damaged") {
      audioRef.current.playDamage();
      setDamageFlash(true);
      window.setTimeout(() => setDamageFlash(false), 180);
      return;
    }

    if (msg.type === "player:respawned") {
      const sp = msg.spawn as { x: number; y: number; z: number; yaw: number } | undefined;
      if (sp) pendingSpawnRef.current = sp;
      spectateTargetIdRef.current = null;
      setSpectateTargetId(null);
      if (msg.team === "vanguard" || msg.team === "syndicate") {
        myTeamRef.current = msg.team;
        setMyTeam(msg.team);
      }
      const nextWep = (msg.weaponId as WeaponId) || "starter_pistol";
      if (msg.resetWeapons) {
        setInventory(makeInitialInventory());
        activeWeaponRef.current = nextWep;
        prevWeaponRef.current = nextWep;
        setActiveWeapon(nextWep);
        reloadingRef.current = false;
        setReloading(false);
        recordedMatchEndRef.current = false;
      } else if (nextWep in WEAPONS_BY_ID) {
        activeWeaponRef.current = nextWep;
        setActiveWeapon(nextWep);
      }
      return;
    }

    if (msg.type === "shop:purchased") {
      audioRef.current.playReload();
      if (msg.kind === "weapon" && typeof msg.weaponId === "string" && msg.weaponId in WEAPONS_BY_ID) {
        const boughtId = msg.weaponId as WeaponId;
        const spec = WEAPONS_BY_ID[boughtId];
        setInventory((prev) => ({
          ...prev,
          [boughtId]: { mag: spec.magSize, reserve: spec.reserveMax },
        }));
        prevWeaponRef.current = activeWeaponRef.current;
        activeWeaponRef.current = boughtId;
        setActiveWeapon(boughtId);
        reloadingRef.current = false;
        setReloading(false);
        setShopNotice({
          text: `Purchased & equipped ${spec.name} ($${spec.price})`,
          isError: false,
          stamp: Date.now(),
        });
      } else if (msg.kind === "armor") {
        setShopNotice({
          text: "Ballistic Armor Vest replenished to 50.",
          isError: false,
          stamp: Date.now(),
        });
      }
      return;
    }

    if (msg.type === "shop:error") {
      setShopNotice({
        text: String(msg.message || "Purchase unavailable."),
        isError: true,
        stamp: Date.now(),
      });
      return;
    }

    if (msg.type === "pickup:collected") {
      if (msg.kind === "ammo") {
        setInventory((prev) => {
          const next = { ...prev };
          for (const w of WEAPON_LIST) {
            next[w.id] = {
              mag: prev[w.id].mag,
              reserve: Math.min(w.reserveMax, prev[w.id].reserve + w.magSize * 2),
            };
          }
          return next;
        });
        audioRef.current.playReload();
        pushFeed("Ammo Crate resupplied");
      } else {
        audioRef.current.playObjectiveChime();
        pushFeed("Medkit applied (+40 HP)");
      }
      return;
    }

    if (msg.type === "combat:shot") {
      const shooterId = String(msg.shooterId);
      if (shooterId !== localPlayerIdRef.current) {
        audioRef.current.playShot((msg.weaponId as WeaponId) || "starter_pistol", 0.45);
      }
      tracerQueueRef.current.push({
        shooterId,
        origin: msg.origin as { x: number; y: number; z: number },
        ends: (msg.ends as { x: number; y: number; z: number; hitWorld: boolean }[]) || [],
      });
      return;
    }

    if (msg.type === "combat:hit_confirm") {
      const headshot = Boolean(msg.headshot);
      const damage = Number(msg.damage || 0);
      audioRef.current.playHitmarker(headshot);
      setHitMarker({ headshot, damage, stamp: Date.now() });
      window.setTimeout(() => {
        setHitMarker((cur) => (cur && Date.now() - cur.stamp >= 170 ? null : cur));
      }, 180);
      return;
    }

    if (msg.type === "combat:kill") {
      const wid = (msg.weaponId as WeaponId) || "starter_pistol";
      const isHeadshot = Boolean(msg.headshot) && wid !== "knife";
      const isKnife = wid === "knife";
      const wallbang = Boolean(msg.wallbang);
      if (String(msg.killerId) === localPlayerIdRef.current) {
        recordStatPatch((st) => ({
          ...st,
          kills: st.kills + 1,
          headshots: st.headshots + (isHeadshot ? 1 : 0),
          knifeKills: st.knifeKills + (isKnife ? 1 : 0),
        }));
      }
      const now = Date.now();
      const entry: KillFeedEntry = {
        id: now + Math.random(),
        killerName: String(msg.killerName || "Unknown"),
        killerTeam: msg.killerTeam === "syndicate" ? "syndicate" : "vanguard",
        victimName: String(msg.victimName || "Unknown"),
        victimTeam: msg.victimTeam === "syndicate" ? "syndicate" : "vanguard",
        weaponId: wid,
        headshot: isHeadshot,
        isKnife,
        wallbang,
        expiresAt: now + killFeedDurationRef.current * 1000,
      };
      setKillFeedEntries((prev) => [...prev.filter((k) => k.expiresAt > now).slice(-5), entry]);
      return;
    }

    if (msg.type === "bomb:planted") {
      audioRef.current.playObjectiveChime();
      pushFeed(`AETHER CHARGE PLANTED AT SITE ${String(msg.siteId)} by ${String(msg.planterName)}!`, "alert");
      return;
    }

    if (msg.type === "bomb:defused") {
      audioRef.current.playObjectiveChime();
      pushFeed(`AETHER CHARGE DEFUSED by ${String(msg.defuserName)}!`, "syndicate");
      return;
    }

    if (msg.type === "bomb:detonated") {
      audioRef.current.playExplosion();
      pushFeed(`SITE ${String(msg.siteId)} DETONATED — ALPHA WIN`, "vanguard");
      return;
    }

    if (msg.type === "round:ended") {
      audioRef.current.playRoundHorn();
      const win = msg.winnerTeam === "syndicate" ? "TEAM BRAVO" : "TEAM ALPHA";
      pushFeed(`${win} WINS ROUND — ${String(msg.reason || "")}`, String(msg.winnerTeam));
      return;
    }
  };

  const dispatchHostEvents = useCallback((events: ShooterOutgoingEvent[]) => {
    const transport = roomTransportRef.current;
    if (!transport) return;
    const localId = transport.localPlayerId;
    for (const ev of events) {
      if (ev.targetId) {
        if (ev.targetId === localId) {
          applyShooterMessageRef.current(ev.payload);
        } else {
          transport.send(ev.payload, ev.targetId);
        }
      } else {
        applyShooterMessageRef.current(ev.payload);
        transport.send(ev.payload);
      }
    }
  }, []);

  const startHostSimulation = useCallback(() => {
    if (hostTickTimerRef.current !== null) {
      window.clearInterval(hostTickTimerRef.current);
    }
    let lastTick = performance.now();
    hostTickTimerRef.current = window.setInterval(() => {
      const host = hostEngineRef.current;
      const transport = roomTransportRef.current;
      if (!host || !transport || !transport.getIsHost()) return;

      const now = performance.now();
      const dt = Math.min(0.15, Math.max(0.016, (now - lastTick) / 1000));
      lastTick = now;

      const events = host.tick(dt);
      if (events.length > 0) {
        dispatchHostEvents(events);
      }
      const snap = host.serializeSnapshot();
      applyShooterMessageRef.current(snap as unknown as Record<string, unknown>);
      transport.send(snap as unknown as Record<string, unknown>);

      if (now - lastMetaSyncAtRef.current >= 2500) {
        lastMetaSyncAtRef.current = now;
        const humanCount = Array.from(host.players.values()).filter((p) => !p.isBot).length;
        void transport.updateRoomMeta({
          title: host.title,
          mode: `${host.mode} · ${host.mapId}`,
          players: humanCount,
          maxPlayers: 8,
          round: host.round,
          phase: host.phase,
        });
      }
    }, 70);
  }, [dispatchHostEvents]);

  const sendAction = useCallback(
    (payload: Record<string, unknown>) => {
      const transport = roomTransportRef.current;
      if (!transport) return false;
      if (transport.getIsHost() && hostEngineRef.current) {
        const host = hostEngineRef.current;
        const pid = transport.localPlayerId;
        if (payload.type === "player:state") {
          host.handlePlayerState(pid, payload);
        } else if (payload.type === "player:shoot") {
          const evs = host.handlePlayerShot(
            pid,
            (payload.origin as { x: number; y: number; z: number }) || { x: 0, y: 1.6, z: 0 },
            (payload.rays as { dx: number; dy: number; dz: number }[]) || [],
            payload.weaponId as WeaponId | undefined,
          );
          dispatchHostEvents(evs);
        } else if (payload.type === "player:plant_tick") {
          dispatchHostEvents(host.handlePlantTick(pid));
        } else if (payload.type === "player:defuse_tick") {
          dispatchHostEvents(host.handleDefuseTick(pid));
        } else if (payload.type === "shop:buy") {
          if (typeof payload.weaponId === "string" && payload.weaponId in WEAPONS_BY_ID) {
            dispatchHostEvents(host.buyWeapon(pid, payload.weaponId as WeaponId));
          }
        } else if (payload.type === "shop:buy_armor") {
          dispatchHostEvents(host.buyArmor(pid));
        } else if (payload.type === "switch_team") {
          dispatchHostEvents(host.switchTeam(pid));
        } else if (payload.type === "next_round") {
          dispatchHostEvents(host.continueNextRound());
        } else if (payload.type === "restart_mission") {
          dispatchHostEvents(host.resetMatch());
        }
        return true;
      }
      transport.send(payload);
      return true;
    },
    [dispatchHostEvents],
  );

  useEffect(() => {
    const lobby = createWorkshopLobbyClient({
      channel: "shooter",
      onStateChange: (state, detail) => {
        setNetState(state);
        setNetDetail(detail ?? null);
      },
      onRoomsChange: (rooms: WorkshopRoomSummary[]) => {
        setPublicRooms(
          rooms.map((r) => {
            const parts = String(r.mode || "DEFUSAL").split(" · ");
            const modePart = parts[0] === "TDM" ? "TDM" : "DEFUSAL";
            const mapPart = getFpsMapDef(parts[1]).id;
            return {
              code: r.code,
              title: r.title,
              mapId: mapPart,
              mode: modePart,
              players: r.players,
              maxPlayers: r.maxPlayers,
              round: r.round ?? 1,
              phase: (r.phase as RoundPhase) || "LIVE",
            };
          }),
        );
      },
      onLatency: (rtt) => setLatencyMs(rtt),
    });

    musicRef.current.attach();
    lobbyClientRef.current = lobby;
    lobby.connect();

    return () => {
      clearJoinTimeout();
      stopHostSimulation();
      void roomTransportRef.current?.leave();
      roomTransportRef.current = null;
      void lobby.disconnect();
      lobbyClientRef.current = null;
      audioRef.current.dispose();
      musicRef.current.dispose();
    };
  }, [clearJoinTimeout, stopHostSimulation]);

  const handleReconnect = () => {
    setWsError(null);
    lobbyClientRef.current?.connect();
  };

  const startRoomSession = async (mode: "create" | "join", code?: string) => {
    const cleanName = callsign.trim() || "Operative-01";
    sessionStorage.setItem("gnosis-shooter-name", cleanName);
    setWsError(null);
    clearJoinTimeout();
    stopHostSimulation();
    await roomTransportRef.current?.leave();
    roomTransportRef.current = null;

    const chosenMap = getFpsMapDef(selectedMapId);
    const lobbyLabel = newRoomTitle.trim() || `${chosenMap.name} Arena`;

    const { session, error } = await openWorkshopRoom({
      channel: "shooter",
      mode,
      code,
      playerName: cleanName,
      maxPlayers: 8,
      initialMeta: {
        title: lobbyLabel,
        mode: `${selectedMode} · ${chosenMap.id}`,
        round: 1,
        phase: selectedMode === "DEFUSAL" ? "BUY_FREEZE" : "LIVE",
      },
      joinHelloPayload: { team: selectedTeam },
      onStatusChange: (st, detail) => {
        if (st === "offline" && detail) setWsError(detail);
      },
      onLatency: (rtt) => setLatencyMs(rtt),
      onPeersChange: (peers, _hostId, isHostNow) => {
        if (isHostNow && !hostEngineRef.current && snapshotRef.current) {
          hostEngineRef.current = ShooterRoomHost.fromSnapshot(
            snapshotRef.current as unknown as HostShooterSnapshot,
          );
          startHostSimulation();
          pushFeed("Match host migrated — your client is now coordinating the match.");
        }
        const host = hostEngineRef.current;
        if (host && isHostNow && peers.some((p) => p.playerId === roomTransportRef.current?.localPlayerId)) {
          const presentIds = new Set(peers.map((p) => p.playerId));
          const removedEvents: ShooterOutgoingEvent[] = [];
          for (const pl of Array.from(host.players.values())) {
            if (!pl.isBot && !presentIds.has(pl.id)) {
              removedEvents.push(...host.removePlayer(pl.id));
            }
          }
          if (removedEvents.length > 0) dispatchHostEvents(removedEvents);
        }
      },
      onMessage: (msg) => {
        const transport = roomTransportRef.current;
        if (transport?.getIsHost() && hostEngineRef.current) {
          const host = hostEngineRef.current;
          const sid = msg.senderId;
          if (msg.type === "peer:hello") {
            const pref =
              msg.team === "vanguard" || msg.team === "syndicate" ? msg.team : "auto";
            const added = host.addHumanPlayer(sid, String(msg.playerName || "Operative"), pref);
            if (!added.ok) {
              transport.send({ type: "error", message: added.error || "Room is full." }, sid);
              return;
            }
            dispatchHostEvents(added.events);
            const snap = host.serializeSnapshot();
            applyShooterMessageRef.current(snap as unknown as Record<string, unknown>);
            transport.send(snap as unknown as Record<string, unknown>);
            return;
          }
          if (msg.type === "peer:left") {
            dispatchHostEvents(host.removePlayer(sid));
            return;
          }
          if (msg.type === "player:state") {
            host.handlePlayerState(sid, msg);
            return;
          }
          if (msg.type === "player:shoot") {
            const evs = host.handlePlayerShot(
              sid,
              (msg.origin as { x: number; y: number; z: number }) || { x: 0, y: 1.6, z: 0 },
              (msg.rays as { dx: number; dy: number; dz: number }[]) || [],
              msg.weaponId as WeaponId | undefined,
            );
            dispatchHostEvents(evs);
            return;
          }
          if (msg.type === "player:plant_tick") {
            dispatchHostEvents(host.handlePlantTick(sid));
            return;
          }
          if (msg.type === "player:defuse_tick") {
            dispatchHostEvents(host.handleDefuseTick(sid));
            return;
          }
          if (msg.type === "shop:buy") {
            if (typeof msg.weaponId === "string" && msg.weaponId in WEAPONS_BY_ID) {
              dispatchHostEvents(host.buyWeapon(sid, msg.weaponId as WeaponId));
            }
            return;
          }
          if (msg.type === "shop:buy_armor") {
            dispatchHostEvents(host.buyArmor(sid));
            return;
          }
          if (msg.type === "switch_team") {
            dispatchHostEvents(host.switchTeam(sid));
            return;
          }
          if (msg.type === "next_round") {
            dispatchHostEvents(host.continueNextRound());
            return;
          }
          if (msg.type === "restart_mission") {
            dispatchHostEvents(host.resetMatch());
            return;
          }
        }
        applyShooterMessageRef.current(msg);
      },
    });

    if (error || !session) {
      setWsError(error || "Unable to open Supabase match room.");
      return;
    }

    roomTransportRef.current = session;

    if (mode === "create") {
      const host = new ShooterRoomHost(
        session.code,
        lobbyLabel,
        selectedMode,
        { alphaBots, bravoBots },
        chosenMap.id,
      );
      hostEngineRef.current = host;
      const joined = host.addHumanPlayer(session.localPlayerId, cleanName, selectedTeam);
      dispatchHostEvents(joined.events);
      startHostSimulation();
    } else {
      joinTimeoutRef.current = window.setTimeout(() => {
        if (!snapshotRef.current && roomTransportRef.current === session) {
          setWsError(`Room "${session.code}" host did not respond (match may have closed).`);
          const ghost = session.getPeers().length <= 1;
          void session.leave(ghost);
          roomTransportRef.current = null;
          void lobbyClientRef.current?.refreshRooms();
        }
      }, 4500);
    }
  };

  const handleCreateRoom = () => {
    audioRef.current.initOnGesture();
    musicRef.current.startOnGesture();
    void startRoomSession("create");
  };

  const handleJoinRoom = (code: string) => {
    const clean = code.trim().toUpperCase();
    if (!clean) {
      setWsError("Enter a 5-character match code to join.");
      return;
    }
    audioRef.current.initOnGesture();
    musicRef.current.startOnGesture();
    void startRoomSession("join", clean);
  };

  const handleLeaveRoom = useCallback(() => {
    if (document.pointerLockElement) document.exitPointerLock?.();
    clearJoinTimeout();
    stopHostSimulation();
    void roomTransportRef.current?.leave();
    roomTransportRef.current = null;
    setInRoom(false);
    setSnapshot(null);
    snapshotRef.current = null;
    setLoadoutOpen(false);
    setPauseMenuOpen(false);
    void lobbyClientRef.current?.refreshRooms();
  }, [clearJoinTimeout, stopHostSimulation]);

  const startReload = useCallback(() => {
    const wid = activeWeaponRef.current;
    if (wid === "knife") return;
    const spec = WEAPONS_BY_ID[wid];
    const cur = inventoryRef.current[wid];
    if (reloadingRef.current || cur.mag >= spec.magSize || cur.reserve <= 0) return;

    reloadingRef.current = true;
    setReloading(true);
    audioRef.current.playReload();

    if (reloadTimerRef.current) window.clearTimeout(reloadTimerRef.current);
    reloadTimerRef.current = window.setTimeout(() => {
      setInventory((prev) => {
        const nowSlot = prev[wid];
        const needed = spec.magSize - nowSlot.mag;
        const load = Math.min(needed, nowSlot.reserve);
        return {
          ...prev,
          [wid]: { mag: nowSlot.mag + load, reserve: nowSlot.reserve - load },
        };
      });
      reloadingRef.current = false;
      setReloading(false);
    }, spec.reloadSec * 1000);
  }, []);

  const getMyOwnedWeapons = useCallback((): WeaponId[] => {
    const snap = snapshotRef.current;
    const me = snap?.players.find((p) => p.id === localPlayerIdRef.current);
    const list = me?.ownedWeapons;
    if (Array.isArray(list) && list.length > 0) {
      return list;
    }
    return ["starter_pistol", "knife"];
  }, []);

  const switchWeapon = useCallback(
    (nextId: WeaponId) => {
      const owned = getMyOwnedWeapons();
      if (!owned.includes(nextId)) return;
      if (activeWeaponRef.current === nextId) return;
      prevWeaponRef.current = activeWeaponRef.current;
      if (reloadTimerRef.current) window.clearTimeout(reloadTimerRef.current);
      reloadingRef.current = false;
      setReloading(false);
      inspectTimerRef.current = 0;
      setIsScopedSniper(false);
      setActiveWeapon(nextId);
      activeWeaponRef.current = nextId;
    },
    [getMyOwnedWeapons],
  );

  // Main 3D Competitive Arena Engine (supports all 4 maps, weapon skins, knives & inspect)
  useEffect(() => {
    if (!inRoom) return;
    const container = mountRef.current;
    if (!container) return;

    const mapDef = getFpsMapDef(activeMapId);
    const q = settingsRef.current.graphicsQuality;
    const w = container.clientWidth || 1024;
    const h = container.clientHeight || 620;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(mapDef.skyHex);
    scene.fog = new THREE.Fog(mapDef.fogHex, 52, 168);

    const camera = new THREE.PerspectiveCamera(settingsRef.current.fov || 74, w / h, 0.08, 280);
    camera.rotation.order = "YXZ";
    scene.add(camera);

    const renderer = new THREE.WebGLRenderer({ antialias: q !== "low", powerPreference: "high-performance" });
    const gl = renderer.getContext();
    const glRendererName = String(gl?.getParameter(gl.RENDERER) || "").toLowerCase();
    const isSoftwareGl =
      glRendererName.includes("swiftshader") ||
      glRendererName.includes("llvmpipe") ||
      glRendererName.includes("software");

    const maxRatio = q === "low" ? 1 : q === "medium" ? 1.4 : 2;
    renderer.setSize(w, h);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, maxRatio));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = mapDef.id === "mansion" ? 1.12 : 1.06;
    renderer.shadowMap.enabled = q !== "low";
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    if (isSoftwareGl) {
      renderer.shadowMap.autoUpdate = false;
      renderer.shadowMap.needsUpdate = true;
    }
    renderer.domElement.style.display = "block";
    renderer.domElement.style.width = "100%";
    renderer.domElement.style.height = "100%";
    renderer.domElement.tabIndex = 0;
    renderer.domElement.style.outline = "none";
    container.appendChild(renderer.domElement);
    (document.activeElement as HTMLElement | null)?.blur?.();
    renderer.domElement.focus({ preventScroll: true });

    const pmrem = new THREE.PMREMGenerator(renderer);
    const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;
    pmrem.dispose();

    const hemi = new THREE.HemisphereLight(
      mapDef.id === "mansion" ? 0xc2d5f5 : 0xd9ecff,
      mapDef.id === "mansion" ? 0x4b4036 : 0x7a6a58,
      mapDef.id === "mansion" ? 0.92 : 0.85,
    );
    scene.add(hemi);

    const sunLight = new THREE.DirectionalLight(mapDef.sunHex, mapDef.id === "mansion" ? 1.35 : 1.65);
    sunLight.position.set(44, 72, 34);
    sunLight.castShadow = q !== "low";
    sunLight.shadow.mapSize.set(
      isSoftwareGl || q === "low" ? 512 : q === "medium" ? 1024 : 2048,
      isSoftwareGl || q === "low" ? 512 : q === "medium" ? 1024 : 2048,
    );
    sunLight.shadow.camera.left = -64;
    sunLight.shadow.camera.right = 64;
    sunLight.shadow.camera.top = 64;
    sunLight.shadow.camera.bottom = -64;
    scene.add(sunLight);

    const maxAniso = isSoftwareGl ? 1 : Math.min(8, renderer.capabilities.getMaxAnisotropy());
    const arena = buildArenaScene(scene, maxAniso, mapDef.id);

    // First-person viewmodels with equipped skins & selected melee knife
    const weaponRigHolder = new THREE.Group();
    camera.add(weaponRigHolder);

    let builtViewSignature = `${myTeamRef.current}|${JSON.stringify(cosmeticsRef.current)}`;
    const buildAllViewModels = (team: ShooterTeam): Record<WeaponId, DetailedWeaponBundle> => {
      const hex = team === "vanguard" ? 0xe69f3a : 0x3b86d1;
      const cos = cosmeticsRef.current;
      return {
        starter_pistol: buildFirstPersonWeapon("starter_pistol", hex, cos.equippedSkins.starter_pistol, cos.equippedKnife, cos.operative.gloveHex),
        carbine: buildFirstPersonWeapon("carbine", hex, cos.equippedSkins.carbine, cos.equippedKnife, cos.operative.gloveHex),
        smg: buildFirstPersonWeapon("smg", hex, cos.equippedSkins.smg, cos.equippedKnife, cos.operative.gloveHex),
        shotgun: buildFirstPersonWeapon("shotgun", hex, cos.equippedSkins.shotgun, cos.equippedKnife, cos.operative.gloveHex),
        pistol: buildFirstPersonWeapon("pistol", hex, cos.equippedSkins.pistol, cos.equippedKnife, cos.operative.gloveHex),
        sniper: buildFirstPersonWeapon("sniper", hex, cos.equippedSkins.sniper, cos.equippedKnife, cos.operative.gloveHex),
        knife: buildFirstPersonWeapon("knife", hex, cos.equippedSkins.knife, cos.equippedKnife, cos.operative.gloveHex),
      };
    };

    let viewModels = buildAllViewModels(myTeamRef.current);
    const attachViewModels = () => {
      for (const id of Object.keys(viewModels) as WeaponId[]) {
        viewModels[id].group.visible = id === activeWeaponRef.current;
        weaponRigHolder.add(viewModels[id].group);
      }
    };
    attachViewModels();

    const rebuildViewModels = (team: ShooterTeam) => {
      for (const id of Object.keys(viewModels) as WeaponId[]) {
        weaponRigHolder.remove(viewModels[id].group);
        disposeHierarchy(viewModels[id].group);
      }
      builtViewSignature = `${team}|${JSON.stringify(cosmeticsRef.current)}`;
      viewModels = buildAllViewModels(team);
      attachViewModels();
    };

    const remoteRigs = new Map<
      string,
      {
        rig: BlockyCharacterRig;
        team: ShooterTeam;
        weaponId: WeaponId;
        flashTimer: number;
        walkPhase: number;
        crouchBlend: number;
        prevX: number;
        prevZ: number;
      }
    >();

    const tracerPool: { line: THREE.Line; life: number }[] = [];
    const sparkPool: { mesh: THREE.Mesh; life: number }[] = [];
    const sparkGeo = new THREE.SphereGeometry(0.11, 6, 6);
    const sparkMat = new THREE.MeshBasicMaterial({ color: 0xffd275 });

    const initSpawn = pendingSpawnRef.current || {
      x: 0,
      y: 0,
      z: myTeamRef.current === "vanguard" ? 40 : -40,
      yaw: myTeamRef.current === "vanguard" ? 0 : Math.PI,
    };
    pendingSpawnRef.current = null;

    const player = {
      x: initSpawn.x,
      y: initSpawn.y,
      z: initSpawn.z,
      vy: 0,
      yaw: initSpawn.yaw,
      pitch: 0,
      grounded: true,
      crouching: false,
      sprinting: false,
      recoilPitch: 0,
      recoilYaw: 0,
      weaponKick: 0,
      flashTimer: 0,
      walkPhase: 0,
      spreadAccum: 0,
      lastFireMs: 0,
      ads: false,
      triggerHeld: false,
      semiNeedsRelease: false,
    };

    const keys: Record<string, boolean> = {};
    const clearKeys = () => {
      for (const prop of Object.keys(keys)) delete keys[prop];
    };
    const isInputFocused = (target: EventTarget | null) =>
      target instanceof HTMLInputElement ||
      target instanceof HTMLTextAreaElement ||
      target instanceof HTMLSelectElement;
    let isDraggingLook = false;

    const onKeyDown = (e: KeyboardEvent) => {
      if (isInputFocused(e.target)) return;
      const k = e.key.toLowerCase();
      if (
        ["Space", "Tab", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code) ||
        [" ", "tab", "arrowup", "arrowdown", "arrowleft", "arrowright"].includes(k)
      ) {
        e.preventDefault();
      }
      audioRef.current.initOnGesture();
      musicRef.current.startOnGesture();

      keys[k] = true;
      if (e.code) keys[e.code] = true;
      if (k === "tab" || e.code === "Tab") setScoreboardOpen(true);

      const snapNow = snapshotRef.current;
      const meNow = snapNow?.players.find((p) => p.id === localPlayerIdRef.current);
      const spectatingNow = Boolean(
        meNow && !meNow.alive && snapNow && (snapNow.phase === "LIVE" || snapNow.phase === "BUY_FREEZE"),
      );

      if (!e.repeat) {
        if (spectatingNow && !modalOpenRef.current) {
          if (e.code === "ArrowLeft" || k === "arrowleft" || k === "a" || e.code === "KeyA") {
            cycleSpectateTarget(-1);
          } else if (e.code === "ArrowRight" || k === "arrowright" || k === "d" || e.code === "KeyD") {
            cycleSpectateTarget(1);
          }
        }
        if (k === "m" || e.code === "KeyM") {
          updateWorkshopSettings({ muted: !settingsRef.current.muted });
        } else if (k === "p" || e.code === "KeyP") {
          setLoadoutOpen(false);
          setPauseMenuOpen((p) => {
            const next = !p;
            if (next && document.pointerLockElement === renderer.domElement) {
              document.exitPointerLock?.();
            }
            return next;
          });
        } else if (!spectatingNow) {
          const owned = getMyOwnedWeapons();
          const ownedPrimary = owned.find((w) => WEAPONS_BY_ID[w].equipSlot === "primary");
          const ownedSecondary = owned.find((w) => WEAPONS_BY_ID[w].equipSlot === "secondary") || "starter_pistol";
          if (k === "1" || e.code === "Digit1") {
            if (ownedPrimary) switchWeapon(ownedPrimary);
          } else if (k === "2" || e.code === "Digit2") {
            switchWeapon(ownedSecondary);
          } else if (k === "3" || e.code === "Digit3" || k === "v" || e.code === "KeyV") {
            switchWeapon("knife");
          } else if (k === "q" || e.code === "KeyQ") {
            const candidate = prevWeaponRef.current;
            const fallback = ownedPrimary || ownedSecondary;
            if (activeWeaponRef.current === "knife") {
              switchWeapon(owned.includes(candidate) && candidate !== "knife" ? candidate : fallback);
            } else {
              switchWeapon(owned.includes(candidate) && candidate !== activeWeaponRef.current ? candidate : "knife");
            }
          } else if (k === "r" || e.code === "KeyR") startReload();
          else if (k === "f" || e.code === "KeyF") {
            inspectTimerRef.current = 1.9;
          } else if (k === "b" || e.code === "KeyB") {
            setPauseMenuOpen(false);
            setLoadoutOpen((open) => {
              const next = !open;
              if (next && document.pointerLockElement === renderer.domElement) {
                document.exitPointerLock?.();
              }
              return next;
            });
          }
        }
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      keys[k] = false;
      if (e.code) keys[e.code] = false;
      if (k === "tab" || e.code === "Tab") setScoreboardOpen(false);
    };

    const onMouseMove = (e: MouseEvent) => {
      if (modalOpenRef.current) return;
      const locked = document.pointerLockElement === renderer.domElement;
      if (!locked && !isDraggingLook) return;
      const sensScale = settingsRef.current.mouseSensitivity || 1;
      const snapNow = snapshotRef.current;
      const meNow = snapNow?.players.find((p) => p.id === localPlayerIdRef.current);
      const spectatingNow = Boolean(
        meNow && !meNow.alive && snapNow && (snapNow.phase === "LIVE" || snapNow.phase === "BUY_FREEZE"),
      );
      if (spectatingNow) {
        const orbitSens = 0.0026 * sensScale;
        spectateOrbitRef.current.yaw -= e.movementX * orbitSens;
        spectateOrbitRef.current.pitch = THREE.MathUtils.clamp(
          spectateOrbitRef.current.pitch + e.movementY * orbitSens,
          -0.25,
          1.1,
        );
        return;
      }
      const baseSens = player.ads && activeWeaponRef.current === "sniper" ? 0.001 : 0.0022;
      const sens = baseSens * sensScale;
      player.yaw -= e.movementX * sens;
      player.pitch = THREE.MathUtils.clamp(player.pitch - e.movementY * sens, -1.48, 1.48);
    };

    const onMouseDown = (e: MouseEvent) => {
      if (modalOpenRef.current) return;
      const snapNow = snapshotRef.current;
      const meNow = snapNow?.players.find((p) => p.id === localPlayerIdRef.current);
      const spectatingNow = Boolean(
        meNow && !meNow.alive && snapNow && (snapNow.phase === "LIVE" || snapNow.phase === "BUY_FREEZE"),
      );
      audioRef.current.initOnGesture();
      musicRef.current.startOnGesture();
      (document.activeElement as HTMLElement | null)?.blur?.();
      renderer.domElement.focus({ preventScroll: true });
      if (e.button === 0) {
        if (document.pointerLockElement !== renderer.domElement) {
          renderer.domElement.requestPointerLock?.();
          isDraggingLook = true;
        }
        if (!spectatingNow) player.triggerHeld = true;
      } else if (e.button === 2) {
        if (spectatingNow || activeWeaponRef.current === "knife") return;
        player.ads = true;
        if (activeWeaponRef.current === "sniper") setIsScopedSniper(true);
      }
    };

    const onMouseUp = (e: MouseEvent) => {
      if (e.button === 0) {
        player.triggerHeld = false;
        player.semiNeedsRelease = false;
        isDraggingLook = false;
      } else if (e.button === 2) {
        player.ads = false;
        setIsScopedSniper(false);
      }
    };

    const onWheel = (e: WheelEvent) => {
      if (modalOpenRef.current) return;
      const owned = getMyOwnedWeapons();
      if (owned.length <= 1) return;
      const idx = Math.max(0, owned.findIndex((id) => id === activeWeaponRef.current));
      const next = (idx + (e.deltaY > 0 ? 1 : -1) + owned.length) % owned.length;
      switchWeapon(owned[next]);
    };

    const onPointerLockChange = () => {
      setPointerLocked(document.pointerLockElement === renderer.domElement);
    };

    const onContextMenu = (e: MouseEvent) => e.preventDefault();

    window.addEventListener("keydown", onKeyDown, { capture: true, passive: false });
    window.addEventListener("keyup", onKeyUp, { capture: true });
    window.addEventListener("blur", clearKeys);
    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup", onMouseUp);
    document.addEventListener("pointerlockchange", onPointerLockChange);
    renderer.domElement.addEventListener("mousedown", onMouseDown);
    renderer.domElement.addEventListener("wheel", onWheel, { passive: true });
    renderer.domElement.addEventListener("contextmenu", onContextMenu);

    const onResize = () => {
      if (!container) return;
      const nw = container.clientWidth;
      const nh = container.clientHeight;
      if (nw <= 0 || nh <= 0) return;
      camera.aspect = nw / nh;
      camera.updateProjectionMatrix();
      renderer.setSize(nw, nh);
    };
    const ro = new ResizeObserver(onResize);
    ro.observe(container);

    const spawnVisualTracer = (
      from: { x: number; y: number; z: number },
      to: { x: number; y: number; z: number },
      hitWorld: boolean,
      teamColorHex: number,
    ) => {
      const pts = [new THREE.Vector3(from.x, from.y, from.z), new THREE.Vector3(to.x, to.y, to.z)];
      const geo = new THREE.BufferGeometry().setFromPoints(pts);
      const mat = new THREE.LineBasicMaterial({ color: teamColorHex, transparent: true, opacity: 0.9 });
      const line = new THREE.Line(geo, mat);
      scene.add(line);
      tracerPool.push({ line, life: 0.085 });

      if (hitWorld) {
        const sp = new THREE.Mesh(sparkGeo, sparkMat);
        sp.position.set(to.x, to.y, to.z);
        scene.add(sp);
        sparkPool.push({ mesh: sp, life: 0.22 });
      }
    };

    const tryFireWeapon = (nowMs: number, moveSpeed: number) => {
      const snap = snapshotRef.current;
      const me = snap?.players.find((p) => p.id === localPlayerIdRef.current);
      if (snap?.phase !== "LIVE" || (me && !me.alive) || reloadingRef.current) return;

      const wid = activeWeaponRef.current;
      const spec = WEAPONS_BY_ID[wid];
      if ((spec.fireMode === "SEMI" || spec.fireMode === "MELEE") && player.semiNeedsRelease) return;

      const intervalMs = 60000 / spec.rpm;
      if (nowMs - player.lastFireMs < intervalMs) return;

      const eyeY = player.y + (player.crouching ? 1.08 : 1.62);
      const effectivePitch = THREE.MathUtils.clamp(player.pitch + player.recoilPitch, -1.5, 1.5);
      const effectiveYaw = player.yaw + player.recoilYaw;
      const forward = new THREE.Vector3(0, 0, -1).applyEuler(
        new THREE.Euler(effectivePitch, effectiveYaw, 0, "YXZ"),
      );

      if (wid === "knife") {
        player.lastFireMs = nowMs;
        player.semiNeedsRelease = true;
        meleeSwingTimerRef.current = 0.28;
        inspectTimerRef.current = 0;
        audioRef.current.playKnifeSwing();
        sendAction({
          type: "player:shoot",
          weaponId: "knife",
          origin: { x: player.x, y: eyeY, z: player.z },
          rays: [{ dx: forward.x, dy: forward.y, dz: forward.z }],
        });
        return;
      }

      const slot = inventoryRef.current[wid];
      if (slot.mag <= 0) {
        if (slot.reserve > 0) startReload();
        return;
      }

      player.lastFireMs = nowMs;
      if (spec.fireMode === "SEMI") player.semiNeedsRelease = true;
      inspectTimerRef.current = 0;

      setInventory((prev) => ({
        ...prev,
        [wid]: { ...prev[wid], mag: Math.max(0, prev[wid].mag - 1) },
      }));

      audioRef.current.playShot(wid, 1);

      const baseOrAds = player.ads ? spec.adsSpread : spec.baseSpread;
      const crouchFactor = player.crouching ? spec.crouchMult : 1.0;
      const spread =
        baseOrAds * crouchFactor +
        (moveSpeed > 0.6 ? spec.moveSpread * (moveSpeed / 8.5) : 0) +
        (!player.grounded ? spec.airSpread : 0) +
        player.spreadAccum;

      const right = new THREE.Vector3(1, 0, 0).applyEuler(
        new THREE.Euler(effectivePitch, effectiveYaw, 0, "YXZ"),
      );
      const up = new THREE.Vector3().crossVectors(right, forward).normalize();

      const rays: { dx: number; dy: number; dz: number }[] = [];
      for (let i = 0; i < spec.pellets; i++) {
        const rx = (Math.random() - 0.5) * 2 * spread;
        const ry = (Math.random() - 0.5) * 2 * spread;
        const d = forward.clone().addScaledVector(right, rx).addScaledVector(up, ry).normalize();
        rays.push({ dx: d.x, dy: d.y, dz: d.z });
      }

      sendAction({
        type: "player:shoot",
        weaponId: wid,
        origin: { x: player.x, y: eyeY, z: player.z },
        rays,
      });

      const adsRecoilMult = (player.ads ? 0.72 : 1.0) * (player.crouching ? 0.8 : 1.0);
      player.recoilPitch += spec.recoilPitch * adsRecoilMult;
      player.recoilYaw += (Math.random() - 0.45) * spec.recoilYaw * adsRecoilMult;
      player.spreadAccum = Math.min(0.055, player.spreadAccum + 0.0055);
      player.weaponKick = wid === "shotgun" || wid === "sniper" ? 0.14 : 0.075;
      player.flashTimer = 0.05;
    };

    const drawMinimap = (snap: RoomSnapshot | null, spectateFocus?: NetPlayer | null) => {
      const mc = minimapCanvasRef.current;
      if (!mc) return;
      const ctx = mc.getContext("2d");
      if (!ctx) return;

      const cw = mc.width;
      const ch = mc.height;
      const mapX = (wx: number) => ((wx + mapDef.halfW) / (mapDef.halfW * 2)) * cw;
      const mapY = (wz: number) => ((wz + mapDef.halfD) / (mapDef.halfD * 2)) * ch;

      ctx.clearRect(0, 0, cw, ch);
      ctx.fillStyle = "rgba(15, 20, 28, 0.92)";
      ctx.fillRect(0, 0, cw, ch);

      for (const b of mapDef.boxes) {
        if (b.kind === "wall" || b.style === "mansion-roof") continue;
        const x = mapX(b.x - b.w * 0.5);
        const y = mapY(b.z - b.d * 0.5);
        const bw = (b.w / (mapDef.halfW * 2)) * cw;
        const bh = (b.d / (mapDef.halfD * 2)) * ch;
        ctx.fillStyle =
          b.style === "wood-door" || b.style === "wood-wall" || b.style === "crate"
            ? "#8c5c32"
            : b.style === "hedge"
              ? "#2d6133"
              : b.kind === "building"
                ? "#526074"
                : b.kind === "platform"
                  ? "#6c798f"
                  : "#3b4557";
        ctx.fillRect(x, y, Math.max(2, bw), Math.max(2, bh));
      }

      for (const site of mapDef.bombSites) {
        const sx = mapX(site.x);
        const sy = mapY(site.z);
        const sr = (site.radius / (mapDef.halfW * 2)) * cw;
        ctx.strokeStyle = site.id === "A" ? "#f2a93b" : "#4cc4ff";
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(sx, sy, sr, 0, Math.PI * 2);
        ctx.stroke();
        ctx.fillStyle = site.id === "A" ? "#f2a93b" : "#4cc4ff";
        ctx.font = "bold 10px monospace";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(site.id, sx, sy);
      }

      if (snap?.bombPlanted) {
        const bx = mapX(snap.bombX);
        const by = mapY(snap.bombZ);
        ctx.fillStyle = "#ff453a";
        ctx.beginPath();
        ctx.arc(bx, by, 4.5, 0, Math.PI * 2);
        ctx.fill();
      }

      const focusTeam = spectateFocus ? spectateFocus.team : myTeamRef.current;
      if (snap) {
        for (const rp of snap.players) {
          if (rp.id === localPlayerIdRef.current || rp.id === spectateFocus?.id || !rp.alive) continue;
          if (rp.team !== focusTeam) continue;
          const px = mapX(rp.x);
          const py = mapY(rp.z);
          ctx.fillStyle = rp.team === "vanguard" ? "#f2a93b" : "#4ea8ff";
          ctx.beginPath();
          ctx.arc(px, py, 3.2, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      const focusPx = spectateFocus ? spectateFocus.x : player.x;
      const focusPz = spectateFocus ? spectateFocus.z : player.z;
      const focusYaw = spectateFocus ? spectateFocus.yaw : player.yaw;
      const lx = mapX(focusPx);
      const ly = mapY(focusPz);
      const lookX = -Math.sin(focusYaw);
      const lookZ = -Math.cos(focusYaw);
      ctx.strokeStyle = "rgba(255,255,255,0.45)";
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.moveTo(lx, ly);
      ctx.lineTo(lx + lookX * 14, ly + lookZ * 14);
      ctx.stroke();

      ctx.fillStyle = spectateFocus ? "#ffe066" : "#ffffff";
      ctx.beginPath();
      ctx.arc(lx, ly, 3.8, 0, Math.PI * 2);
      ctx.fill();
    };

    const clock = new THREE.Clock();
    let rafId = 0;
    let disposed = false;
    let lastNetSend = 0;
    let lastBombInteract = 0;
    let lastBombBeepAt = 0;
    let lastUiSyncAt = 0;
    let prevCallout = "";
    let prevObjPrompt: string | null = null;

    const tick = () => {
      if (disposed) return;
      const dt = Math.min(clock.getDelta(), 0.05);
      const nowMs = performance.now();

      const desiredSig = `${myTeamRef.current}|${JSON.stringify(cosmeticsRef.current)}`;
      if (desiredSig !== builtViewSignature) {
        rebuildViewModels(myTeamRef.current);
      }

      if (pendingSpawnRef.current) {
        player.x = pendingSpawnRef.current.x;
        player.y = pendingSpawnRef.current.y;
        player.z = pendingSpawnRef.current.z;
        player.yaw = pendingSpawnRef.current.yaw;
        player.vy = 0;
        pendingSpawnRef.current = null;
      }

      const snap = snapshotRef.current;
      const me = snap?.players.find((p) => p.id === localPlayerIdRef.current);
      const isAlive = me ? me.alive : true;
      const isSpectating = Boolean(
        me && !me.alive && snap && (snap.phase === "LIVE" || snap.phase === "BUY_FREEZE"),
      );
      if (isSpectating) {
        player.triggerHeld = false;
        player.ads = false;
      }
      const canMove =
        isAlive &&
        Boolean(snap) &&
        snap!.phase !== "BUY_FREEZE" &&
        snap!.phase !== "ROUND_END" &&
        snap!.phase !== "MATCH_END" &&
        !modalOpenRef.current;

      const spec = WEAPONS_BY_ID[activeWeaponRef.current];

      let moveHorizSpeed = 0;
      if (canMove) {
        player.crouching = Boolean(
          keys["c"] || keys["KeyC"] || keys["control"] || keys["ControlLeft"] || keys["ControlRight"],
        );
        player.sprinting = Boolean(
          (keys["shift"] || keys["ShiftLeft"] || keys["ShiftRight"]) && !player.crouching && !player.ads,
        );

        const fwdInput =
          (keys["w"] || keys["KeyW"] || keys["arrowup"] || keys["ArrowUp"] ? 1 : 0) -
          (keys["s"] || keys["KeyS"] || keys["arrowdown"] || keys["ArrowDown"] ? 1 : 0);
        const sideInput =
          (keys["d"] || keys["KeyD"] || keys["arrowright"] || keys["ArrowRight"] ? 1 : 0) -
          (keys["a"] || keys["KeyA"] || keys["arrowleft"] || keys["ArrowLeft"] ? 1 : 0);

        const rawSpeed = player.crouching ? 4.3 : player.sprinting ? 10.4 : 7.5;
        const speedWithWeight = rawSpeed * spec.moveSpeedMult;
        const fx = -Math.sin(player.yaw);
        const fz = -Math.cos(player.yaw);
        const rx = Math.cos(player.yaw);
        const rz = -Math.sin(player.yaw);

        let mx = fx * fwdInput + rx * sideInput;
        let mz = fz * fwdInput + rz * sideInput;
        const mLen = Math.hypot(mx, mz);
        if (mLen > 0.001) {
          mx /= mLen;
          mz /= mLen;
          moveHorizSpeed = speedWithWeight;
          player.walkPhase += dt * (player.sprinting ? 13 : 9);
        }

        if ((keys[" "] || keys["Space"]) && player.grounded) {
          player.vy = 7.5;
          player.grounded = false;
        }

        player.vy -= 20.5 * dt;
        player.x += mx * moveHorizSpeed * dt;
        player.z += mz * moveHorizSpeed * dt;
        player.y += player.vy * dt;

        const col = resolveCircleBoxCollisions(player.x, player.y, player.z, 0.56, mapDef.id);
        player.x = col.x;
        player.z = col.z;
        if (player.y <= col.floorY + 0.01) {
          player.y = col.floorY;
          player.vy = 0;
          player.grounded = true;
        } else {
          player.grounded = false;
        }
      }

      let activeSpectateTarget: NetPlayer | null = null;
      if (isSpectating && snap) {
        const livingPool = snap.players.filter((p) => p.alive && p.id !== localPlayerIdRef.current);
        activeSpectateTarget =
          livingPool.find((p) => p.id === spectateTargetIdRef.current) || livingPool[0] || null;
        if ((activeSpectateTarget?.id ?? null) !== spectateTargetIdRef.current) {
          spectateTargetIdRef.current = activeSpectateTarget ? activeSpectateTarget.id : null;
          setSpectateTargetId(spectateTargetIdRef.current);
        }
      }

      let nextObjPrompt: string | null = null;
      if (snap?.mode === "DEFUSAL" && snap.phase === "LIVE" && isAlive) {
        if (myTeamRef.current === "vanguard" && !snap.bombPlanted) {
          const site = mapDef.bombSites.find(
            (s) => Math.hypot(player.x - s.x, player.z - s.z) <= s.radius && Math.abs(player.y - s.y) <= 2.4,
          );
          if (site) {
            nextObjPrompt = `HOLD [E] TO PLANT AETHER CHARGE (${site.callout})`;
            if ((keys["e"] || keys["KeyE"]) && nowMs - lastBombInteract >= 160) {
              lastBombInteract = nowMs;
              sendAction({ type: "player:plant_tick" });
            }
          }
        } else if (myTeamRef.current === "syndicate" && snap.bombPlanted) {
          const distToBomb = Math.hypot(player.x - snap.bombX, player.z - snap.bombZ);
          if (distToBomb <= 4.2 && Math.abs(player.y - snap.bombY) <= 2.4) {
            nextObjPrompt = "HOLD [E] TO DEFUSE AETHER CHARGE";
            if ((keys["e"] || keys["KeyE"]) && nowMs - lastBombInteract >= 160) {
              lastBombInteract = nowMs;
              sendAction({ type: "player:defuse_tick" });
            }
          }
        }
      }

      if (nowMs - lastUiSyncAt >= 90) {
        lastUiSyncAt = nowMs;
        const calloutX = activeSpectateTarget ? activeSpectateTarget.x : player.x;
        const calloutZ = activeSpectateTarget ? activeSpectateTarget.z : player.z;
        const callout = getMapCallout(calloutX, calloutZ, mapDef.id);
        if (callout !== prevCallout) {
          prevCallout = callout;
          setCalloutName(callout);
        }
        if (nextObjPrompt !== prevObjPrompt) {
          prevObjPrompt = nextObjPrompt;
          setObjectivePrompt(nextObjPrompt);
        }
        drawMinimap(snap, activeSpectateTarget);
      }

      if (player.triggerHeld && !modalOpenRef.current && !isSpectating) {
        tryFireWeapon(nowMs, moveHorizSpeed);
      }
      player.recoilPitch = THREE.MathUtils.damp(player.recoilPitch, 0, spec.recoilRecovery, dt);
      player.recoilYaw = THREE.MathUtils.damp(player.recoilYaw, 0, spec.recoilRecovery, dt);
      player.spreadAccum = THREE.MathUtils.damp(player.spreadAccum, 0, 8.5, dt);
      player.weaponKick = THREE.MathUtils.damp(player.weaponKick, 0, 14, dt);
      if (player.flashTimer > 0) player.flashTimer -= dt;
      if (inspectTimerRef.current > 0) inspectTimerRef.current = Math.max(0, inspectTimerRef.current - dt);
      if (meleeSwingTimerRef.current > 0) meleeSwingTimerRef.current = Math.max(0, meleeSwingTimerRef.current - dt);

      if (crosshairGapRef.current) {
        const dynamicGap = Math.round(
          THREE.MathUtils.clamp(
            8 + (moveHorizSpeed / 10) * 10 + player.spreadAccum * 320 + (player.ads ? -5 : 0),
            4,
            34,
          ),
        );
        crosshairGapRef.current.style.setProperty("--gap", `${dynamicGap}px`);
      }

      if (isSpectating && activeSpectateTarget) {
        const rigEntry = remoteRigs.get(activeSpectateTarget.id);
        const focusX = rigEntry ? rigEntry.rig.group.position.x : activeSpectateTarget.x;
        const focusY = (rigEntry ? rigEntry.rig.group.position.y : activeSpectateTarget.y) + (activeSpectateTarget.crouching ? 1.15 : 1.58);
        const focusZ = rigEntry ? rigEntry.rig.group.position.z : activeSpectateTarget.z;

        const orbitYaw = spectateOrbitRef.current.yaw;
        const orbitPitch = spectateOrbitRef.current.pitch;
        const cosP = Math.cos(orbitPitch);
        const dirX = Math.sin(orbitYaw) * cosP;
        const dirY = Math.sin(orbitPitch);
        const dirZ = Math.cos(orbitYaw) * cosP;
        const desiredDist = 3.5;
        const wallHit = raycastArenaObstacles(focusX, focusY, focusZ, dirX, dirY, dirZ, desiredDist, mapDef.id);
        const safeDist = Math.max(0.75, Math.min(desiredDist, wallHit - 0.35));

        const desiredCamPos = new THREE.Vector3(
          focusX + dirX * safeDist,
          Math.max(0.45, focusY + dirY * safeDist),
          focusZ + dirZ * safeDist,
        );
        camera.position.lerp(desiredCamPos, 1 - Math.exp(-16 * dt));
        camera.lookAt(focusX, focusY, focusZ);
      } else {
        const eyeHeight = player.crouching ? 1.08 : 1.62;
        camera.position.set(player.x, player.y + eyeHeight, player.z);
        camera.rotation.y = player.yaw + player.recoilYaw;
        camera.rotation.x = THREE.MathUtils.clamp(player.pitch + player.recoilPitch, -1.5, 1.5);
      }

      const baseFov = settingsRef.current.fov || 74;
      const desiredFov = isSpectating
        ? baseFov
        : player.ads
          ? spec.adsFov
          : player.sprinting
            ? Math.min(104, baseFov + 6)
            : baseFov;
      if (Math.abs(camera.fov - desiredFov) > 0.1) {
        camera.fov = THREE.MathUtils.damp(camera.fov, desiredFov, 14, dt);
        camera.updateProjectionMatrix();
      }

      const showViewModel = !isSpectating && isAlive && !(player.ads && activeWeaponRef.current === "sniper");
      for (const id of Object.keys(viewModels) as WeaponId[]) {
        const vm = viewModels[id];
        const active = id === activeWeaponRef.current;
        vm.group.visible = showViewModel && active;
        vm.muzzleFlash.visible = showViewModel && player.flashTimer > 0 && active && id !== "knife";
        if (active && vm.bladePivot && inspectTimerRef.current > 0) {
          vm.bladePivot.rotation.z = Math.sin((1.9 - inspectTimerRef.current) * 6.5) * 0.45;
        } else if (vm.bladePivot) {
          vm.bladePivot.rotation.z = 0;
        }
      }

      const adsCenterX = player.ads ? 0 : activeWeaponRef.current === "knife" ? 0.25 : 0.22;
      const adsCenterY = player.ads ? -0.15 : -0.21;
      const bobX = moveHorizSpeed > 0.5 && !player.ads ? Math.sin(player.walkPhase) * 0.012 : 0;
      const bobY = moveHorizSpeed > 0.5 && !player.ads ? Math.abs(Math.cos(player.walkPhase)) * 0.012 : 0;
      const reloadDip = reloadingRef.current ? -0.26 : 0;
      const inspectProg = inspectTimerRef.current > 0 ? Math.sin((1.9 - inspectTimerRef.current) * 1.65) : 0;
      const slashProg = meleeSwingTimerRef.current > 0 ? Math.sin((0.28 - meleeSwingTimerRef.current) / 0.28 * Math.PI) : 0;

      weaponRigHolder.position.set(
        adsCenterX + bobX - slashProg * 0.16,
        adsCenterY - bobY + reloadDip + inspectProg * 0.04,
        -0.35 + player.weaponKick - slashProg * 0.18,
      );
      weaponRigHolder.rotation.set(
        player.weaponKick * 0.65 + (reloadingRef.current ? -0.45 : 0) - slashProg * 0.68,
        inspectProg * 0.72 + slashProg * 0.52,
        inspectProg * 0.28,
      );

      if (nowMs - lastNetSend >= 60) {
        lastNetSend = nowMs;
        sendAction({
          type: "player:state",
          x: player.x,
          y: player.y,
          z: player.z,
          yaw: player.yaw,
          pitch: player.pitch,
          crouching: player.crouching,
          weaponId: activeWeaponRef.current,
        });
      }

      const activeRemoteIds = new Set<string>();
      const netBlend = 1 - Math.exp(-20 * dt);
      if (snap) {
        for (const rp of snap.players) {
          if (rp.id === localPlayerIdRef.current) continue;
          activeRemoteIds.add(rp.id);
          let entry = remoteRigs.get(rp.id);
          const desiredWeapon = rp.weaponId || "starter_pistol";
          if (!entry || entry.team !== rp.team || entry.weaponId !== desiredWeapon) {
            if (entry) {
              scene.remove(entry.rig.group);
              disposeHierarchy(entry.rig.group);
            }
            const rig = buildOperativeModel(
              rp.team,
              rp.name,
              cosmeticsRef.current.operative,
              desiredWeapon === "knife" ? "starter_pistol" : desiredWeapon,
            );
            rig.group.position.set(rp.x, rp.y, rp.z);
            scene.add(rig.group);
            entry = {
              rig,
              team: rp.team,
              weaponId: desiredWeapon,
              flashTimer: entry?.flashTimer ?? 0,
              walkPhase: entry?.walkPhase ?? 0,
              crouchBlend: entry?.crouchBlend ?? (rp.crouching ? 1 : 0),
              prevX: rp.x,
              prevZ: rp.z,
            };
            remoteRigs.set(rp.id, entry);
          }

          const rig = entry.rig;
          rig.group.visible = rp.alive;
          if (rp.alive) {
            const targetPos = new THREE.Vector3(rp.x, rp.y, rp.z);
            rig.group.position.lerp(targetPos, netBlend);
            const movedDist = Math.hypot(rig.group.position.x - entry.prevX, rig.group.position.z - entry.prevZ);
            entry.prevX = rig.group.position.x;
            entry.prevZ = rig.group.position.z;

            const speedEst = dt > 0.0001 ? movedDist / dt : 0;
            if (speedEst > 0.4) {
              entry.walkPhase += dt * Math.min(14, speedEst * 1.6);
            } else {
              entry.walkPhase = THREE.MathUtils.damp(entry.walkPhase, 0, 8, dt);
            }

            const stride = speedEst > 0.4 ? Math.sin(entry.walkPhase) * 0.52 : 0;
            rig.leftLegPivot.rotation.x = stride;
            rig.rightLegPivot.rotation.x = -stride;
            rig.leftArmPivot.rotation.x = -0.45 - stride * 0.35;
            rig.rightArmPivot.rotation.x = -0.95 + rp.pitch * 0.65;

            entry.crouchBlend = THREE.MathUtils.damp(entry.crouchBlend, rp.crouching ? 1 : 0, 12, dt);
            rig.bodyPivot.position.y = -0.34 * entry.crouchBlend;
            rig.group.rotation.y = rp.yaw + Math.PI;
            rig.headGroup.rotation.x = -rp.pitch;

            const hpPct = THREE.MathUtils.clamp(rp.hp / rp.maxHp, 0.01, 1);
            rig.hpBarFill.scale.x = hpPct;
            rig.hpBarFill.lookAt(camera.position);

            let visibleTag = rp.team === myTeamRef.current;
            if (!visibleTag) {
              const tx = rig.group.position.x - camera.position.x;
              const ty = rig.group.position.y + 1.5 - camera.position.y;
              const tz = rig.group.position.z - camera.position.z;
              const dist = Math.hypot(tx, ty, tz);
              if (dist < 48 && dist > 0.1) {
                const wallHit = raycastArenaObstacles(
                  camera.position.x,
                  camera.position.y,
                  camera.position.z,
                  tx / dist,
                  ty / dist,
                  tz / dist,
                  dist,
                  mapDef.id,
                );
                visibleTag = wallHit >= dist - 0.8;
              }
            }
            rig.nameSprite.visible = visibleTag;
            rig.hpBarFill.visible = visibleTag;
          }

          if (entry.flashTimer > 0) {
            entry.flashTimer -= dt;
            rig.muzzleFlash.visible = true;
          } else {
            rig.muzzleFlash.visible = false;
          }
        }
      }

      for (const [id, entry] of remoteRigs.entries()) {
        if (!activeRemoteIds.has(id)) {
          scene.remove(entry.rig.group);
          disposeHierarchy(entry.rig.group);
          remoteRigs.delete(id);
        }
      }

      if (arena.reactorCoreMesh) arena.reactorCoreMesh.rotation.y += dt * 0.9;
      if (arena.fountainWaterMesh) {
        arena.fountainWaterMesh.rotation.y += dt * 0.6;
      }
      for (const sb of arena.siteBeacons) {
        sb.core.rotation.y += dt * 1.4;
      }

      if (snap) {
        for (const pk of snap.pickups) {
          const grp = arena.pickupMeshes.get(pk.id);
          if (grp) {
            grp.visible = pk.active;
            grp.rotation.y += dt * 1.8;
          }
        }

        arena.chargeGroup.visible = snap.bombPlanted;
        if (snap.bombPlanted) {
          arena.chargeGroup.position.set(snap.bombX, snap.bombY, snap.bombZ);
          arena.chargeCore.rotation.y += dt * 4.5;
          const pulseScale = 1 + Math.sin(nowMs * 0.012) * 0.14;
          arena.chargeRing.scale.set(pulseScale, pulseScale, 1);

          const beepInterval = snap.bombTimer < 8 ? 280 : snap.bombTimer < 16 ? 520 : 950;
          if (nowMs - lastBombBeepAt >= beepInterval) {
            lastBombBeepAt = nowMs;
            audioRef.current.playBombBeep(snap.bombTimer < 10);
          }
        }
      }

      while (tracerQueueRef.current.length > 0) {
        const shot = tracerQueueRef.current.shift()!;
        const isLocal = shot.shooterId === localPlayerIdRef.current;
        const shooterSnap = snapshotRef.current?.players.find((p) => p.id === shot.shooterId);
        const tracerHex = shooterSnap?.team === "syndicate" ? 0x67d4ff : 0xffcf70;

        if (!isLocal) {
          const rem = remoteRigs.get(shot.shooterId);
          if (rem) rem.flashTimer = 0.06;
        }
        const startOrigin = isLocal
          ? { x: shot.origin.x + 0.12, y: shot.origin.y - 0.14, z: shot.origin.z }
          : { x: shot.origin.x, y: shot.origin.y - 0.24, z: shot.origin.z };
        for (const end of shot.ends) {
          spawnVisualTracer(startOrigin, end, end.hitWorld, tracerHex);
        }
      }

      for (let i = tracerPool.length - 1; i >= 0; i--) {
        const tr = tracerPool[i];
        tr.life -= dt;
        if (tr.life <= 0) {
          scene.remove(tr.line);
          tr.line.geometry.dispose();
          (tr.line.material as THREE.Material).dispose();
          tracerPool.splice(i, 1);
        }
      }
      for (let i = sparkPool.length - 1; i >= 0; i--) {
        const sp = sparkPool[i];
        sp.life -= dt;
        if (sp.life <= 0) {
          scene.remove(sp.mesh);
          sparkPool.splice(i, 1);
        }
      }

      renderer.render(scene, camera);
      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);

    return () => {
      disposed = true;
      cancelAnimationFrame(rafId);
      if (document.pointerLockElement === renderer.domElement) {
        document.exitPointerLock?.();
      }
      window.removeEventListener("keydown", onKeyDown, { capture: true });
      window.removeEventListener("keyup", onKeyUp, { capture: true });
      window.removeEventListener("blur", clearKeys);
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup", onMouseUp);
      document.removeEventListener("pointerlockchange", onPointerLockChange);
      renderer.domElement.removeEventListener("mousedown", onMouseDown);
      renderer.domElement.removeEventListener("wheel", onWheel);
      renderer.domElement.removeEventListener("contextmenu", onContextMenu);
      ro.disconnect();

      for (const id of Object.keys(viewModels) as WeaponId[]) {
        disposeHierarchy(viewModels[id].group);
      }
      for (const entry of remoteRigs.values()) disposeHierarchy(entry.rig.group);
      for (const tr of tracerPool) {
        tr.line.geometry.dispose();
        (tr.line.material as THREE.Material).dispose();
      }
      sparkGeo.dispose();
      sparkMat.dispose();
      arena.dispose();
      envTex.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [inRoom, activeMapId, sendAction, startReload, switchWeapon, cycleSpectateTarget, getMyOwnedWeapons]);

  const selectedMap = useMemo(() => getFpsMapDef(selectedMapId), [selectedMapId]);
  const categoryWeapons = useMemo(
    () => WEAPON_LIST.filter((w) => w.collectionCategory === armoryCategory),
    [armoryCategory],
  );
  const inspectedWeapon = WEAPONS_BY_ID[previewWeaponId] || WEAPON_LIST[0];
  const inspectedSkin = WEAPON_SKINS_BY_ID[cosmetics.equippedSkins[inspectedWeapon.id]] || WEAPON_SKINS[0];
  const inspectedKnife = KNIVES_BY_ID[cosmetics.equippedKnife] || KNIFE_LIST[0];

  const statusBadgeText =
    netState === "connected"
      ? `● SUPABASE REALTIME${latencyMs !== null ? ` · ${latencyMs}ms` : ""}`
      : netState === "probing" || netState === "connecting" || netState === "reconnecting"
        ? "◌ CONNECTING REALTIME…"
        : netState === "unconfigured"
          ? "⚠ SUPABASE NOT CONFIGURED"
          : "✕ REALTIME OFFLINE";

  const statusBadgeClass =
    netState === "connected"
      ? "connected"
      : netState === "offline" || netState === "unconfigured"
        ? "error"
        : "";

  // ===================== CS-INSPIRED MULTI-TAB LOBBY & COLLECTION HUB =====================
  if (!inRoom) {
    return (
      <div className="gw-fps-lobby">
        <div className="gw-hero-deck theme-shooter">
          <img className="gw-hero-deck-bg" src={cardShooterImg} alt="" />
          <div className="gw-hero-deck-scrim" />
          <div className="gw-hero-deck-content">
            <span className="gw-hero-deck-kicker">GNOSIS Strike · Competitive Tactical FPS</span>
            <h3>Competitive Operations Hub</h3>
            <p>
              Deploy across {FPS_MAP_LIST.length} playable arenas including Mansion Estate, inspect 14
              textured weapon finishes and 6 melee knives in interactive 3D, and battle via Supabase Realtime.
            </p>
          </div>
          <div className="gw-hero-deck-actions">
            <button
              type="button"
              className={`gw-btn ${settings.musicEnabled && !settings.muted ? "gw-btn-primary" : ""}`}
              onClick={() => {
                musicRef.current.startOnGesture();
                updateWorkshopSettings({ musicEnabled: !settings.musicEnabled });
              }}
            >
              {settings.musicEnabled && !settings.muted ? "♪ Music On" : "♪ Music Off"}
            </button>
            <span className={`gw-ws-badge ${statusBadgeClass}`}>{statusBadgeText}</span>
            <button
              type="button"
              className="brass-button"
              disabled={netState !== "connected"}
              onClick={handleCreateRoom}
            >
              Quick Deploy ({selectedMap.name}) →
            </button>
          </div>
        </div>

        {/* Navigation Bar */}
        <div className="gw-menu-tabs" role="tablist" aria-label="GNOSIS Strike navigation">
          {(
            [
              ["play", "Play & Maps"],
              ["armory", "Weapon Collection & Skins"],
              ["knives", "Knife Vault"],
              ["operative", "Operative Studio"],
              ["settings", "Settings & Controls"],
              ["profile", "Operative Profile"],
            ] as [FpsMenuTab, string][]
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={menuTab === id}
              className={`gw-menu-tab ${menuTab === id ? "active" : ""}`}
              onClick={() => {
                audioRef.current.initOnGesture();
                musicRef.current.startOnGesture();
                setMenuTab(id);
                if (id === "knives") setPreviewWeaponId("knife");
                else if (id === "armory" && previewWeaponId === "knife") setPreviewWeaponId("carbine");
              }}
            >
              {label}
            </button>
          ))}
        </div>

        {(wsError || netDetail) && (
          <div className="gw-fps-error" role="alert">
            <span>{wsError || netDetail}</span>
            <button type="button" className="gw-btn" onClick={handleReconnect}>
              Reconnect
            </button>
          </div>
        )}

        {/* TAB 1: PLAY & 4-MAP SELECTOR */}
        {menuTab === "play" && (
          <div className="gw-fps-lobby-grid">
            <div className="gw-fps-panel">
              <h4>1. Select Arena ({FPS_MAP_LIST.length} Maps)</h4>
              <div className="gw-map-grid">
                {FPS_MAP_LIST.map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    className={`gw-map-card ${selectedMapId === m.id ? "active" : ""}`}
                    onClick={() => {
                      setSelectedMapId(m.id);
                      setNewRoomTitle(m.name);
                    }}
                  >
                    <svg viewBox="-60 -50 120 100" className="gw-map-svg" aria-hidden="true">
                      <rect x="-58" y="-48" width="116" height="96" fill="#0f1520" stroke="#334155" strokeWidth="2" />
                      {m.boxes
                        .filter((b) => b.kind !== "wall" && b.style !== "mansion-roof")
                        .map((b) => (
                          <rect
                            key={b.id}
                            x={b.x - b.w * 0.5}
                            y={b.z - b.d * 0.5}
                            width={b.w}
                            height={b.d}
                            fill={b.style === "hedge" ? "#2d6a38" : b.kind === "building" ? "#64748b" : "#475569"}
                          />
                        ))}
                      {m.bombSites.map((s) => (
                        <circle
                          key={s.id}
                          cx={s.x}
                          cy={s.z}
                          r={s.radius}
                          fill="none"
                          stroke={s.id === "A" ? "#f59e0b" : "#38bdf8"}
                          strokeWidth="2.4"
                        />
                      ))}
                    </svg>
                    <div className="gw-map-card-meta">
                      <small>{m.atmosphereTag}</small>
                      <strong>{m.name}</strong>
                      <span>{m.subtitle}</span>
                    </div>
                  </button>
                ))}
              </div>
              <p className="gw-map-desc">{selectedMap.description}</p>

              <div className="gw-fps-divider" />

              <h4>2. Match Parameters</h4>
              <label className="gw-fps-field">
                <span>Operative Callsign</span>
                <input
                  type="text"
                  value={callsign}
                  maxLength={18}
                  onChange={(e) => setCallsign(e.target.value)}
                  placeholder="Operative name…"
                />
              </label>

              <label className="gw-fps-field">
                <span>Match Lobby Title</span>
                <input
                  type="text"
                  value={newRoomTitle}
                  maxLength={32}
                  onChange={(e) => setNewRoomTitle(e.target.value)}
                  placeholder="Estate: Mansion Lobby…"
                />
              </label>

              <div className="gw-fps-two-cols">
                <div className="gw-fps-field">
                  <span>Game Mode</span>
                  <div className="gp-seg">
                    <button
                      type="button"
                      className={selectedMode === "DEFUSAL" ? "active" : ""}
                      onClick={() => setSelectedMode("DEFUSAL")}
                    >
                      Defusal (Round-Based)
                    </button>
                    <button
                      type="button"
                      className={selectedMode === "TDM" ? "active" : ""}
                      onClick={() => setSelectedMode("TDM")}
                    >
                      Team DM (25K)
                    </button>
                  </div>
                </div>

                <div className="gw-fps-field">
                  <span>Your Team</span>
                  <div className="gp-seg">
                    <button
                      type="button"
                      className={selectedTeam === "vanguard" ? "active" : ""}
                      onClick={() => setSelectedTeam("vanguard")}
                    >
                      Team Alpha
                    </button>
                    <button
                      type="button"
                      className={selectedTeam === "syndicate" ? "active" : ""}
                      onClick={() => setSelectedTeam("syndicate")}
                    >
                      Team Bravo
                    </button>
                  </div>
                </div>
              </div>

              {/* Independent Team Bot Composition (0-10 bots per team) */}
              <div className="gw-fps-team-comp">
                <div className="gw-fps-team-comp-head">
                  <span>TEAM BOT COMPOSITION (0–10 BOTS PER TEAM)</span>
                  <strong>
                    {(selectedTeam === "vanguard" ? 1 : 0) + alphaBots} ALPHA vs{" "}
                    {(selectedTeam === "syndicate" ? 1 : 0) + bravoBots} BRAVO TOTAL
                  </strong>
                </div>

                <div className="gw-fps-two-cols">
                  <div className={`gw-fps-bot-card alpha ${selectedTeam === "vanguard" ? "is-yours" : ""}`}>
                    <div className="gw-fps-bot-card-top">
                      <span>TEAM ALPHA BOTS</span>
                      <b>
                        {alphaBots} {alphaBots === 1 ? "Bot" : "Bots"}
                        {selectedTeam === "vanguard" ? " + You" : ""}
                      </b>
                    </div>
                    <div className="gw-fps-stepper">
                      <button
                        type="button"
                        className="gw-btn"
                        disabled={alphaBots <= 0}
                        onClick={() => setAlphaBots((v) => Math.max(0, v - 1))}
                        aria-label="Decrease Team Alpha bots"
                      >
                        −
                      </button>
                      <input
                        type="range"
                        min={0}
                        max={10}
                        value={alphaBots}
                        onChange={(e) => setAlphaBots(Math.max(0, Math.min(10, Number(e.target.value))))}
                        aria-label="Team Alpha bot count"
                      />
                      <button
                        type="button"
                        className="gw-btn"
                        disabled={alphaBots >= 10}
                        onClick={() => setAlphaBots((v) => Math.min(10, v + 1))}
                        aria-label="Increase Team Alpha bots"
                      >
                        +
                      </button>
                    </div>
                    <small>
                      Alpha Total: {(selectedTeam === "vanguard" ? 1 : 0) + alphaBots} combatant
                      {(selectedTeam === "vanguard" ? 1 : 0) + alphaBots === 1 ? "" : "s"}
                    </small>
                  </div>

                  <div className={`gw-fps-bot-card bravo ${selectedTeam === "syndicate" ? "is-yours" : ""}`}>
                    <div className="gw-fps-bot-card-top">
                      <span>TEAM BRAVO BOTS</span>
                      <b>
                        {bravoBots} {bravoBots === 1 ? "Bot" : "Bots"}
                        {selectedTeam === "syndicate" ? " + You" : ""}
                      </b>
                    </div>
                    <div className="gw-fps-stepper">
                      <button
                        type="button"
                        className="gw-btn"
                        disabled={bravoBots <= 0}
                        onClick={() => setBravoBots((v) => Math.max(0, v - 1))}
                        aria-label="Decrease Team Bravo bots"
                      >
                        −
                      </button>
                      <input
                        type="range"
                        min={0}
                        max={10}
                        value={bravoBots}
                        onChange={(e) => setBravoBots(Math.max(0, Math.min(10, Number(e.target.value))))}
                        aria-label="Team Bravo bot count"
                      />
                      <button
                        type="button"
                        className="gw-btn"
                        disabled={bravoBots >= 10}
                        onClick={() => setBravoBots((v) => Math.min(10, v + 1))}
                        aria-label="Increase Team Bravo bots"
                      >
                        +
                      </button>
                    </div>
                    <small>
                      Bravo Total: {(selectedTeam === "syndicate" ? 1 : 0) + bravoBots} combatant
                      {(selectedTeam === "syndicate" ? 1 : 0) + bravoBots === 1 ? "" : "s"}
                    </small>
                  </div>
                </div>

                <div className="gw-fps-comp-summary">
                  Roster:{" "}
                  <b>
                    {selectedTeam === "vanguard"
                      ? `You + ${alphaBots} Alpha ${alphaBots === 1 ? "Bot" : "Bots"} vs ${bravoBots} Bravo ${bravoBots === 1 ? "Bot" : "Bots"}`
                      : `${alphaBots} Alpha ${alphaBots === 1 ? "Bot" : "Bots"} vs You + ${bravoBots} Bravo ${bravoBots === 1 ? "Bot" : "Bots"}`}
                  </b>
                </div>
              </div>

              <button
                type="button"
                className="brass-button"
                disabled={netState !== "connected"}
                onClick={handleCreateRoom}
              >
                Deploy to {selectedMap.name} →
              </button>
            </div>

            <div className="gw-fps-panel">
              <div className="gw-fps-panel-top">
                <h4>Live PvP Match Browser ({publicRooms.length})</h4>
                <button
                  type="button"
                  className="gw-btn"
                  disabled={netState !== "connected"}
                  onClick={() => void lobbyClientRef.current?.refreshRooms()}
                >
                  ↻ Refresh
                </button>
              </div>

              {publicRooms.length === 0 ? (
                <div className="gw-fps-empty">
                  <p>No active PvP lobbies open yet.</p>
                  <small>
                    Pick a map on the left and deploy to open a live Supabase room, or enter an invite
                    code below to join another player's match.
                  </small>
                </div>
              ) : (
                <div className="gw-fps-room-list">
                  {publicRooms.map((r) => (
                    <div key={r.code} className="gw-fps-room-row">
                      <div>
                        <strong>{r.title}</strong>
                        <small>
                          MAP: {getFpsMapDef(r.mapId).name} · CODE: {r.code} · {r.mode} · {r.players}/
                          {r.maxPlayers} PLAYERS
                        </small>
                      </div>
                      <button
                        type="button"
                        className="gw-btn gw-btn-primary"
                        disabled={netState !== "connected"}
                        onClick={() => handleJoinRoom(r.code)}
                      >
                        Join →
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <div className="gw-fps-divider" />

              <label className="gw-fps-field">
                <span>Join Existing Match by Code</span>
                <div className="gw-fps-code-row">
                  <input
                    type="text"
                    value={joinCodeInput}
                    maxLength={8}
                    onChange={(e) => setJoinCodeInput(e.target.value.toUpperCase())}
                    placeholder="e.g. K9R2V"
                    onKeyDown={(e) => e.key === "Enter" && handleJoinRoom(joinCodeInput)}
                  />
                  <button
                    type="button"
                    className="gw-btn gw-btn-primary"
                    disabled={netState !== "connected"}
                    onClick={() => handleJoinRoom(joinCodeInput)}
                  >
                    Join Match
                  </button>
                </div>
              </label>

              <div className="gw-fps-arsenal-preview">
                <small>ACTIVE LOADOUT FINISHES &amp; MELEE</small>
                <div className="gw-fps-weapons-mini">
                  {WEAPON_LIST.map((w) => {
                    const sk = WEAPON_SKINS_BY_ID[cosmetics.equippedSkins[w.id]];
                    return (
                      <span key={w.id}>
                        [{w.slot}] {w.id === "knife" ? inspectedKnife.name : w.name} ·{" "}
                        <b>{sk?.name || "Standard"}</b>
                      </span>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: WEAPON COLLECTION & 14 TEXTURED SKINS */}
        {menuTab === "armory" && (
          <div className="gw-fps-lobby-grid">
            <div className="gw-fps-panel">
              <div className="gw-fps-panel-top">
                <h4>3D Inspection Stage</h4>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                  <button
                    type="button"
                    className="gw-btn"
                    onClick={() => setPreviewAnim((p) => ({ trigger: "inspect", seq: p.seq + 1 }))}
                  >
                    Inspect [F]
                  </button>
                  <button
                    type="button"
                    className="gw-btn"
                    onClick={() => {
                      audioRef.current.initOnGesture();
                      audioRef.current.playShot(inspectedWeapon.id, 0.8);
                      setPreviewAnim((p) => ({ trigger: "fire", seq: p.seq + 1 }));
                    }}
                  >
                    Test Fire
                  </button>
                  {inspectedWeapon.id !== "knife" && (
                    <button
                      type="button"
                      className="gw-btn"
                      onClick={() => {
                        audioRef.current.initOnGesture();
                        audioRef.current.playReload();
                        setPreviewAnim((p) => ({ trigger: "reload", seq: p.seq + 1 }));
                      }}
                    >
                      Reload [R]
                    </button>
                  )}
                </div>
              </div>

              <WeaponPreview3D
                mode="weapon"
                weaponId={inspectedWeapon.id}
                skinId={inspectedSkin.id}
                knifeId={inspectedKnife.id}
                animTrigger={previewAnim.trigger}
                animSeq={previewAnim.seq}
              />

              <div className="gw-weapon-dossier">
                <div className="gw-weapon-dossier-head">
                  <div>
                    <small>
                      SLOT {inspectedWeapon.slot} · {inspectedWeapon.category} · {inspectedSkin.rarity.toUpperCase()}
                    </small>
                    <h4>
                      {inspectedWeapon.id === "knife" ? inspectedKnife.name : inspectedWeapon.name} —{" "}
                      <span>{inspectedSkin.name}</span>
                    </h4>
                  </div>
                  <button
                    type="button"
                    className="gw-btn"
                    onClick={() => applySkinToAllWeapons(inspectedSkin.id)}
                  >
                    Equip Skin to All Weapons
                  </button>
                </div>
                <p>{inspectedWeapon.lore}</p>
                <div className="gw-stat-pills">
                  <div>
                    <span>Damage</span>
                    <strong>{inspectedWeapon.damage} {inspectedWeapon.pellets > 1 ? `×${inspectedWeapon.pellets}` : ""}</strong>
                  </div>
                  <div>
                    <span>Rate</span>
                    <strong>{inspectedWeapon.rpm} RPM</strong>
                  </div>
                  <div>
                    <span>HS Mult</span>
                    <strong>{inspectedWeapon.headshotMult}×</strong>
                  </div>
                  <div>
                    <span>Armor Pen</span>
                    <strong>{Math.round(inspectedWeapon.armorPen * 100)}%</strong>
                  </div>
                  <div>
                    <span>Velocity</span>
                    <strong>{inspectedWeapon.muzzleVelocityMps || "Melee"} m/s</strong>
                  </div>
                  <div>
                    <span>Weight</span>
                    <strong>{inspectedWeapon.weightKg} kg</strong>
                  </div>
                </div>
              </div>
            </div>

            <div className="gw-fps-panel">
              <h4>Category &amp; Finish Selector</h4>
              <div className="gp-seg" style={{ flexWrap: "wrap", marginBottom: 12 }}>
                {WEAPON_CATEGORIES.map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    className={armoryCategory === cat ? "active" : ""}
                    onClick={() => {
                      setArmoryCategory(cat);
                      const first = WEAPON_LIST.find((w) => w.collectionCategory === cat);
                      if (first) setPreviewWeaponId(first.id);
                    }}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              <div className="gw-weapon-pick-list">
                {categoryWeapons.map((w) => (
                  <button
                    key={w.id}
                    type="button"
                    className={`gw-fps-armory-card ${previewWeaponId === w.id ? "active" : ""}`}
                    onClick={() => setPreviewWeaponId(w.id)}
                  >
                    <small>
                      SLOT [{w.slot}] · {w.fireMode}
                    </small>
                    <strong>{w.id === "knife" ? inspectedKnife.name : w.name}</strong>
                    <span>
                      Finish: {WEAPON_SKINS_BY_ID[cosmetics.equippedSkins[w.id]]?.name}
                    </span>
                  </button>
                ))}
              </div>

              <div className="gw-fps-divider" />
              <div className="gw-fps-panel-top">
                <h4>Available Skins ({WEAPON_SKINS.length})</h4>
                <small style={{ color: "var(--muted)" }}>{inspectedSkin.themeLabel}</small>
              </div>
              <div className="gw-skin-grid">
                {WEAPON_SKINS.map((sk) => {
                  const isActive = cosmetics.equippedSkins[inspectedWeapon.id] === sk.id;
                  return (
                    <button
                      key={sk.id}
                      type="button"
                      className={`gw-skin-card rarity-${sk.rarity.toLowerCase()} ${isActive ? "active" : ""}`}
                      onClick={() => {
                        setWeaponSkin(inspectedWeapon.id, sk.id);
                        audioRef.current.initOnGesture();
                        audioRef.current.playObjectiveChime();
                      }}
                    >
                      <div className="gw-skin-swatches">
                        <span style={{ background: sk.previewSwatches[0] }} />
                        <span style={{ background: sk.previewSwatches[1] }} />
                        <span style={{ background: sk.previewSwatches[2] }} />
                      </div>
                      <small>{sk.rarity}</small>
                      <strong>{sk.name}</strong>
                      <span>{sk.themeLabel}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: KNIFE & MELEE VAULT */}
        {menuTab === "knives" && (
          <div className="gw-fps-lobby-grid">
            <div className="gw-fps-panel">
              <div className="gw-fps-panel-top">
                <h4>Melee Showcase: {inspectedKnife.name}</h4>
                <div style={{ display: "flex", gap: 6 }}>
                  <button
                    type="button"
                    className="gw-btn"
                    onClick={() => setPreviewAnim((p) => ({ trigger: "inspect", seq: p.seq + 1 }))}
                  >
                    Flourish Spin [F]
                  </button>
                  <button
                    type="button"
                    className="gw-btn"
                    onClick={() => {
                      audioRef.current.initOnGesture();
                      audioRef.current.playKnifeSwing();
                      setPreviewAnim((p) => ({ trigger: "fire", seq: p.seq + 1 }));
                    }}
                  >
                    Slash Preview
                  </button>
                </div>
              </div>

              <WeaponPreview3D
                mode="weapon"
                weaponId="knife"
                skinId={cosmetics.equippedSkins.knife}
                knifeId={inspectedKnife.id}
                animTrigger={previewAnim.trigger}
                animSeq={previewAnim.seq}
              />

              <div className="gw-weapon-dossier">
                <small>
                  MELEE SLOT [6] · {inspectedKnife.rarity.toUpperCase()} · BLADE {inspectedKnife.bladeLengthCm}cm
                </small>
                <h4>
                  {inspectedKnife.name} · <span>{WEAPON_SKINS_BY_ID[cosmetics.equippedSkins.knife]?.name}</span>
                </h4>
                <p>{inspectedKnife.lore}</p>
                <p>
                  Style: <b>{inspectedKnife.silhouette}</b> · Flourish: <b>{inspectedKnife.drawStyle}</b>
                </p>
              </div>
            </div>

            <div className="gw-fps-panel">
              <h4>Select Equipped Knife ({KNIFE_LIST.length})</h4>
              <div className="gw-knife-grid">
                {KNIFE_LIST.map((kn) => (
                  <button
                    key={kn.id}
                    type="button"
                    className={`gw-skin-card rarity-${kn.rarity.toLowerCase()} ${
                      cosmetics.equippedKnife === kn.id ? "active" : ""
                    }`}
                    onClick={() => {
                      setEquippedKnife(kn.id);
                      audioRef.current.initOnGesture();
                      audioRef.current.playKnifeSwing();
                    }}
                  >
                    <small>{kn.rarity}</small>
                    <strong>{kn.name}</strong>
                    <span>{kn.silhouette}</span>
                  </button>
                ))}
              </div>

              <div className="gw-fps-divider" />
              <h4>Knife Blade Finish</h4>
              <div className="gw-skin-grid">
                {WEAPON_SKINS.map((sk) => (
                  <button
                    key={sk.id}
                    type="button"
                    className={`gw-skin-card rarity-${sk.rarity.toLowerCase()} ${
                      cosmetics.equippedSkins.knife === sk.id ? "active" : ""
                    }`}
                    onClick={() => setWeaponSkin("knife", sk.id)}
                  >
                    <div className="gw-skin-swatches">
                      <span style={{ background: sk.previewSwatches[0] }} />
                      <span style={{ background: sk.previewSwatches[1] }} />
                      <span style={{ background: sk.previewSwatches[2] }} />
                    </div>
                    <small>{sk.themeLabel}</small>
                    <strong>{sk.name}</strong>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: OPERATIVE CUSTOMIZATION */}
        {menuTab === "operative" && (
          <div className="gw-fps-lobby-grid">
            <div className="gw-fps-panel">
              <div className="gw-fps-panel-top">
                <h4>3D Operative Armor Preview</h4>
                <div className="gp-seg">
                  <button
                    type="button"
                    className={previewTeam === "vanguard" ? "active" : ""}
                    onClick={() => setPreviewTeam("vanguard")}
                  >
                    Vanguard Rig
                  </button>
                  <button
                    type="button"
                    className={previewTeam === "syndicate" ? "active" : ""}
                    onClick={() => setPreviewTeam("syndicate")}
                  >
                    Syndicate Rig
                  </button>
                </div>
              </div>
              <WeaponPreview3D
                mode="operative"
                weaponId="carbine"
                skinId={cosmetics.equippedSkins.carbine}
                knifeId={cosmetics.equippedKnife}
                operative={cosmetics.operative}
                team={previewTeam}
              />
            </div>

            <div className="gw-fps-panel">
              <h4>Tactical Gear Appearance</h4>
              <div className="gw-fps-field">
                <span>Visor &amp; Chest Core Optics</span>
                <div className="gw-swatch-row">
                  {VISOR_PALETTE.map((v) => (
                    <button
                      key={v.hex}
                      type="button"
                      className={`gw-swatch-btn ${cosmetics.operative.visorHex === v.hex ? "active" : ""}`}
                      onClick={() => updateOperativeCustomization({ visorHex: v.hex })}
                    >
                      <i style={{ background: v.hex }} />
                      <span>{v.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="gw-fps-field">
                <span>Vest &amp; Helmet Plate Finish</span>
                <div className="gw-swatch-row">
                  {TRIM_PALETTE.map((t) => (
                    <button
                      key={t.hex}
                      type="button"
                      className={`gw-swatch-btn ${cosmetics.operative.armorTrimHex === t.hex ? "active" : ""}`}
                      onClick={() => updateOperativeCustomization({ armorTrimHex: t.hex, gloveHex: t.hex })}
                    >
                      <i style={{ background: t.hex }} />
                      <span>{t.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <label className="gw-fps-field">
                <span>Squadron Badge Code (3 chars shown on rig)</span>
                <input
                  type="text"
                  maxLength={3}
                  value={cosmetics.operative.badgeTag}
                  onChange={(e) =>
                    updateOperativeCustomization({ badgeTag: e.target.value.toUpperCase() })
                  }
                />
              </label>
            </div>
          </div>
        )}

        {/* TAB 5: SETTINGS & CONTROLS */}
        {menuTab === "settings" && (
          <div className="gw-fps-lobby-grid">
            <div className="gw-fps-panel">
              <div className="gw-fps-panel-top">
                <h4>Audio, Graphics &amp; Aim Settings</h4>
                <button type="button" className="gw-btn" onClick={resetWorkshopSettings}>
                  Reset Defaults
                </button>
              </div>

              <label className="gw-fps-field">
                <span>Soundtrack Track (All 4 Licensed/OST Tracks + Custom)</span>
                <select
                  value={settings.preferredTrackUrl || playlist[0]?.url || ""}
                  onChange={(e) => {
                    const url = e.target.value;
                    selectActiveSoundtrackByUrl(url);
                    updateWorkshopSettings({ preferredTrackUrl: url, musicEnabled: true });
                  }}
                >
                  {playlist.map((t) => (
                    <option key={t.id} value={t.url}>
                      {t.title} {t.artist ? `— ${t.artist}` : ""}
                    </option>
                  ))}
                </select>
              </label>

              <label className="gw-fps-field">
                <span>Music Volume: {Math.round(settings.musicVolume * 100)}%</span>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={Math.round(settings.musicVolume * 100)}
                  onChange={(e) => updateWorkshopSettings({ musicVolume: Number(e.target.value) / 100 })}
                />
              </label>

              <label className="gw-fps-field">
                <span>Combat SFX Volume: {Math.round(settings.sfxVolume * 100)}%</span>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={Math.round(settings.sfxVolume * 100)}
                  onChange={(e) => updateWorkshopSettings({ sfxVolume: Number(e.target.value) / 100 })}
                />
              </label>

              <label className="gw-fps-field">
                <span>Mouse Aim Sensitivity: {settings.mouseSensitivity.toFixed(2)}×</span>
                <input
                  type="range"
                  min={25}
                  max={300}
                  value={Math.round(settings.mouseSensitivity * 100)}
                  onChange={(e) =>
                    updateWorkshopSettings({ mouseSensitivity: Number(e.target.value) / 100 })
                  }
                />
              </label>

              <label className="gw-fps-field">
                <span>Field of View (FOV): {settings.fov}°</span>
                <input
                  type="range"
                  min={64}
                  max={100}
                  value={settings.fov}
                  onChange={(e) => updateWorkshopSettings({ fov: Number(e.target.value) })}
                />
              </label>

              <div className="gw-fps-field">
                <span>Graphics &amp; Shadow Quality</span>
                <div className="gp-seg">
                  {(["low", "medium", "high"] as const).map((q) => (
                    <button
                      key={q}
                      type="button"
                      className={settings.graphicsQuality === q ? "active" : ""}
                      onClick={() => updateWorkshopSettings({ graphicsQuality: q })}
                    >
                      {q.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>

              <label className="gw-fps-field">
                <span>Killfeed Duration: {killFeedDurationSec.toFixed(1)}s</span>
                <input
                  type="range"
                  min={30}
                  max={100}
                  step={5}
                  value={Math.round(killFeedDurationSec * 10)}
                  onChange={(e) => setKillFeedDurationSec(Number(e.target.value) / 10)}
                />
              </label>
            </div>

            <div className="gw-fps-panel">
              <h4>Tactical Controls Reference</h4>
              <div className="gw-controls-grid">
                <div><b>W / A / S / D</b><span>Move Operative</span></div>
                <div><b>Shift / C</b><span>Sprint / Crouch</span></div>
                <div><b>Space</b><span>Jump / Climb Ledges</span></div>
                <div><b>Left Click</b><span>Fire Weapon / Knife Slash</span></div>
                <div><b>Right Click</b><span>Aim Down Sights / Rail Scope</span></div>
                <div><b>1 / 2 / 3</b><span>Primary / Sidearm / Knife</span></div>
                <div><b>Q</b><span>Quick-Switch Weapon / Knife</span></div>
                <div><b>F</b><span>Weapon &amp; Knife Inspect Animation</span></div>
                <div><b>R</b><span>Tactical Reload</span></div>
                <div><b>E</b><span>Hold to Plant / Defuse Charge</span></div>
                <div><b>B / Tab</b><span>Tactical Buy Menu / Scoreboard</span></div>
                <div><b>P / Esc</b><span>Match Settings &amp; Pause Menu</span></div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: CAREER PROFILE */}
        {menuTab === "profile" && (
          <div className="gw-fps-panel" style={{ maxWidth: 820 }}>
            <h4>Operative Service Record · {callsign}</h4>
            <div className="gw-stat-pills" style={{ marginTop: 12 }}>
              <div><span>Matches Played</span><strong>{careerStats.matchesPlayed}</strong></div>
              <div><span>Match Wins</span><strong>{careerStats.wins}</strong></div>
              <div><span>Total Kills</span><strong>{careerStats.kills}</strong></div>
              <div><span>Headshots</span><strong>{careerStats.headshots}</strong></div>
              <div><span>Knife Kills</span><strong>{careerStats.knifeKills}</strong></div>
              <div><span>Damage Dealt</span><strong>{careerStats.damageDealt}</strong></div>
            </div>
            <div style={{ marginTop: 18 }}>
              <button
                type="button"
                className="gw-btn"
                onClick={() => {
                  const empty: FpsCareerStats = {
                    matchesPlayed: 0,
                    wins: 0,
                    kills: 0,
                    headshots: 0,
                    knifeKills: 0,
                    damageDealt: 0,
                  };
                  saveFpsStats(empty);
                  setCareerStats(empty);
                }}
              >
                Reset Local Career Stats
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ===================== IN-MATCH 3D HUD & OVERLAYS =====================
  const me = snapshot?.players.find((p) => p.id === localPlayerId);
  const activeSpec = WEAPONS_BY_ID[activeWeapon];
  const curAmmo = inventory[activeWeapon];
  const alphaPlayers = (snapshot?.players || []).filter((p) => p.team === "vanguard");
  const bravoPlayers = (snapshot?.players || []).filter((p) => p.team === "syndicate");
  const alphaAlive = alphaPlayers.filter((p) => p.alive);
  const bravoAlive = bravoPlayers.filter((p) => p.alive);

  const isRoundEnd = snapshot?.phase === "ROUND_END";
  const isMatchEnd = snapshot?.phase === "MATCH_END";
  const isSpectating = Boolean(
    me && !me.alive && snapshot && (snapshot.phase === "LIVE" || snapshot.phase === "BUY_FREEZE"),
  );
  const spectatedCombatant = isSpectating
    ? snapshot?.players.find((p) => p.id === spectateTargetId && p.alive) ||
      getLivingSpectatePool(snapshot, localPlayerId)[0] ||
      null
    : null;
  const livingPoolCount = getLivingSpectatePool(snapshot, localPlayerId).length;
  const isRoomHost = Boolean(roomTransportRef.current?.getIsHost() || hostEngineRef.current);

  return (
    <div className="gw-fps-stage-root">
      <div ref={mountRef} className="gw-fps-canvas" />

      {damageFlash && !isSpectating && <div className="gw-fps-damage-vignette" />}

      {isScopedSniper && !isSpectating && !isRoundEnd && !isMatchEnd && (
        <div className="gw-fps-sniper-scope">
          <div className="gw-scope-ring" />
          <div className="gw-scope-h" />
          <div className="gw-scope-v" />
        </div>
      )}

      {!isSpectating && !isRoundEnd && !isMatchEnd && (
        <div ref={crosshairGapRef} className="gw-fps-crosshair">
          <div className="ch-dot" />
          <span className="ch-top" />
          <span className="ch-bottom" />
          <span className="ch-left" />
          <span className="ch-right" />
          {hitMarker && (
            <div className={`gw-fps-hitmarker ${hitMarker.headshot ? "headshot" : ""}`} />
          )}
        </div>
      )}

      {/* Top-Center Competitive Score & Clock */}
      <div className="gw-fps-match-top">
        <div className="gw-fps-team-score vanguard">
          <span>TEAM ALPHA</span>
          <strong>
            {snapshot?.mode === "TDM" ? snapshot.vanguardKills : snapshot?.vanguardRounds ?? 0}
          </strong>
        </div>

        <div className={`gw-fps-round-clock ${snapshot?.bombPlanted ? "bomb-live" : ""}`}>
          <small>
            {getFpsMapDef(activeMapId).name.toUpperCase()} ·{" "}
            {snapshot?.mode === "TDM"
              ? "TDM 25K"
              : `RD ${snapshot?.round ?? 1}/${snapshot?.maxRounds ?? 7} · ${snapshot?.phase ?? "LIVE"}`}
          </small>
          <strong>
            {snapshot?.bombPlanted
              ? `SITE ${snapshot.bombSiteId} · ${snapshot.bombTimer.toFixed(1)}s`
              : isRoundEnd
                ? "ROUND OVER"
                : isMatchEnd
                  ? "MATCH OVER"
                  : formatTimer(snapshot?.phaseTimer ?? 0)}
          </strong>
        </div>

        <div className="gw-fps-team-score syndicate">
          <strong>
            {snapshot?.mode === "TDM" ? snapshot.syndicateKills : snapshot?.syndicateRounds ?? 0}
          </strong>
          <span>TEAM BRAVO</span>
        </div>
      </div>

      {/* Top-Left Minimap + Room Chip + Match Event Log */}
      <div className="gw-fps-hud-tl">
        <div className="gw-fps-minimap-card">
          <canvas
            ref={minimapCanvasRef}
            width={176}
            height={148}
            className="gw-fps-minimap-canvas"
          />
          <div className="gw-fps-callout-bar">
            <span>{calloutName}</span>
            <small>{latencyMs !== null ? `${latencyMs}ms` : "LIVE"}</small>
          </div>
        </div>

        <div className="gw-fps-room-chip">
          <span>
            {roomTitle} · <b>{roomCode}</b>
          </span>
          <button
            type="button"
            className="gw-fps-copy-btn"
            onClick={() => {
              navigator.clipboard?.writeText(roomCode).catch(() => {});
              setCopiedCode(true);
              window.setTimeout(() => setCopiedCode(false), 1600);
            }}
          >
            {copiedCode ? "Copied" : "Copy"}
          </button>
        </div>

        <div className="gw-fps-feed">
          {eventFeed.map((f) => (
            <div key={f.id} className={f.tone ? `tone-${f.tone}` : ""}>
              {f.text}
            </div>
          ))}
        </div>
      </div>

      {/* Top-Right Squad Roster, Action Buttons & CS-Style Killfeed */}
      <div className="gw-fps-hud-tr">
        <div className="gw-fps-squad-list">
          <div className="gw-fps-roster-mini-head">
            <span className="vg-txt">ALPHA ({alphaAlive.length}/{alphaPlayers.length})</span>
            <span className="sy-txt">BRAVO ({bravoAlive.length}/{bravoPlayers.length})</span>
          </div>
          <div className="gw-fps-squad-scroll">
            {(snapshot?.players || []).map((p) => (
              <div
                key={p.id}
                className={`gw-fps-squad-row ${p.id === spectatedCombatant?.id ? "is-spectated" : ""} ${!p.alive ? "is-dead" : ""}`}
              >
                <span className="sq-dot" style={{ background: p.color }} />
                <b>
                  {p.name}
                  {p.id === localPlayerId ? " (You)" : ""}
                  {p.id === spectatedCombatant?.id ? " [CAM]" : ""}
                </b>
                <span>{p.alive ? `${p.hp}HP` : "DEAD"}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="gw-fps-top-btns">
          <button
            type="button"
            className="gw-btn"
            disabled={isSpectating || isRoundEnd || isMatchEnd}
            onClick={() => sendAction({ type: "switch_team" })}
            title="Switch between Team Alpha and Team Bravo"
          >
            Swap Team
          </button>
          <button
            type="button"
            className="gw-btn gw-btn-primary"
            disabled={isSpectating || isRoundEnd || isMatchEnd}
            onClick={() => {
              setPauseMenuOpen(false);
              setShopNotice(null);
              setLoadoutOpen((v) => !v);
            }}
          >
            [B] Buy (${me?.money ?? 800})
          </button>
          <button
            type="button"
            className="gw-btn"
            onClick={() => {
              setLoadoutOpen(false);
              setPauseMenuOpen((v) => !v);
            }}
          >
            [P] Pause
          </button>
          <button type="button" className="gw-btn" onClick={() => setScoreboardOpen((s) => !s)}>
            [Tab]
          </button>
          <button type="button" className="gw-btn" onClick={onToggleFullscreen}>
            {isFullscreen ? "Exit FS" : "FS"}
          </button>
          <button type="button" className="gw-btn danger" onClick={handleLeaveRoom}>
            Leave
          </button>
          <button type="button" className="gw-btn" onClick={onExit}>
            Hub
          </button>
        </div>

        {/* Dedicated Upper-Right Tactical Killfeed (Combat Kills Only) */}
        {killFeedEntries.length > 0 && (
          <div className="gw-fps-killfeed-tr" aria-live="polite" aria-label="Killfeed">
            {killFeedEntries.map((kf) => (
              <div key={kf.id} className={`kf-row ${kf.headshot ? "is-hs" : ""}`}>
                <span className={`kf-name ${kf.killerTeam === "vanguard" ? "alpha" : "bravo"}`}>
                  {kf.killerName}
                </span>
                <span className="kf-icon-wrap" title={WEAPONS_BY_ID[kf.weaponId]?.name || kf.weaponId}>
                  <WeaponKillIcon id={kf.weaponId} />
                </span>
                {kf.wallbang && <span className="kf-badge pen">PEN</span>}
                {kf.isKnife ? (
                  <span className="kf-badge knife">KNIFE</span>
                ) : kf.headshot ? (
                  <span className="kf-badge hs">HS</span>
                ) : (
                  <span className="kf-badge body">BODY</span>
                )}
                <span className={`kf-name ${kf.victimTeam === "vanguard" ? "alpha" : "bravo"}`}>
                  {kf.victimName}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {objectivePrompt && !isSpectating && !isRoundEnd && !isMatchEnd && (
        <div className="gw-fps-bomb-prompt">
          <span>{objectivePrompt}</span>
          {(snapshot?.plantProgress ?? 0) > 0 && (
            <div className="gw-fps-obj-bar">
              <i style={{ width: `${snapshot?.plantProgress ?? 0}%` }} />
            </div>
          )}
          {(snapshot?.defuseProgress ?? 0) > 0 && (
            <div className="gw-fps-obj-bar">
              <i style={{ width: `${snapshot?.defuseProgress ?? 0}%` }} />
            </div>
          )}
        </div>
      )}

      {/* Spectator Mode HUD (Active immediately on death during a round) */}
      {isSpectating && snapshot && (
        <>
          <div className="gw-fps-spec-banner" role="status">
            <div className="gw-fps-spec-status">
              <span className="spec-elim">YOU ARE ELIMINATED</span>
              <span className="spec-badge">SPECTATOR MODE</span>
              <span className="spec-round">
                ROUND {snapshot.round}/{snapshot.maxRounds} · {snapshot.phase}
              </span>
            </div>
            <div className="gw-fps-spec-counts">
              <span className="vg-txt">ALPHA ALIVE: {alphaAlive.length}/{alphaPlayers.length}</span>
              <span className="sy-txt">BRAVO ALIVE: {bravoAlive.length}/{bravoPlayers.length}</span>
            </div>
          </div>

          <div className="gw-fps-spec-bar">
            <button
              type="button"
              className="gw-btn"
              disabled={livingPoolCount <= 1}
              onClick={() => cycleSpectateTarget(-1)}
            >
              ◀ Prev [←]
            </button>

            <div className="gw-fps-spec-target">
              {spectatedCombatant ? (
                <>
                  <div className="gw-fps-spec-target-head">
                    <span
                      className={`spec-team-pill ${spectatedCombatant.team === "vanguard" ? "alpha" : "bravo"}`}
                    >
                      {spectatedCombatant.team === "vanguard" ? "TEAM ALPHA" : "TEAM BRAVO"}
                    </span>
                    <strong>{spectatedCombatant.name}</strong>
                  </div>
                  <small>
                    HP {spectatedCombatant.hp} · ARMOR {spectatedCombatant.armor} ·{" "}
                    {(WEAPONS_BY_ID[spectatedCombatant.weaponId]?.name || spectatedCombatant.weaponId).toUpperCase()}
                  </small>
                </>
              ) : (
                <strong>Awaiting round resolution…</strong>
              )}
              <span className="gw-fps-spec-hint">
                [← / →] Switch Living Combatant ({livingPoolCount} Alive) · Mouse Move Camera
              </span>
            </div>

            <button
              type="button"
              className="gw-btn"
              disabled={livingPoolCount <= 1}
              onClick={() => cycleSpectateTarget(1)}
            >
              [→] Next ▶
            </button>
          </div>
        </>
      )}

      {/* Living Player Bottom-Left & Bottom-Right HUD */}
      {!isSpectating && !isRoundEnd && !isMatchEnd && (
        <>
          <div className="gw-fps-hud-bl">
            <div className="gw-fps-bl-head">
              <small>
                {myTeam === "vanguard" ? "TEAM ALPHA" : "TEAM BRAVO"} ·{" "}
                {me?.alive
                  ? snapshot?.phase === "BUY_FREEZE"
                    ? `DEPLOYING ${snapshot.phaseTimer.toFixed(1)}s`
                    : snapshot?.isPistolRound
                      ? "PISTOL ROUND"
                      : "OPERATIONAL"
                  : snapshot?.mode === "TDM"
                    ? `RESPAWN ${me?.respawnTimer ?? 0}s`
                    : "ELIMINATED"}
              </small>
              <span className="gw-fps-money-badge">${me?.money ?? 800}</span>
            </div>
            <div className="gw-fps-hp-row">
              <strong>{me?.hp ?? 100}</strong>
              <div className="gw-fps-bars-col">
                <div className="gw-fps-hp-bar">
                  <i
                    style={{
                      width: `${Math.max(0, ((me?.hp ?? 100) / (me?.maxHp ?? 100)) * 100)}%`,
                      background: (me?.hp ?? 100) > 35 ? "#67d47c" : "#e35a45",
                    }}
                  />
                </div>
                <div className="gw-fps-armor-row">
                  <span>ARMOR {me?.armor ?? 50}</span>
                  <div className="gw-fps-armor-bar">
                    <i style={{ width: `${Math.max(0, ((me?.armor ?? 50) / 50) * 100)}%` }} />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="gw-fps-hud-br">
            <div className="gw-fps-ammo-readout">
              <div>
                <small>
                  {activeSpec.category} · {WEAPON_SKINS_BY_ID[cosmetics.equippedSkins[activeSpec.id]]?.name}
                </small>
                <strong>{activeSpec.id === "knife" ? inspectedKnife.name : activeSpec.name}</strong>
              </div>
              <div className="gw-fps-ammo-nums">
                {activeSpec.id === "knife" ? (
                  <span className="reloading-txt">MELEE</span>
                ) : reloading ? (
                  <span className="reloading-txt">RELOADING…</span>
                ) : (
                  <>
                    <b>{curAmmo.mag}</b>
                    <small>/ {curAmmo.reserve}</small>
                  </>
                )}
              </div>
            </div>
            <div className="gw-fps-weapon-strip">
              {(me?.ownedWeapons || ["starter_pistol", "knife"]).map((wid) => {
                const w = WEAPONS_BY_ID[wid];
                if (!w) return null;
                return (
                  <button
                    key={w.id}
                    type="button"
                    className={activeWeapon === w.id ? "active" : ""}
                    onClick={() => switchWeapon(w.id)}
                  >
                    [{w.slot}] {w.id === "starter_pistol" ? "P9" : w.id.toUpperCase()}
                  </button>
                );
              })}
            </div>
          </div>

          {!pointerLocked && !loadoutOpen && !pauseMenuOpen && (
            <div className="gw-fps-lock-prompt">
              Click viewport to lock aim · WASD Move · [1/2/3] Weapons &amp; Knife · [B] Buy Menu · [P] Pause
            </div>
          )}
        </>
      )}

      {/* Tactical Buy Menu & Economy Armory ([B]) */}
      {loadoutOpen && !isSpectating && !isRoundEnd && !isMatchEnd && (
        <div className="gw-fps-scoreboard gw-fps-buy-menu" role="dialog" aria-label="Tactical Buy Menu">
          <div className="gw-fps-panel-top" style={{ marginBottom: 10 }}>
            <div>
              <h4 style={{ margin: 0 }}>TACTICAL BUY MENU [B]</h4>
              <small style={{ color: "#9fb2c8", fontFamily: "JetBrains Mono", fontSize: 11 }}>
                Available Funds: <b style={{ color: "#67d47c" }}>${me?.money ?? 800}</b> · Starter Issue: P9 Service Pistol &amp; Knife
              </small>
            </div>
            <button type="button" className="gw-btn gw-btn-primary" onClick={() => setLoadoutOpen(false)}>
              Resume Match [B]
            </button>
          </div>

          {snapshot?.isPistolRound && (
            <div className="gw-fps-pistol-banner">
              ROUND 1 — PISTOL ROUND: Primary weapons (SMGs, Shotguns, Rifles, Snipers) are locked until Round 2.
            </div>
          )}

          {shopNotice && (
            <div className={`gw-fps-shop-notice ${shopNotice.isError ? "error" : "ok"}`}>
              {shopNotice.text}
            </div>
          )}

          <div className="gw-fps-buy-armor-bar">
            <div>
              <b>Kevlar Vest Refill</b>
              <span>Current Armor: {me?.armor ?? 50} / 50</span>
            </div>
            <button
              type="button"
              className="gw-btn"
              disabled={(me?.armor ?? 50) >= 50 || (me?.money ?? 0) < ARMOR_REFILL_PRICE}
              onClick={() => sendAction({ type: "shop:buy_armor" })}
            >
              {(me?.armor ?? 50) >= 50 ? "ARMOR FULL" : `Refill Armor ($${ARMOR_REFILL_PRICE})`}
            </button>
          </div>

          <div className="gw-fps-buy-grid">
            {BUYABLE_WEAPON_LIST.map((w) => {
              const ownedList = me?.ownedWeapons || ["starter_pistol", "knife"];
              const isOwned = ownedList.includes(w.id);
              const isEquipped = activeWeapon === w.id;
              const lockedPistolRd = Boolean(snapshot?.isPistolRound && !w.allowedInPistolRound);
              const myMoney = me?.money ?? 0;
              const canAfford = myMoney >= w.price;

              return (
                <button
                  key={w.id}
                  type="button"
                  disabled={!isOwned && (lockedPistolRd || !canAfford)}
                  className={`gw-fps-armory-card gw-fps-buy-card ${isEquipped ? "active" : ""} ${
                    isOwned ? "is-owned" : ""
                  } ${lockedPistolRd ? "is-locked" : ""}`}
                  onClick={() => {
                    if (isOwned) {
                      switchWeapon(w.id);
                      setLoadoutOpen(false);
                    } else {
                      sendAction({ type: "shop:buy", weaponId: w.id });
                    }
                  }}
                >
                  <div className="buy-card-head">
                    <small>
                      SLOT [{w.slot}] · {w.collectionCategory.toUpperCase()}
                    </small>
                    <strong className="buy-price">
                      {isEquipped
                        ? "EQUIPPED"
                        : isOwned
                          ? "OWNED"
                          : lockedPistolRd
                            ? "LOCKED RD 1"
                            : `$${w.price}`}
                    </strong>
                  </div>
                  <div className="buy-card-title">
                    <WeaponKillIcon id={w.id} />
                    <strong>{w.name}</strong>
                  </div>
                  <span>
                    {w.damage}
                    {w.pellets > 1 ? `×${w.pellets}` : ""} DMG · Pen {Math.round(w.penetrationPower * 100)}% ·{" "}
                    {WEAPON_SKINS_BY_ID[cosmetics.equippedSkins[w.id]]?.name}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* In-Match Pause & Live Settings Menu ([P]) */}
      {pauseMenuOpen && (
        <div className="gw-fps-scoreboard">
          <div className="gw-fps-panel-top" style={{ marginBottom: 12 }}>
            <h4 style={{ margin: 0 }}>MATCH PAUSED — LIVE SETTINGS</h4>
            <button type="button" className="gw-btn gw-btn-primary" onClick={() => setPauseMenuOpen(false)}>
              Resume Match
            </button>
          </div>
          <div className="gw-fps-two-cols">
            <label className="gw-fps-field">
              <span>Mouse Sensitivity: {settings.mouseSensitivity.toFixed(2)}×</span>
              <input
                type="range"
                min={25}
                max={300}
                value={Math.round(settings.mouseSensitivity * 100)}
                onChange={(e) =>
                  updateWorkshopSettings({ mouseSensitivity: Number(e.target.value) / 100 })
                }
              />
            </label>
            <label className="gw-fps-field">
              <span>Field of View: {settings.fov}°</span>
              <input
                type="range"
                min={64}
                max={100}
                value={settings.fov}
                onChange={(e) => updateWorkshopSettings({ fov: Number(e.target.value) })}
              />
            </label>
          </div>
          <div className="gw-fps-two-cols">
            <label className="gw-fps-field">
              <span>Music Volume: {Math.round(settings.musicVolume * 100)}%</span>
              <input
                type="range"
                min={0}
                max={100}
                value={Math.round(settings.musicVolume * 100)}
                onChange={(e) => updateWorkshopSettings({ musicVolume: Number(e.target.value) / 100 })}
              />
            </label>
            <label className="gw-fps-field">
              <span>SFX Volume: {Math.round(settings.sfxVolume * 100)}%</span>
              <input
                type="range"
                min={0}
                max={100}
                value={Math.round(settings.sfxVolume * 100)}
                onChange={(e) => updateWorkshopSettings({ sfxVolume: Number(e.target.value) / 100 })}
              />
            </label>
          </div>
          <label className="gw-fps-field" style={{ marginTop: 6 }}>
            <span>Killfeed Duration: {killFeedDurationSec.toFixed(1)}s</span>
            <input
              type="range"
              min={30}
              max={100}
              step={5}
              value={Math.round(killFeedDurationSec * 10)}
              onChange={(e) => setKillFeedDurationSec(Number(e.target.value) / 10)}
            />
          </label>
          <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
            <button
              type="button"
              className="gw-btn"
              onClick={() => updateWorkshopSettings({ muted: !settings.muted })}
            >
              {settings.muted ? "Unmute Audio" : "Mute All"}
            </button>
            <button type="button" className="gw-btn danger" onClick={handleLeaveRoom}>
              Return to Match Menu
            </button>
          </div>
        </div>
      )}

      {/* Round-End Result Screen (waits for user Continue or Return to Menu) */}
      {isRoundEnd && snapshot && !pauseMenuOpen && (
        <div className="gw-fps-round-end" role="dialog" aria-label="Round Result">
          <small className="re-kicker">
            ROUND {snapshot.round} / {snapshot.maxRounds} COMPLETE
          </small>
          <h3 className={snapshot.roundWinnerTeam === "syndicate" ? "sy-txt" : "vg-txt"}>
            {snapshot.roundWinnerTeam === "syndicate" ? "TEAM BRAVO WINS ROUND" : "TEAM ALPHA WINS ROUND"}
          </h3>
          <p className="re-reason">{snapshot.winReason || "Round concluded"}</p>

          <div className="re-score-strip">
            <div className="re-score-box alpha">
              <span>TEAM ALPHA</span>
              <strong>{snapshot.vanguardRounds}</strong>
              <small>
                {alphaAlive.length}/{alphaPlayers.length} Surviving
              </small>
            </div>
            <div className="re-score-box bravo">
              <span>TEAM BRAVO</span>
              <strong>{snapshot.syndicateRounds}</strong>
              <small>
                {bravoAlive.length}/{bravoPlayers.length} Surviving
              </small>
            </div>
          </div>

          {(alphaAlive.length > 0 || bravoAlive.length > 0) && (
            <div className="re-survivors">
              <span>REMAINING COMBATANTS:</span>
              <b>
                {[...alphaAlive, ...bravoAlive].map((p) => `${p.name} (${p.hp} HP)`).join(" · ")}
              </b>
            </div>
          )}

          <div className="re-actions">
            {isRoomHost ? (
              <button
                type="button"
                className="brass-button"
                onClick={() => sendAction({ type: "next_round" })}
              >
                Continue to Next Round →
              </button>
            ) : (
              <span className="re-wait-note">Waiting for match host to start next round…</span>
            )}
            <button type="button" className="gw-btn" onClick={handleLeaveRoom}>
              Return to Match Menu
            </button>
          </div>
        </div>
      )}

      {/* Scoreboard Overlay ([Tab]) or Match End Summary */}
      {(scoreboardOpen || isMatchEnd) && snapshot && (
        <div className="gw-fps-scoreboard">
          <div className="gw-fps-panel-top" style={{ marginBottom: 10 }}>
            <div>
              <h4 style={{ margin: 0 }}>
                {isMatchEnd
                  ? `MATCH COMPLETE · ${
                      snapshot.winnerTeam === "syndicate"
                        ? "TEAM BRAVO VICTORY"
                        : snapshot.winnerTeam === "vanguard"
                          ? "TEAM ALPHA VICTORY"
                          : "DRAW"
                    }`
                  : `${getFpsMapDef(activeMapId).name} · ${roomTitle} [${roomCode}]`}
              </h4>
              {isMatchEnd && (
                <small style={{ color: "#b7aa95", fontFamily: "JetBrains Mono", fontSize: 11 }}>
                  {snapshot.winReason || ""} · Remaining: Alpha {alphaAlive.length}/{alphaPlayers.length} · Bravo{" "}
                  {bravoAlive.length}/{bravoPlayers.length}
                </small>
              )}
            </div>
            {isMatchEnd && (
              <div style={{ display: "flex", gap: 8 }}>
                {isRoomHost && (
                  <button
                    type="button"
                    className="gw-btn gw-btn-primary"
                    onClick={() => sendAction({ type: "restart_mission" })}
                  >
                    Play Next Match →
                  </button>
                )}
                <button type="button" className="gw-btn" onClick={handleLeaveRoom}>
                  Return to Match Menu
                </button>
              </div>
            )}
          </div>
          <div className="gw-fps-score-scroll">
            <table className="gw-fps-score-table">
              <thead>
                <tr>
                  <th>Operative</th>
                  <th>Team</th>
                  <th>Status</th>
                  <th>Kills</th>
                  <th>Deaths</th>
                  <th>Assists</th>
                  <th>Damage</th>
                  <th>Score</th>
                </tr>
              </thead>
              <tbody>
                {[...snapshot.players]
                  .sort((a, b) => b.score - a.score)
                  .map((p) => (
                    <tr key={p.id}>
                      <td>
                        {p.name}
                        {p.id === localPlayerId ? " (You)" : ""}
                      </td>
                      <td style={{ color: p.team === "vanguard" ? "#f2a93b" : "#4ea8ff" }}>
                        {p.team === "vanguard" ? "ALPHA" : "BRAVO"}
                      </td>
                      <td>{p.alive ? `${p.hp} HP` : "DEAD"}</td>
                      <td>{p.kills}</td>
                      <td>{p.deaths}</td>
                      <td>{p.assists}</td>
                      <td>{p.damageDealt}</td>
                      <td>{p.score}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
